import type { ReactNode } from "react";
import {
  ArrowLeft,
  Wifi,
  BatteryFull,
  Signal,
  Home,
  Calendar,
  Baby,
  Bot,
  User,
  Heart,
} from "lucide-react";
import { cn } from "../utils/cn";
import { fa, type Screen } from "../lib/nav";

/* ---------- Logo ---------- */
export function NivaLogo({ className, color = "white" }: { className?: string; color?: string }) {
  return (
    <svg viewBox="0 0 120 120" className={className} fill="none">
      <path
        d="M46 22c8-6 20-4 25 6 3 7 1 14-4 19 10 3 16 12 16 23 0 16-15 28-32 28-14 0-25-8-29-19"
        stroke={color}
        strokeWidth="6"
        strokeLinecap="round"
      />
      <circle cx="58" cy="34" r="12" stroke={color} strokeWidth="6" />
      <path
        d="M74 78c0-6 5-10 10-10s9 4 9 9c0 8-19 19-19 19S55 85 55 77c0-5 4-9 9-9s10 4 10 10z"
        fill={color}
      />
    </svg>
  );
}

/* ---------- Status bar ---------- */
export function StatusBar({ dark = false }: { dark?: boolean }) {
  return (
    <div
      className={cn(
        "flex items-center justify-between px-5 pt-3 pb-1 text-[11px] font-semibold fa-num",
        dark ? "text-white" : "text-niva-900",
      )}
    >
      <div className="flex items-center gap-1">
        <BatteryFull className="w-4 h-4" />
        <Wifi className="w-3.5 h-3.5" />
        <Signal className="w-3.5 h-3.5" />
      </div>
      <span>{fa("9:41")}</span>
    </div>
  );
}

/* ---------- Header ---------- */
export function Header({
  title,
  onBack,
  dark = true,
  right,
}: {
  title: string;
  onBack?: () => void;
  dark?: boolean;
  right?: ReactNode;
}) {
  return (
    <div
      className={cn(
        "flex items-center justify-between px-4 py-3",
        dark ? "text-white" : "text-niva-900",
      )}
    >
      <div className="w-9 flex items-center">{right}</div>
      <h1 className="text-base font-bold">{title}</h1>
      <button
        onClick={onBack}
        aria-label="بازگشت"
        className={cn(
          "w-9 h-9 rounded-full flex items-center justify-center transition",
          dark ? "hover:bg-white/15" : "hover:bg-niva-100",
        )}
      >
        <ArrowLeft className="w-5 h-5" />
      </button>
    </div>
  );
}

/* ---------- Page shells ---------- */
export function BluePage({
  title,
  onBack,
  children,
  right,
  headerExtra,
  bottom,
}: {
  title: string;
  onBack?: () => void;
  children: ReactNode;
  right?: ReactNode;
  headerExtra?: ReactNode;
  bottom?: ReactNode;
}) {
  return (
    <div className="flex flex-col h-full niva-gradient">
      <StatusBar dark />
      <Header title={title} onBack={onBack} right={right} />
      {headerExtra}
      <div className="flex-1 min-h-0 bg-[#f3f8ff] rounded-t-[28px] overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto thin-scroll px-4 pt-4 pb-6 animate-fade-up">{children}</div>
        {bottom}
      </div>
    </div>
  );
}

/* ---------- Bottom nav ---------- */
const NAV: { id: Screen; label: string; icon: typeof Home }[] = [
  { id: "home", label: "خانه", icon: Home },
  { id: "cycle", label: "چرخه", icon: Calendar },
  { id: "pregnancy", label: "بارداری", icon: Heart },
  { id: "child", label: "کودک", icon: Baby },
  { id: "ai-chat", label: "دستیار", icon: Bot },
  { id: "profile", label: "پروفایل", icon: User },
];

export function BottomNav({ active, go }: { active: Screen; go: (s: Screen) => void }) {
  return (
    <nav className="glass border-t border-niva-100 px-2 py-2 flex items-center justify-around shrink-0">
      {NAV.map(({ id, label, icon: Icon }) => {
        const on = active === id;
        return (
          <button
            key={id}
            onClick={() => go(id)}
            className={cn(
              "flex flex-col items-center gap-0.5 px-2 py-1 rounded-xl text-[10px] transition",
              on ? "text-niva-600 font-bold" : "text-slate-400 hover:text-niva-500",
            )}
          >
            <span className={cn("p-1.5 rounded-xl transition", on && "bg-niva-100")}>
              <Icon className="w-5 h-5" />
            </span>
            {label}
          </button>
        );
      })}
    </nav>
  );
}

/* ---------- Primitives ---------- */
export function Button({
  children,
  variant = "primary",
  className,
  onClick,
  full = true,
  size = "md",
}: {
  children: ReactNode;
  variant?: "primary" | "soft" | "outline" | "danger" | "ghost" | "white";
  className?: string;
  onClick?: () => void;
  full?: boolean;
  size?: "sm" | "md";
}) {
  const styles = {
    primary: "bg-niva-600 text-white shadow-lg shadow-niva-500/30 hover:bg-niva-700",
    soft: "bg-niva-100 text-niva-700 hover:bg-niva-200",
    outline: "border border-white/70 text-white hover:bg-white/10",
    danger: "bg-rose-50 text-rose-500 hover:bg-rose-100",
    ghost: "text-niva-600 hover:bg-niva-50",
    white: "bg-white text-niva-700 shadow-md hover:bg-niva-50",
  }[variant];
  return (
    <button
      onClick={onClick}
      className={cn(
        "rounded-2xl font-bold transition active:scale-[0.98]",
        size === "md" ? "py-3 text-sm" : "py-2 px-4 text-xs",
        full && "w-full",
        styles,
        className,
      )}
    >
      {children}
    </button>
  );
}

export function Card({ children, className, onClick }: { children: ReactNode; className?: string; onClick?: () => void }) {
  return (
    <div
      onClick={onClick}
      className={cn(
        "bg-white rounded-2xl shadow-[0_6px_24px_-10px_rgba(47,127,242,0.25)] border border-niva-50",
        onClick && "cursor-pointer hover:shadow-[0_10px_28px_-10px_rgba(47,127,242,0.35)] transition",
        className,
      )}
    >
      {children}
    </div>
  );
}

export function Toggle({ on, onChange }: { on: boolean; onChange: (v: boolean) => void }) {
  return (
    <button
      onClick={() => onChange(!on)}
      role="switch"
      aria-checked={on}
      className={cn(
        "w-11 h-6 rounded-full relative transition",
        on ? "bg-niva-500" : "bg-slate-200",
      )}
    >
      <span
        className={cn(
          "absolute top-0.5 w-5 h-5 bg-white rounded-full shadow transition-all",
          on ? "left-0.5" : "left-[22px]",
        )}
      />
    </button>
  );
}

export function Input({
  label,
  placeholder,
  type = "text",
  icon,
}: {
  label?: string;
  placeholder?: string;
  type?: string;
  icon?: ReactNode;
}) {
  return (
    <label className="block">
      {label && <span className="block text-xs text-slate-500 mb-1.5">{label}</span>}
      <div className="flex items-center gap-2 bg-white border border-niva-100 rounded-2xl px-3.5 py-3 focus-within:border-niva-400 focus-within:ring-2 focus-within:ring-niva-100 transition">
        <input
          type={type}
          placeholder={placeholder}
          className="flex-1 bg-transparent outline-none text-sm text-niva-900 placeholder:text-slate-300"
        />
        {icon && <span className="text-niva-300">{icon}</span>}
      </div>
    </label>
  );
}

export function Badge({ children, tone = "mint" }: { children: ReactNode; tone?: "mint" | "amber" | "rose" | "blue" }) {
  const t = {
    mint: "bg-emerald-50 text-emerald-600",
    amber: "bg-amber-50 text-amber-600",
    rose: "bg-rose-50 text-rose-500",
    blue: "bg-niva-50 text-niva-600",
  }[tone];
  return <span className={cn("text-[11px] font-bold px-2.5 py-1 rounded-full", t)}>{children}</span>;
}

export function Avatar({ src, size = 48, ring = true }: { src: string; size?: number; ring?: boolean }) {
  return (
    <img
      src={src}
      alt=""
      width={size}
      height={size}
      style={{ width: size, height: size }}
      className={cn("rounded-full object-cover bg-niva-100", ring && "ring-2 ring-white shadow")}
    />
  );
}

export function SectionTitle({ children, action }: { children: ReactNode; action?: ReactNode }) {
  return (
    <div className="flex items-center justify-between mb-3">
      <h2 className="text-sm font-bold text-niva-900">{children}</h2>
      {action}
    </div>
  );
}

/* Simple avatar generator (SVG data URI) */
export const avatarUrl = (seed: string, bg = "bfd9fd") =>
  `https://api.dicebear.com/9.x/avataaars/svg?seed=${encodeURIComponent(seed)}&backgroundColor=${bg}&radius=50`;
