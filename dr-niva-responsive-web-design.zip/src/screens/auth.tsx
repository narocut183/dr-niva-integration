import { useState } from "react";
import { Baby, Bot, Calendar, Camera, Check, Heart, Phone, LogIn, User } from "lucide-react";
import { Button, Input, NivaLogo, StatusBar, Header } from "../components/ui";
import type { Screen } from "../lib/nav";
import { cn } from "../utils/cn";

type P = { go: (s: Screen) => void };

/* ---------------- Splash ---------------- */
export function SplashScreen({ go }: P) {
  return (
    <div className="h-full niva-gradient flex flex-col text-white relative overflow-hidden">
      <div className="absolute -top-20 -left-20 w-64 h-64 rounded-full bg-white/10" />
      <div className="absolute top-40 -right-24 w-72 h-72 rounded-full bg-white/10" />
      <StatusBar dark />
      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center relative">
        <div className="w-32 h-32 rounded-[36px] bg-white/15 border border-white/30 flex items-center justify-center backdrop-blur-sm animate-float">
          <NivaLogo className="w-24 h-24" />
        </div>
        <h1 className="text-3xl font-black mt-8">دکتر نیوا</h1>
        <p className="text-white/85 text-sm mt-2">همراه هوشمند بانوان</p>
        <p className="text-white/70 text-xs mt-10">سلامتِ امروز، آرامشِ فردا</p>
      </div>
      <div className="px-8 pb-10 relative">
        <Button variant="outline" onClick={() => go("onboarding")}>
          شروع کنید
        </Button>
        <div className="flex justify-center gap-1.5 mt-6">
          <span className="w-5 h-1.5 rounded-full bg-white" />
          <span className="w-1.5 h-1.5 rounded-full bg-white/40" />
          <span className="w-1.5 h-1.5 rounded-full bg-white/40" />
          <span className="w-1.5 h-1.5 rounded-full bg-white/40" />
        </div>
      </div>
    </div>
  );
}

/* ---------------- Onboarding ---------------- */
export function OnboardingScreen({ go }: P) {
  const feats = [
    { icon: Heart, label: "بارداری" },
    { icon: Baby, label: "کودک" },
    { icon: Bot, label: "مشاوره هوشمند" },
    { icon: Calendar, label: "چرخه" },
  ];
  return (
    <div className="h-full soft-gradient flex flex-col">
      <StatusBar />
      <div className="flex-1 flex flex-col items-center px-6 pt-4 text-center overflow-y-auto no-scrollbar">
        <div className="relative w-full max-w-[280px] aspect-square">
          <div className="absolute inset-4 rounded-full bg-niva-100/70 blur-xl" />
          <img
            src="/images/onboarding.png"
            alt=""
            className="relative w-full h-full object-contain animate-float"
          />
        </div>
        <h1 className="text-2xl font-black text-niva-800 mt-2">دکتر نیوا</h1>
        <p className="text-slate-500 text-sm mt-1.5">همراه شما در تمام مراحل</p>
        <div className="grid grid-cols-2 gap-x-6 gap-y-3 mt-6 w-full max-w-xs">
          {feats.map(({ icon: Icon, label }) => (
            <div key={label} className="flex items-center gap-2 text-sm text-niva-800">
              <span className="w-8 h-8 rounded-xl bg-white shadow flex items-center justify-center text-niva-500">
                <Icon className="w-4 h-4" />
              </span>
              {label}
            </div>
          ))}
        </div>
      </div>
      <div className="px-6 pb-8 pt-4 space-y-3">
        <Button onClick={() => go("login")}>ورود به برنامه</Button>
        <Button variant="ghost" onClick={() => go("complete-profile")}>
          ثبت نام
        </Button>
      </div>
    </div>
  );
}

/* ---------------- Login ---------------- */
export function LoginScreen({ go }: P) {
  return (
    <div className="h-full soft-gradient flex flex-col">
      <StatusBar />
      <div className="flex-1 overflow-y-auto no-scrollbar px-6 pt-6 flex flex-col items-center">
        <div className="w-20 h-20 rounded-3xl niva-gradient shadow-xl shadow-niva-500/30 flex items-center justify-center">
          <NivaLogo className="w-14 h-14" />
        </div>
        <h1 className="text-2xl font-black text-niva-800 mt-4">دکتر نیوا</h1>
        <p className="text-slate-500 text-xs mt-1">همراه هوشمند بانوان</p>

        <div className="w-full mt-8 space-y-4">
          <Input placeholder="شماره موبایل" type="tel" icon={<Phone className="w-4 h-4" />} />
          <Button onClick={() => go("home")}>
            <span className="inline-flex items-center gap-2">
              <LogIn className="w-4 h-4" /> ورود
            </span>
          </Button>
          <div className="flex items-center gap-3 text-xs text-slate-400">
            <span className="flex-1 h-px bg-niva-100" />
            یا
            <span className="flex-1 h-px bg-niva-100" />
          </div>
          <button
            onClick={() => go("home")}
            className="w-full bg-white border border-niva-100 rounded-2xl py-3 text-sm font-semibold text-niva-900 flex items-center justify-center gap-3 hover:bg-niva-50 transition"
          >
            <GoogleIcon /> ورود با حساب کاربری گوگل
          </button>
          <p className="text-[11px] text-slate-400 text-center leading-6">
            ورود شما به معنای پذیرش <span className="text-niva-600">قوانین و مقررات</span> است.
          </p>
        </div>
      </div>
      <div className="px-6 pb-8 text-center text-xs text-slate-500">
        حساب کاربری ندارید؟{" "}
        <button onClick={() => go("complete-profile")} className="text-niva-600 font-bold">
          ثبت نام کنید
        </button>
      </div>
    </div>
  );
}

function GoogleIcon() {
  return (
    <svg viewBox="0 0 24 24" className="w-5 h-5">
      <path fill="#EA4335" d="M12 10.2v3.9h5.4c-.2 1.3-1.6 3.8-5.4 3.8-3.3 0-5.9-2.7-5.9-6s2.6-6 5.9-6c1.9 0 3.1.8 3.8 1.5l2.6-2.5C16.8 3.3 14.6 2.4 12 2.4 6.7 2.4 2.4 6.7 2.4 12S6.7 21.6 12 21.6c5.5 0 9.2-3.9 9.2-9.4 0-.6-.1-1.1-.2-1.6H12z" />
      <path fill="#4285F4" d="M21.2 12.2c0-.6-.1-1.1-.2-1.6H12v3.9h5.4c-.3 1.4-1.1 2.4-2.2 3.1l3.4 2.6c2-1.9 3.1-4.7 3.1-8z" opacity=".9" />
      <path fill="#34A853" d="M12 21.6c2.6 0 4.8-.9 6.4-2.4l-3.4-2.6c-.9.6-2 1-3 1-3 0-5.3-1.9-6.1-4.6l-3.5 2.7c1.6 3.5 5.2 5.9 9.6 5.9z" opacity=".95" />
      <path fill="#FBBC05" d="M5.9 13c-.2-.6-.4-1.3-.4-2s.1-1.4.4-2L2.4 6.3C1.7 7.8 1.3 9.4 1.3 11s.4 3.2 1.1 4.7L5.9 13z" opacity=".95" />
    </svg>
  );
}

/* ---------------- Complete profile ---------------- */
export function CompleteProfileScreen({ go }: P) {
  const [gender, setGender] = useState<"f" | "m">("f");
  return (
    <div className="h-full soft-gradient flex flex-col">
      <StatusBar />
      <Header title="تکمیل پروفایل" dark={false} onBack={() => go("login")} />
      <div className="px-10 flex items-center gap-2 mb-4">
        {[1, 2, 3].map((s, i) => (
          <div key={s} className="flex items-center flex-1 last:flex-none">
            <span
              className={cn(
                "w-3 h-3 rounded-full ring-4",
                i === 0 ? "bg-niva-500 ring-niva-100" : "bg-niva-200 ring-transparent",
              )}
            />
            {i < 2 && <span className="flex-1 h-0.5 bg-niva-200 mx-1" />}
          </div>
        ))}
      </div>
      <div className="flex-1 overflow-y-auto no-scrollbar px-6 flex flex-col items-center">
        <div className="relative">
          <div className="w-24 h-24 rounded-full bg-niva-100 flex items-center justify-center text-niva-400">
            <User className="w-12 h-12" />
          </div>
          <span className="absolute -bottom-1 -left-1 w-8 h-8 rounded-full bg-niva-600 text-white flex items-center justify-center shadow">
            <Camera className="w-4 h-4" />
          </span>
        </div>
        <p className="text-xs text-slate-500 mt-2 mb-6">عکس پروفایل</p>
        <div className="w-full space-y-3">
          <Input placeholder="نام و نام خانوادگی" />
          <Input placeholder="تاریخ تولد" icon={<Calendar className="w-4 h-4" />} />
          <div>
            <span className="block text-xs text-slate-500 mb-1.5">جنسیت</span>
            <div className="grid grid-cols-2 gap-3">
              {(
                [
                  ["f", "زن"],
                  ["m", "مرد"],
                ] as const
              ).map(([v, l]) => (
                <button
                  key={v}
                  onClick={() => setGender(v)}
                  className={cn(
                    "rounded-2xl py-3 text-sm font-semibold border flex items-center justify-center gap-2 transition",
                    gender === v
                      ? "bg-niva-50 border-niva-400 text-niva-700"
                      : "bg-white border-niva-100 text-slate-500",
                  )}
                >
                  {gender === v && <Check className="w-4 h-4" />}
                  {l}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>
      <div className="px-6 pb-8 pt-4">
        <Button onClick={() => go("home")}>مرحله بعد</Button>
      </div>
    </div>
  );
}

/* ---------------- Logout done ---------------- */
export function LogoutScreen({ go }: P) {
  return (
    <div className="h-full niva-gradient flex flex-col">
      <StatusBar dark />
      <Header title="ورود/خروج" onBack={() => go("settings")} />
      <div className="flex-1 bg-[#f3f8ff] rounded-t-[28px] flex flex-col items-center justify-center px-8 text-center relative overflow-hidden">
        <div className="absolute bottom-0 inset-x-0 h-40 bg-gradient-to-t from-niva-100/70 to-transparent" />
        <div className="w-24 h-24 rounded-full bg-emerald-50 flex items-center justify-center text-emerald-500 ring-8 ring-emerald-50/60 animate-fade-up">
          <Check className="w-12 h-12" strokeWidth={3} />
        </div>
        <h2 className="text-xl font-black text-niva-900 mt-6">با موفقیت خارج شدید</h2>
        <p className="text-sm text-slate-500 mt-2">امیدواریم دوباره ببینیمتون</p>
        <div className="w-full mt-10 relative">
          <Button onClick={() => go("login")}>بازگشت به ورود</Button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Final branding ---------------- */
export function FinalScreen({ go }: P) {
  return (
    <div className="h-full niva-gradient flex flex-col text-white relative overflow-hidden">
      <StatusBar dark />
      <div className="flex-1 flex flex-col items-center justify-center px-8 text-center">
        <div className="w-56 h-56 rounded-full overflow-hidden ring-8 ring-white/20 shadow-2xl animate-float">
          <img src="/images/mother-baby.png" alt="" className="w-full h-full object-cover" />
        </div>
        <h2 className="text-2xl font-black mt-8">سلامت تو</h2>
        <p className="text-lg mt-1 text-white/90">آرامش خانواده است</p>
        <Heart className="w-7 h-7 mt-6 fill-white/90" />
      </div>
      <div className="px-8 pb-10">
        <Button variant="white" onClick={() => go("splash")}>
          شروع دوباره
        </Button>
      </div>
    </div>
  );
}
