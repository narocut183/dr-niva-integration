import { useEffect, useState } from "react";
import { Inbox, Frown, Check, HelpCircle, Clock, Calendar, Repeat } from "lucide-react";
import { BluePage, Button, Input, StatusBar } from "../components/ui";
import type { Screen } from "../lib/nav";
import { cn } from "../utils/cn";

type P = { go: (s: Screen) => void };

function Center({ children }: { children: React.ReactNode }) {
  return <div className="h-full flex flex-col items-center justify-center text-center px-6 py-10">{children}</div>;
}

/* ---------------- Empty ---------------- */
export function EmptyScreen({ go }: P) {
  return (
    <BluePage title="صفحه خالی" onBack={() => go("home")}>
      <Center>
        <div className="w-24 h-24 rounded-3xl bg-niva-50 flex items-center justify-center text-niva-300">
          <Inbox className="w-12 h-12" strokeWidth={1.5} />
        </div>
        <p className="font-black text-niva-900 mt-5">هنوز داده‌ای وجود ندارد</p>
        <p className="text-xs text-slate-400 mt-2 leading-6">
          اولین مورد خود را ثبت کنید تا اطلاعات شما اینجا نمایش داده شود.
        </p>
        <Button className="mt-8 max-w-xs" onClick={() => go("add-form")}>
          افزودن اولین مورد
        </Button>
      </Center>
    </BluePage>
  );
}

/* ---------------- Error ---------------- */
export function ErrorScreen({ go }: P) {
  return (
    <BluePage title="خطا" onBack={() => go("home")}>
      <Center>
        <div className="w-24 h-24 rounded-full bg-rose-50 flex items-center justify-center text-rose-400 ring-8 ring-rose-50/60">
          <Frown className="w-12 h-12" strokeWidth={1.5} />
        </div>
        <p className="font-black text-rose-500 mt-5">خطایی رخ داده است</p>
        <p className="text-xs text-slate-400 mt-2">لطفاً دوباره تلاش کنید</p>
        <Button className="mt-8 max-w-xs" onClick={() => go("loading")}>
          تلاش مجدد
        </Button>
      </Center>
    </BluePage>
  );
}

/* ---------------- Loading ---------------- */
export function LoadingScreen({ go }: P) {
  useEffect(() => {
    const t = setTimeout(() => go("success"), 2200);
    return () => clearTimeout(t);
  }, [go]);
  return (
    <BluePage title="در حال بارگذاری" onBack={() => go("home")}>
      <Center>
        <div className="w-16 h-16 rounded-full border-4 border-niva-100 border-t-niva-500 border-dashed animate-spin-slow" />
        <p className="text-sm text-slate-500 mt-6">در حال بارگذاری...</p>
      </Center>
    </BluePage>
  );
}

/* ---------------- Success ---------------- */
export function SuccessScreen({ go }: P) {
  return (
    <div className="h-full niva-gradient flex flex-col">
      <StatusBar dark />
      <div className="flex-1 flex items-end sm:items-center justify-center p-4 bg-black/20">
        <div className="w-full bg-white rounded-3xl p-6 text-center shadow-2xl animate-fade-up">
          <div className="w-16 h-16 rounded-full bg-emerald-50 text-emerald-500 flex items-center justify-center mx-auto">
            <Check className="w-8 h-8" strokeWidth={3} />
          </div>
          <p className="font-black text-niva-900 mt-4">عملیات با موفقیت انجام شد</p>
          <p className="text-xs text-slate-400 mt-1">اطلاعات شما ذخیره شد</p>
          <Button className="mt-5" onClick={() => go("home")}>
            باشه
          </Button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Confirm ---------------- */
export function ConfirmScreen({ go }: P) {
  return (
    <div className="h-full niva-gradient flex flex-col">
      <StatusBar dark />
      <div className="flex-1 flex items-end sm:items-center justify-center p-4 bg-black/20">
        <div className="w-full bg-white rounded-3xl p-6 text-center shadow-2xl animate-fade-up">
          <div className="w-16 h-16 rounded-full bg-niva-50 text-niva-500 flex items-center justify-center mx-auto">
            <HelpCircle className="w-8 h-8" />
          </div>
          <p className="font-black text-niva-900 mt-4">آیا از حذف این مورد مطمئن هستید؟</p>
          <p className="text-xs text-slate-400 mt-1">این عمل قابل بازگشت نیست</p>
          <div className="grid grid-cols-2 gap-3 mt-5">
            <button
              onClick={() => go("success")}
              className="rounded-2xl py-3 text-sm font-bold bg-rose-500 text-white shadow-lg shadow-rose-500/30 hover:bg-rose-600 transition"
            >
              حذف
            </button>
            <Button variant="soft" onClick={() => go("settings")}>
              لغو
            </Button>
          </div>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Add form ---------------- */
export function AddFormScreen({ go }: P) {
  const [repeat, setRepeat] = useState<"daily" | "weekly" | "once">("daily");
  return (
    <BluePage title="فرم جدید" onBack={() => go("meds")}>
      <p className="font-bold text-niva-900 text-sm mb-4">ثبت یادآور جدید</p>
      <div className="space-y-3">
        <Input placeholder="نام یادآور را وارد کنید" />
        <Input placeholder="زمان" icon={<Clock className="w-4 h-4" />} />
        <Input placeholder="تاریخ شروع" icon={<Calendar className="w-4 h-4" />} />
        <div>
          <span className="block text-xs text-slate-500 mb-1.5 inline-flex items-center gap-1">
            <Repeat className="w-3.5 h-3.5" /> تکرار
          </span>
          <div className="grid grid-cols-3 gap-2">
            {(
              [
                ["daily", "روزانه"],
                ["weekly", "هفتگی"],
                ["once", "یک‌بار"],
              ] as const
            ).map(([k, l]) => (
              <button
                key={k}
                onClick={() => setRepeat(k)}
                className={cn(
                  "rounded-xl py-2.5 text-xs font-semibold border transition",
                  repeat === k ? "bg-niva-50 border-niva-400 text-niva-700" : "bg-white border-niva-100 text-slate-500",
                )}
              >
                {l}
              </button>
            ))}
          </div>
        </div>
        <label className="block">
          <span className="block text-xs text-slate-500 mb-1.5">توضیحات</span>
          <textarea
            rows={3}
            placeholder="یادداشت اختیاری..."
            className="w-full bg-white border border-niva-100 rounded-2xl px-3.5 py-3 text-sm outline-none focus:border-niva-400 focus:ring-2 focus:ring-niva-100 resize-none"
          />
        </label>
      </div>
      <Button className="mt-6" onClick={() => go("success")}>
        ذخیره
      </Button>
    </BluePage>
  );
}
