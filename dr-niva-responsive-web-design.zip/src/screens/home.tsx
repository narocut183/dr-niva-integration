import { useState } from "react";
import {
  Bell,
  Heart,
  Calendar,
  Baby,
  FlaskConical,
  Pill,
  Users,
  Bot,
  MoreHorizontal,
  Stethoscope,
  ChevronRight,
  ChevronLeft,
  Activity,
  ClipboardList,
  ShoppingBag,
  History,
  CheckCircle2,
  Clock,
} from "lucide-react";
import { Avatar, avatarUrl, BluePage, BottomNav, Button, Card, SectionTitle, StatusBar } from "../components/ui";
import { fa, type Screen } from "../lib/nav";
import { cn } from "../utils/cn";

type P = { go: (s: Screen) => void };

/* ---------------- Home ---------------- */
export function HomeScreen({ go }: P) {
  const tiles: { icon: typeof Heart; label: string; to: Screen; tone: string }[] = [
    { icon: Heart, label: "بارداری", to: "pregnancy", tone: "bg-rose-50 text-rose-500" },
    { icon: Calendar, label: "چرخه", to: "cycle", tone: "bg-pink-50 text-pink-500" },
    { icon: Baby, label: "کودک", to: "child", tone: "bg-sky-50 text-sky-500" },
    { icon: FlaskConical, label: "آزمایش‌ها", to: "tests", tone: "bg-indigo-50 text-indigo-500" },
    { icon: Pill, label: "داروها", to: "meds", tone: "bg-emerald-50 text-emerald-500" },
    { icon: Users, label: "همراهان", to: "family", tone: "bg-amber-50 text-amber-500" },
    { icon: Bot, label: "مشاوره", to: "ai-chat", tone: "bg-niva-50 text-niva-600" },
    { icon: Stethoscope, label: "سلامت روان", to: "mental", tone: "bg-violet-50 text-violet-500" },
    { icon: MoreHorizontal, label: "بیشتر", to: "settings", tone: "bg-slate-100 text-slate-500" },
  ];
  const reminders = [
    { t: "ویتامین D", time: "۱۰:۰۰", done: true },
    { t: "فولیک اسید", time: "۱۴:۰۰", done: false },
    { t: "پیاده‌روی سبک", time: "۱۸:۰۰", done: false },
  ];
  return (
    <div className="flex flex-col h-full niva-gradient">
      <StatusBar dark />
      <div className="flex items-center justify-between px-4 py-3 text-white">
        <button className="w-10 h-10 rounded-2xl bg-white/15 flex items-center justify-center relative hover:bg-white/25 transition">
          <Bell className="w-5 h-5" />
          <span className="absolute top-2 left-2.5 w-2 h-2 rounded-full bg-rose-400 ring-2 ring-niva-500" />
        </button>
        <div className="flex items-center gap-3">
          <div className="text-left">
            <p className="font-bold text-sm text-right">سلام نرگس جان 👋</p>
            <p className="text-[11px] text-white/80 text-right">امیدوارم حال خوبی داشته باشی</p>
          </div>
          <Avatar src={avatarUrl("Narges", "ffd5dc")} />
        </div>
      </div>

      <div className="flex-1 min-h-0 bg-[#f3f8ff] rounded-t-[28px] overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto thin-scroll px-4 pt-4 pb-4 animate-fade-up">
          {/* pregnancy card */}
          <Card
            onClick={() => go("pregnancy")}
            className="p-4 flex items-center gap-4 bg-gradient-to-l from-rose-50 to-white"
          >
            <div className="w-16 h-16 rounded-full bg-rose-100 flex items-center justify-center text-3xl shrink-0">
              👶
            </div>
            <div className="flex-1">
              <p className="font-black text-niva-900">هفته {fa(12)} بارداری</p>
              <p className="text-xs text-slate-500 mt-1">
                {fa(4)} روز <span className="text-rose-500 font-bold">{fa(84)}</span> روز گذشته
              </p>
              <div className="h-1.5 bg-rose-100 rounded-full mt-2 overflow-hidden">
                <div className="h-full w-[30%] bg-gradient-to-l from-rose-400 to-rose-300 rounded-full" />
              </div>
            </div>
            <ChevronLeft className="w-5 h-5 text-slate-300" />
          </Card>

          {/* tiles */}
          <div className="grid grid-cols-3 gap-3 mt-4">
            {tiles.map(({ icon: Icon, label, to, tone }) => (
              <button
                key={label}
                onClick={() => go(to)}
                className="bg-white rounded-2xl p-3 flex flex-col items-center gap-2 shadow-[0_6px_20px_-12px_rgba(47,127,242,0.35)] border border-niva-50 hover:-translate-y-0.5 transition"
              >
                <span className={cn("w-11 h-11 rounded-2xl flex items-center justify-center", tone)}>
                  <Icon className="w-5 h-5" />
                </span>
                <span className="text-xs font-semibold text-niva-900">{label}</span>
              </button>
            ))}
          </div>

          {/* reminders */}
          <div className="mt-5">
            <SectionTitle
              action={
                <button onClick={() => go("meds")} className="text-xs text-niva-600 font-semibold">
                  همه
                </button>
              }
            >
              یادآورهای امروز
            </SectionTitle>
            <div className="space-y-2">
              {reminders.map((r) => (
                <Card key={r.t} className="px-4 py-3 flex items-center gap-3">
                  <span className={cn("shrink-0", r.done ? "text-emerald-500" : "text-slate-300")}>
                    {r.done ? <CheckCircle2 className="w-5 h-5" /> : <Clock className="w-5 h-5" />}
                  </span>
                  <span className={cn("flex-1 text-sm font-semibold", r.done ? "line-through text-slate-400" : "text-niva-900")}>
                    {r.t}
                  </span>
                  <span className="text-xs text-slate-400 fa-num">{r.time}</span>
                </Card>
              ))}
            </div>
          </div>
        </div>
        <BottomNav active="home" go={go} />
      </div>
    </div>
  );
}

/* ---------------- Cycle calendar ---------------- */
export function CycleScreen({ go }: P) {
  const days = ["ش", "ی", "د", "س", "چ", "پ", "ج"];
  const [sel, setSel] = useState(14);
  const period = [1, 2, 3, 4, 5];
  const fertile = [12, 13, 14, 15, 16];
  const ovul = 14;
  const cells = Array.from({ length: 35 }, (_, i) => i - 2);
  return (
    <BluePage title="تقویم چرخه" onBack={() => go("home")} bottom={<BottomNav active="cycle" go={go} />}>
      <Card className="p-4">
        <div className="flex items-center justify-between mb-3">
          <button className="p-1.5 rounded-lg hover:bg-niva-50 text-niva-500">
            <ChevronRight className="w-4 h-4" />
          </button>
          <p className="font-bold text-niva-900">مهر {fa(1404)}</p>
          <button className="p-1.5 rounded-lg hover:bg-niva-50 text-niva-500">
            <ChevronLeft className="w-4 h-4" />
          </button>
        </div>
        <div className="grid grid-cols-7 text-center text-[11px] text-slate-400 mb-2">
          {days.map((d) => (
            <span key={d}>{d}</span>
          ))}
        </div>
        <div className="grid grid-cols-7 gap-y-1.5 text-center text-xs fa-num">
          {cells.map((d, i) => {
            if (d < 1 || d > 30) return <span key={i} />;
            const isP = period.includes(d);
            const isF = fertile.includes(d);
            const isO = d === ovul;
            return (
              <button
                key={i}
                onClick={() => setSel(d)}
                className={cn(
                  "mx-auto w-8 h-8 rounded-full flex items-center justify-center font-semibold transition",
                  sel === d && "ring-2 ring-niva-500",
                  isO
                    ? "bg-niva-500 text-white"
                    : isP
                      ? "bg-rose-100 text-rose-500"
                      : isF
                        ? "bg-niva-100 text-niva-700"
                        : "text-niva-900 hover:bg-niva-50",
                )}
              >
                {fa(d)}
              </button>
            );
          })}
        </div>
      </Card>

      <Card className="p-4 mt-4 space-y-3 bg-gradient-to-l from-rose-50/60 to-white">
        {[
          ["روز قاعدگی", "bg-rose-400"],
          ["روز تخمک‌گذاری", "bg-niva-500"],
          ["بارداری احتمالی", "bg-niva-200"],
        ].map(([l, c]) => (
          <div key={l} className="flex items-center gap-3 text-sm text-niva-900">
            <span className={cn("w-3 h-3 rounded-full", c)} />
            {l}
          </div>
        ))}
      </Card>

      <div className="grid grid-cols-3 gap-3 mt-4">
        {[
          ["روز چرخه", fa(14)],
          ["تا قاعدگی", `${fa(14)} روز`],
          ["طول چرخه", `${fa(28)} روز`],
        ].map(([l, v]) => (
          <Card key={l} className="p-3 text-center">
            <p className="text-[11px] text-slate-400">{l}</p>
            <p className="font-black text-niva-700 mt-1 fa-num">{v}</p>
          </Card>
        ))}
      </div>
      <Button className="mt-4" onClick={() => go("add-form")}>
        ثبت علائم امروز
      </Button>
    </BluePage>
  );
}

/* ---------------- Pregnancy ---------------- */
export function PregnancyScreen({ go }: P) {
  const items: { icon: typeof Heart; label: string; to: Screen }[] = [
    { icon: Activity, label: "رشد جنین", to: "fetal-growth" },
    { icon: ClipboardList, label: "چک‌لیست بارداری", to: "add-form" },
    { icon: ShoppingBag, label: "وسایل مورد نیاز", to: "empty" },
    { icon: History, label: "سوابق بارداری", to: "tests" },
  ];
  const pct = 30;
  return (
    <BluePage title="بارداری" onBack={() => go("home")} bottom={<BottomNav active="pregnancy" go={go} />}>
      <Card className="p-5 flex items-center gap-4 bg-gradient-to-l from-rose-50 to-white">
        <div className="flex-1">
          <p className="text-2xl font-black text-niva-900">هفته {fa(12)}</p>
          <p className="text-sm text-slate-500 mt-1">
            روز <span className="font-bold text-rose-500">{fa(84)}</span>
          </p>
          <div className="h-2 bg-slate-100 rounded-full mt-3 overflow-hidden">
            <div className="h-full bg-gradient-to-l from-niva-500 to-niva-300 rounded-full" style={{ width: `${pct}%` }} />
          </div>
          <p className="text-[11px] text-slate-400 mt-1 fa-num">{fa(pct)}٪ از مسیر طی شده</p>
        </div>
        <div className="w-24 h-24 rounded-full bg-rose-100 flex items-center justify-center text-5xl shadow-inner shrink-0">
          👶
        </div>
      </Card>

      <Card className="p-4 mt-4">
        <p className="text-sm font-bold text-niva-900 mb-2">وضعیت شما</p>
        <ul className="text-xs text-slate-500 space-y-1.5 leading-6">
          <li>• تهوع صبحگاهی معمولاً از این هفته کاهش می‌یابد.</li>
          <li>• مصرف فولیک اسید و ویتامین D را فراموش نکنید.</li>
          <li>• نوبت سونوگرافی NT این هفته توصیه می‌شود.</li>
        </ul>
      </Card>

      <div className="mt-4 space-y-2.5">
        {items.map(({ icon: Icon, label, to }) => (
          <Card key={label} onClick={() => go(to)} className="px-4 py-3.5 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-niva-50 text-niva-600 flex items-center justify-center">
              <Icon className="w-5 h-5" />
            </span>
            <span className="flex-1 text-sm font-semibold text-niva-900">{label}</span>
            <ChevronLeft className="w-4 h-4 text-slate-300" />
          </Card>
        ))}
      </div>
    </BluePage>
  );
}

/* ---------------- Fetal growth ---------------- */
export function FetalGrowthScreen({ go }: P) {
  const [tab, setTab] = useState<"w" | "h">("w");
  return (
    <BluePage title="رشد جنین" onBack={() => go("pregnancy")}>
      <div className="flex bg-white rounded-2xl p-1 shadow-sm border border-niva-50">
        {(
          [
            ["w", "وزن"],
            ["h", "قد"],
          ] as const
        ).map(([k, l]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={cn(
              "flex-1 py-2 rounded-xl text-sm font-semibold transition",
              tab === k ? "bg-niva-600 text-white shadow" : "text-slate-500",
            )}
          >
            {l}
          </button>
        ))}
      </div>

      <Card className="p-4 mt-4">
        <LineChart
          values={tab === "w" ? [4, 7, 14, 23, 43, 70, 100] : [2.3, 3.1, 4.1, 5.4, 7.4, 8.7, 10]}
          labels={["۸", "۹", "۱۰", "۱۱", "۱۲", "۱۳", "۱۴"]}
          unit={tab === "w" ? "گرم" : "cm"}
        />
      </Card>

      <div className="grid grid-cols-3 gap-3 mt-4">
        {[
          ["وزن", `${fa(14)} g`],
          ["قد", `${fa(5.4)} cm`],
          ["هفته", fa(12)],
        ].map(([l, v]) => (
          <Card key={l} className="p-3 text-center">
            <p className="text-[11px] text-slate-400">{l}</p>
            <p className="font-black text-niva-700 mt-1 fa-num">{v}</p>
          </Card>
        ))}
      </div>

      <Card className="p-4 mt-4 bg-gradient-to-l from-emerald-50 to-white">
        <div className="flex items-center gap-2 text-emerald-600 text-sm font-bold">
          <CheckCircle2 className="w-4 h-4" /> وضعیت رشد عالی است
        </div>
        <p className="text-xs text-slate-500 mt-2 leading-6">
          جنین شما به اندازه یک لیمو است. اندام‌ها در حال شکل‌گیری کامل هستند و رفلکس‌های اولیه آغاز شده‌اند.
        </p>
      </Card>
      <Button className="mt-4" onClick={() => go("ai-chat")}>
        مشاهده جزئیات
      </Button>
    </BluePage>
  );
}

/* ---------------- Child ---------------- */
export function ChildScreen({ go }: P) {
  return (
    <BluePage title="کودک" onBack={() => go("home")} bottom={<BottomNav active="child" go={go} />}>
      <Card className="p-4 flex items-center gap-4">
        <Avatar src={avatarUrl("Ali", "bfd9fd")} size={64} />
        <div className="flex-1">
          <p className="font-black text-niva-900 text-lg">علی</p>
          <p className="text-xs text-slate-500 mt-0.5">{fa(5)} ماه و {fa(12)} روز</p>
        </div>
        <span className="text-3xl">🍼</span>
      </Card>

      <div className="grid grid-cols-3 gap-3 mt-4">
        {[
          ["قد", `${fa(67)} cm`],
          ["وزن", `${fa(8.5)} kg`],
          ["دور سر", `${fa(42)} cm`],
        ].map(([l, v]) => (
          <Card key={l} className="p-3 text-center">
            <p className="text-[11px] text-slate-400">{l}</p>
            <p className="font-black text-niva-700 mt-1 fa-num">{v}</p>
          </Card>
        ))}
      </div>

      <Card className="p-4 mt-4">
        <p className="text-sm font-bold text-niva-900 mb-3">نمودار رشد</p>
        <LineChart
          values={[3.3, 4.5, 5.6, 6.4, 7.0, 7.6, 8.5]}
          labels={["تولد", "۱", "۲", "۳", "۴", "۵", "۶"]}
          unit="kg"
          secondary={[3.2, 4.2, 5.1, 5.8, 6.4, 6.9, 7.3]}
        />
      </Card>

      <Card className="p-4 mt-4">
        <p className="text-sm font-bold text-niva-900 mb-2">واکسن بعدی</p>
        <div className="flex items-center justify-between text-xs">
          <span className="text-slate-500">واکسن ۶ ماهگی (پنتاوالان)</span>
          <span className="text-niva-600 font-bold fa-num">{fa(18)} روز دیگر</span>
        </div>
      </Card>
      <Button className="mt-4" onClick={() => go("add-form")}>
        ثبت اندازه‌گیری جدید
      </Button>
    </BluePage>
  );
}

/* ---------------- Mini line chart (SVG) ---------------- */
export function LineChart({
  values,
  labels,
  unit,
  secondary,
}: {
  values: number[];
  labels: string[];
  unit?: string;
  secondary?: number[];
}) {
  const w = 300;
  const h = 140;
  const pad = 20;
  const all = [...values, ...(secondary ?? [])];
  const max = Math.max(...all) * 1.1;
  const min = 0;
  const pt = (v: number, i: number, arr: number[]) => {
    const x = pad + ((w - pad * 2) * i) / (arr.length - 1);
    const y = h - pad - ((h - pad * 2) * (v - min)) / (max - min);
    return [x, y] as const;
  };
  const path = (arr: number[]) => arr.map((v, i) => pt(v, i, arr)).map(([x, y], i) => `${i ? "L" : "M"}${x},${y}`).join(" ");
  const area = `${path(values)} L${pad + (w - pad * 2)},${h - pad} L${pad},${h - pad} Z`;
  return (
    <div dir="ltr" className="w-full">
      <svg viewBox={`0 0 ${w} ${h}`} className="w-full h-auto">
        <defs>
          <linearGradient id="g" x1="0" x2="0" y1="0" y2="1">
            <stop offset="0" stopColor="#2f7ff2" stopOpacity=".25" />
            <stop offset="1" stopColor="#2f7ff2" stopOpacity="0" />
          </linearGradient>
        </defs>
        {[0.25, 0.5, 0.75, 1].map((f) => (
          <line
            key={f}
            x1={pad}
            x2={w - pad}
            y1={h - pad - (h - pad * 2) * f}
            y2={h - pad - (h - pad * 2) * f}
            stroke="#e5eefb"
            strokeDasharray="3 3"
          />
        ))}
        <path d={area} fill="url(#g)" />
        {secondary && (
          <path d={path(secondary)} fill="none" stroke="#ff7aa2" strokeWidth="2" strokeDasharray="4 3" />
        )}
        <path d={path(values)} fill="none" stroke="#2f7ff2" strokeWidth="2.5" strokeLinecap="round" />
        {values.map((v, i) => {
          const [x, y] = pt(v, i, values);
          return <circle key={i} cx={x} cy={y} r="3.5" fill="#fff" stroke="#2f7ff2" strokeWidth="2" />;
        })}
        {labels.map((l, i) => (
          <text
            key={l + i}
            x={pad + ((w - pad * 2) * i) / (labels.length - 1)}
            y={h - 4}
            textAnchor="middle"
            fontSize="9"
            fill="#94a3b8"
            fontFamily="Vazirmatn"
          >
            {l}
          </text>
        ))}
      </svg>
      {unit && <p dir="rtl" className="text-[10px] text-slate-400 mt-1">واحد: {unit}</p>}
    </div>
  );
}
