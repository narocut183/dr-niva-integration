import { useState } from "react";
import {
  Heart,
  MessageCircle,
  Eye,
  Plus,
  Copy,
  Check,
  ChevronLeft,
  User,
  FileText,
  Settings,
  Bell,
  Wallet,
  Shield,
  Moon,
  Globe,
  Trash2,
  LogOut,
  Phone,
  HelpCircle,
  Scale,
  Crown,
  Sparkles,
} from "lucide-react";
import { Avatar, avatarUrl, Badge, BluePage, BottomNav, Button, Card, NivaLogo, Toggle } from "../components/ui";
import { fa, type Screen } from "../lib/nav";
import { cn } from "../utils/cn";

type P = { go: (s: Screen) => void };

/* ---------------- Community ---------------- */
export function CommunityScreen({ go }: P) {
  const [tab, setTab] = useState("همه");
  const posts = [
    { t: "سؤال درباره درد کمر در بارداری", a: "مریم", tag: "بارداری", l: 24, c: 8, v: 120 },
    { t: "تجربه زایمان طبیعی", a: "سارا", tag: "بارداری", l: 56, c: 19, v: 340 },
    { t: "تغذیه در دوران بارداری", a: "زهرا", tag: "تغذیه", l: 31, c: 11, v: 210 },
    { t: "خواب نوزاد ۳ ماهه", a: "نگار", tag: "کودک", l: 17, c: 6, v: 98 },
  ];
  const tabs = ["همه", "بارداری", "کودک", "تغذیه"];
  const list = tab === "همه" ? posts : posts.filter((p) => p.tag === tab);
  return (
    <BluePage title="انجمن و گفتگوها" onBack={() => go("home")} bottom={<BottomNav active="home" go={go} />}>
      <div className="flex gap-2 overflow-x-auto no-scrollbar pb-1">
        {tabs.map((t) => (
          <button
            key={t}
            onClick={() => setTab(t)}
            className={cn(
              "px-4 py-1.5 rounded-full text-xs font-semibold whitespace-nowrap transition border",
              tab === t ? "bg-niva-600 text-white border-niva-600" : "bg-white text-slate-500 border-niva-100",
            )}
          >
            {t}
          </button>
        ))}
      </div>
      <div className="mt-4 space-y-3">
        {list.map((p) => (
          <Card key={p.t} className="p-4" onClick={() => go("ai-chat")}>
            <div className="flex items-center gap-2">
              <Avatar src={avatarUrl(p.a, "ffd5dc")} size={32} ring={false} />
              <span className="text-xs text-slate-500">{p.a}</span>
              <span className="mr-auto">
                <Badge tone="blue">{p.tag}</Badge>
              </span>
            </div>
            <p className="font-bold text-sm text-niva-900 mt-3">{p.t}</p>
            <div className="flex items-center gap-4 mt-3 text-[11px] text-slate-400 fa-num">
              <span className="flex items-center gap-1"><Heart className="w-3.5 h-3.5 text-rose-400" /> {fa(p.l)}</span>
              <span className="flex items-center gap-1"><MessageCircle className="w-3.5 h-3.5 text-niva-400" /> {fa(p.c)}</span>
              <span className="flex items-center gap-1"><Eye className="w-3.5 h-3.5" /> {fa(p.v)}</span>
            </div>
          </Card>
        ))}
      </div>
      <button
        onClick={() => go("add-form")}
        className="mt-5 w-full bg-niva-600 text-white rounded-2xl py-3 text-sm font-bold shadow-lg shadow-niva-500/30 flex items-center justify-center gap-2 hover:bg-niva-700 transition"
      >
        <Plus className="w-4 h-4" /> پست جدید
      </button>
    </BluePage>
  );
}

/* ---------------- Family / companions ---------------- */
export function FamilyScreen({ go }: P) {
  const [copied, setCopied] = useState(false);
  const code = "A7K3-9F2Q";
  const copy = () => {
    navigator.clipboard?.writeText(code).catch(() => {});
    setCopied(true);
    setTimeout(() => setCopied(false), 1500);
  };
  const members = [
    { n: "همسر", d: "دسترسی کامل · فعال", s: "فعال", tone: "mint" as const, seed: "Reza" },
    { n: "مادر", d: "دسترسی محدود", s: "محدود", tone: "amber" as const, seed: "Mother" },
  ];
  return (
    <BluePage title="همراهی و خانواده" onBack={() => go("home")}>
      <Card className="p-5 text-center">
        <p className="text-sm text-slate-500">کد همراهی</p>
        <p dir="ltr" className="text-2xl font-black tracking-widest text-niva-900 mt-2">{code}</p>
        <Button variant="soft" size="sm" full={false} className="mt-3" onClick={copy}>
          <span className="inline-flex items-center gap-1.5">
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            {copied ? "کپی شد" : "کپی کد"}
          </span>
        </Button>
      </Card>
      <p className="text-sm font-bold text-niva-900 mt-5 mb-3">اعضای خانواده</p>
      <div className="space-y-3">
        {members.map((m) => (
          <Card key={m.n} className="px-4 py-3 flex items-center gap-3">
            <Avatar src={avatarUrl(m.seed)} size={44} />
            <div className="flex-1">
              <p className="text-sm font-bold text-niva-900">{m.n}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">{m.d}</p>
            </div>
            <Badge tone={m.tone}>{m.s}</Badge>
          </Card>
        ))}
      </div>
      <Button className="mt-5" onClick={() => go("add-form")}>
        مدیریت کد ها
      </Button>
    </BluePage>
  );
}

/* ---------------- Companion news ---------------- */
export function CompanionNewsScreen({ go }: P) {
  const news = [
    { n: "مادر", d: "آزمایش خون ثبت شد", e: "🩸", seed: "Mother", time: "۲ ساعت پیش" },
    { n: "خواهر", d: "یادآور دارو · فعال شد", e: "💊", seed: "Sister", time: "دیروز" },
    { n: "همسر", d: "ویزیت پزشک ثبت شد", e: "🩺", seed: "Reza", time: "۳ روز پیش" },
  ];
  return (
    <BluePage title="خبرهای همراه" onBack={() => go("family")}>
      <div className="space-y-3">
        {news.map((n) => (
          <Card key={n.n} className="px-4 py-3 flex items-center gap-3">
            <Avatar src={avatarUrl(n.seed)} size={44} />
            <div className="flex-1">
              <p className="text-sm font-bold text-niva-900">{n.n}</p>
              <p className="text-[11px] text-slate-400 mt-0.5">{n.d}</p>
              <p className="text-[10px] text-slate-300 mt-0.5 fa-num">{n.time}</p>
            </div>
            <span className="w-10 h-10 rounded-xl bg-niva-50 flex items-center justify-center text-lg">{n.e}</span>
          </Card>
        ))}
      </div>
      <Button className="mt-5" onClick={() => go("family")}>
        افزودن کد همراه
      </Button>
    </BluePage>
  );
}

/* ---------------- Profile ---------------- */
export function ProfileScreen({ go }: P) {
  const items: { icon: typeof User; label: string; to: Screen }[] = [
    { icon: User, label: "اطلاعات شخصی", to: "complete-profile" },
    { icon: FileText, label: "سوابق پزشکی", to: "tests" },
    { icon: Settings, label: "تنظیمات کاربر", to: "settings" },
    { icon: Bell, label: "اعلان‌ها", to: "meds" },
    { icon: Wallet, label: "کیف پول و پلن‌ها", to: "wallet" },
    { icon: Shield, label: "حریم خصوصی", to: "about" },
  ];
  return (
    <BluePage title="پروفایل" onBack={() => go("home")} bottom={<BottomNav active="profile" go={go} />}>
      <div className="flex flex-col items-center">
        <Avatar src={avatarUrl("Narges", "ffd5dc")} size={88} />
        <p className="font-black text-niva-900 text-lg mt-3">نرگس احمدی</p>
        <p className="text-xs text-slate-400">کاربر عادی</p>
        <button onClick={() => go("wallet")} className="mt-2 inline-flex items-center gap-1 text-[11px] text-amber-600 bg-amber-50 px-3 py-1 rounded-full font-bold">
          <Crown className="w-3.5 h-3.5" /> ارتقا به پلن ویژه
        </button>
      </div>
      <div className="mt-5 space-y-2.5">
        {items.map(({ icon: Icon, label, to }) => (
          <Card key={label} onClick={() => go(to)} className="px-4 py-3.5 flex items-center gap-3">
            <span className="w-9 h-9 rounded-xl bg-niva-50 text-niva-600 flex items-center justify-center">
              <Icon className="w-4.5 h-4.5" />
            </span>
            <span className="flex-1 text-sm font-semibold text-niva-900">{label}</span>
            <ChevronLeft className="w-4 h-4 text-slate-300" />
          </Card>
        ))}
      </div>
    </BluePage>
  );
}

/* ---------------- Settings ---------------- */
export function SettingsScreen({ go }: P) {
  const [s, setS] = useState({ notif: true, rem: true, dark: false });
  const rows = [
    { icon: Bell, label: "اعلان‌ها", sub: s.notif ? "فعال" : "غیرفعال", key: "notif" as const },
    { icon: MessageCircle, label: "پیامک یادآوری", sub: s.rem ? "فعال" : "غیرفعال", key: "rem" as const },
    { icon: Moon, label: "حالت تاریک", sub: s.dark ? "روشن" : "خاموش", key: "dark" as const },
  ];
  return (
    <BluePage title="تنظیمات" onBack={() => go("profile")}>
      <div className="space-y-2.5">
        {rows.map(({ icon: Icon, label, sub, key }) => (
          <Card key={label} className="px-4 py-3.5 flex items-center gap-3">
            <span className="w-9 h-9 rounded-xl bg-niva-50 text-niva-600 flex items-center justify-center">
              <Icon className="w-4.5 h-4.5" />
            </span>
            <div className="flex-1">
              <p className="text-sm font-semibold text-niva-900">{label}</p>
              <p className="text-[11px] text-slate-400">{sub}</p>
            </div>
            <Toggle on={s[key]} onChange={(v) => setS({ ...s, [key]: v })} />
          </Card>
        ))}
        <Card className="px-4 py-3.5 flex items-center gap-3" onClick={() => {}}>
          <span className="w-9 h-9 rounded-xl bg-niva-50 text-niva-600 flex items-center justify-center">
            <Globe className="w-4.5 h-4.5" />
          </span>
          <div className="flex-1">
            <p className="text-sm font-semibold text-niva-900">زبان برنامه</p>
            <p className="text-[11px] text-slate-400">فارسی</p>
          </div>
          <ChevronLeft className="w-4 h-4 text-slate-300" />
        </Card>
        <Card className="px-4 py-3.5 flex items-center gap-3" onClick={() => go("confirm")}>
          <span className="w-9 h-9 rounded-xl bg-rose-50 text-rose-500 flex items-center justify-center">
            <Trash2 className="w-4.5 h-4.5" />
          </span>
          <p className="flex-1 text-sm font-semibold text-rose-500">حذف حساب کاربری</p>
          <ChevronLeft className="w-4 h-4 text-slate-300" />
        </Card>
      </div>
      <Button variant="danger" className="mt-6" onClick={() => go("logout")}>
        <span className="inline-flex items-center gap-2">
          <LogOut className="w-4 h-4" /> خروج از حساب
        </span>
      </Button>
    </BluePage>
  );
}

/* ---------------- Wallet ---------------- */
export function WalletScreen({ go }: P) {
  const plans = [
    { n: "ماهانه", p: "۹۹,۰۰۰", d: "۱ ماه دسترسی کامل", hot: false },
    { n: "سه‌ماهه", p: "۲۴۹,۰۰۰", d: "۱۵٪ تخفیف", hot: true },
    { n: "سالانه", p: "۷۹۰,۰۰۰", d: "۳۵٪ تخفیف", hot: false },
  ];
  return (
    <BluePage title="کیف پول و پلن‌ها" onBack={() => go("profile")}>
      <Card className="p-5 bg-gradient-to-br from-niva-600 to-niva-800 text-white border-0">
        <p className="text-xs text-white/80">موجودی کیف پول</p>
        <p className="text-3xl font-black mt-1 fa-num">{fa("45,000")} <span className="text-sm font-semibold">تومان</span></p>
        <Button variant="white" size="sm" full={false} className="mt-4" onClick={() => go("success")}>
          افزایش اعتبار
        </Button>
      </Card>

      <Card className="p-4 mt-4 flex items-center gap-3 border-amber-100 bg-gradient-to-l from-amber-50 to-white">
        <span className="w-12 h-12 rounded-2xl bg-amber-100 text-amber-500 flex items-center justify-center">
          <Crown className="w-6 h-6" />
        </span>
        <div className="flex-1">
          <p className="text-[11px] text-slate-400">پلن فعال</p>
          <p className="font-black text-niva-900">ماهانه</p>
          <p className="text-[11px] text-slate-400 fa-num">تا ۱۴۰۴/۰۸/۱۵ اعتبار دارد</p>
        </div>
      </Card>

      <p className="text-sm font-bold text-niva-900 mt-5 mb-3">پلن‌های اشتراک</p>
      <div className="space-y-3">
        {plans.map((p) => (
          <Card key={p.n} className={cn("p-4 flex items-center gap-3", p.hot && "border-niva-300 ring-2 ring-niva-100")}>
            <div className="flex-1">
              <p className="font-bold text-niva-900 text-sm flex items-center gap-2">
                {p.n}
                {p.hot && <span className="text-[10px] bg-niva-600 text-white px-2 py-0.5 rounded-full inline-flex items-center gap-1"><Sparkles className="w-3 h-3" /> پیشنهادی</span>}
              </p>
              <p className="text-[11px] text-slate-400 mt-0.5">{p.d}</p>
            </div>
            <p className="font-black text-niva-700 fa-num">{p.p} <span className="text-[10px] font-normal text-slate-400">تومان</span></p>
          </Card>
        ))}
      </div>
      <Button className="mt-5" onClick={() => go("success")}>
        مشاهده پلن‌ها
      </Button>
    </BluePage>
  );
}

/* ---------------- About ---------------- */
export function AboutScreen({ go }: P) {
  const links = [
    { icon: Phone, label: "تماس با ما" },
    { icon: HelpCircle, label: "پرسش‌های متداول" },
    { icon: Scale, label: "قوانین و مقررات" },
  ];
  return (
    <BluePage title="درباره ما" onBack={() => go("profile")}>
      <div className="flex flex-col items-center text-center">
        <div className="w-20 h-20 rounded-3xl niva-gradient flex items-center justify-center shadow-xl shadow-niva-500/30">
          <NivaLogo className="w-14 h-14" />
        </div>
        <p className="font-black text-niva-900 text-xl mt-3">دکتر نیوا</p>
        <p className="text-[11px] text-slate-400 fa-num">نسخه ۱.۰.۰</p>
        <p className="text-xs text-slate-500 leading-6 mt-4 px-4">
          اپلیکیشن سلامت زنان، بارداری و کودک با هدف همراهی هوشمند خانواده در تمام مراحل زندگی طراحی شده است.
        </p>
      </div>
      <div className="mt-6 space-y-2.5">
        {links.map(({ icon: Icon, label }) => (
          <Card key={label} className="px-4 py-3.5 flex items-center gap-3" onClick={() => go("empty")}>
            <span className="w-9 h-9 rounded-xl bg-niva-50 text-niva-600 flex items-center justify-center">
              <Icon className="w-4.5 h-4.5" />
            </span>
            <span className="flex-1 text-sm font-semibold text-niva-900">{label}</span>
            <ChevronLeft className="w-4 h-4 text-slate-300" />
          </Card>
        ))}
      </div>
      <p className="text-center text-[11px] text-slate-400 mt-8">ساخته شده با 💙 برای بانوان ایران</p>
    </BluePage>
  );
}
