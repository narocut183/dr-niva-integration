import { useState, useRef, useEffect } from "react";
import {
  FlaskConical,
  ChevronLeft,
  Download,
  BarChart3,
  Send,
  Paperclip,
  Brain,
  Wind,
  Lightbulb,
  MessageCircle,
  Pill,
  Plus,
  Bell,
  CheckCircle2,
  Droplets,
} from "lucide-react";
import { Badge, BluePage, BottomNav, Button, Card, Toggle, StatusBar, Header } from "../components/ui";
import type { Screen } from "../lib/nav";
import { cn } from "../utils/cn";

type P = { go: (s: Screen) => void };

/* ---------------- Tests list ---------------- */
export function TestsScreen({ go }: P) {
  const tests = [
    { n: "آزمایش خون", d: "۱۴۰۴/۰۵/۲۰", s: "طبیعی", tone: "mint" as const },
    { n: "TSH", d: "۱۴۰۴/۰۵/۱۲", s: "طبیعی", tone: "mint" as const },
    { n: "ویتامین D", d: "۱۴۰۴/۰۵/۲۵", s: "کمبود", tone: "amber" as const },
    { n: "سونوگرافی", d: "۱۴۰۴/۰۵/۱۰", s: "طبیعی", tone: "mint" as const },
    { n: "قند خون ناشتا", d: "۱۴۰۴/۰۴/۲۸", s: "مرزی", tone: "rose" as const },
  ];
  return (
    <BluePage title="آزمایش‌ها" onBack={() => go("home")}>
      <div className="space-y-3">
        {tests.map((t) => (
          <Card key={t.n} onClick={() => go("test-detail")} className="px-4 py-3.5 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-niva-50 text-niva-600 flex items-center justify-center">
              <FlaskConical className="w-5 h-5" />
            </span>
            <div className="flex-1">
              <p className="text-sm font-bold text-niva-900">{t.n}</p>
              <p className="text-[11px] text-slate-400 mt-0.5 fa-num">{t.d}</p>
            </div>
            <Badge tone={t.tone}>{t.s}</Badge>
          </Card>
        ))}
      </div>
      <Button className="mt-5" onClick={() => go("add-form")}>
        <span className="inline-flex items-center gap-2">
          <Plus className="w-4 h-4" /> ثبت آزمایش جدید
        </span>
      </Button>
    </BluePage>
  );
}

/* ---------------- Test detail ---------------- */
export function TestDetailScreen({ go }: P) {
  const rows = [
    ["هموگلوبین", "۱۲.۵ g/dL", "۱۲–۱۶", true],
    ["TSH", "۲.۴ mIU/L", "۰.۴–۴", true],
    ["ویتامین D", "۱۸ ng/mL", "۳۰–۱۰۰", false],
    ["فریتین", "۳۵ ng/mL", "۱۵–۱۵۰", true],
  ] as const;
  return (
    <BluePage title="جزئیات آزمایش" onBack={() => go("tests")}>
      <Card className="p-4">
        <div className="flex items-center justify-between">
          <div>
            <p className="font-black text-niva-900">آزمایش خون</p>
            <p className="text-[11px] text-slate-400 mt-0.5 fa-num">۱۴۰۴/۰۵/۲۰ · آزمایشگاه پارس</p>
          </div>
          <span className="w-10 h-10 rounded-xl bg-niva-50 text-niva-600 flex items-center justify-center">
            <FlaskConical className="w-5 h-5" />
          </span>
        </div>
        <div className="mt-4 divide-y divide-niva-50">
          {rows.map(([k, v, r, ok]) => (
            <div key={k} className="flex items-center justify-between py-2.5 text-sm">
              <span className="text-niva-900 font-semibold">{k}</span>
              <div className="text-left">
                <p className={cn("font-bold fa-num", ok ? "text-niva-900" : "text-amber-500")}>{v}</p>
                <p className="text-[10px] text-slate-400 fa-num">محدوده: {r}</p>
              </div>
            </div>
          ))}
        </div>
      </Card>

      <Card className="p-4 mt-4">
        <p className="text-sm font-bold text-niva-900 mb-3">نمودار ویتامین D</p>
        <div dir="ltr" className="relative h-3 rounded-full bg-gradient-to-r from-rose-300 via-emerald-300 to-rose-300">
          <span className="absolute -top-1.5 left-[22%] w-6 h-6 rounded-full bg-white border-2 border-niva-500 shadow -translate-x-1/2" />
        </div>
        <div className="flex justify-between text-[10px] text-slate-400 mt-2 fa-num">
          <span>۱۰۰</span>
          <span>۳۰</span>
          <span>۰</span>
        </div>
        <div className="mt-3 flex items-center gap-2 text-xs text-amber-600 bg-amber-50 rounded-xl px-3 py-2">
          <Droplets className="w-4 h-4" /> کمتر از محدوده طبیعی — مکمل توصیه می‌شود
        </div>
      </Card>

      <div className="grid grid-cols-2 gap-3 mt-4">
        <Button onClick={() => go("success")}>
          <span className="inline-flex items-center gap-2">
            <Download className="w-4 h-4" /> دانلود گزارش
          </span>
        </Button>
        <Button variant="soft" onClick={() => go("fetal-growth")}>
          <span className="inline-flex items-center gap-2">
            <BarChart3 className="w-4 h-4" /> نمودار مقایسه
          </span>
        </Button>
      </div>
    </BluePage>
  );
}

/* ---------------- AI chat ---------------- */
type Msg = { from: "ai" | "me"; text: string };
export function AiChatScreen({ go }: P) {
  const [msgs, setMsgs] = useState<Msg[]>([
    { from: "ai", text: "سلام نرگس! من دستیار هوشمند دکتر نیوا هستم. امروز چه کمکی می‌تونم بکنم؟" },
  ]);
  const [text, setText] = useState("");
  const [typing, setTyping] = useState(false);
  const endRef = useRef<HTMLDivElement>(null);
  useEffect(() => endRef.current?.scrollIntoView({ behavior: "smooth" }), [msgs, typing]);

  const replies: Record<string, string> = {
    "درباره تغذیه بارداری": "در هفته ۱۲ بارداری، مصرف پروتئین، آهن، فولات و کلسیم اهمیت زیادی داره. سبزیجات برگ‌دار، لبنیات کم‌چرب و حبوبات رو در برنامه‌ات بگنجون 🥗",
    "مشکلات خواب": "برای خواب بهتر: به پهلوی چپ بخوابید، از بالش بین زانوها استفاده کنید و مصرف مایعات را عصرها کم کنید 🌙",
    "دردهای بارداری": "دردهای خفیف کشاله ران در این هفته طبیعیه (درد لیگامان گرد). اگر درد شدید یا همراه خونریزی بود حتماً به پزشک مراجعه کن ⚠️",
  };
  const send = (t: string) => {
    if (!t.trim()) return;
    setMsgs((m) => [...m, { from: "me", text: t }]);
    setText("");
    setTyping(true);
    setTimeout(() => {
      setTyping(false);
      setMsgs((m) => [
        ...m,
        { from: "ai", text: replies[t] ?? "ممنون از پیامت 💙 این موضوع رو بررسی می‌کنم. پیشنهاد می‌کنم برای اطمینان با پزشک خودت هم مشورت کنی." },
      ]);
    }, 1100);
  };
  const suggestions = Object.keys(replies);

  return (
    <div className="flex flex-col h-full niva-gradient">
      <StatusBar dark />
      <Header title="مشاوره هوشمند" onBack={() => go("home")} />
      <div className="flex-1 min-h-0 bg-[#f3f8ff] rounded-t-[28px] overflow-hidden flex flex-col">
        <div className="flex-1 overflow-y-auto thin-scroll px-4 pt-4 pb-3">
          <div className="flex flex-col items-center mb-4">
            <img src="/images/assistant.png" alt="" className="w-20 h-20 rounded-full object-cover ring-4 ring-white shadow-lg" />
            <p className="text-xs text-slate-400 mt-2">دستیار آنلاین · پاسخ فوری</p>
          </div>
          <div className="space-y-3">
            {msgs.map((m, i) => (
              <div key={i} className={cn("flex", m.from === "me" ? "justify-start flex-row-reverse" : "justify-start")}>
                <div
                  className={cn(
                    "max-w-[82%] px-4 py-2.5 text-sm leading-6 shadow-sm animate-fade-up",
                    m.from === "ai"
                      ? "bg-white text-niva-900 rounded-2xl rounded-tr-md"
                      : "bg-niva-600 text-white rounded-2xl rounded-tl-md",
                  )}
                >
                  {m.text}
                </div>
              </div>
            ))}
            {typing && (
              <div className="flex">
                <div className="bg-white rounded-2xl rounded-tr-md px-4 py-3 flex gap-1">
                  {[0, 1, 2].map((i) => (
                    <span
                      key={i}
                      className="w-1.5 h-1.5 rounded-full bg-niva-300 animate-bounce"
                      style={{ animationDelay: `${i * 0.15}s` }}
                    />
                  ))}
                </div>
              </div>
            )}
            <div ref={endRef} />
          </div>
          {msgs.length <= 2 && (
            <div className="mt-4">
              <p className="text-xs text-slate-400 mb-2">درباره‌ی چه موضوعی سؤال داری؟</p>
              <div className="flex flex-col gap-2">
                {suggestions.map((s) => (
                  <button
                    key={s}
                    onClick={() => send(s)}
                    className="self-start bg-white border border-niva-100 text-niva-700 text-xs font-semibold px-3.5 py-2 rounded-full hover:bg-niva-50 transition"
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}
        </div>
        <div className="p-3 border-t border-niva-100 bg-white flex items-center gap-2">
          <button onClick={() => send(text)} className="w-10 h-10 rounded-xl bg-niva-600 text-white flex items-center justify-center shadow hover:bg-niva-700 transition">
            <Send className="w-4 h-4 -scale-x-100" />
          </button>
          <input
            value={text}
            onChange={(e) => setText(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && send(text)}
            placeholder="پیام خود را بنویسید..."
            className="flex-1 bg-niva-50 rounded-xl px-3.5 py-2.5 text-sm outline-none focus:ring-2 focus:ring-niva-200"
          />
          <button className="w-10 h-10 rounded-xl text-slate-400 hover:bg-niva-50 flex items-center justify-center">
            <Paperclip className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
}

/* ---------------- Mental health ---------------- */
export function MentalScreen({ go }: P) {
  const moods = [
    ["😊", "عالی"],
    ["🙂", "خوب"],
    ["😐", "معمولی"],
    ["😔", "ناراحت"],
    ["😢", "بد"],
  ];
  const [mood, setMood] = useState(1);
  const items: { icon: typeof Brain; label: string; to: Screen }[] = [
    { icon: Brain, label: "ارزیابی سلامت روان", to: "add-form" },
    { icon: Wind, label: "تمرین تنفسی", to: "loading" },
    { icon: Lightbulb, label: "ثبت افکار", to: "add-form" },
    { icon: MessageCircle, label: "گفتگو با مشاور", to: "ai-chat" },
  ];
  return (
    <BluePage title="سلامت روان" onBack={() => go("home")}>
      <div className="flex flex-col items-center">
        <img src="/images/assistant.png" alt="" className="w-24 h-24 rounded-full object-cover ring-4 ring-white shadow-lg" />
        <p className="font-bold text-niva-900 mt-3">امروز حال شما چطور است؟</p>
      </div>
      <div className="flex justify-between mt-4 px-1">
        {moods.map(([e, l], i) => (
          <button
            key={l}
            onClick={() => setMood(i)}
            className={cn(
              "flex flex-col items-center gap-1 px-2 py-2 rounded-2xl transition",
              mood === i ? "bg-white shadow-md scale-105" : "opacity-70 hover:opacity-100",
            )}
          >
            <span className="text-2xl">{e}</span>
            <span className="text-[10px] text-slate-500">{l}</span>
          </button>
        ))}
      </div>
      <div className="mt-5 space-y-2.5">
        {items.map(({ icon: Icon, label, to }) => (
          <Card key={label} onClick={() => go(to)} className="px-4 py-3.5 flex items-center gap-3">
            <span className="w-10 h-10 rounded-xl bg-violet-50 text-violet-500 flex items-center justify-center">
              <Icon className="w-5 h-5" />
            </span>
            <span className="flex-1 text-sm font-semibold text-niva-900">{label}</span>
            <ChevronLeft className="w-4 h-4 text-slate-300" />
          </Card>
        ))}
      </div>
    </BluePage>
  );
}

/* ---------------- Meds & reminders ---------------- */
export function MedsScreen({ go }: P) {
  const [tab, setTab] = useState<"meds" | "rem">("meds");
  const [meds, setMeds] = useState([
    { n: "ویتامین D", t: "روزانه · ۱۰ صبح", on: true, c: "bg-amber-50 text-amber-500" },
    { n: "فولیک اسید", t: "روزانه · ۸ صبح", on: false, c: "bg-rose-50 text-rose-500" },
    { n: "آهن", t: "روزانه · ۱۰ شب", on: true, c: "bg-emerald-50 text-emerald-500" },
  ]);
  const rems = [
    { n: "نوبت سونوگرافی", t: "۱۴۰۴/۰۷/۱۸ · ۹:۳۰", done: false },
    { n: "آزمایش قند", t: "۱۴۰۴/۰۷/۲۲ · ۸:۰۰", done: false },
    { n: "ویزیت ماهانه", t: "۱۴۰۴/۰۷/۱۰ · ۱۱:۰۰", done: true },
  ];
  return (
    <BluePage title="داروها و یادآورها" onBack={() => go("home")} bottom={<BottomNav active="home" go={go} />}>
      <div className="flex bg-white rounded-2xl p-1 shadow-sm border border-niva-50">
        {(
          [
            ["meds", "داروها"],
            ["rem", "یادآورها"],
          ] as const
        ).map(([k, l]) => (
          <button
            key={k}
            onClick={() => setTab(k)}
            className={cn("flex-1 py-2 rounded-xl text-sm font-semibold transition", tab === k ? "bg-niva-600 text-white shadow" : "text-slate-500")}
          >
            {l}
          </button>
        ))}
      </div>
      <div className="mt-4 space-y-3">
        {tab === "meds"
          ? meds.map((m, i) => (
              <Card key={m.n} className="px-4 py-3.5 flex items-center gap-3">
                <span className={cn("w-10 h-10 rounded-xl flex items-center justify-center", m.c)}>
                  <Pill className="w-5 h-5" />
                </span>
                <div className="flex-1">
                  <p className="text-sm font-bold text-niva-900">{m.n}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5 fa-num">{m.t}</p>
                </div>
                <Toggle on={m.on} onChange={(v) => setMeds((arr) => arr.map((x, j) => (j === i ? { ...x, on: v } : x)))} />
              </Card>
            ))
          : rems.map((r) => (
              <Card key={r.n} className="px-4 py-3.5 flex items-center gap-3">
                <span className={cn("w-10 h-10 rounded-xl flex items-center justify-center", r.done ? "bg-emerald-50 text-emerald-500" : "bg-niva-50 text-niva-600")}>
                  {r.done ? <CheckCircle2 className="w-5 h-5" /> : <Bell className="w-5 h-5" />}
                </span>
                <div className="flex-1">
                  <p className={cn("text-sm font-bold", r.done ? "text-slate-400 line-through" : "text-niva-900")}>{r.n}</p>
                  <p className="text-[11px] text-slate-400 mt-0.5 fa-num">{r.t}</p>
                </div>
              </Card>
            ))}
      </div>
      <Button className="mt-5" onClick={() => go("add-form")}>
        <span className="inline-flex items-center gap-2">
          <Plus className="w-4 h-4" /> افزودن {tab === "meds" ? "دارو" : "یادآور"} جدید
        </span>
      </Button>
    </BluePage>
  );
}
