export type Screen =
  | "splash"
  | "onboarding"
  | "login"
  | "complete-profile"
  | "home"
  | "cycle"
  | "pregnancy"
  | "fetal-growth"
  | "child"
  | "tests"
  | "test-detail"
  | "ai-chat"
  | "mental"
  | "meds"
  | "community"
  | "family"
  | "companion-news"
  | "profile"
  | "settings"
  | "wallet"
  | "about"
  | "logout"
  | "empty"
  | "error"
  | "loading"
  | "success"
  | "confirm"
  | "add-form"
  | "final";

export const SCREEN_GROUPS: { title: string; items: { id: Screen; label: string }[] }[] = [
  {
    title: "ورود و شروع",
    items: [
      { id: "splash", label: "اسپلش" },
      { id: "onboarding", label: "معرفی" },
      { id: "login", label: "ورود" },
      { id: "complete-profile", label: "تکمیل پروفایل" },
    ],
  },
  {
    title: "اصلی",
    items: [
      { id: "home", label: "خانه" },
      { id: "cycle", label: "تقویم چرخه" },
      { id: "pregnancy", label: "بارداری" },
      { id: "fetal-growth", label: "رشد جنین" },
      { id: "child", label: "کودک" },
    ],
  },
  {
    title: "سلامت",
    items: [
      { id: "tests", label: "آزمایش‌ها" },
      { id: "test-detail", label: "جزئیات آزمایش" },
      { id: "ai-chat", label: "مشاوره هوشمند" },
      { id: "mental", label: "سلامت روان" },
      { id: "meds", label: "داروها و یادآورها" },
    ],
  },
  {
    title: "اجتماعی و حساب",
    items: [
      { id: "community", label: "انجمن و گفتگوها" },
      { id: "family", label: "همراهی و خانواده" },
      { id: "companion-news", label: "خبرهای همراه" },
      { id: "profile", label: "پروفایل" },
      { id: "settings", label: "تنظیمات" },
      { id: "wallet", label: "کیف پول و پلن‌ها" },
      { id: "about", label: "درباره ما" },
      { id: "logout", label: "خروج" },
    ],
  },
  {
    title: "وضعیت‌ها",
    items: [
      { id: "empty", label: "صفحه خالی" },
      { id: "error", label: "خطا" },
      { id: "loading", label: "در حال بارگذاری" },
      { id: "success", label: "اعلان موفق" },
      { id: "confirm", label: "مودال تأیید" },
      { id: "add-form", label: "فرم جدید" },
      { id: "final", label: "پایانی" },
    ],
  },
];

/** Convert latin digits to Persian digits */
export const fa = (v: string | number): string =>
  String(v).replace(/\d/g, (d) => "۰۱۲۳۴۵۶۷۸۹"[Number(d)]);
