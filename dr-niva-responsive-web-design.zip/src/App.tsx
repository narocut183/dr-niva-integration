import { useCallback, useEffect, useState } from "react";
import { LayoutGrid, X, Smartphone } from "lucide-react";
import { NivaLogo } from "./components/ui";
import { SCREEN_GROUPS, type Screen } from "./lib/nav";
import { cn } from "./utils/cn";
import {
  SplashScreen,
  OnboardingScreen,
  LoginScreen,
  CompleteProfileScreen,
  LogoutScreen,
  FinalScreen,
} from "./screens/auth";
import { HomeScreen, CycleScreen, PregnancyScreen, FetalGrowthScreen, ChildScreen } from "./screens/home";
import { TestsScreen, TestDetailScreen, AiChatScreen, MentalScreen, MedsScreen } from "./screens/health";
import {
  CommunityScreen,
  FamilyScreen,
  CompanionNewsScreen,
  ProfileScreen,
  SettingsScreen,
  WalletScreen,
  AboutScreen,
} from "./screens/social";
import {
  EmptyScreen,
  ErrorScreen,
  LoadingScreen,
  SuccessScreen,
  ConfirmScreen,
  AddFormScreen,
} from "./screens/states";

const SCREENS: Record<Screen, (p: { go: (s: Screen) => void }) => React.JSX.Element> = {
  splash: SplashScreen,
  onboarding: OnboardingScreen,
  login: LoginScreen,
  "complete-profile": CompleteProfileScreen,
  home: HomeScreen,
  cycle: CycleScreen,
  pregnancy: PregnancyScreen,
  "fetal-growth": FetalGrowthScreen,
  child: ChildScreen,
  tests: TestsScreen,
  "test-detail": TestDetailScreen,
  "ai-chat": AiChatScreen,
  mental: MentalScreen,
  meds: MedsScreen,
  community: CommunityScreen,
  family: FamilyScreen,
  "companion-news": CompanionNewsScreen,
  profile: ProfileScreen,
  settings: SettingsScreen,
  wallet: WalletScreen,
  about: AboutScreen,
  logout: LogoutScreen,
  empty: EmptyScreen,
  error: ErrorScreen,
  loading: LoadingScreen,
  success: SuccessScreen,
  confirm: ConfirmScreen,
  "add-form": AddFormScreen,
  final: FinalScreen,
};

const isScreen = (v: string): v is Screen => v in SCREENS;

export default function App() {
  const [screen, setScreen] = useState<Screen>(() => {
    const h = window.location.hash.replace("#", "");
    return isScreen(h) ? h : "splash";
  });
  const [menuOpen, setMenuOpen] = useState(false);

  const go = useCallback((s: Screen) => {
    setScreen(s);
    setMenuOpen(false);
    window.location.hash = s;
  }, []);

  useEffect(() => {
    const onHash = () => {
      const h = window.location.hash.replace("#", "");
      if (isScreen(h)) setScreen(h);
    };
    window.addEventListener("hashchange", onHash);
    return () => window.removeEventListener("hashchange", onHash);
  }, []);

  const Current = SCREENS[screen];

  const Sidebar = (
    <aside className="flex flex-col h-full bg-white/80 backdrop-blur border-l border-niva-100 w-72 shrink-0">
      <div className="flex items-center gap-3 px-5 py-5 border-b border-niva-100">
        <div className="w-11 h-11 rounded-2xl niva-gradient flex items-center justify-center shadow-lg shadow-niva-500/30">
          <NivaLogo className="w-8 h-8" />
        </div>
        <div className="flex-1">
          <p className="font-black text-niva-900">دکتر نیوا</p>
          <p className="text-[11px] text-slate-400">Dr Niva · همراه هوشمند بانوان</p>
        </div>
        <button onClick={() => setMenuOpen(false)} className="lg:hidden p-2 rounded-xl hover:bg-niva-50 text-slate-400">
          <X className="w-5 h-5" />
        </button>
      </div>
      <div className="flex-1 overflow-y-auto thin-scroll px-3 py-4 space-y-5">
        {SCREEN_GROUPS.map((g) => (
          <div key={g.title}>
            <p className="text-[11px] font-bold text-slate-400 px-2 mb-2">{g.title}</p>
            <div className="space-y-0.5">
              {g.items.map((it) => (
                <button
                  key={it.id}
                  onClick={() => go(it.id)}
                  className={cn(
                    "w-full text-right px-3 py-2 rounded-xl text-sm transition flex items-center gap-2",
                    screen === it.id
                      ? "bg-niva-600 text-white font-bold shadow-md shadow-niva-500/25"
                      : "text-niva-900 hover:bg-niva-50",
                  )}
                >
                  <span className={cn("w-1.5 h-1.5 rounded-full", screen === it.id ? "bg-white" : "bg-niva-200")} />
                  {it.label}
                </button>
              ))}
            </div>
          </div>
        ))}
      </div>
      <div className="px-5 py-4 border-t border-niva-100 text-[11px] text-slate-400 flex items-center gap-2">
        <Smartphone className="w-4 h-4" /> طراحی اختصاصی · واکنش‌گرا برای وب و موبایل
      </div>
    </aside>
  );

  return (
    <div className="h-full w-full bg-[#e9f1fb] lg:flex lg:flex-row relative overflow-hidden">
      {/* decorative blobs for desktop */}
      <div className="hidden lg:block absolute -top-32 -right-32 w-[28rem] h-[28rem] rounded-full bg-niva-200/40 blur-3xl pointer-events-none" />
      <div className="hidden lg:block absolute -bottom-40 left-1/3 w-[30rem] h-[30rem] rounded-full bg-niva-300/30 blur-3xl pointer-events-none" />

      {/* Desktop sidebar */}
      <div className="hidden lg:block h-full relative z-10">{Sidebar}</div>

      {/* Mobile drawer */}
      {menuOpen && (
        <div className="lg:hidden fixed inset-0 z-50 flex">
          <div className="h-full">{Sidebar}</div>
          <button aria-label="بستن" className="flex-1 bg-black/30" onClick={() => setMenuOpen(false)} />
        </div>
      )}

      {/* Mobile floating menu button */}
      <button
        onClick={() => setMenuOpen(true)}
        aria-label="فهرست صفحات"
        className="lg:hidden fixed bottom-24 left-4 z-40 w-11 h-11 rounded-full bg-white/90 backdrop-blur shadow-lg border border-niva-100 text-niva-600 flex items-center justify-center"
      >
        <LayoutGrid className="w-5 h-5" />
      </button>

      {/* Stage */}
      <main className="h-full flex-1 relative z-10 flex flex-col items-center justify-center lg:p-6">
        <div className="hidden lg:flex items-center justify-between w-full max-w-5xl mb-4 px-2">
          <div>
            <h1 className="text-2xl font-black text-niva-900">
              Dr Niva <span className="text-niva-500">|</span> دکتر نیوا
            </h1>
            <p className="text-sm text-slate-500 mt-1">
              سلامت زنان، بارداری و کودک — طراحی رابط کاربری کامل با {SCREEN_GROUPS.reduce((a, g) => a + g.items.length, 0)} صفحه
            </p>
          </div>
          <span className="text-xs text-slate-400 bg-white/70 px-3 py-1.5 rounded-full border border-niva-100">
            صفحه فعلی: {SCREEN_GROUPS.flatMap((g) => g.items).find((i) => i.id === screen)?.label}
          </span>
        </div>

        {/* Phone frame on desktop; full-bleed on mobile */}
        <div
          className={cn(
            "w-full h-full lg:h-auto lg:w-[400px] lg:aspect-[9/19] lg:max-h-[calc(100vh-120px)]",
            "lg:rounded-[44px] lg:p-2.5 lg:bg-niva-900 lg:shadow-[0_40px_80px_-30px_rgba(26,58,121,0.55)] relative",
          )}
        >
          <div className="hidden lg:block absolute top-5 left-1/2 -translate-x-1/2 w-24 h-5 bg-niva-900 rounded-full z-20" />
          <div className="w-full h-full lg:rounded-[36px] overflow-hidden bg-white relative">
            <div key={screen} className="h-full">
              <Current go={go} />
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
