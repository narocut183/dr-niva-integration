<?php
/**
 * Plugin Name:       دکتر نیوا — همراه سلامت
 * Description:       کلینیک دیجیتال: مشاور هوش مصنوعی با سیستم اعتبار، تحلیل آزمایش، چرخه و بارداری، رشد نوزاد و یادآور — با اتصال به ووکامرس و فروشگاه‌های اپلیکیشن.
 * Version:           5.0.0
 * Requires at least: 6.4
 * Requires PHP:      7.4
 * Author:            Dr. Niva
 * License:           GPL-2.0-or-later
 * Text Domain:       dr-niva
 * Domain Path:       /languages
 * WC requires at least: 8.0
 *
 * @package DrNiva
 */

defined( 'ABSPATH' ) || exit;

define( 'DR_NIVA_VERSION', '5.0.0' );
define( 'DR_NIVA_FILE', __FILE__ );
define( 'DR_NIVA_PATH', plugin_dir_path( __FILE__ ) );
define( 'DR_NIVA_URL', plugin_dir_url( __FILE__ ) );
define( 'DR_NIVA_OPTION', 'dr_niva_settings' );
define( 'DR_NIVA_LAYOUT_OPTION', 'dr_niva_layout' );

require_once DR_NIVA_PATH . 'includes/class-niva-labs.php';
require_once DR_NIVA_PATH . 'includes/class-niva-db.php';
require_once DR_NIVA_PATH . 'includes/class-niva-modules.php';
require_once DR_NIVA_PATH . 'includes/class-niva-plans.php';
require_once DR_NIVA_PATH . 'includes/class-niva-partners.php';
require_once DR_NIVA_PATH . 'includes/class-niva-push.php';
require_once DR_NIVA_PATH . 'includes/class-niva-icons.php';
require_once DR_NIVA_PATH . 'includes/class-niva-links.php';
require_once DR_NIVA_PATH . 'includes/class-niva-profile.php';
require_once DR_NIVA_PATH . 'includes/class-niva-messages.php';
require_once DR_NIVA_PATH . 'includes/class-niva-chrome.php';
require_once DR_NIVA_PATH . 'includes/class-niva-insights.php';
require_once DR_NIVA_PATH . 'includes/class-niva-notifications.php';
require_once DR_NIVA_PATH . 'includes/class-niva-compat.php';
require_once DR_NIVA_PATH . 'includes/class-niva-settings.php';
require_once DR_NIVA_PATH . 'includes/class-niva-wallet.php';
require_once DR_NIVA_PATH . 'includes/class-niva-safety.php';
require_once DR_NIVA_PATH . 'includes/class-niva-ai.php';
require_once DR_NIVA_PATH . 'includes/class-niva-layout.php';
require_once DR_NIVA_PATH . 'includes/class-niva-rest.php';
require_once DR_NIVA_PATH . 'includes/class-niva-orders.php';
require_once DR_NIVA_PATH . 'includes/class-niva-reminders.php';
require_once DR_NIVA_PATH . 'elementor/class-niva-elementor.php';
require_once DR_NIVA_PATH . 'includes/class-niva-onboarding.php';
require_once DR_NIVA_PATH . 'includes/class-niva-community.php';
require_once DR_NIVA_PATH . 'includes/class-niva-companion.php';
require_once DR_NIVA_PATH . 'includes/class-niva-migrate.php';
require_once DR_NIVA_PATH . 'includes/class-niva-repair.php';
require_once DR_NIVA_PATH . 'includes/class-niva-subscription.php';
require_once DR_NIVA_PATH . 'includes/class-niva-menu.php';
require_once DR_NIVA_PATH . 'admin/class-niva-community-admin.php';
require_once DR_NIVA_PATH . 'admin/views/shell.php';
require_once DR_NIVA_PATH . 'admin/class-niva-users-admin.php';
require_once DR_NIVA_PATH . 'admin/class-niva-admin.php';
require_once DR_NIVA_PATH . 'admin/class-niva-data.php';
require_once DR_NIVA_PATH . 'admin/class-niva-partners-admin.php';
require_once DR_NIVA_PATH . 'admin/class-niva-health.php';
require_once DR_NIVA_PATH . 'admin/class-niva-messages-admin.php';
require_once DR_NIVA_PATH . 'public/class-niva-frontend.php';

/**
 * Main plugin container.
 */
/*
 * The container attaches its parts as properties while booting ($plans, $orders,
 * $profile, $onboarding, …). Declaring them all would mean touching every
 * bootstrap path, so the class opts in to dynamic properties explicitly — which
 * is exactly what the PHP 8.2 deprecation asks for, and is ignored on 7.4/8.0.
 */
#[\AllowDynamicProperties]
final class Dr_Niva_Plugin {

	/** @var Dr_Niva_Plugin|null */
	private static $instance = null;

	/** @var Niva_Settings */
	public $settings;

	/** @var Niva_Wallet */
	public $wallet;

	/** @var Niva_Plans|null */
	public $plans = null;

	/** @var Niva_Push|null */
	public $push = null;

	/** @var Niva_Notifications|null */
	public $notifications = null;

	/** @var Niva_Partners|null */
	public $partners = null;

	/** @var Niva_Links|null */
	public $links = null;

	/** @var Niva_Profile|null */
	public $profile = null;

	/** @var Niva_Messages|null */
	public $messages = null;

	/** @var Niva_Safety */
	public $safety;

	/** @var Niva_AI */
	public $ai;

	/** @var Niva_Layout */
	public $layout;

	/** @var Niva_Frontend|null */
	public $frontend = null;

	/** @var Niva_Orders|null */
	public $orders = null;

	public static function instance() : Dr_Niva_Plugin {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	private function __construct() {
		$this->settings = new Niva_Settings();
		$this->settings->migrate_palette();
		// Persian numerals everywhere, through WordPress' own number filter.
		add_filter( 'number_format_i18n', array( 'Niva_Chrome', 'localize_number' ), 10, 1 );
		$this->wallet   = new Niva_Wallet();
		$this->safety   = new Niva_Safety();
		$this->ai       = new Niva_AI();
		$this->layout   = new Niva_Layout();

		add_action( 'plugins_loaded', array( $this, 'boot' ) );
		add_action( 'admin_init', array( $this, 'ensure_tables' ), 5 );
		add_action( 'admin_init', array( $this, 'maybe_seed' ), 20 );

		/*
		 * 2.0.0 — build the header menu ourselves.
		 *
		 * The WXR importer refuses nav menu items when the menu term is missing
		 * and skips them silently, so the menu is created from PHP instead. It
		 * keeps retrying on each admin load until every page is present, then
		 * records that it finished.
		 */
		add_action(
			'admin_init',
			static function () {
				if ( get_option( 'dr_niva_menu_built' ) || ! class_exists( 'Niva_Menu' ) ) {
					return;
				}
				Niva_Menu::ensure();
			},
			12
		);

		// 2.0.0 — schema upgrade + one-off profile data migration.
		add_action( 'init', array( 'Niva_DB', 'maybe_upgrade' ), 1 );
		// Wrapped in a closure: WordPress passes '' as the first argument to
		// admin_init callbacks, which a typed int parameter would reject.
		add_action(
			'admin_init',
			static function () {
				Niva_Profile::maybe_migrate_legacy();
			},
			6
		);
	}

	public function boot() : void {
		add_filter( 'cron_schedules', array( $this, 'cron_schedules' ) );
		load_plugin_textdomain( 'dr-niva', false, dirname( plugin_basename( DR_NIVA_FILE ) ) . '/languages' );

		/*
		 * Each part is loaded in isolation: if one of them cannot start, the
		 * reason is recorded and the rest of the site keeps working.
		 */
		$this->start( 'messages', static function () {
			dr_niva()->messages = new Niva_Messages();
		} );
		$this->start( 'links', static function () {
			dr_niva()->links = new Niva_Links();
			// The page-key map is cached for a day; drop it the moment a page
			// changes so a freshly imported page is never missed by a link.
			add_action( 'save_post_page', array( 'Niva_Links', 'flush_page_map' ) );
			add_action( 'deleted_post', array( 'Niva_Links', 'flush_page_map' ) );
			add_action( 'edited_term', array( 'Niva_Links', 'flush_page_map' ) );
		} );
		$this->start( 'profile', static function () {
			dr_niva()->profile = new Niva_Profile();
		} );
		$this->start( 'onboarding', static function () {
			dr_niva()->onboarding = new Niva_Onboarding();
		} );
		$this->start( 'community', static function () {
			dr_niva()->community = new Niva_Community();
		} );
		$this->start( 'companion', static function () {
			dr_niva()->companion = new Niva_Companion();
		} );
		$this->start( 'subscription', static function () {
			dr_niva()->subscription = new Niva_Subscription();
		} );
		$this->start( 'migrate', static function () {
			// One-time move of the old «آوا» tables/meta onto the new names.
			new Niva_Migrate();
		} );
		$this->start( 'repair', static function () {
			// Keeps re-imports honest and repairs pages built by 2.0.0.
			new Niva_Repair();
		} );
		$this->start( 'plans', static function () {
			dr_niva()->plans = new Niva_Plans();
		} );
		$this->start( 'rest', static function () {
			new Niva_Rest();
		} );
		$this->start( 'orders', static function () {
			dr_niva()->orders = new Niva_Orders( dr_niva()->wallet, dr_niva()->settings );
		} );
		$this->start( 'frontend', static function () {
			dr_niva()->frontend = new Niva_Frontend( dr_niva()->settings, dr_niva()->layout, dr_niva()->wallet );
		} );
		$this->start( 'reminders', static function () {
			new Niva_Reminders();
		} );
		$this->start( 'admin', static function () {
			new Niva_Admin( dr_niva()->settings, dr_niva()->layout, dr_niva()->wallet );
		} );

		/*
		 * 3.0.1 — Niva_Community_Admin and Niva_Users_Admin own admin-post handlers
		 * (community moderation, user bulk/CSV/health/companion actions). They used
		 * to be created only while their own screen was rendered, so on
		 * admin-post.php the handler was never registered and WordPress answered
		 * with a completely blank page. They are now started on every admin request.
		 */
		$this->start( 'admin_actions', static function () {
			if ( ! is_admin() ) {
				return;
			}
			Niva_Community_Admin::instance();
			Niva_Users_Admin::instance( dr_niva()->settings, dr_niva()->wallet );
		} );
		$this->start( 'data', static function () {
			new Niva_Data( dr_niva()->settings, dr_niva()->wallet );
		} );
		$this->start( 'partners_admin', static function () {
			new Niva_Partners_Admin();
		} );
		$this->start( 'health', static function () {
			new Niva_Health();
		} );
		$this->start( 'messages_admin', static function () {
			new Niva_Messages_Admin();
		} );
		$this->start( 'elementor', static function () {
			new Niva_Elementor();
		} );
		$this->start( 'push', static function () {
			dr_niva()->push = new Niva_Push();
		} );
		$this->start( 'partners', static function () {
			dr_niva()->partners = new Niva_Partners();
		} );
		$this->start( 'notifications', static function () {
			dr_niva()->notifications = new Niva_Notifications();
		} );
		$this->start( 'chrome', static function () {
			new Niva_Chrome();
		} );

		add_action( 'dr_niva_daily_maintenance', array( $this, 'daily_maintenance' ) );
		if ( ! wp_next_scheduled( 'dr_niva_daily_maintenance' ) ) {
			wp_schedule_event( time() + 3600, 'daily', 'dr_niva_daily_maintenance' );
		}

		if ( ! wp_next_scheduled( 'dr_niva_every_minute' ) ) {
			wp_schedule_event( time() + 60, 'dr_niva_minute', 'dr_niva_every_minute' );
		}
		if ( ! wp_next_scheduled( 'dr_niva_daily' ) ) {
			wp_schedule_event( strtotime( 'tomorrow 07:00' ), 'daily', 'dr_niva_daily' );
		}
	}

	/** WordPress has no built-in one-minute interval. */
	public function cron_schedules( array $schedules ) : array {
		$schedules['dr_niva_minute'] = array(
			'interval' => MINUTE_IN_SECONDS,
			'display'  => 'هر دقیقه (دکتر نیوا)',
		);
		return $schedules;
	}

	/**
	 * Daily housekeeping: quota rollover happens lazily per user, here we only
	 * trim old logs so the tables stay small.
	 */
	public function daily_maintenance() : void {
		global $wpdb;
		$keep_days = (int) $this->settings->get( 'retention_chat_days' );
		if ( $keep_days > 0 ) {
			$table = Niva_DB::table( 'usage' );
			$wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < DATE_SUB(NOW(), INTERVAL %d DAY)", $keep_days ) ); // phpcs:ignore
		}
	}

	/**
	 * Runs one startup step; a failure is recorded instead of taking the site down.
	 */
	private function start( string $label, callable $factory ) : void {
		try {
			$factory();
		} catch ( \Throwable $error ) {
			if ( class_exists( 'Niva_Compat' ) ) {
				Niva_Compat::add_boot_error( $label, $error->getMessage() . ' @ ' . basename( $error->getFile() ) . ':' . $error->getLine() );
			}
		}
	}

	/** Runs on activation. */
	public static function activate() : void {
		delete_option( 'dr_niva_activation_error' );

		/*
		 * dbDelta() and the seeders can print MySQL notices, and WordPress counts
		 * ANY output produced during activation as a plugin error
		 * ("the plugin generated N characters of unexpected output"). The whole
		 * routine therefore runs inside a buffer that is always discarded.
		 */
		$buffered = false;
		if ( ! ob_get_level() ) {
			ob_start();
			$buffered = true;
		}

		try {
			if ( ! Niva_Compat::php_ok() ) {
				update_option( 'dr_niva_activation_error', 'نسخه‌ی PHP این سرور ' . PHP_VERSION . ' است؛ حداقل ۷.۴ لازم است.', false );
				return;
			}

			Niva_DB::install();
			flush_rewrite_rules();

			$settings = new Niva_Settings();
			$settings->seed_defaults();
			$layout = new Niva_Layout();
			$layout->seed_defaults();

			delete_option( 'dr_niva_needs_seed' );
			update_option( 'dr_niva_needs_seed', 1, false );

			if ( ! wp_next_scheduled( 'dr_niva_daily_maintenance' ) ) {
				wp_schedule_event( time() + 3600, 'daily', 'dr_niva_daily_maintenance' );
			}
			if ( ! wp_next_scheduled( 'dr_niva_every_minute' ) ) {
				wp_schedule_event( time() + 60, 'dr_niva_minute', 'dr_niva_every_minute' );
			}
			if ( ! wp_next_scheduled( 'dr_niva_daily' ) ) {
				wp_schedule_event( strtotime( 'tomorrow 07:00' ), 'daily', 'dr_niva_daily' );
			}
		} catch ( \Throwable $error ) {
			update_option(
				'dr_niva_activation_error',
				$error->getMessage() . ' @ ' . basename( $error->getFile() ) . ':' . $error->getLine(),
				false
			);
		} finally {
			// Discard only OUR buffer: WordPress (or another plugin) may own one too.
			if ( $buffered && ob_get_level() ) {
				ob_end_clean();
			}
		}
	}

	/** Repairs any table that is missing (runs before anything else touches the DB). */
	public function ensure_tables() : void {
		if ( class_exists( 'Niva_DB' ) ) {
			Niva_DB::ensure_tables();
		}
	}

	/** Imports the bundled message library once on activation or first admin visit. */
	public function maybe_seed() : void {
		if ( ! current_user_can( 'manage_options' ) || ! $this->messages ) {
			return;
		}
		$needs_seed = (bool) get_option( 'dr_niva_needs_seed' );
		if ( ! $needs_seed && $this->messages->count() > 0 ) {
			return;
		}
		if ( get_transient( 'dr_niva_seed_retry' ) ) {
			return;
		}

		try {
			$this->messages->seed();
			if ( $this->messages->count() < 1 ) {
				set_transient( 'dr_niva_seed_retry', 1, 10 * MINUTE_IN_SECONDS );
				Niva_Compat::add_boot_error( 'seed_messages', 'کتابخانهٔ پیام‌ها خالی است یا جدول پیام‌ها در دسترس نیست.' );
				return;
			}
			delete_option( 'dr_niva_needs_seed' );
			delete_transient( 'dr_niva_seed_retry' );
			if ( $needs_seed ) {
				$this->start( 'vapid', static function () {
					Niva_Notifications::ensure_vapid_keys();
				} );
			}
		} catch ( \Throwable $error ) {
			set_transient( 'dr_niva_seed_retry', 1, 10 * MINUTE_IN_SECONDS );
			Niva_Compat::add_boot_error( 'seed_messages', $error->getMessage() . ' @ ' . basename( $error->getFile() ) . ':' . $error->getLine() );
		}
	}

	/** Runs on deactivation. */
	public static function deactivate() : void {
		wp_clear_scheduled_hook( 'dr_niva_daily_maintenance' );
	}
}

register_activation_hook( __FILE__, array( 'Dr_Niva_Plugin', 'activate' ) );
register_deactivation_hook( __FILE__, array( 'Dr_Niva_Plugin', 'deactivate' ) );

/**
 * Global accessor used across the plugin.
 */
function dr_niva() : Dr_Niva_Plugin {
	return Dr_Niva_Plugin::instance();
}

Dr_Niva_Plugin::instance();
