/* ==========================================================================
   Dr. Niva — profile editing UI (2.0.0)
   Two entry points, one set of controls:
     1. [data-niva-wizard]  — the full-page onboarding wizard
     2. [data-niva-wheel] / [data-niva-calendar] — the inline editors used by
        «پروفایل من» and «تنظیمات من», so the user never meets a raw number
        input for the cycle, and always meets the same Jalali calendar.
   The step list, the order and who may see a step come from PHP.
   ========================================================================== */
(function () {
  'use strict';

  /* ------------------------------------------------------------ Jalali dates
     Same arithmetic as Niva_Chrome::jalali()/jalali_to_gregorian(); verified
     against the PHP implementation on 4000 dates spanning 1930–2028.        */

  function isLeapJalali(year) {
    var y = ((year % 33) + 33) % 33;
    return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(y) !== -1;
  }

  function jalaliMonthDays(year, month) {
    if (month <= 6) { return 31; }
    if (month <= 11) { return 30; }
    return isLeapJalali(year) ? 30 : 29;
  }

  function jalaliToGregorian(jy, jm, jd) {
    jy += 1595;
    var days = -355668 + (365 * jy) + (Math.floor(jy / 33) * 8) +
      Math.floor(((jy % 33) + 3) / 4) + jd +
      (jm < 7 ? (jm - 1) * 31 : ((jm - 7) * 30) + 186);
    var gy = 400 * Math.floor(days / 146097);
    days %= 146097;
    if (days > 36524) {
      days -= 1;
      gy += 100 * Math.floor(days / 36524);
      days %= 36524;
      if (days >= 365) { days += 1; }
    }
    gy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      gy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    var gd = days + 1;
    var leap = ((gy % 4 === 0 && gy % 100 !== 0) || gy % 400 === 0);
    var month = [0, 31, leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
    var gm = 1;
    while (gm <= 12 && gd > month[gm]) { gd -= month[gm]; gm += 1; }
    return [gy, gm, gd];
  }

  function gregorianToJalali(gy, gm, gd) {
    var gDays = [0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334];
    var jy = (gy <= 1600) ? 0 : 979;
    gy -= (gy <= 1600) ? 621 : 1600;
    var gy2 = (gm > 2) ? (gy + 1) : gy;
    var days = (365 * gy) + Math.floor((gy2 + 3) / 4) - Math.floor((gy2 + 99) / 100) +
      Math.floor((gy2 + 399) / 400) - 80 + gd + gDays[gm - 1];
    jy += 33 * Math.floor(days / 12053);
    days %= 12053;
    jy += 4 * Math.floor(days / 1461);
    days %= 1461;
    if (days > 365) {
      jy += Math.floor((days - 1) / 365);
      days = (days - 1) % 365;
    }
    var jm = (days < 186) ? 1 + Math.floor(days / 31) : 7 + Math.floor((days - 186) / 30);
    var jd = 1 + ((days < 186) ? (days % 31) : ((days - 186) % 30));
    return [jy, jm, jd];
  }

  function pad(n) { return (n < 10 ? '0' : '') + n; }
  function toIso(y, m, d) { return y + '-' + pad(m) + '-' + pad(d); }

  function isoToJalali(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    if (!m) { return null; }
    return gregorianToJalali(+m[1], +m[2], +m[3]);
  }

  function jalaliToIso(jy, jm, jd) {
    var g = jalaliToGregorian(jy, jm, jd);
    return toIso(g[0], g[1], g[2]);
  }

  function addDays(iso, days) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    if (!m) { return ''; }
    var date = new Date(+m[1], +m[2] - 1, +m[3]);
    date.setDate(date.getDate() + days);
    return toIso(date.getFullYear(), date.getMonth() + 1, date.getDate());
  }

  function faDigits(value) {
    var fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return String(value).replace(/\d/g, function (d) { return fa[+d]; });
  }

  function faDate(iso) {
    var j = isoToJalali(iso);
    return j ? faDigits(j[0] + '/' + pad(j[1]) + '/' + pad(j[2])) : '';
  }

  function todayJalali() {
    var now = new Date();
    return gregorianToJalali(now.getFullYear(), now.getMonth() + 1, now.getDate());
  }

  /** Saturday = 0, matching Niva_Chrome::weekday_index(). */
  function jalaliWeekdayIndex(jy, jm, jd) {
    var g = jalaliToGregorian(jy, jm, jd);
    return (new Date(g[0], g[1] - 1, g[2]).getDay() + 1) % 7;
  }

  function ageFromIso(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    if (!m) { return 0; }
    var now = new Date();
    var age = now.getFullYear() - (+m[1]);
    var md = (now.getMonth() + 1) * 100 + now.getDate();
    if (md < (+m[2]) * 100 + (+m[3])) { age -= 1; }
    return Math.max(0, age);
  }

  function weeksFromDue(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    if (!m) { return 0; }
    var due = new Date(+m[1], +m[2] - 1, +m[3]).getTime();
    return Math.max(0, Math.min(42, 40 - Math.round((due - Date.now()) / (7 * 86400000))));
  }

  function monthsSince(iso) {
    var m = /^(\d{4})-(\d{2})-(\d{2})$/.exec(iso || '');
    if (!m) { return 0; }
    var born = new Date(+m[1], +m[2] - 1, +m[3]).getTime();
    return Math.max(0, Math.floor((Date.now() - born) / (30.44 * 86400000)));
  }

  /* ---------------------------------------------------------------- locale */

  /** Persian defaults; PHP sends the authoritative lists when rendering. */
  var MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  var WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

  function setLocale(months, weekdays) {
    if (months && Object.keys(months).length) { MONTHS = months; }
    if (weekdays && weekdays.length) { WEEKDAYS = weekdays; }
  }

  function monthName(month) { return MONTHS[month] || MONTHS[String(month)] || ''; }

  function el(tag, className, text) {
    var node = document.createElement(tag);
    if (className) { node.className = className; }
    if (text !== undefined && text !== null) { node.textContent = text; }
    return node;
  }

  /* -------------------------------------------------------- shared widgets */

  /** Vertical number picker; the chosen value is exposed on `widget.dataset.read`. */
  function makeWheel(min, max, current, unit, onChange) {
    var wrap = el('div', 'niva-ob__wheel-wrap');
    var list = el('ul', 'niva-ob__wheel');
    list.setAttribute('role', 'listbox');
    list.setAttribute('aria-label', 'انتخاب عدد');
    list.dataset.picked = '';

    for (var n = min; n <= max; n += 1) {
      (function (value) {
        var li = el('li', 'niva-ob__wheel-item', faDigits(value) + (unit ? ' ' + unit : ''));
        li.setAttribute('role', 'option');
        li.tabIndex = 0;
        li.dataset.value = String(value);
        if (String(current) === String(value)) {
          li.classList.add('is-active');
          li.setAttribute('aria-selected', 'true');
          list.dataset.picked = String(value);
        }
        function pick() {
          Array.prototype.forEach.call(list.children, function (other) {
            other.classList.remove('is-active');
            other.removeAttribute('aria-selected');
          });
          li.classList.add('is-active');
          li.setAttribute('aria-selected', 'true');
          list.dataset.picked = li.dataset.value;
          if (typeof onChange === 'function') { onChange(li.dataset.value); }
        }
        li.addEventListener('click', pick);
        li.addEventListener('keydown', function (event) {
          if (event.key === 'Enter' || event.key === ' ') { event.preventDefault(); pick(); }
        });
        list.appendChild(li);
      }(n));
    }
    /*
     * 3.8.2 — with an empty profile no item matched `current`, so nothing was
     * marked and `dataset.picked` stayed empty; the step then sent `{}` (the log
     * showed `send step {"step":"birth","data":{}}`) and the date was never saved.
     * A wheel now always starts on a real value.
     */
    if (!list.dataset.picked) {
      var all = list.querySelectorAll('.niva-ob__wheel-item');
      var wanted = (min <= 1370 && max >= 1370) ? '1370' : String(Math.round((min + max) / 2));
      var chosen = null;
      Array.prototype.forEach.call(all, function (item) {
        if (!chosen && item.dataset.value === wanted) { chosen = item; }
      });
      if (!chosen && all.length) { chosen = all[Math.floor(all.length / 2)]; }
      if (chosen) {
        chosen.classList.add('is-active');
        chosen.setAttribute('aria-selected', 'true');
        list.dataset.picked = chosen.dataset.value;
        wrap.dataset.picked = chosen.dataset.value;
        try { list.scrollTop = Math.max(0, chosen.offsetTop - list.clientHeight / 2); } catch (error) { /* ignore */ }
      }
    }

    wrap.appendChild(list);
    wrap.avaRead = function () { return list.dataset.picked; };
    return wrap;
  }


  /*
   * 3.5.1 — `element.dataset.read = function () {}` looks like a method but the
   * DOM stores dataset values as STRINGS, so `dataset.read` was never callable
   * («hField.dataset.read is not a function»). Everything now goes through this
   * one accessor, which understands every control this wizard builds.
   */
  function nodeValue(node, fallback) {
    if (!node) { return fallback === undefined ? '' : fallback; }
    if (typeof node.avaRead === 'function') { return node.avaRead(); }
    if (typeof node.read === 'function') { return node.read(); }
    if (node.dataset && typeof node.dataset.read === 'function') { return nodeValue(node); }
    if (node.dataset && node.dataset.picked) { return node.dataset.picked; }
    if (node.querySelector) {
      var active = node.querySelector('.is-active[data-value], [aria-pressed="true"][data-value], [aria-selected="true"][data-value]');
      if (active && active.dataset.value) { return active.dataset.value; }
      var field = node.querySelector('input:not([type="range"]), select, textarea');
      if (field && field.value !== '' && field.value !== null) { return field.value; }
    }
    return fallback === undefined ? '' : fallback;
  }

  function makeNumberField(key, min, max, unit, current) {
    var wrap = el('div', 'niva-ob__number');
    var input = document.createElement('input');
    input.type = 'number';
    input.min = String(min);
    input.max = String(max);
    input.dir = 'ltr';
    input.className = 'field__input';
    input.setAttribute('aria-label', unit);
    input.setAttribute('data-niva-ob-key', key);
    if (current !== undefined && current !== '' && current !== null) { input.value = String(current); }

    var range = document.createElement('input');
    range.type = 'range';
    range.min = String(min);
    range.max = String(max);
    range.dir = 'ltr';
    range.className = 'niva-ob__range';
    range.value = input.value || String(Math.round((min + max) / 2));
    range.setAttribute('aria-label', 'انتخاب سریع ' + unit);
    range.addEventListener('input', function () { input.value = range.value; });
    input.addEventListener('input', function () { if (input.value) { range.value = input.value; } });

    wrap.appendChild(el('span', 'niva-ob__unit', unit));
    wrap.appendChild(input);
    wrap.appendChild(range);
    wrap.avaRead = function () { return input.value; };
    return wrap;
  }

  function makeCardChoice(options, current, multi, onChange) {
    var wrap = el('div', 'niva-ob__cards');
    var chosen = multi
      ? (Array.isArray(current) ? current.slice() : [])
      : [String(current || '')];
    options.forEach(function (option) {
      var button = el('button', 'niva-ob__card-choice');
      button.type = 'button';
      button.dataset.value = option.value;
      var on = chosen.indexOf(String(option.value)) !== -1;
      if (on) { button.classList.add('is-active'); }
      button.setAttribute('aria-pressed', on ? 'true' : 'false');
      if (option.icon && window.AvaIcons) {
        var ic = el('span', 'niva-ob__card-icon');
        ic.innerHTML = window.AvaIcons.svg(option.icon, 26);
        button.appendChild(ic);
      }
      button.appendChild(el('strong', null, option.label));
      if (option.note) { button.appendChild(el('span', 'niva-ob__card-note', option.note)); }
      button.addEventListener('click', function () {
        if (multi) {
          var isOn = button.classList.toggle('is-active');
          button.setAttribute('aria-pressed', isOn ? 'true' : 'false');
        } else {
          Array.prototype.forEach.call(wrap.children, function (other) {
            other.classList.remove('is-active');
            other.setAttribute('aria-pressed', 'false');
          });
          button.classList.add('is-active');
          button.setAttribute('aria-pressed', 'true');
        }
        if (typeof onChange === 'function') { onChange(nodeValue(wrap)); }
      });
      wrap.appendChild(button);
    });
    wrap.avaRead = function () {
      if (multi) {
        return Array.prototype.filter.call(wrap.children, function (b) {
          return b.classList.contains('is-active');
        }).map(function (b) { return b.dataset.value; });
      }
      var active = wrap.querySelector('.niva-ob__card-choice.is-active');
      return active ? active.dataset.value : '';
    };
    return wrap;
  }

  /**
   * Jalali month calendar. The caller owns `bag.iso` (Gregorian ISO); every pick
   * writes it back and calls `bag.onPick`, so a caller never reads internal state.
   */
  function makeCalendar(bag, options) {
    options = options || {};
    var minYear = options.minYear || 1300;
    var maxYear = options.maxYear || (new Date().getFullYear() - 621 + 1);
    var start = isoToJalali(bag.iso) || todayJalali();
    var view = { y: Math.min(maxYear, Math.max(minYear, start[0])), m: start[1] };

    var wrap = el('div', 'niva-ob__cal');
    var head = el('div', 'niva-ob__cal-head');
    var title = el('strong', 'niva-ob__cal-title');
    var older = el('button', 'niva-ob__cal-nav', '›');
    older.type = 'button';
    older.setAttribute('aria-label', 'ماه قبل');
    var newer = el('button', 'niva-ob__cal-nav', '‹');
    newer.type = 'button';
    newer.setAttribute('aria-label', 'ماه بعد');
    var grid = el('div', 'niva-ob__cal-grid');
    var valueOut = el('span', 'niva-ob__cal-value');
    var todayBtn = el('button', 'btn btn--ghost niva-ob__cal-today', 'امروز');
    todayBtn.type = 'button';

    function choose(y, m, d) {
      if (y < minYear || y > maxYear) { return; }
      bag.iso = jalaliToIso(y, m, d);
      if (typeof bag.onPick === 'function') { bag.onPick(bag.iso); }
      draw();
    }

    function draw() {
      title.textContent = monthName(view.m) + ' ' + faDigits(view.y);
      grid.innerHTML = '';
      WEEKDAYS.forEach(function (day) { grid.appendChild(el('span', 'niva-ob__cal-weekday', day)); });

      var offset = jalaliWeekdayIndex(view.y, view.m, 1);
      for (var i = 0; i < offset; i += 1) {
        grid.appendChild(el('span', 'niva-ob__cal-cell niva-ob__cal-cell--empty', ''));
      }
      var days = jalaliMonthDays(view.y, view.m);
      var today = todayJalali();
      var selected = isoToJalali(bag.iso);
      for (var d = 1; d <= days; d += 1) {
        (function (day) {
          var cell = el('button', 'niva-ob__cal-cell', faDigits(day));
          cell.type = 'button';
          if (today[0] === view.y && today[1] === view.m && today[2] === day) { cell.classList.add('is-today'); }
          if (selected && selected[0] === view.y && selected[1] === view.m && selected[2] === day) { cell.classList.add('is-active'); }
          cell.setAttribute('aria-label', faDigits(day) + ' ' + monthName(view.m) + ' ' + faDigits(view.y));
          cell.addEventListener('click', function () { choose(view.y, view.m, day); });
          grid.appendChild(cell);
        }(d));
      }
      valueOut.textContent = bag.iso ? faDate(bag.iso) : 'انتخاب نشده';
    }

    older.addEventListener('click', function () {
      view.m -= 1;
      if (view.m < 1) { view.m = 12; view.y -= 1; }
      if (view.y < minYear) { view.y = minYear; view.m = 1; }
      draw();
    });
    newer.addEventListener('click', function () {
      view.m += 1;
      if (view.m > 12) { view.m = 1; view.y += 1; }
      if (view.y > maxYear) { view.y = maxYear; view.m = 12; }
      draw();
    });
    todayBtn.addEventListener('click', function () {
      var t = todayJalali();
      if (t[0] < minYear || t[0] > maxYear) { return; }
      view.y = t[0];
      view.m = t[1];
      choose(t[0], t[1], t[2]);
    });

    head.appendChild(newer);
    head.appendChild(title);
    head.appendChild(older);
    var foot = el('div', 'niva-ob__cal-foot');
    foot.appendChild(valueOut);
    foot.appendChild(todayBtn);
    wrap.appendChild(head);
    wrap.appendChild(grid);
    wrap.appendChild(foot);
    draw();
    return wrap;
  }

  /* ==================================================================== wizard */

  function bootWizard(root) {
    if (!root || root.__avaWizardBooted) { return; }
    root.__avaWizardBooted = true;
    var config;
    try { config = JSON.parse(root.getAttribute('data-config') || '{}'); } catch (e) { return; }
    if (!config.order || !config.order.length) { return; }

    setLocale(config.months, config.weekdays);

    var state = config.state || {};
    var values = Object.assign({}, config.values || {});
    var order = config.order.slice();
    var steps = config.steps || {};
    /*
     * 3.6.0 — the wizard opens where the user really is:
     *  · ?niva_step=<id>      → that question, in «ویرایش» mode (saves and returns)
     *  · ?niva_edit=1         → edit mode without a target step
     *  · state.step          → the first unanswered question
     *  · already completed   → the summary, so nothing has to be walked again
     */
    if (window.NIVA_DEBUG && window.NIVA_DEBUG.note) {
      window.NIVA_DEBUG.note('wizard boot', { order: order, index: index, values: Object.keys(values || {}), state: state });
    }
    var params = (function () { try { return new window.URLSearchParams(location.search); } catch (error) { return null; } })();
    var jump = params ? String(params.get('niva_step') || '') : '';
    var editMode = !!(params && (params.get('niva_edit') === '1' || jump));
    // 3.7.0 — a token so a slow save can never rewrite the screen the user is on.
    var editToken = 0;

    var index = Math.max(0, order.indexOf(state.step || order[0]));
    if (jump && order.indexOf(jump) > -1) {
      index = order.indexOf(jump);
    } else if (!state.step && state.completed) {
      index = order.length;
    }
    var busy = false;
    var currentBag = null;

    var labelNode = root.querySelector('[data-niva-ob-label]');
    var titleNode = root.querySelector('[data-niva-ob-title]');
    var hintNode = root.querySelector('[data-niva-ob-hint]');
    var controlNode = root.querySelector('[data-niva-ob-control]');
    var errorNode = root.querySelector('[data-niva-ob-error]');
    var prevBtn = root.querySelector('[data-niva-ob-prev]');
    var nextBtn = root.querySelector('[data-niva-ob-next]');
    var skipBtn = root.querySelector('[data-niva-ob-skip]');
    var summaryNode = root.querySelector('[data-niva-ob-summary]');
    var bodyNode = root.querySelector('.niva-ob__body');
    var footNode = root.querySelector('.niva-ob__foot');

    function api(path, payload, isForm) {
      /* 2.0.1 — go through NIVA_FETCH when it is present: a response that is not
         JSON (a server error page) becomes a readable sentence instead of
         «Unexpected token '<'». */
      if (window.NIVA_FETCH && window.NIVA_FETCH.json) {
        return window.NIVA_FETCH.json(config.rest + path, {
          method: 'POST',
          body: payload,
          form: !!isForm,
          headers: { 'X-WP-Nonce': config.nonce }
        });
      }
      var options = { method: 'POST', credentials: 'same-origin', headers: { 'X-WP-Nonce': config.nonce } };
      if (isForm) { options.body = payload; }
      else {
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(payload || {});
      }
      return fetch(config.rest + path, options).then(function (res) {
        return res.text().then(function (text) {
          var json = null;
          try { json = text ? JSON.parse(text) : null; } catch (error) { json = null; }
          if (!res.ok || json === null) {
            throw new Error((json && json.message) ? json.message : 'ارتباط برقرار نشد؛ دوباره تلاش کن.');
          }
          return json;
        });
      });
    }

    /* --------------------------------------------------------- avatar upload
       The picture is resized in the browser before it is sent, so a multi
       megabyte phone photo can no longer exhaust the server and come back as
       an HTML crash page.                                                    */

    function avatarDataUrl(file, maxSide) {
      return new Promise(function (resolve, reject) {
        if (!file) { reject(new Error('عکسی انتخاب نشده است.')); return; }
        var reader = new FileReader();
        reader.onerror = function () { reject(new Error('عکس خوانده نشد؛ دوباره انتخاب کن.')); };
        reader.onload = function () {
          var image = new Image();
          image.onerror = function () { reject(new Error('این فایل، تصویر سالمی نیست.')); };
          image.onload = function () {
            try {
              var scale = Math.min(1, (maxSide || 1024) / Math.max(image.width, image.height));
              var canvas = document.createElement('canvas');
              canvas.width = Math.max(1, Math.round(image.width * scale));
              canvas.height = Math.max(1, Math.round(image.height * scale));
              canvas.getContext('2d').drawImage(image, 0, 0, canvas.width, canvas.height);
              resolve(canvas.toDataURL('image/jpeg', 0.9));
            } catch (error) {
              resolve(String(reader.result || ''));
            }
          };
          image.src = String(reader.result || '');
        };
        reader.readAsDataURL(file);
      });
    }

    function uploadAvatar(file) {
      return avatarDataUrl(file, 1024)
        .then(function (data) { return api('onboarding/avatar-json', { data: data }); })
        .catch(function (error) {
          var status = error && error.status ? Number(error.status) : 0;
          // A real validation answer (too big / wrong type) is final.
          if (status >= 400 && status < 500 && status !== 404) { throw error; }
          var form = new FormData();
          form.append('file', file);
          return api('onboarding/avatar', form, true);
        });
    }

    function setError(message) {
      errorNode.textContent = message || '';
      errorNode.hidden = !message;
    }

    function progress(fraction) {
      var percent = Math.round((fraction === undefined ? index / Math.max(1, order.length) : fraction) * 100);
      var fill = root.querySelector('[data-niva-ob-progress]');
      if (fill) { fill.style.width = percent + '%'; }
      var bar = root.querySelector('.niva-ob__progress');
      if (bar) { bar.setAttribute('aria-valuenow', String(percent)); }
    }

    function renderStep() {
      /*
       * 3.5.0 — the bag is created first and the step body is isolated: if a
       * question cannot build its own control, the wizard still shows it with a
       * simple fallback instead of dying (and `currentBag` is never null).
       */
      try {
        return buildStep();
      } catch (stepError) {
        if (window.console && console.warn) { console.warn('[niva] step build failed', order[index], stepError); }
        if (window.NIVA_DIAG && window.NIVA_DIAG.add) { window.NIVA_DIAG.add('step build: ' + order[index] + ' — ' + stepError.message); }
        controlNode.innerHTML = '';
        var fallback = document.createElement('p');
        fallback.className = 'niva-ob__hint-inline';
        fallback.textContent = 'این پرسش ساده نمایش داده می‌شود؛ می‌توانی رد کنی یا از «پروفایل من» کاملش کنی.';
        controlNode.appendChild(fallback);
        return { data: {}, read: function () { return {}; } };
      }
    }

    function buildStep() {
      // 3.0.3 — a step is always interactive: no stale lock can survive a render.
      busy = false;
      nextBtn.disabled = false;
      var id = order[index];
      var step = steps[id] || { title: '', hint: '', optional: true };
      labelNode.textContent = 'مرحله ' + faDigits(index + 1) + ' از ' + faDigits(order.length);
      titleNode.textContent = step.title;
      hintNode.textContent = step.hint || '';
      controlNode.innerHTML = '';
      setError('');
      skipBtn.hidden = !step.optional;
      prevBtn.hidden = index === 0;
      /* 2.0.1 — the label says what the button does: the next question, or the
         end of the wizard on the last one. «تأیید» told the user nothing. */
      var isLast = index === order.length - 1;
      nextBtn.textContent = editMode ? 'ذخیره' : (isLast ? 'پایان و ذخیره' : 'مرحله بعد');
      skipBtn.textContent = 'رد کردن این مرحله';
      controlNode.dataset.step = id;

      var bag = { data: {}, read: function () { return {}; } };

      if (id === 'name') {
        var first = el('input', 'field__input');
        first.type = 'text';
        first.placeholder = 'مثلاً سارا';
        first.value = values.first_name || '';
        first.setAttribute('aria-label', 'نام');

        var last = el('input', 'field__input');
        last.type = 'text';
        last.placeholder = 'مثلاً احمدی';
        last.value = values.last_name || '';
        last.setAttribute('aria-label', 'نام خانوادگی');

        var avatar = el('div', 'niva-ob__avatar');
        var preview = el('span', 'niva-ob__avatar-preview');
        if (values.avatar_url) { preview.style.backgroundImage = 'url("' + values.avatar_url + '")'; }
        var fileInput = el('input', 'niva-ob__avatar-input');
        fileInput.type = 'file';
        fileInput.accept = 'image/jpeg,image/png,image/webp';
        fileInput.addEventListener('change', function () {
          if (!fileInput.files || !fileInput.files[0]) { return; }
          setError('');
          preview.classList.add('is-loading');
          uploadAvatar(fileInput.files[0]).then(function (json) {
            if (json && json.url) {
              values.avatar_url = json.url;
              values.avatar_id = json.id;
              preview.style.backgroundImage = 'url("' + json.url + '")';
            } else {
              setError('عکس ذخیره نشد؛ دوباره تلاش کن.');
            }
          }).catch(function (err) {
            setError(err && err.message ? err.message : 'ارسال عکس ناموفق بود؛ دوباره تلاش کن.');
          }).then(function () {
            preview.classList.remove('is-loading');
          });
        });
        var avatarBtn = el('button', 'btn btn--ghost', 'انتخاب عکس');
        avatarBtn.type = 'button';
        avatarBtn.addEventListener('click', function () { fileInput.click(); });
        avatar.appendChild(preview);
        avatar.appendChild(avatarBtn);
        avatar.appendChild(fileInput);

        controlNode.appendChild(first);
        controlNode.appendChild(last);
        controlNode.appendChild(avatar);

        bag.read = function () {
          var out = {};
          if (first.value.trim()) { out.first_name = first.value.trim(); }
          if (last.value.trim()) { out.last_name = last.value.trim(); }
          if (values.avatar_id) { out.avatar_id = values.avatar_id; }
          bag.data = out;
          return out;
        };
      } else if (id === 'phone') {
        var phone = el('input', 'field__input');
        phone.type = 'tel';
        phone.dir = 'ltr';
        phone.placeholder = '09xxxxxxxxx';
        phone.value = values.phone || '';
        phone.setAttribute('aria-label', 'شمارهٔ موبایل');

        var code = el('input', 'field__input');
        code.type = 'text';
        code.dir = 'ltr';
        code.placeholder = 'کد ۶ رقمی';
        code.hidden = true;
        code.setAttribute('aria-label', 'کد تأیید');

        var sendBtn = el('button', 'btn btn--ghost', 'ارسال کد');
        sendBtn.type = 'button';
        var verifyBtn = el('button', 'btn btn--ghost', 'تأیید کد');
        verifyBtn.type = 'button';
        verifyBtn.hidden = true;

        if (values.phone_verified) {
          controlNode.appendChild(el('p', 'niva-ob__ok', 'شمارهٔ تو قبلاً تأیید شده است.'));
        }
        sendBtn.addEventListener('click', function () {
          setError('');
          api('onboarding/otp', { mode: 'send', phone: phone.value }).then(function () {
            code.hidden = false;
            verifyBtn.hidden = false;
          }).catch(function (err) {
            setError(err.message + ' می‌توانی فعلاً رد کنی.');
          });
        });
        verifyBtn.addEventListener('click', function () {
          api('onboarding/otp', { mode: 'verify', code: code.value, phone: phone.value })
            .then(function () { values.phone_verified = true; goNext(false); })
            .catch(function (err) { setError(err.message); });
        });

        controlNode.appendChild(phone);
        controlNode.appendChild(sendBtn);
        controlNode.appendChild(code);
        controlNode.appendChild(verifyBtn);
        bag.read = function () {
          bag.data = phone.value ? { phone: phone.value.replace(/[^0-9+]/g, '') } : {};
          return bag.data;
        };
      } else if (id === 'sex') {
        var sexCards = makeCardChoice([
          { value: 'female', label: 'خانم', icon: 'heart' },
          { value: 'male', label: 'آقا', icon: 'user' },
          { value: 'other', label: 'ترجیح می‌دهم نگویم', icon: 'shield-check' }
        ], values.sex);
        controlNode.appendChild(sexCards);
        bag.read = function () {
          var value = nodeValue(sexCards);
          bag.data = value ? { sex: value } : {};
          return bag.data;
        };
        // Picking an answer moves on by itself — one tap instead of two.
        sexCards.addEventListener('click', function () {
          window.setTimeout(function () { goNext(false); }, 160);
        });
      } else if (id === 'birth') {
        var current = isoToJalali(values.birth_date) || [];
        var yearPick = makeWheel(config.yearMin, config.yearMax, current[0], '', readBirth);
        var monthPick = makeWheel(1, 12, current[1], '', readBirth);
        var dayPick = makeWheel(1, 31, current[2], '', readBirth);
        var ageOut = el('p', 'niva-ob__ok', '');
        var readBirthValue = '';
        /*
         * 3.5.0 — the wheels expose their choice as `data-picked`, not as a
         * `dataset.read()` function. Calling the missing function threw inside
         * renderStep(), so this step never rendered and the wizard stopped here.
         */
        function wheelValue(node, fallback) {
          if (!node) { return parseInt(fallback, 10) || 0; }
          if (typeof node.dataset.read === 'function') {
            return parseInt(nodeValue(node), 10) || parseInt(fallback, 10) || 0;
          }
          var picked = parseInt(node.dataset.picked || '', 10);
          if (!picked) {
            var activeItem = node.querySelector ? node.querySelector('.is-active[data-value], [aria-selected="true"][data-value]') : null;
            if (activeItem) { picked = parseInt(activeItem.dataset.value, 10) || 0; }
          }
          if (!picked) {
            var inner = node.querySelector ? node.querySelector('[data-picked]') : null;
            if (inner) { picked = parseInt(inner.dataset.picked, 10) || 0; }
          }
          return picked || parseInt(fallback, 10) || 0;
        }
        function readBirth() {
          var y = wheelValue(yearPick, current[0]);
          var m = wheelValue(monthPick, current[1]);
          var d = wheelValue(dayPick, current[2]);
          if (!y || !m || !d) { ageOut.textContent = ''; readBirthValue = ''; return; }
          readBirthValue = jalaliToIso(y, m, d);
          var age = ageFromIso(readBirthValue);
          ageOut.textContent = age > 0 ? 'سن تو حدوداً ' + faDigits(age) + ' سال می‌شود.' : '';
        }
        controlNode.appendChild(yearPick);
        controlNode.appendChild(monthPick);
        controlNode.appendChild(dayPick);
        controlNode.appendChild(el('p', 'niva-ob__hint-inline', 'سال، ماه و روز تولد را با چرخ انتخاب کن.'));
        controlNode.appendChild(ageOut);
        readBirth();
        bag.read = function () {
          bag.data = readBirthValue ? { birth_date: readBirthValue } : {};
          return bag.data;
        };
      } else if (id === 'height') {
        var hField = makeNumberField('height', 120, 220, 'سانتی‌متر', values.height);
        controlNode.appendChild(hField);
        bag.read = function () {
          var v = nodeValue(hField);
          bag.data = v ? { height: v } : {};
          return bag.data;
        };
      } else if (id === 'weight') {
        var wField = makeNumberField('weight', 30, 200, 'کیلوگرم', values.weight);
        controlNode.appendChild(wField);
        bag.read = function () {
          var v = nodeValue(wField);
          bag.data = v ? { weight: v } : {};
          return bag.data;
        };
      } else if (id === 'lmp') {
        controlNode.appendChild(el('p', 'niva-ob__hint-inline', 'اگر نمی‌دانی، خالی بگذار و «رد کردن» را بزن؛ بعداً هم می‌شود اصلاح کرد.'));
        var lmpBag = { iso: values.lmp || '' };
        controlNode.appendChild(makeCalendar(lmpBag));
        bag.read = function () {
          bag.data = lmpBag.iso ? { lmp: lmpBag.iso } : {};
          return bag.data;
        };
      } else if (id === 'period_length') {
        controlNode.appendChild(el('p', 'niva-ob__hint-inline', 'می‌توانی حدودی وارد کنی.'));
        var pWheel = makeWheel(2, 10, values.period_length, 'روز');
        controlNode.appendChild(pWheel);
        bag.read = function () {
          var v = nodeValue(pWheel);
          bag.data = v ? { period_length: v } : {};
          return bag.data;
        };
      } else if (id === 'cycle_length') {
        controlNode.appendChild(el('p', 'niva-ob__hint-inline', 'از اولین روز پریود تا اولین روز پریود بعدی.'));
        var cWheel = makeWheel(21, 45, values.cycle_length, 'روز');
        controlNode.appendChild(cWheel);
        bag.read = function () {
          var v = nodeValue(cWheel);
          bag.data = v ? { cycle_length: v } : {};
          return bag.data;
        };
      } else if (id === 'pregnancy') {
        var pregCards = makeCardChoice([
          { value: 'yes', label: 'بله', icon: 'baby' },
          { value: 'no', label: 'خیر', icon: 'check-circle' },
          { value: 'unknown', label: 'نمی‌دانم', icon: 'help-circle' }
        ], values.pregnant ? 'yes' : '', false, function () {
          pregExtra.hidden = nodeValue(pregCards) !== 'yes';
        });
        var pregExtra = el('div', 'niva-ob__extra');
        pregExtra.hidden = !values.pregnant;
        var modeCards = makeCardChoice([
          { value: 'lmp', label: 'تاریخ آخرین پریود را می‌دانم' },
          { value: 'due', label: 'تاریخ زایمان تخمینی را می‌دانم' }
        ], 'lmp', false, function () { updateWeeks(); });
        var weekOut = el('p', 'niva-ob__ok', '');
        var pregBag = { iso: values.due_date || values.lmp || '', onPick: function () { updateWeeks(); } };
        function updateWeeks() {
          if (!pregBag.iso) { weekOut.textContent = ''; return; }
          var dueIso = nodeValue(modeCards) === 'due' ? pregBag.iso : addDays(pregBag.iso, 280);
          weekOut.textContent = 'هفتهٔ بارداری حدوداً ' + faDigits(weeksFromDue(dueIso)) +
            ' است. زایمان حدوداً ' + faDate(dueIso) + '. درست است؟';
        }
        pregExtra.appendChild(modeCards);
        pregExtra.appendChild(makeCalendar(pregBag));
        pregExtra.appendChild(weekOut);
        controlNode.appendChild(pregCards);
        controlNode.appendChild(pregExtra);
        updateWeeks();
        bag.read = function () {
          var answer = nodeValue(pregCards);
          if (answer === 'no' || answer === 'unknown') {
            bag.data = { pregnant: 0, lmp: '', due_date: '' };
            return bag.data;
          }
          if (answer === 'yes') {
            var isDue = nodeValue(modeCards) === 'due';
            bag.data = {
              pregnant: 1,
              lmp: isDue ? '' : (pregBag.iso || ''),
              due_date: isDue ? (pregBag.iso || '') : addDays(pregBag.iso || '', 280)
            };
            return bag.data;
          }
          bag.data = {};
          return bag.data;
        };
      } else if (id === 'baby') {
        var hasBaby = makeCardChoice([
          { value: 'yes', label: 'بله' },
          { value: 'no', label: 'خیر' }
        ], (values.baby_name || values.baby_birth) ? 'yes' : '', false, function () {
          babyExtra.hidden = nodeValue(hasBaby) !== 'yes';
        });
        var babyExtra = el('div', 'niva-ob__extra');
        babyExtra.hidden = !(values.baby_name || values.baby_birth);
        var babyName = el('input', 'field__input');
        babyName.type = 'text';
        babyName.placeholder = 'نام فرزند';
        babyName.value = values.baby_name || '';
        babyName.setAttribute('aria-label', 'نام فرزند');
        var babyAge = el('p', 'niva-ob__ok', '');
        var babyBag = {
          iso: values.baby_birth || '',
          onPick: function () {
            babyAge.textContent = babyBag.iso ? 'سن حدوداً ' + faDigits(monthsSince(babyBag.iso)) + ' ماه است.' : '';
          }
        };
        babyExtra.appendChild(babyName);
        babyExtra.appendChild(makeCalendar(babyBag));
        babyExtra.appendChild(babyAge);
        controlNode.appendChild(hasBaby);
        controlNode.appendChild(babyExtra);
        bag.read = function () {
          if (nodeValue(hasBaby) !== 'yes') {
            bag.data = { baby_name: '', baby_birth: '' };
            return bag.data;
          }
          bag.data = { baby_name: babyName.value.trim(), baby_birth: babyBag.iso || '' };
          return bag.data;
        };
      } else if (id === 'mood') {
        var moodCards = makeCardChoice([
          { value: '26', label: 'خوب', icon: 'smile' },
          { value: '20', label: 'بد نیست', icon: 'meh' },
          { value: '14', label: 'این‌طور که باید نه', icon: 'meh' },
          { value: '8', label: 'بی‌حوصله', icon: 'frown' },
          { value: '4', label: 'خیلی سخت', icon: 'frown' }
        ], '');
        controlNode.appendChild(moodCards);
        bag.read = function () {
          var v = nodeValue(moodCards);
          bag.data = v ? { mood_scores: v } : {};
          return bag.data;
        };
      } else if (id === 'notify') {
        controlNode.appendChild(el('p', 'niva-ob__hint-inline', 'یادآور دارو و قرار را برایت می‌فرستیم. هر وقت خواستی خاموشش کن.'));
        var allow = el('button', 'btn btn--primary', 'اجازه می‌دهم');
        allow.type = 'button';
        var channels = { inapp: 1, push: 0, email: 0 };
        allow.addEventListener('click', function () {
          function apply(permission) {
            channels.push = permission === 'granted' ? 1 : 0;
            allow.textContent = permission === 'granted' ? 'فعال شد' : 'فقط اعلان داخل اپ';
          }
          if (window.Notification && Notification.permission !== 'granted') {
            Notification.requestPermission().then(apply).catch(function () { apply('denied'); });
          } else {
            apply(window.Notification ? Notification.permission : 'denied');
          }
        });
        controlNode.appendChild(allow);
        bag.read = function () {
          bag.data = { channels: channels };
          return bag.data;
        };
      } else if (id === 'focus') {
        var areas = Object.keys(config.focus || {}).map(function (key) {
          return { value: key, label: config.focus[key].label, icon: config.focus[key].icon };
        });
        var focusCards = makeCardChoice(areas, values.focus_area);
        controlNode.appendChild(focusCards);
        bag.read = function () {
          var v = nodeValue(focusCards);
          bag.data = v ? { focus_area: v } : {};
          return bag.data;
        };
      } else {
        controlNode.appendChild(el('p', 'niva-ob__hint-inline', 'این مرحله فعلاً سؤالی ندارد.'));
      }

      return bag;
    }

    function validate(stepId, data) {
      if (stepId === 'name' && !data.first_name) { return 'نوشتن نام لازم است.'; }
      if (stepId === 'sex' && !data.sex) { return 'یکی از گزینه‌ها را انتخاب کن.'; }
      if (stepId === 'height' && data.height && (+data.height < 120 || +data.height > 220)) {
        return 'قد را بین ۱۲۰ تا ۲۲۰ سانتی‌متر وارد کن؛ می‌توانی حدودی بنویسی.';
      }
      if (stepId === 'weight' && data.weight && (+data.weight < 30 || +data.weight > 200)) {
        return 'وزن را بین ۳۰ تا ۲۰۰ کیلوگرم وارد کن؛ می‌توانی حدودی بنویسی.';
      }
      if (stepId === 'phone' && data.phone && !/^(\+?98|0)?9\d{9}$/.test(data.phone)) {
        return 'شمارهٔ موبایل را به شکل 09xxxxxxxxx وارد کن.';
      }
      return '';
    }

    /*
     * 3.0.2 — the wizard used to wait for the server before every step: while
     * the request was in flight the button stayed dead (it looked frozen on
     * «جنسیت») and any failed request stopped the whole flow. Answers are now
     * queued, the next question renders at once, and only the last save waits.
     */
    var pendingSteps = [];

    function queueStep(stepId, data, skip) {
      var request = api('onboarding/step', { step: stepId, data: data, skip: !!skip })
        .then(function (json) {
          if (window.NIVA_DEBUG && window.NIVA_DEBUG.api) { window.NIVA_DEBUG.api('step saved', { step: stepId, state: json && json.state }); }
          var nextState = json.state || {};
          values = Object.assign({}, values, nextState.values || {});
          if (nextState.steps) { steps = nextState.steps; }
          if (nextState.order && nextState.order.length) {
            order = nextState.order;
            var shown = order[index];
            var target = order.indexOf(nextState.step || '');
            // The answer opened or closed a branch: follow the server order.
            if (target > -1 && (shown === undefined || order.indexOf(shown) === -1)) {
              index = target;
              currentBag = renderStep();
              progress();
            }
          }
          return json;
        })
        .catch(function (error) {
          if (window.NIVA_DEBUG && window.NIVA_DEBUG.api) { window.NIVA_DEBUG.api('step save FAILED', { step: stepId, error: error && error.message }); }
          setError('این پاسخ ذخیره نشد؛ در پایان یک‌بار دیگر تلاش می‌شود.');
          if (window.console && console.warn) { console.warn('[niva] step save failed', error); }
          return null;
        });
      pendingSteps.push(request);
      return request;
    }

    var failStreak = {};

    /*
     * 3.1.0 — read whatever the current step actually rendered (inputs, selects,
     * textareas and the optional `data-niva-ob-field` hints) so a missing reader
     * can never turn into a lost answer.
     */
    function harvest(stepId) {
      var out = {};
      var control = document.querySelector('[data-niva-ob-control]');
      if (!control) { return out; }
      Array.prototype.forEach.call(control.querySelectorAll('input, select, textarea'), function (field) {
        var name = field.getAttribute('data-niva-ob-field') || field.getAttribute('name') || '';
        if (!name) { return; }
        if (field.type === 'checkbox') {
          if (field.checked) { out[name] = field.value || 1; }
          return;
        }
        if (field.type === 'radio') {
          if (field.checked) { out[name] = field.value; }
          return;
        }
        if (field.type === 'file') { return; }
        if (field.value === '' || field.value === null) { return; }
        out[name] = field.value;
      });
      if (!Object.keys(out).length && typeof currentBag.read === 'function') {
        try { out = currentBag.read() || out; } catch (error) { /* ignore */ }
      }
      return out;
    }

    function goNext(skip) {
      if (busy) { return; }
      var stepId = order[index];
      var data = {};
      var problem = '';

      try {
        data = {};
        if (!skip && currentBag && typeof currentBag.read === 'function') {
          try {
            data = currentBag.read() || {};
          } catch (readError) {
            // Console only: the user must never see an internal read problem.
            data = {};
            if (window.console && console.warn) { console.warn('[niva] step reader failed', readError); }
          }
        }
        /*
         * 3.1.0 — if a step's own reader returns nothing, harvest every named
         * field inside it. Steps whose reader was missing sent nothing at all,
         * which is why answers were never saved.
         */
        if (!skip && (!data || !Object.keys(data).length)) {
          data = harvest(stepId);
        }
        problem = skip ? '' : validate(stepId, data);
      } catch (error) {
        problem = 'خواندن پاسخ این مرحله ممکن نشد.';
        if (window.console && console.warn) { console.warn('[niva] read step failed', error); }
      }

      if (problem) {
        if (window.NIVA_DEBUG && window.NIVA_DEBUG.step) { window.NIVA_DEBUG.step('validation refused', { step: stepId, problem: problem, data: data }); }
        /*
         * 3.1.0 — never trap the user, and never lose the answer: after the
         * second refusal the wizard moves on but still sends what it has.
         */
        failStreak[stepId] = (failStreak[stepId] || 0) + 1;
        if (failStreak[stepId] < 2) {
          setError(problem);
          return;
        }
        setError('');
        // 3.3.0 — no «later» wording: whatever is missing is written again on
        // the last screen, so the user is never told to redo anything.
        if (window.console && console.warn) { console.warn('[niva] step not sent, will be saved at the end'); }
        data = (!data || !Object.keys(data).length) ? harvest(stepId) : data;
      } else {
        failStreak[stepId] = 0;
      }
      setError('');

      if (window.NIVA_DEBUG && window.NIVA_DEBUG.api) {
        window.NIVA_DEBUG.api('send step', { step: stepId, data: data, skip: !!skip, editMode: editMode });
        if (stepId === 'birth') {
          window.NIVA_DEBUG.api('birth wheels', {
            years: document.querySelectorAll('.niva-ob__wheel-item.is-active').length,
            picked: Array.prototype.map.call(document.querySelectorAll('[data-picked]'), function (n) { return n.dataset.picked; })
          });
        }
      }
      values = Object.assign({}, values, data);
      var saved = queueStep(stepId, data, skip);

      if (editMode) {
        var myToken = ++editToken;
        saved.then(function (json) {
          if (myToken !== editToken) { return; }              // the user moved on
          if (!json) {
            setError('ذخیره نشد؛ یک بار دیگر بزن.');
            return;
          }
          editMode = false;
          // Read the truth back from the server before showing the summary.
          api('onboarding/state', {}).then(function (fresh) {
            var next = fresh && fresh.state ? fresh.state : {};
            values = next.values || values;
            steps = next.steps || steps;
            order = next.order || order;
            showSummary();
            if (window.NIVA_TOAST) { window.NIVA_TOAST('ذخیره شد.'); }
          }).catch(function () {
            showSummary();
            if (window.NIVA_TOAST) { window.NIVA_TOAST('ذخیره شد.'); }
          });
        });
        return;
      }

      // «بارداری» decides what comes next, so that one waits for the answer.
      if (stepId === 'pregnancy') {
        busy = true;
        nextBtn.disabled = true;
        // Never leave the button locked if the answer never arrives.
        var release = function () { busy = false; nextBtn.disabled = false; };
        window.setTimeout(release, 6000);
        saved.then(function (json) {
          release();
          var next = json && json.state && json.state.step ? order.indexOf(json.state.step) : index + 1;
          if (next === -1 || next >= order.length) { showSummary(); return; }
          index = next;
          currentBag = renderStep();
          progress();
        });
        return;
      }

      var following = index + 1;
      if (following >= order.length) { showSummary(); return; }
      index = following;
      currentBag = renderStep();
      progress();
    }

    function summaryValue(key) {
      switch (key) {
        case 'name': return ((values.first_name || '') + ' ' + (values.last_name || '')).trim() || 'ثبت نشده';
        case 'sex':
          if (values.sex === 'female') { return 'خانم'; }
          if (values.sex === 'male') { return 'آقا'; }
          return values.sex ? 'ترجیح می‌دهم نگویم' : 'ثبت نشده';
        case 'birth': return faDate(values.birth_date) || 'ثبت نشده';
        case 'height': return values.height ? faDigits(values.height) + ' سانتی‌متر' : 'ثبت نشده';
        case 'weight': return values.weight ? faDigits(values.weight) + ' کیلوگرم' : 'ثبت نشده';
        case 'lmp': return faDate(values.lmp) || 'ثبت نشده';
        case 'period_length': return values.period_length ? faDigits(values.period_length) + ' روز' : 'ثبت نشده';
        case 'cycle_length': return values.cycle_length ? faDigits(values.cycle_length) + ' روز' : 'ثبت نشده';
        case 'pregnancy': return values.pregnant ? 'باردار' : 'باردار نیست';
        case 'baby': return (values.baby_name || values.baby_birth)
          ? ((values.baby_name || 'فرزند') + ' · ' + (faDate(values.baby_birth) || ''))
          : 'ثبت نشده';
        case 'focus': return (config.focus && config.focus[values.focus_area]) ? config.focus[values.focus_area].label : 'انتخاب نشده';
      }
      return '—';
    }

    function showSummary() {
      bodyNode.hidden = true;
      footNode.hidden = true;
      skipBtn.hidden = true;

      summaryNode.innerHTML = '';
      var card = el('div', 'niva-ob__card');
      card.appendChild(el('h2', null, 'همه‌چیز آماده است'));
      card.appendChild(el('p', null, 'این‌ها را ثبت کردیم. هر وقت خواستی از «پروفایل من» اصلاحش کن.'));

      var labels = {
        name: 'نام', sex: 'جنسیت', birth: 'تاریخ تولد', height: 'قد', weight: 'وزن',
        lmp: 'آخرین پریود', period_length: 'مدت پریود', cycle_length: 'طول سیکل',
        pregnancy: 'بارداری', baby: 'فرزند', focus: 'مسیر پیشنهادی'
      };
      var list = el('dl', 'niva-ob__summary-list');
      Object.keys(labels).forEach(function (key) {
        if (!steps[key]) { return; }
        list.appendChild(el('dt', null, labels[key]));
        var dd = el('dd', null, summaryValue(key));
        var edit = el('button', 'niva-ob__edit', 'ویرایش');
        edit.type = 'button';
        edit.addEventListener('click', function () {
          editMode = true;
          editToken++;
          index = order.indexOf(key);
          bodyNode.hidden = false;
          footNode.hidden = false;
          summaryNode.hidden = true;
          currentBag = renderStep();
          progress();
        });
        dd.appendChild(edit);
        list.appendChild(dd);
      });
      card.appendChild(list);

      var start = el('button', 'btn btn--primary btn--block', 'شروع');
      start.type = 'button';
      start.addEventListener('click', function () {
        start.disabled = true;
        Promise.all(pendingSteps).then(function () { return api('onboarding/complete', { data: values }); }).then(function () {
          window.location.href = config.profileUrl;
        }).catch(function () {
          window.location.href = config.profileUrl;
        });
      });
      card.appendChild(start);
      summaryNode.appendChild(card);
      summaryNode.hidden = false;
      progress(1);
    }

    prevBtn.addEventListener('click', function () {
      if (index > 0) {
        index -= 1;
        summaryNode.hidden = true;
        bodyNode.hidden = false;
        footNode.hidden = false;
        currentBag = renderStep();
        progress();
      }
    });
    skipBtn.addEventListener('click', function () { goNext(true); });
    nextBtn.addEventListener('click', function () { goNext(false); });
    root.querySelector('[data-niva-ob-close]').addEventListener('click', function (event) {
      event.preventDefault();
      window.location.href = config.profileUrl;
    });

    currentBag = renderStep();
    progress();
    if (state.completed) { showSummary(); }
  }

  /* ================================================ inline editors (profile) */

  /**
   * Upgrades the profile screens:
   *   <div data-niva-wheel="pf-cycle-length" data-min="21" data-max="45" data-unit="روز"></div>
   *   <div data-niva-calendar="pf-lmp" data-max-year="1405"></div>
   * The hidden input keeps the same id, so the existing save code is untouched.
   */
  function bootEditors() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-wheel]'), function (host) {
      var target = document.getElementById(host.getAttribute('data-niva-wheel'));
      if (!target || host.dataset.avaReady) { return; }
      host.dataset.avaReady = '1';
      var min = parseInt(host.dataset.min, 10) || 1;
      var max = parseInt(host.dataset.max, 10) || 31;
      var unit = host.dataset.unit || '';
      host.appendChild(makeWheel(min, max, target.value, unit, function (value) {
        target.value = value;
        target.dispatchEvent(new Event('change', { bubbles: true }));
      }));
    });

    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-calendar]'), function (host) {
      var target = document.getElementById(host.getAttribute('data-niva-calendar'));
      if (!target || host.dataset.avaReady) { return; }
      host.dataset.avaReady = '1';
      var bag = {
        iso: target.value || '',
        onPick: function (iso) {
          target.value = iso;
          target.dispatchEvent(new Event('change', { bubbles: true }));
          var out = host.querySelector('[data-niva-calendar-output]');
          if (out) { out.textContent = faDate(iso); }
        }
      };
      host.appendChild(makeCalendar(bag, {
        minYear: parseInt(host.dataset.minYear, 10) || 1300,
        maxYear: parseInt(host.dataset.maxYear, 10) || undefined
      }));
    });
  }

  /* -------------------------------------------------- completion card (home) */

  function bootSnooze() {
    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-ob-snooze]'), function (button) {
      button.addEventListener('click', function () {
        var card = button.closest('[data-niva-completion]');
        var hide = function () { if (card) { card.remove(); } };
        if (!card) { hide(); return; }
        var rest = card.getAttribute('data-rest');
        var nonce = card.getAttribute('data-nonce');
        if (!rest) { hide(); return; }
        fetch(rest + 'onboarding/snooze', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
          body: JSON.stringify({})
        }).then(hide).catch(hide);
      });
    });
  }

  /* 3.0.1 — the screen can be replaced in place by the in-app router, so
     the initialiser runs again on every view change (bindings below are
     idempotent or attach to the freshly rendered nodes). */
  function ready(fn) {
    var run = function () { try { fn(); } catch (error) { if (window.console && console.warn) console.warn('[niva]', error); } };
    if (document.readyState !== 'loading') { run(); } else { document.addEventListener('DOMContentLoaded', run); }
    document.addEventListener('niva:view-ready', run);
    document.addEventListener('niva:view-changed', run);
  }
  function readyLegacy(fn) {
    if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
  }

  ready(function () {
    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-wizard]'), bootWizard);
    bootEditors();
    bootSnooze();
  });

  /* Exposed for the automated comparison against the PHP calendar. */
  window.AvaOnboarding = {
    gregorianToJalali: gregorianToJalali,
    jalaliToGregorian: jalaliToGregorian,
    jalaliMonthDays: jalaliMonthDays,
    isLeapJalali: isLeapJalali,
    faDate: faDate,
    bootEditors: bootEditors
  };
}());
