(function () {
  'use strict';

  var config = window.DR_NIVA_CHROME || {};

  function request(path, options) {
    var settings = options || {};
    settings.credentials = 'same-origin';
    settings.headers = Object.assign({
      'Accept': 'application/json',
      'X-WP-Nonce': config.nonce || ''
    }, settings.headers || {});
    return fetch((config.rest || '') + path, settings).then(function (response) {
      return response.text().then(function (text) {
        var payload;
        try {
          payload = text ? JSON.parse(text) : {};
        } catch (error) {
          throw new Error('پاسخ سرور برای این درخواست قابل‌خواندن نیست.');
        }
        if (!response.ok) {
          throw new Error(payload && payload.message ? payload.message : 'دریافت اعلان‌ها انجام نشد.');
        }
        return payload;
      });
    });
  }

  function pushBytes(value) {
    var padding = '='.repeat((4 - (value.length % 4)) % 4);
    var raw = window.atob((value + padding).replace(/-/g, '+').replace(/_/g, '/'));
    return Uint8Array.from(raw, function (character) { return character.charCodeAt(0); });
  }

  function enablePush() {
    var push = config.push || {};
    if (!window.isSecureContext || !('serviceWorker' in navigator) || !('PushManager' in window) || !window.Notification) {
      return Promise.reject(new Error('این مرورگر یا اتصال امن، اعلان پوش را پشتیبانی نمی‌کند.'));
    }
    if (!push.enabled || !push.publicKey) {
      return Promise.reject(new Error('اجازهٔ اعلان مرورگر فعال شد، اما مدیر سایت هنوز سرویس پوش را راه‌اندازی نکرده است.'));
    }
    return navigator.serviceWorker.register(push.sw).then(function (registration) {
      return registration.pushManager.getSubscription().then(function (subscription) {
        return subscription || registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: pushBytes(push.publicKey)
        });
      });
    }).then(function (subscription) {
      return fetch(push.endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': push.nonce || '' },
        body: JSON.stringify(subscription.toJSON())
      }).then(function (response) {
        if (!response.ok) return response.json().then(function (payload) {
          throw new Error(payload && payload.message ? payload.message : 'ثبت اعلان پوش در سرور انجام نشد.');
        });
      });
    });
  }

  function bindDrawer() {
  document.querySelectorAll('[data-chrome-drawer-open]').forEach(function (button) {
    var nav = document.getElementById(button.getAttribute('aria-controls'));
    var header = button.closest('.niva-header');
    var scrim = header ? header.querySelector('[data-chrome-drawer-close]') : null;
    if (!nav || !scrim) return;

    function setOpen(open) {
      document.body.classList.toggle('niva-nav-open', open);
      button.setAttribute('aria-expanded', open ? 'true' : 'false');
      if (open) {
        var firstLink = nav.querySelector('a');
        if (firstLink) firstLink.focus();
      } else {
        button.focus();
      }
    }

    button.addEventListener('click', function () {
      setOpen(button.getAttribute('aria-expanded') !== 'true');
    });
    scrim.addEventListener('click', function () {
      setOpen(false);
    });
    nav.addEventListener('click', function (event) {
      if (event.target instanceof Element && event.target.closest('a')) setOpen(false);
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && button.getAttribute('aria-expanded') === 'true') {
        setOpen(false);
      }
    });
  });

  }

  function bindNotifications() {
  document.querySelectorAll('[data-chrome-notifications-open]').forEach(function (button) {
    var sheet = document.getElementById(button.getAttribute('aria-controls'));
    if (!sheet) return;
    if (sheet.getAttribute('data-chrome-bound') === '1') return;
    sheet.setAttribute('data-chrome-bound', '1');

    var list = sheet.querySelector('[data-chrome-notification-items]');
    var status = sheet.querySelector('[data-chrome-notification-status]');
    var count = sheet.querySelector('[data-chrome-notification-count]');
    var badge = button.querySelector('[data-chrome-notification-badge]');
    var panel = sheet.querySelector('[role="dialog"]');
    var items = [];

    function paintCount(unread) {
      var total = Math.max(0, Number(unread) || 0);
      button.setAttribute('aria-label', 'اعلان‌ها' + (total ? '، ' + total + ' خوانده‌نشده' : ''));
      if (badge) {
        badge.textContent = String(Math.min(total, 99));
        badge.hidden = total === 0;
      }
      if (count) count.textContent = total ? total + ' خوانده‌نشده' : 'همهٔ اعلان‌ها خوانده شده‌اند';
    }

    function paintItems() {
      list.replaceChildren();
      if (!items.length) {
        var empty = document.createElement('p');
        empty.className = 'niva-chrome-notifications__empty';
        empty.textContent = 'هنوز اعلانی برای نمایش نداری.';
        list.appendChild(empty);
        return;
      }
      items.forEach(function (item) {
        var row = document.createElement('article');
        row.className = 'niva-chrome-notifications__item' + (Number(item.is_read) ? ' is-read' : '');
        var title = document.createElement('strong');
        title.textContent = item.title || 'اعلان';
        var body = document.createElement('p');
        body.textContent = item.body || '';
        var date = document.createElement('time');
        date.textContent = item.created_at_label || '';
        row.append(title, body, date);
        if (!Number(item.is_read)) {
          var mark = document.createElement('button');
          mark.type = 'button';
          mark.className = 'niva-chrome-notifications__mark';
          mark.textContent = 'خوانده شد';
          mark.addEventListener('click', function () {
            mark.disabled = true;
            request('/notifications', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ id: item.id })
            }).then(function () {
              item.is_read = 1;
              paintCount(items.filter(function (entry) { return !Number(entry.is_read); }).length);
              paintItems();
            }).catch(function (error) {
              mark.disabled = false;
              status.textContent = error.message;
            });
          });
          row.appendChild(mark);
        }
        list.appendChild(row);
      });
      if (items.some(function (item) { return !Number(item.is_read); })) {
        var markAll = document.createElement('button');
        markAll.type = 'button';
        markAll.className = 'niva-chrome-notifications__all';
        markAll.textContent = 'همه را خوانده‌شده کن';
        markAll.addEventListener('click', function () {
          markAll.disabled = true;
          request('/notifications', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ id: 0 })
          }).then(function () {
            items.forEach(function (item) { item.is_read = 1; });
            paintCount(0);
            paintItems();
          }).catch(function (error) {
            markAll.disabled = false;
            status.textContent = error.message;
          });
        });
        list.appendChild(markAll);
      }
    }

    function close() {
      sheet.hidden = true;
      button.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('niva-header-notifications-open');
      button.focus();
    }

    function loadNotifications(pushError) {
      status.textContent = 'در حال دریافت اعلان‌ها…';
      list.replaceChildren();
      request('/notifications').then(function (payload) {
        items = Array.isArray(payload.items) ? payload.items : [];
        status.textContent = pushError || '';
        paintCount(payload.unread);
        paintItems();
      }).catch(function (error) {
        status.textContent = error.message;
      });
    }

    function showPermissionPrompt() {
      list.replaceChildren();
      if (!window.Notification) {
        status.textContent = 'این مرورگر اعلان‌های سیستم را پشتیبانی نمی‌کند.';
        return;
      }
      if ('denied' === Notification.permission) {
        status.textContent = 'اجازهٔ اعلان برای این سایت مسدود شده است. از تنظیمات مرورگر، اعلان‌های این سایت را مجاز کن و دوباره این بخش را باز کن.';
        return;
      }
      status.textContent = 'برای دیدن اعلان‌ها، ابتدا اجازهٔ اعلان این سایت را فعال کن.';
      var allow = document.createElement('button');
      allow.type = 'button';
      allow.className = 'niva-chrome-notifications__allow';
      allow.textContent = 'اجازه و نمایش اعلان‌ها';
      allow.addEventListener('click', function () {
        allow.disabled = true;
        Notification.requestPermission().then(function (permission) {
          if ('granted' !== permission) {
            status.textContent = 'اجازه داده نشد؛ برای فعال‌سازی، دسترسی اعلان این سایت را در تنظیمات مرورگر تغییر بده.';
            return;
          }
          status.textContent = 'دسترسی فعال شد؛ در حال آماده‌سازی اعلان پوش…';
          enablePush().then(function () {
            loadNotifications('');
          }).catch(function (error) {
            loadNotifications(error.message);
          });
        }).catch(function (error) {
          status.textContent = error.message || 'درخواست اجازهٔ اعلان انجام نشد.';
          allow.disabled = false;
        });
      });
      list.appendChild(allow);
    }

    button.addEventListener('click', function () {
      sheet.hidden = false;
      button.setAttribute('aria-expanded', 'true');
      document.body.classList.add('niva-header-notifications-open');
      panel.focus();
      list.replaceChildren();
      if (!config.loggedIn) {
        status.textContent = 'برای دیدن اعلان‌ها وارد حساب کاربری‌ات شو.';
        var login = document.createElement('a');
        login.href = config.loginUrl || '/wp-login.php';
        login.className = 'niva-chrome-notifications__login';
        login.textContent = 'ورود / ثبت‌نام';
        list.appendChild(login);
        return;
      }
      if (!window.Notification || 'granted' !== Notification.permission) {
        showPermissionPrompt();
        return;
      }
      loadNotifications();
    });

    sheet.querySelectorAll('[data-chrome-notifications-close]').forEach(function (closeButton) {
      closeButton.addEventListener('click', close);
    });
    sheet.addEventListener('click', function (event) {
      if (event.target.classList.contains('niva-chrome-notifications__scrim')) close();
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && !sheet.hidden) close();
    });
  });
  }

  /* 3.0.1 — NIVA_BOOT() rebuilds the header/footer on every in-app navigation,
     so the drawer and notification buttons are re-wired each time the view
     changes (and once on load). */
  function bindChrome() {
    var header = document.querySelector('.niva-header');
    if (!header || header.getAttribute('data-chrome-bound') === '1') return;
    header.setAttribute('data-chrome-bound', '1');
    bindDrawer();
    bindNotifications();
  }
  bindChrome();
  document.addEventListener('niva:view-ready', bindChrome);
  document.addEventListener('niva:view-changed', bindChrome);
})();
