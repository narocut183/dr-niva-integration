/* ==========================================================================
   Dr. Niva — small shared helpers (3.0.1)
   ----------------------------------------------------------------------
   This file used to hold a SECOND in-app router. Two routers competed for the
   same clicks: this one replaced only #main-content inside .niva-view and so
   threw away the #site-header / #site-footer hosts, and called NIVA_BOOT_CONTENT()
   instead of NIVA_BOOT(), so the header, navigation and footer disappeared until
   a full page reload.

   Navigation now lives in exactly one place (wp-bridge.js, which injects the
   whole payload and calls NIVA_BOOT()). What stays here:
     · NIVA_FETCH  — JSON that never breaks on an HTML error page
     · NIVA_MODAL  — opens markup that is already in the page, instantly
     · NIVA_TOAST  — short confirmations
     · a view observer that tells the module scripts to re-bind after a swap
   ========================================================================== */
(function () {
  'use strict';

  function config() { return window.NIVA_CONFIG || {}; }

  function ready(fn) {
    if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
  }

  /* ---------------------------------------------------------------- fetch */

  function jsonHeaders(extra) {
    var headers = { 'Accept': 'application/json' };
    var nonce = config().nonce;
    if (nonce) { headers['X-WP-Nonce'] = nonce; }
    if (extra) { Object.keys(extra).forEach(function (k) { headers[k] = extra[k]; }); }
    return headers;
  }

  function readJson(response) {
    return response.text().then(function (text) {
      var data = null;
      try { data = text ? JSON.parse(text) : null; } catch (error) { data = null; }
      if (!response.ok || data === null) {
        var message = data && data.message ? data.message : '';
        if (!message) {
          message = response.status === 403 || response.status === 401
            ? 'نشست شما منقضی شده؛ صفحه را دوباره باز کن و وارد شو.'
            : 'پاسخ سرور قابل خواندن نبود (کد ' + response.status + '). اگر تکرار شد، پشتیبانی را خبر کن.';
        }
        var failure = new Error(message);
        failure.status = response.status;
        failure.raw = text ? text.slice(0, 200) : '';
        throw failure;
      }
      return data;
    });
  }

  window.NIVA_FETCH = {
    json: function (url, options) {
      var opts = options || {};
      var payload = {
        method: opts.method || 'GET',
        credentials: 'same-origin',
        headers: jsonHeaders(opts.headers)
      };
      if (opts.body !== undefined) {
        if (opts.form) {
          payload.body = opts.body;                    // FormData: browser sets the boundary
        } else {
          payload.headers['Content-Type'] = 'application/json';
          payload.body = JSON.stringify(opts.body || {});
        }
      }
      return fetch(url, payload).then(readJson);
    },
    post: function (url, body, form) {
      return window.NIVA_FETCH.json(url, { method: 'POST', body: body, form: !!form });
    }
  };

  /* ---------------------------------------------------------------- toast */

  function toast(text) {
    if (!text) { return; }
    var host = document.querySelector('[data-niva-toast-host]');
    if (!host) {
      host = document.createElement('div');
      host.className = 'niva-toast-host';
      host.setAttribute('data-niva-toast-host', '');
      host.setAttribute('role', 'status');
      host.setAttribute('aria-live', 'polite');
      document.body.appendChild(host);
    }
    var node = document.createElement('div');
    node.className = 'niva-toast';
    node.textContent = text;
    host.appendChild(node);
    window.setTimeout(function () {
      node.classList.add('is-out');
      window.setTimeout(function () { if (node.parentNode) { node.parentNode.removeChild(node); } }, 200);
    }, 3200);
  }
  window.NIVA_TOAST = toast;

  /* ---------------------------------------------------------------- modal
     Markup ships with the page (hidden). Opening is a class toggle, so it is
     instant: nothing is fetched and nothing is rendered from scratch.       */

  var lastFocus = null;

  function modalRoot(id) { return document.querySelector('[data-niva-modal="' + id + '"]'); }

  function openModal(id) {
    var modal = modalRoot(id);
    if (!modal) { return false; }
    lastFocus = document.activeElement;
    modal.hidden = false;
    modal.classList.add('is-open');
    document.body.classList.add('niva-modal-open');
    var focusable = modal.querySelector('[data-niva-modal-focus]') ||
      modal.querySelector('input:not([type="hidden"]), select, textarea, button');
    if (focusable) { window.setTimeout(function () { focusable.focus(); }, 0); }
    document.dispatchEvent(new CustomEvent('niva:modal-open', { detail: { id: id, modal: modal } }));
    return true;
  }

  function closeModal(node) {
    var modal = node || document.querySelector('.niva-modal.is-open');
    if (!modal) { return; }
    modal.classList.remove('is-open');
    modal.hidden = true;
    if (!document.querySelector('.niva-modal.is-open')) { document.body.classList.remove('niva-modal-open'); }
    if (lastFocus && lastFocus.focus) { lastFocus.focus(); }
  }

  window.NIVA_MODAL = { open: openModal, close: closeModal, toast: toast };

  document.addEventListener('click', function (event) {
    var opener = event.target.closest ? event.target.closest('[data-niva-modal-open]') : null;
    if (opener) { event.preventDefault(); openModal(opener.getAttribute('data-niva-modal-open')); return; }
    var closer = event.target.closest ? event.target.closest('[data-niva-modal-close]') : null;
    if (closer) { event.preventDefault(); closeModal(closer.closest('.niva-modal')); return; }
    if (event.target.classList && event.target.classList.contains('niva-modal__backdrop')) {
      closeModal(event.target.closest('.niva-modal'));
    }
  });

  document.addEventListener('keydown', function (event) {
    if (event.key !== 'Escape') { return; }
    var open = document.querySelector('.niva-modal.is-open');
    if (open) { closeModal(open); }
  });

  /* ------------------------------------------------- sub-menu open/close
     3.0.3 — the header and the drawer are rendered from NIVA_CONFIG.menu; the
     toggle is delegated so it keeps working after NIVA_BOOT() rebuilds them. */

  document.addEventListener('click', function (event) {
    var toggle = event.target.closest ? event.target.closest('[data-nav-toggle]') : null;
    if (!toggle) { return; }
    event.preventDefault();
    var holder = toggle.closest('.nav__item, .drawer__group');
    if (!holder) { return; }
    var open = !holder.classList.contains('is-open');
    holder.classList.toggle('is-open', open);
    toggle.setAttribute('aria-expanded', open ? 'true' : 'false');
  });

  /* ------------------------------------------------------- view observer
     Whoever swaps the screen (the bridge today, anything else tomorrow) is
     watched here: when .niva-view's content changes, every module script is
     told to re-bind, so buttons keep working without a reload.             */

  var viewToken = 0;

  function announceView(reason) {
    viewToken += 1;
    var shell = document.querySelector('.niva-shell');
    var view = shell ? (shell.getAttribute('data-view') || '') : '';
    document.dispatchEvent(new CustomEvent('niva:view-ready', { detail: { view: view, reason: reason || 'change', token: viewToken } }));
    document.dispatchEvent(new CustomEvent('niva:view-changed', { detail: { view: view, reason: reason || 'change', token: viewToken } }));
  }
  window.NIVA_ANNOUNCE_VIEW = announceView;

  ready(function () {
    var host = document.querySelector('.niva-view');
    if (!host || typeof MutationObserver !== 'function') { return; }
    var timer = null;
    var observer = new MutationObserver(function () {
      window.clearTimeout(timer);
      timer = window.setTimeout(function () { announceView('mutation'); }, 40);
    });
    observer.observe(host, { childList: true, subtree: false });
  });
}());
