/* ==========================================================================
   Dr. Niva — site behaviour (vanilla JS, no build step)
   Design language v3: simple dark app shell, Persian digits, bottom dock.
   ========================================================================== */
(function () {
  'use strict';

  var ICONS = window.NIVA_ICONS || {};
  var PAGE = (location.pathname.split('/').pop() || 'index.html').toLowerCase();
  /* inside WordPress the screens are views (?niva_view=advisor), not files */
  var VIEW_PARAM = (location.search.match(/[?&]niva_view=([a-z0-9\-]+)/i) || [])[1];
  var APP_SHELL = document.querySelector('#niva-app');
  var APP_VIEW = VIEW_PARAM || (APP_SHELL && APP_SHELL.getAttribute('data-view')) || '';
  if (APP_VIEW) PAGE = APP_VIEW + '.html';
  document.addEventListener('niva:view-ready', function (event) {
    if (event.detail && event.detail.view) {
      APP_VIEW = event.detail.view;
      PAGE = APP_VIEW + '.html';
    }
  });
  var FA_DIGITS = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

  /* ---------------------------------------------------------------- helpers */

  /** Latin digits -> Persian digits (the whole UI is Persian-first). */
  function fa(input) {
    return String(input).replace(/[0-9]/g, function (d) { return FA_DIGITS[Number(d)]; });
  }

  function checkDue() {
    var config = window.NIVA_CONFIG || {};
    var timezone = config.plugin && config.plugin.timezone;
    var now = new Date();
    var clock = {};
    try {
      new Intl.DateTimeFormat('en-GB', {
        timeZone: timezone || undefined,
        year: 'numeric', month: '2-digit', day: '2-digit',
        hour: '2-digit', minute: '2-digit', hourCycle: 'h23'
      }).formatToParts(now).forEach(function (part) {
        if (part.type !== 'literal') clock[part.type] = part.value;
      });
    } catch (error) {
      var offset = Number(config.plugin && config.plugin.timezone_offset || 0);
      var shifted = new Date(now.getTime() + offset * 60000);
      clock = {
        year: String(shifted.getUTCFullYear()),
        month: String(shifted.getUTCMonth() + 1).padStart(2, '0'),
        day: String(shifted.getUTCDate()).padStart(2, '0'),
        hour: String(shifted.getUTCHours()).padStart(2, '0'),
        minute: String(shifted.getUTCMinutes()).padStart(2, '0')
      };
    }
    var currentTime = clock.hour + ':' + clock.minute;
    var today = clock.year + '-' + clock.month + '-' + clock.day;
    var weekday = now.getDay();
    try {
      var weekdayText = new Intl.DateTimeFormat('en-US', { timeZone: timezone || undefined, weekday: 'short' }).format(now);
      weekday = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'].indexOf(weekdayText);
    } catch (error) {
      var siteOffset = Number(config.plugin && config.plugin.timezone_offset || 0);
      weekday = new Date(now.getTime() + siteOffset * 60000).getUTCDay();
    }
    items.forEach(function (item) {
      if (Number(item.done) || (item.time_at || '') !== currentTime) return;
      if (item.repeat_rule === 'weekly') {
        var createdDate = item.created_at ? String(item.created_at).slice(0, 10) : '';
        var createdParts = createdDate.split('-').map(Number);
        var createdWeekday = createdParts.length === 3 ? new Date(Date.UTC(createdParts[0], createdParts[1] - 1, createdParts[2])).getUTCDay() : -1;
        if (createdWeekday !== weekday) return;
      }
      var key = String(item.id);
      if (firedToday[key] === today) return;
      firedToday[key] = today;
      try { window.localStorage.setItem(firedKey, JSON.stringify(firedToday)); } catch (error) { /* notification still appears in this tab */ }
      notify('یادآور دکتر نیوا', item.title || 'وقت انجام یادآورت رسیده است.');
      if (item.repeat_rule === 'once') {
        request('POST', { action: 'toggle', id: item.id }).then(function (data) {
          items = Array.isArray(data.items) ? data.items : items;
          paint();
        }).catch(function (error) {
          if (statusOut) statusOut.textContent = error.message;
        });
      }
    });
  }

  /** 290000 -> ۲۹۰٬۰۰۰ */
  function faNum(value) {
    return fa(String(value).replace(/\B(?=(\d{3})+(?!\d))/g, '٬'));
  }

  function icon(name, size, extraClass) {
    var body = ICONS[name];
    if (!body) return '';
    var cls = extraClass ? ' class="' + extraClass + '"' : '';
    return (
      '<svg' + cls + ' width="' + (size || 20) + '" height="' + (size || 20) + '" viewBox="0 0 24 24" fill="none"' +
      ' stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true">' +
      body + '</svg>'
    );
  }

  function el(selector, root) { return (root || document).querySelector(selector); }
  function els(selector, root) { return Array.prototype.slice.call((root || document).querySelectorAll(selector)); }

  /* --------------------------------------------------- Persian (Jalali) date */

  /** Today in the Persian calendar, via Intl (no hand-rolled conversion). */
  function todayJalali() {
    try {
      var parts = new Intl.DateTimeFormat('en-u-ca-persian', {
        year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'Asia/Tehran'
      }).formatToParts(new Date());
      var out = {};
      parts.forEach(function (p) { if (p.type !== 'literal') out[p.type] = Number(p.value.replace(/[^\d]/g, '')); });
      if (out.year && out.month && out.day) return out;
    } catch (error) { /* falls through */ }
    return null;
  }

  function jalaliLabel(j) {
    return fa(j.year) + '/' + fa(String(j.month).padStart(2, '0')) + '/' + fa(String(j.day).padStart(2, '0'));
  }

  var MONTHS = ['فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور',
    'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند'];
  var WEEKDAYS = ['شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه'];

  /** Today's Gregorian y/m/d in Tehran, so weekday and Jalali date never disagree. */
  function tehranYmd() {
    try {
      var parts = new Intl.DateTimeFormat('en-GB', {
        timeZone: 'Asia/Tehran', year: 'numeric', month: '2-digit', day: '2-digit'
      }).formatToParts(new Date());
      var out = {};
      parts.forEach(function (p) { if (p.type !== 'literal') out[p.type] = Number(p.value); });
      if (out.year && out.month && out.day) return out;
    } catch (error) { /* falls through */ }
    var now = new Date();
    return { year: now.getFullYear(), month: now.getMonth() + 1, day: now.getDate() };
  }

  /** 0 = شنبه … 6 = جمعه (the Persian week starts on Saturday). */
  function todayWeekdayIndex() {
    var g = tehranYmd();
    return (new Date(Date.UTC(g.year, g.month - 1, g.day)).getUTCDay() + 1) % 7;
  }

  /** Length of a Jalali month (leap years follow the 33-year cycle). */
  function jalaliMonthDays(year, month) {
    if (month <= 6) return 31;
    if (month <= 11) return 30;
    var y = ((year % 33) + 33) % 33;
    return [1, 5, 9, 13, 17, 22, 26, 30].indexOf(y) !== -1 ? 30 : 29;
  }

  /** «سه‌شنبه ۱۵ مهر ۱۴۰۵» */
  function todayLongLabel() {
    var j = todayJalali();
    if (!j) return '';
    return WEEKDAYS[todayWeekdayIndex()] + ' ' + fa(j.day) + ' ' + MONTHS[j.month - 1] + ' ' + fa(j.year);
  }

  /** «۱۵ مهر» */
  function todayShortLabel() {
    var j = todayJalali();
    return j ? fa(j.day) + ' ' + MONTHS[j.month - 1] : '';
  }

  /** «مهر ۱۴۰۵» */
  function todayMonthLabel() {
    var j = todayJalali();
    return j ? MONTHS[j.month - 1] + ' ' + fa(j.year) : '';
  }

  /**
   * Replaces every server-rendered date with the visitor's real date, so the
   * header can never fall behind (or drift into the future).
   */
  function paintToday() {
    var long = todayLongLabel();
    var short = todayShortLabel();
    if (long) els('[data-niva-date]').forEach(function (node) { node.textContent = long; });
    if (short) els('[data-niva-date-short]').forEach(function (node) { node.textContent = short; });
  }

  /** Whole months between two Persian-calendar dates. */
  function monthsBetween(from, to) {
    var months = (to.year - from.year) * 12 + (to.month - from.month);
    if (to.day < from.day) months -= 1;
    return Math.max(0, months);
  }

  /* ------------------------------------------------------- shared chrome */

  /**
   * Links come from the site (NIVA_CONFIG.links) when the plugin provides them,
   * otherwise the static files are used. Nothing is hard-coded to a page that
   * may not exist.
   */
  function url(key, fallback) {
    var links = window.NIVA_CONFIG && window.NIVA_CONFIG.links ? window.NIVA_CONFIG.links : {};
    return links[key] || fallback;
  }

  var NAV_LINKS = [
    { key: 'home', fallback: 'index.html', label: 'خانه', icon: 'home' },
    { key: 'advisor', fallback: 'advisor.html', label: 'مشاور', icon: 'message-circle' },
    { key: 'tools', fallback: 'tools.html', label: 'ابزارها', icon: 'layers' },
    { key: 'cycle', fallback: 'cycle.html', label: 'چرخه', icon: 'calendar-days' },
    { key: 'profile', fallback: 'profile.html', label: 'حساب من', icon: 'user' }
  ];

  var DOCK_TABS = [
    { key: 'home', fallback: 'index.html', label: 'خانه', icon: 'home' },
    { key: 'advisor', fallback: 'advisor.html', label: 'مشاور', icon: 'message-circle' },
    { key: 'tools', fallback: 'tools.html', label: 'ابزارها', icon: 'layers' },
    { key: 'cycle', fallback: 'cycle.html', label: 'چرخه', icon: 'calendar-days' },
    { key: 'profile', fallback: 'profile.html', label: 'حساب من', icon: 'user' }
  ];

  function dockTab(tab) {
    var href = url(tab.key, tab.fallback);
    return '<a class="mobile-bar__tab' + (isActive(href) ? ' mobile-bar__tab--active' : '') + '" href="' + htmlText(href) + '">' +
      icon(tab.icon, 22) + '<span>' + tab.label + '</span></a>';
  }

  var FOOTER_GROUPS = [
    {
      title: 'ابزارها',
      links: [
        { href: 'analyze.html', label: 'تحلیل آزمایش و تصویر' },
        { href: 'cycle.html', label: 'تقویم چرخه' },
        { href: 'pregnancy.html', label: 'مسیر بارداری' },
        { href: 'baby.html', label: 'رشد نوزاد' }
      ]
    },
    {
      title: 'سلامت روان',
      links: [
        { href: 'mind.html', label: 'پیام مشاور' },
        { href: 'mind.html#chat', label: 'گفت‌وگوی همراه' },
        { href: 'mind.html', label: 'تمرین‌های آرام‌سازی' },
        { href: 'mind.html', label: 'کمک فوری' }
      ]
    },
    {
      title: 'دکتر نیوا',
      links: [
        { href: 'about.html', label: 'درباره ما' },
        { href: 'about.html', label: 'حریم خصوصی' },
        { href: 'plans.html', label: 'پلن‌ها و اشتراک' },
        { href: 'index.html#faq', label: 'پرسش‌های پرتکرار' }
      ]
    }
  ];

  function isActive(href) {
    var currentView = (APP_VIEW || PAGE.replace(/\.html$/, '').replace(/^$/, 'home')).toLowerCase();
    if (currentView === 'index') currentView = 'home';
    if (currentView === 'alarms') currentView = 'reminders';
    if (currentView === 'analyze') currentView = 'lab';
    try {
      var target = new URL(href, window.location.href);
      var targetView = target.searchParams.get('niva_view');
      if (targetView) return targetView.toLowerCase() === currentView;
      var path = target.pathname.replace(/\/+$/, '').split('/').pop() || 'home';
      path = path.replace(/\.html$/, '').toLowerCase();
      if (path === 'index') path = 'home';
      if (path === 'alarms') path = 'reminders';
      if (path === 'analyze') path = 'lab';
      if (target.pathname === window.location.pathname) return true;
      return path === currentView;
    } catch (error) {
      return href === PAGE || href === currentView + '.html';
    }
  }

  function htmlText(value) {
    return String(value || '').replace(/[&<>"']/g, function (character) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#039;' }[character];
    });
  }

  function renderHeader() {
    var host = el('#site-header');
    if (!host) return;
    var config = window.NIVA_CONFIG || {};
    var user = config.user || {};
    var wallet = config.wallet || {};
    var plugin = config.plugin || {};
    var menuItems = Array.isArray(config.menu) && config.menu.length ? config.menu.map(function (item) {
      var key = item.key || '';
      var defaults = NAV_LINKS.filter(function (entry) { return entry.key === key; })[0] || {};
      return {
        key: key,
        href: item.url || (defaults.key ? url(defaults.key, defaults.fallback) : '#'),
        label: item.label || defaults.label || '',
        icon: item.icon || defaults.icon || 'circle'
      };
    }).filter(function (item) { return item.label && item.href !== '#'; }) : NAV_LINKS.map(function (item) {
      return { key: item.key, href: url(item.key, item.fallback), label: item.label, icon: item.icon };
    });
    var notificationCount = window.Notification && 'granted' === Notification.permission
      ? Number((config.notifications || {}).unread || 0)
      : 0;
    var brandName = htmlText(plugin.brand || 'دکتر نیوا');
    var brandLogo = plugin.logo_url
      ? '<img class="niva-brand__img" src="' + htmlText(plugin.logo_url) + '" alt="" />'
      : '<span class="brand__mark" aria-hidden="true">' + icon('activity', 20) + '</span>';
    var account = user.logged_in
      ? '<div class="drawer__account"><strong>' + htmlText(user.name || 'حساب کاربری') + '</strong>' +
        '<span>اعتبار: ' + fa(wallet.balance || 0) + '</span>' +
        '<div class="row"><a class="btn btn--secondary btn--sm" href="' + htmlText(url('profile', 'profile.html')) + '">پروفایل من</a>' +
        '<a class="btn btn--primary btn--sm" href="' + htmlText(url('wallet', 'wallet.html')) + '">کیف پول</a></div></div>'
      : '<a class="btn btn--primary btn--block" href="' + htmlText(url('plans', 'plans.html')) + '" style="margin-block-start:12px">ورود / شروع رایگان</a>';

    host.innerHTML =
      '<a class="skip-link" href="#main-content">رفتن به محتوای اصلی</a>' +
      '<header class="header">' +
        '<div class="container header__inner">' +
          '<a class="brand" href="' + htmlText(url('home', 'index.html')) + '">' +
            brandLogo +
            '<span><span class="brand__name">' + brandName + '</span><span class="brand__tag">' + htmlText(plugin.tagline || 'همراه سلامت شما') + '</span></span>' +
          '</a>' +
          '<nav class="nav" aria-label="ناوبری اصلی">' +
            menuItems.map(function (l) {
              var href = l.href;
              var link = '<a class="nav__link' + (isActive(href) ? ' nav__link--active' : '') + '" href="' + htmlText(href) + '">' +
                icon(l.icon, 18) + '<span>' + l.label + '</span></a>';
              /* 3.0.3 — sub-menu items are rendered instead of being ignored. */
              var kids = l.children || [];
              if (!kids.length) { return link; }
              return '<div class="nav__item">' + link +
                '<button type="button" class="nav__toggle" data-nav-toggle aria-expanded="false" aria-label="زیرمنوی ' + htmlText(l.label) + '">' + icon('chevron-down', 16) + '</button>' +
                '<div class="sub-menu">' + kids.map(function (c) {
                  return '<a class="sub-menu__link" href="' + htmlText(c.href) + '">' + (c.icon ? icon(c.icon, 16) : '') + '<span>' + c.label + '</span></a>';
                }).join('') + '</div></div>';
            }).join('') +
          '</nav>' +
          '<div class="header__actions">' +
            '<button type="button" class="icon-btn icon-btn--bare header__bell" id="notifications-open" aria-label="اعلان‌ها' + (notificationCount ? '، ' + fa(notificationCount) + ' خوانده‌نشده' : '') + '" aria-haspopup="dialog" aria-expanded="false">' + icon('bell', 20) +
              (notificationCount ? '<span class="header__badge" aria-hidden="true">' + fa(Math.min(notificationCount, 99)) + '</span>' : '') +
            '</button>' +
            (user.logged_in
              ? '<a class="btn btn--secondary btn--sm header__cta" href="' + htmlText(url('wallet', 'wallet.html')) + '">اعتبار: ' + fa(wallet.balance || 0) + '</a>'
              : '<a class="btn btn--primary btn--sm header__cta" href="' + htmlText(url('plans', 'plans.html')) + '">شروع رایگان</a>') +
            '<button type="button" class="icon-btn header__menu" id="menu-open" aria-label="باز کردن منو" aria-expanded="false">' +
              icon('menu', 22) +
            '</button>' +
          '</div>' +
        '</div>' +
      '</header>' +
      '<div class="notification-sheet" id="header-notifications" hidden>' +
        '<button type="button" class="notification-sheet__scrim" data-notifications-close aria-label="بستن اعلان‌ها"></button>' +
        '<section class="notification-sheet__panel" role="dialog" aria-modal="true" aria-labelledby="header-notifications-title">' +
          '<div class="notification-sheet__head"><div><h2 id="header-notifications-title">اعلان‌های شما</h2><span class="caption" data-header-notification-count></span></div>' +
          '<button type="button" class="icon-btn icon-btn--bare" data-notifications-close aria-label="بستن">' + icon('x', 20) + '</button></div>' +
          '<p class="caption" role="status" data-header-notification-status></p>' +
          '<div class="notification-sheet__items" data-header-notification-items></div>' +
        '</section>' +
      '</div>' +
      '<div class="drawer" id="drawer" hidden>' +
        '<button type="button" class="drawer__scrim" id="drawer-scrim" aria-label="بستن منو"></button>' +
        '<div class="drawer__panel" role="dialog" aria-modal="true" aria-label="منوی سایت">' +
          '<div class="sheet__head">' +
            '<span class="brand">' + (plugin.logo_url
              ? '<img class="niva-brand__img" src="' + htmlText(plugin.logo_url) + '" alt="" />'
              : '<span class="brand__mark" aria-hidden="true">' + icon('activity', 18) + '</span>') +
            '<span class="brand__name">' + brandName + '</span></span>' +
            '<button type="button" class="icon-btn icon-btn--bare" id="drawer-close" aria-label="بستن منو">' + icon('x', 20) + '</button>' +
          '</div>' +
          '<span class="drawer__title">مسیرهای اصلی</span>' +
          account +
          menuItems.map(function (l) {
            var href = l.href;
            var link = '<a class="drawer__link' + (isActive(href) ? ' drawer__link--active' : '') + '" href="' + htmlText(href) + '">' +
              icon(l.icon, 19) + '<span>' + l.label + '</span></a>';
            var kids = l.children || [];
            if (!kids.length) { return link; }
            return '<div class="drawer__group">' + link +
              '<button type="button" class="drawer__toggle" data-nav-toggle aria-expanded="false" aria-label="زیرمنوی ' + htmlText(l.label) + '">' + icon('chevron-down', 18) + '</button>' +
              '<div class="sub-menu sub-menu--drawer">' + kids.map(function (c) {
                return '<a class="drawer__link drawer__link--child" href="' + htmlText(c.href) + '">' + (c.icon ? icon(c.icon, 17) : '') + '<span>' + c.label + '</span></a>';
              }).join('') + '</div></div>';
          }).join('') +
        '</div>' +
      '</div>';

    var drawer = el('#drawer');
    function close() {
      drawer.hidden = true;
      el('#menu-open').setAttribute('aria-expanded', 'false');
      document.body.classList.remove('niva-header-menu-open');
    }
    el('#menu-open').addEventListener('click', function () {
      drawer.hidden = false;
      el('#menu-open').setAttribute('aria-expanded', 'true');
      document.body.classList.add('niva-header-menu-open');
      var first = el('.drawer__link', drawer);
      if (first) first.focus();
    });
    el('#drawer-close').addEventListener('click', close);
    el('#drawer-scrim').addEventListener('click', close);
    document.addEventListener('keydown', function (event) { if (event.key === 'Escape' && !drawer.hidden) close(); });
    els('.drawer__link, .drawer__account a', drawer).forEach(function (link) {
      link.addEventListener('click', close);
    });
    bindHeaderNotifications();
  }

  function bindHeaderNotifications() {
    var button = el('#notifications-open');
    var sheet = el('#header-notifications');
    if (!button || !sheet || !bindOnce(button, 'header-notifications')) return;
    var list = el('[data-header-notification-items]', sheet);
    var status = el('[data-header-notification-status]', sheet);
    var count = el('[data-header-notification-count]', sheet);
    var items = [];

    function paintBadge(unread) {
      var current = Number(unread || 0);
      var badge = el('.header__badge', button);
      button.setAttribute('aria-label', 'اعلان‌ها' + (current ? '، ' + fa(current) + ' خوانده‌نشده' : ''));
      if (current && !badge) {
        badge = document.createElement('span');
        badge.className = 'header__badge';
        badge.setAttribute('aria-hidden', 'true');
        button.appendChild(badge);
      }
      if (badge) {
        badge.textContent = fa(Math.min(current, 99));
        badge.hidden = !current;
      }
      var config = window.NIVA_CONFIG || {};
      config.notifications = config.notifications || {};
      config.notifications.unread = current;
      window.NIVA_CONFIG = config;
      if (count) count.textContent = current ? fa(current) + ' خوانده‌نشده' : 'همهٔ اعلان‌ها خوانده شده‌اند';
    }

    function markRead(id) {
      var config = window.NIVA_CONFIG || {};
      var rest = config.rest || (config.plugin && config.plugin.rest);
      var nonce = config.nonce || (config.plugin && config.plugin.nonce) || '';
      return fetch(rest + '/notifications', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
        body: JSON.stringify({ id: id })
      }).then(function (response) {
        return response.json().then(function (data) {
          if (!response.ok) throw new Error(data && data.message ? data.message : 'وضعیت اعلان ذخیره نشد.');
          return data;
        });
      });
    }

    function renderItems() {
      list.replaceChildren();
      if (!items.length) {
        var empty = document.createElement('p');
        empty.className = 'notification-sheet__empty';
        empty.textContent = 'هنوز اعلانی برای نمایش نداری.';
        list.appendChild(empty);
        return;
      }
      items.forEach(function (item) {
        var row = document.createElement('article');
        row.className = 'notification-card' + (Number(item.is_read) ? ' notification-card--read' : '');
        var text = document.createElement('div');
        text.className = 'notification-card__text';
        var title = document.createElement('strong');
        title.textContent = item.title || 'اعلان';
        var body = document.createElement('p');
        body.textContent = item.body || '';
        var date = document.createElement('span');
        date.className = 'caption';
        date.textContent = item.created_at_label || '';
        text.append(title, body, date);
        row.appendChild(text);
        if (!Number(item.is_read)) {
          var read = document.createElement('button');
          read.type = 'button';
          read.className = 'chip';
          read.textContent = 'خوانده شد';
          read.addEventListener('click', function () {
            read.disabled = true;
            markRead(item.id).then(function () {
              item.is_read = 1;
              paintBadge(items.filter(function (entry) { return !Number(entry.is_read); }).length);
              renderItems();
            }).catch(function (error) {
              read.disabled = false;
              if (status) status.textContent = error.message;
            });
          });
          row.appendChild(read);
        }
        list.appendChild(row);
      });
      if (items.some(function (item) { return !Number(item.is_read); })) {
        var markAll = document.createElement('button');
        markAll.type = 'button';
        markAll.className = 'btn btn--secondary btn--block';
        markAll.textContent = 'همه را خوانده‌شده کن';
        markAll.addEventListener('click', function () {
          markAll.disabled = true;
          markRead(0).then(function () {
            items.forEach(function (item) { item.is_read = 1; });
            paintBadge(0);
            renderItems();
          }).catch(function (error) {
            markAll.disabled = false;
            if (status) status.textContent = error.message;
          });
        });
        list.appendChild(markAll);
      }
    }

    function close() {
      sheet.hidden = true;
      button.setAttribute('aria-expanded', 'false');
      document.body.classList.remove('niva-header-notifications-open');
    }

    function loadNotifications(pushError) {
      var config = window.NIVA_CONFIG || {};
      var rest = config.rest || (config.plugin && config.plugin.rest);
      var nonce = config.nonce || (config.plugin && config.plugin.nonce) || '';
      if (!rest) {
        if (status) status.textContent = 'اتصال به سرور برقرار نیست.';
        return;
      }
      fetch(rest + '/notifications', { credentials: 'same-origin', headers: { 'X-WP-Nonce': nonce } })
        .then(function (response) {
          return response.json().then(function (data) {
            if (!response.ok) throw new Error(data && data.message ? data.message : 'اعلان‌ها بارگذاری نشدند.');
            return data;
          });
        }).then(function (data) {
          items = Array.isArray(data.items) ? data.items : [];
          if (status) status.textContent = pushError || '';
          paintBadge(data.unread);
          renderItems();
        }).catch(function (error) {
          if (status) status.textContent = error.message || 'اعلان‌ها بارگذاری نشدند.';
        });
    }

    function showPermissionPrompt() {
      list.replaceChildren();
      if (!window.Notification) {
        if (status) status.textContent = 'این مرورگر اعلان‌های سیستم را پشتیبانی نمی‌کند.';
        return;
      }
      if ('denied' === Notification.permission) {
        if (status) status.textContent = 'اجازهٔ اعلان برای این سایت مسدود است. از تنظیمات مرورگر، اعلان‌های این سایت را مجاز کن و دوباره این بخش را باز کن.';
        return;
      }
      if (status) status.textContent = 'برای دیدن اعلان‌ها، ابتدا اجازهٔ اعلان این سایت را فعال کن.';
      var allow = document.createElement('button');
      allow.type = 'button';
      allow.className = 'btn btn--primary';
      allow.textContent = 'اجازه و نمایش اعلان‌ها';
      allow.addEventListener('click', function () {
        allow.disabled = true;
        Notification.requestPermission().then(function (permission) {
          if ('granted' !== permission) {
            if (status) status.textContent = 'اجازه داده نشد؛ دسترسی اعلان این سایت را در تنظیمات مرورگر تغییر بده.';
            allow.disabled = false;
            return;
          }
          var enablePush = window.NIVA_ENABLE_PUSH;
          if (typeof enablePush === 'function') {
            enablePush().then(function () {
              loadNotifications('');
            }).catch(function (error) {
              loadNotifications(error.message);
            });
          } else {
            loadNotifications('');
          }
        }).catch(function (error) {
          if (status) status.textContent = error.message || 'درخواست اجازهٔ اعلان انجام نشد.';
          allow.disabled = false;
        });
      });
      list.appendChild(allow);
    }

    button.addEventListener('click', function () {
      sheet.hidden = false;
      button.setAttribute('aria-expanded', 'true');
      document.body.classList.add('niva-header-notifications-open');
      var config = window.NIVA_CONFIG || {};
      if (!config.user || !config.user.logged_in) {
        list.replaceChildren();
        if (status) status.textContent = 'برای مشاهدهٔ اعلان‌ها وارد حساب کاربری‌ات شو.';
        return;
      }
      if (!window.Notification || 'granted' !== Notification.permission) {
        showPermissionPrompt();
        return;
      }
      if (status) status.textContent = 'در حال دریافت اعلان‌ها…';
      list.replaceChildren();
      loadNotifications('');
    });
    els('[data-notifications-close]', sheet).forEach(function (closeButton) {
      closeButton.addEventListener('click', close);
    });
    sheet.addEventListener('click', function (event) {
      if (event.target.classList.contains('notification-sheet__scrim')) close();
    });
    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape' && !sheet.hidden) close();
    });
  }

  function renderFooter() {
    var host = el('#site-footer');
    if (!host) return;
    var plugin = (window.NIVA_CONFIG || {}).plugin || {};
    var brandName = htmlText(plugin.brand || 'دکتر نیوا');
    var brandLogo = plugin.logo_url
      ? '<img class="niva-brand__img" src="' + htmlText(plugin.logo_url) + '" alt="" />'
      : '<span class="brand__mark" aria-hidden="true">' + icon('activity', 20) + '</span>';

    host.innerHTML =
      '<footer class="footer">' +
        '<div class="container">' +
          '<div class="footer__grid">' +
            '<div class="stack">' +
              '<span class="brand">' +
                brandLogo +
                '<span class="brand__name">' + brandName + '</span>' +
              '</span>' +
              '<p style="font-size:var(--t-2xs)">پرونده سلامتت را بفهم، پیگیری کن، و بدون قضاوت درباره‌اش حرف بزن.</p>' +
            '</div>' +
            FOOTER_GROUPS.map(function (group) {
              return '<div><h3 class="footer__title">' + group.title + '</h3><ul>' +
                group.links.map(function (l) { return '<li><a class="footer__link" href="' + l.href + '">' + l.label + '</a></li>'; }).join('') +
                '</ul></div>';
            }).join('') +
          '</div>' +
          '<div class="footer__legal">' +
            '<p>دکتر نیوا برای آموزش، پیگیری و آماده‌سازی مراجعه به پزشک طراحی شده است و جایگزین تشخیص، درمان یا مشاوره پزشک نیست.</p>' +
            '<p>خطوط کمک فوری: اورژانس اجتماعی ' + fa('123') + ' و صدای مشاور ' + fa('1480') + ' — شبانه‌روزی و رایگان (سازمان بهزیستی).</p>' +
            '<p>© ' + fa('1405') + ' ' + brandName + ' — تمام حقوق محفوظ است.</p>' +
          '</div>' +
        '</div>' +
      '</footer>' +
      '<nav class="mobile-bar" aria-label="ناوبری پایین">' +
        DOCK_TABS.map(dockTab).join('') +
      '</nav>';
  }

  /* ------------------------------------------------------ small widgets */

  function bindIcons() {
    els('[data-icon]').forEach(function (node) {
      node.innerHTML = icon(node.dataset.icon, Number(node.dataset.size || 20));
    });
  }

  function bindReveal() {
    var targets = els('.card, .tile, .quickstart__card, .stat, .step, .hub-card, .plan-card, .safety-item, .review-step');
    if (!targets.length || !('IntersectionObserver' in window)) return;
    var observer = new IntersectionObserver(function (entries) {
      entries.forEach(function (entry) {
        if (entry.isIntersecting) {
          entry.target.classList.add('is-in');
          observer.unobserve(entry.target);
        }
      });
    }, { rootMargin: '0px 0px -6% 0px', threshold: 0.05 });
    targets.forEach(function (node, index) {
      node.classList.add('reveal');
      node.style.transitionDelay = Math.min(index % 5, 4) * 35 + 'ms';
      observer.observe(node);
    });
  }

  function bindAccordions() {
    els('[data-accordion]').forEach(function (item) {
      if (!bindOnce(item, 'accordion')) return;
      var trigger = el('.accordion__trigger', item);
      var panel = el('.accordion__panel', item);
      if (!trigger || !panel) return;
      trigger.addEventListener('click', function () {
        var open = trigger.getAttribute('aria-expanded') === 'true';
        trigger.setAttribute('aria-expanded', open ? 'false' : 'true');
        panel.hidden = open;
      });
    });
  }

  function bindChips() {
    els('[data-chips]').forEach(function (group) {
      if (!bindOnce(group, 'chips')) return;
      var output = el('[data-chip-count]');
      els('button[data-chip]', group).forEach(function (chip) {
        chip.addEventListener('click', function () {
          var selected = chip.classList.toggle('chip--selected');
          chip.setAttribute('aria-pressed', selected ? 'true' : 'false');
          if (output && group.hasAttribute('data-chip-output')) {
            output.textContent = fa(els('button[data-chip].chip--selected', group).length);
          }
        });
      });
    });
  }

  function bindChecklists() {
    els('[data-checklist]').forEach(function (list) {
      if (!bindOnce(list, 'checklist')) return;
      var counter = el('[data-checklist-count]');
      function refresh() {
        if (counter) counter.textContent = fa(els('.checklist__item--done', list).length);
      }
      els('.checklist__item', list).forEach(function (item) {
        item.addEventListener('click', function () {
          var done = item.classList.toggle('checklist__item--done');
          item.setAttribute('aria-pressed', done ? 'true' : 'false');
          refresh();
        });
      });
      refresh();
    });
  }

  function bindCounters() {
    els('[data-counter]').forEach(function (widget) {
      var valueEl = el('[data-counter-value]', widget);
      var statusEl = el('[data-counter-status]', widget);
      var goal = Number(widget.dataset.goal || 0);
      var alertAt = Number(widget.dataset.alertAt || 0);
      var value = Number(widget.dataset.value || 0);

      function paint() {
        valueEl.textContent = fa(value);
        if (!statusEl) return;
        if (alertAt && value >= alertAt) {
          statusEl.className = 'badge badge--urgent';
          statusEl.innerHTML = icon('alert-triangle', 13) + (widget.dataset.alertLabel || 'نیازمند بررسی');
        } else if (goal && value < goal) {
          statusEl.className = 'badge badge--caution';
          statusEl.innerHTML = icon('activity', 13) + (widget.dataset.lowLabel || 'کمتر از هدف');
        } else {
          statusEl.className = 'badge badge--green';
          statusEl.innerHTML = icon('check', 13) + (widget.dataset.okLabel || 'خوب');
        }
      }

      el('[data-counter-inc]', widget).addEventListener('click', function () { value += 1; paint(); });
      el('[data-counter-dec]', widget).addEventListener('click', function () { value = Math.max(0, value - 1); paint(); });
      paint();
      widget.dataset.value = String(value);
    });
  }

  /* -------------------------------------------------------- trend charts */

  var TONES = {
    green: { line: '#3368a0', fill: 'rgba(51, 104, 160, 0.14)' },
    pink: { line: '#7f9cbb', fill: 'rgba(127, 156, 187, 0.16)' },
    purple: { line: '#5f7fa8', fill: 'rgba(95, 127, 168, 0.16)' },
    cyan: { line: '#66a3bf', fill: 'rgba(102, 163, 191, 0.16)' },
    orange: { line: '#c69a5a', fill: 'rgba(198, 154, 90, 0.16)' }
  };

  var CHART_SERIES = {
    hemoglobin: {
      tone: 'green', unit: ' g/dL',
      band: [12, 16], bandLabel: 'بازه مرجع آزمایشگاه (۱۲ تا ۱۶)', seriesLabel: 'هموگلوبین',
      series: [{ label: 'فروردین', value: 10.4 }, { label: 'اردیبهشت', value: 10.6 }, { label: 'خرداد', value: 10.9 },
               { label: 'تیر', value: 11.0 }, { label: 'مرداد', value: 10.8 }, { label: 'شهریور', value: 11.2 }]
    },
    mood: {
      tone: 'purple', bars: true, integerAxis: true,
      note: 'میانگین این هفته ۳٫۶ از ۵ — دو روز پایین‌تر از میانگینت بوده',
      series: [{ label: 'شنبه', value: 3 }, { label: 'یکشنبه', value: 4 }, { label: 'دوشنبه', value: 3 },
               { label: 'سه‌شنبه', value: 2 }, { label: 'چهارشنبه', value: 4 }, { label: 'پنجشنبه', value: 5 },
               { label: 'جمعه', value: 4 }]
    },
    assessment: {
      tone: 'purple', integerAxis: true,
      note: 'از ۱۵ به ۱۱ رسیده — یعنی نشانه‌ها کمتر شده است',
      series: [{ label: 'تیر', value: 15 }, { label: 'مرداد', value: 13 }, { label: 'شهریور', value: 11 }]
    },
    babyWeight: {
      tone: 'pink', unit: ' kg', emptyText: 'برای دیدن نمودار، حداقل دو بار وزن را ثبت کن.',
      series: []
    }
  };

  /**
   * Reads a number written by a Persian user: '۵٫۲' → 5.2, '۱۲' → 12.
   * Numeric input from markup must never go through Number() directly.
   */
  function toNumber(value) {
    if (value === null || value === undefined) return NaN;
    var text = String(value)
      .replace(/[\u06F0-\u06F9]/g, function (d) { return String('\u06F0\u06F1\u06F2\u06F3\u06F4\u06F5\u06F6\u06F7\u06F8\u06F9'.indexOf(d)); })
      .replace(/[\u0660-\u0669]/g, function (d) { return String('\u0660\u0661\u0662\u0663\u0664\u0665\u0666\u0667\u0668\u0669'.indexOf(d)); })
      .replace(/[\u066B\u066C\u060C]/g, '.')
      .replace(/[^0-9.\-]/g, '');
    return text === '' ? NaN : Number(text);
  }

  /**
   * Write-through sync: the browser keeps working offline, and when someone is
   * signed in on a WordPress site the record is also stored server side so the
   * back office can manage it. Failures are ignored on purpose.
   */
  function syncToServer(kind, payload) {
    var cfg = window.NIVA_CONFIG;
    if (!cfg || !cfg.plugin || !cfg.plugin.rest) return;
    if (!cfg.user || !cfg.user.logged_in) return;
    try {
      fetch(cfg.plugin.rest + '/' + kind, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.plugin.nonce },
        body: JSON.stringify(payload || {})
      })["catch"](function () {});
    } catch (error) { /* offline is a supported state */ }
  }

  function faDecimal(value) {
    var text = String(Math.round(value * 10) / 10);
    return fa(text).replace('.', '٫');
  }

  function renderCharts() {
    els('[data-chart]').forEach(function (host) {
      var config = CHART_SERIES[host.dataset.chart];
      if (!config) return;
      var series = config.series || [];
      if (series.length < 2) {
        host.innerHTML = '<p class="caption">' + (config.emptyText || 'برای دیدن نمودار، حداقل دو اندازه لازم است.') + '</p>';
        return;
      }

      var height = Number(host.dataset.height || 200);
      var width = 640;
      var padTop = 26;
      var padBottom = 10;
      var plotH = height - padTop - padBottom;
      var values = series.map(function (p) { return p.value; });
      var rawMin = Math.min.apply(null, values);
      var rawMax = Math.max.apply(null, values);

      if (config.band) {
        rawMin = Math.min(rawMin, config.band[0]);
        rawMax = Math.max(rawMax, config.band[1]);
      }
      var spread = (rawMax - rawMin) || 1;
      var lo = config.bars ? Math.min(0, rawMin - 0.5) : rawMin - spread * 0.28;
      var hi = config.bars ? rawMax + 0.6 : rawMax + spread * 0.22;
      var span = (hi - lo) || 1;

      function yOf(value) { return padTop + plotH - ((value - lo) / span) * plotH; }

      var palette = TONES[config.tone] || TONES.green;
      var step = width / (series.length - 1);
      var points = series.map(function (p, i) {
        return { label: p.label, value: p.value, left: (i * step / width) * 100, y: yOf(p.value) };
      });

      var grids = [];
      var axes = [];
      for (var g = 0; g <= 4; g += 1) {
        var gridValue = lo + (span * g) / 4;
        var gridY = yOf(gridValue);
        grids.push('<line class="chart__grid" x1="0" y1="' + gridY.toFixed(1) + '" x2="' + width + '" y2="' + gridY.toFixed(1) + '"></line>');
        axes.push('<span class="chart__axis" style="top:' + gridY.toFixed(1) + 'px">' +
          (config.integerAxis ? fa(gridValue.toFixed(0)) : faDecimal(gridValue)) + '</span>');
      }

      var band = '';
      if (config.band) {
        var yTop = yOf(config.band[1]);
        var yBottom = yOf(config.band[0]);
        band = '<rect class="chart__band" x="0" y="' + yTop.toFixed(1) + '" width="' + width + '" height="' +
          Math.max(3, yBottom - yTop).toFixed(1) + '"></rect>';
      }

      var marks = '';
      if (config.bars) {
        var barW = Math.max(12, (width / series.length) * 0.52);
        marks = points.map(function (p, i) {
          var center = (i * step).toFixed(1);
          var barH = Math.max(4, padTop + plotH - p.y);
          var isLast = i === points.length - 1;
          return '<rect x="' + (center - barW / 2).toFixed(1) + '" y="' + p.y.toFixed(1) + '" width="' + barW.toFixed(1) +
            '" height="' + barH.toFixed(1) + '" rx="4" fill="' + palette.line + '" opacity="' + (isLast ? '1' : '0.5') + '"></rect>';
        }).join('');
      } else {
        var line = points.map(function (p, i) { return (i === 0 ? 'M' : 'L') + (i * step).toFixed(1) + ',' + p.y.toFixed(1); }).join(' ');
        var area = line + ' L' + width + ',' + height + ' L0,' + height + ' Z';
        marks = '<path d="' + area + '" fill="' + palette.fill + '" stroke="none"></path>' +
          '<path d="' + line + '" fill="none" stroke="' + palette.line + '" stroke-width="2.5" stroke-linecap="round" ' +
          'stroke-linejoin="round" vector-effect="non-scaling-stroke"></path>' +
          points.map(function (p) {
            return '<span class="chart__dot" style="left:' + p.left.toFixed(3) + '%;top:' + p.y.toFixed(1) +
              'px;border-color:' + palette.line + '" aria-hidden="true"></span>';
          }).join('');
      }

      var valueLabels = '';
      if (!config.bars) {
        valueLabels = points.map(function (p, i) {
          var show = points.length <= 4 || i === 0 || i === points.length - 1 || p.value === rawMax;
          if (!show) return '';
          return '<span class="chart__label" style="left:' + p.left.toFixed(3) + '%;top:' +
            Math.max(0, p.y - 24).toFixed(1) + 'px">' + faDecimal(p.value) + '</span>';
        }).join('');
      }

      var first = series[0].value;
      var last = series[series.length - 1].value;
      var diff = last - first;
      var direction = diff > 0 ? 'روند افزایشی' : diff < 0 ? 'روند کاهشی' : 'بدون تغییر';
      var note = config.note || ('از ' + faDecimal(first) + ' به ' + faDecimal(last) + ' — ' + direction);
      var status = '';
      if (config.band && last < config.band[0]) {
        status = '<span class="badge badge--urgent">' + icon('alert-triangle', 13) + 'زیر بازه مرجع</span>';
      } else if (config.band && last > config.band[1]) {
        status = '<span class="badge badge--caution">بالای بازه مرجع</span>';
      } else if (config.band) {
        status = '<span class="badge badge--green">' + icon('check', 13) + 'داخل بازه مرجع</span>';
      }

      var legend = '';
      if (config.band) {
        legend = '<div class="chart__legend">' +
          '<span class="chart__key"><i style="background:' + palette.line + '"></i>' + (config.seriesLabel || 'مقدار اندازه‌گیری‌شده') + '</span>' +
          '<span class="chart__key"><i style="background:rgba(51,104,160,0.32)"></i>' + (config.bandLabel || 'بازه مرجع') + '</span>' +
          '</div>';
      }

      host.innerHTML =
        '<p class="chart__note" dir="auto">' + note + status + '</p>' +
        '<div class="chart">' +
          axes.join('') +
          '<div class="chart__plot" style="height:' + height + 'px">' +
            '<svg class="chart__svg" viewBox="0 0 ' + width + ' ' + height + '" preserveAspectRatio="none" role="img" ' +
              'aria-label="' + series.map(function (p) { return p.label + ': ' + p.value; }).join('، ') + '">' +
              grids.join('') + band + marks +
            '</svg>' +
            valueLabels +
          '</div>' +
        '</div>' +
        '<div dir="ltr" style="display:flex;justify-content:space-between;gap:6px;margin-block-start:6px;padding-left:40px">' +
          series.map(function (p) { return '<span class="caption">' + p.label + '</span>'; }).join('') +
        '</div>' + legend;
    });
  }

  /* ------------------------------------------------------------- calendar */

  var CALENDAR = {
    title: '', days: 31, today: 1, offset: 0,
    period: [], predicted: [], fertile: [], ovulation: [], pms: [], symptoms: []
  };

  /* The calendar always opens on the real current month, with today's real
     number highlighted — the sample cycle data stays as sample data. */
  (function syncCalendarToToday() {
    /*
     * The server owns the calendar: its clock is the site's clock, so the
     * highlighted day can never disagree with the date printed in the page
     * header. The Intl path is only a fallback for the standalone HTML pages.
     */
    var j = todayJalali();
    if (j) {
      CALENDAR.today = j.day;
      CALENDAR.title = MONTHS[j.month - 1] + ' ' + fa(j.year);
      CALENDAR.monthName = MONTHS[j.month - 1];
      CALENDAR.days = jalaliMonthDays(j.year, j.month);
      CALENDAR.year = j.year;
      CALENDAR.offset = ((todayWeekdayIndex() - (j.day - 1)) % 7 + 7) % 7;
    }

    var grid = el('[data-calendar]');
    if (!grid) return;

    var attr = function (name) { return grid.getAttribute(name); };
    var num = function (name, fallback) {
      var value = attr(name);
      return (value === null || value === '') ? fallback : Number(value);
    };
    var list = function (name) {
      var raw = attr(name);
      if (raw === null) return null;
      return raw.split(',').filter(function (item) { return item !== ''; }).map(Number);
    };

    CALENDAR.today = num('data-today', CALENDAR.today);
    CALENDAR.days = num('data-days', CALENDAR.days);
    CALENDAR.offset = num('data-offset', CALENDAR.offset);
    if (attr('data-month')) {
      CALENDAR.monthName = attr('data-month');
      CALENDAR.title = CALENDAR.monthName + ' ' + fa(num('data-year', 0));
      CALENDAR.year = num('data-year', 0);
    }
    ['period', 'predicted', 'fertile', 'ovulation', 'pms'].forEach(function (key) {
      var parsed = list('data-' + key);
      if (parsed) CALENDAR[key] = parsed;
    });
    // symptom dots come from the logged symptom table only — never invented.
    CALENDAR.symptoms = list('data-symptoms') || [];
  })();

  function bindCalendar() {
    var grid = el('[data-calendar]');
    if (!grid) return;
    var periodDays = CALENDAR.period.slice();
    var selected = CALENDAR.today;

    function stateOf(day) {
      if (periodDays.indexOf(day) !== -1) return { cls: ' calendar__cell--period', label: 'روز پریود ثبت‌شده' };
      if (CALENDAR.predicted.indexOf(day) !== -1) return { cls: ' calendar__cell--predicted', label: 'پریود پیش‌بینی‌شده' };
      if (CALENDAR.ovulation.indexOf(day) !== -1) return { cls: ' calendar__cell--ovulation', label: 'روز تخمک‌گذاری' };
      if (CALENDAR.fertile.indexOf(day) !== -1) return { cls: ' calendar__cell--fertile', label: 'داخل دوره باروری' };
      if (CALENDAR.pms.indexOf(day) !== -1) return { cls: ' calendar__cell--pms', label: 'دوره PMS' };
      return { cls: '', label: 'بدون رویداد ثبت‌شده' };
    }

    function paint() {
      var html = '';
      for (var pad = 0; pad < CALENDAR.offset; pad += 1) {
        html += '<span class="calendar__cell calendar__cell--outside" aria-hidden="true"></span>';
      }
      for (var day = 1; day <= CALENDAR.days; day += 1) {
        var state = stateOf(day);
        var classes = 'calendar__cell' + state.cls + (day === CALENDAR.today ? ' calendar__cell--today' : '');
        var dot = CALENDAR.symptoms.indexOf(day) !== -1 ? '<span class="calendar__dot" aria-hidden="true"></span>' : '';
        html += '<button type="button" class="' + classes + '" data-day="' + day + '" aria-label="روز ' + fa(day) + ' ' +
          CALENDAR.title + (day === CALENDAR.today ? ' — امروز' : '') + '">' + fa(day) + dot + '</button>';
      }
      grid.innerHTML = html;
      var titleEl = el('[data-day-title]');
      var metaEl = el('[data-day-meta]');
      if (titleEl) titleEl.textContent = 'روز ' + fa(selected) + ' ' + (CALENDAR.monthName || CALENDAR.title);
      if (metaEl) metaEl.textContent = stateOf(selected).label;
    }

    grid.addEventListener('click', function (event) {
      var button = event.target.closest('[data-day]');
      if (!button) return;
      var day = Number(button.dataset.day);
      selected = day;
      paint();
    });

    document.addEventListener('niva:cycle-symptoms-updated', paint);
    paint();

    /* one-tap "my period started today" — the single action most users open this screen for */
    var markToday = el('[data-mark-today]');
    if (markToday) {
      var today = tehranYmd();
      var todayIso = today.year + '-' + String(today.month).padStart(2, '0') + '-' + String(today.day).padStart(2, '0');
      var status = el('[data-cycle-status]');
      var alreadySaved = markToday.getAttribute('data-lmp-current') === todayIso;
      if (alreadySaved) {
        markToday.disabled = true;
        markToday.innerHTML = icon('check', 18) + 'شروع پریود امروز ثبت شده';
      }
      markToday.addEventListener('click', function () {
        var config = window.NIVA_CONFIG || {};
        if (!config.rest) {
          if (status) status.textContent = 'اتصال به سرور برقرار نیست؛ تاریخ را از تنظیمات حساب ثبت کن.';
          return;
        }
        markToday.disabled = true;
        if (status) status.textContent = 'در حال ذخیرهٔ تاریخ شروع پریود…';
        fetch(config.rest + '/profile', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
          body: JSON.stringify({ __partial: 'cycle', lmp: todayIso })
        }).then(function (response) {
          return response.json().then(function (payload) {
            if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'ثبت تاریخ انجام نشد.');
            return payload;
          });
        }).then(function () {
          document.dispatchEvent(new CustomEvent('niva:refresh-view'));
        }).catch(function (error) {
          markToday.disabled = false;
          if (status) status.textContent = error.message || 'ثبت تاریخ انجام نشد؛ دوباره تلاش کن.';
        });
      });
    }
  }

  /* ------------------------------------------------------------ documents */

  function refreshLabModules(html) {
    var refreshed = document.createElement('div');
    refreshed.innerHTML = html;
    ['lab_values', 'lab_chart', 'lab_print'].forEach(function (module) {
      var previous = document.querySelector('[data-module="' + module + '"]');
      var next = refreshed.querySelector('[data-module="' + module + '"]');
      if (previous && next) previous.replaceWith(next);
    });
    if (typeof window.NIVA_BOOT_CONTENT === 'function') window.NIVA_BOOT_CONTENT();
  }

  function bindAnalyze() {
    els('[data-lab-upload]').forEach(function (form) {
      if (!bindOnce(form, 'lab-upload')) return;
      var input = form.querySelector('input[type="file"]');
      var status = form.querySelector('[data-lab-status]');
      var output = form.parentNode.querySelector('[data-lab-ai-result]');
      var submit = form.querySelector('[type="submit"]');
      if (!input) return;

      function analyze(file, paymentSource) {
        if (!file) return;
        if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
          if (status) status.textContent = 'فقط تصویر JPG، PNG یا WebP پذیرفته می‌شود.';
          return;
        }
        var config = window.NIVA_CONFIG || {};
        var rest = config.rest || (config.plugin && config.plugin.rest);
        var nonce = config.nonce || (config.plugin && config.plugin.nonce) || '';
        if (!rest) {
          if (status) status.textContent = 'اتصال به سرور برقرار نیست.';
          return;
        }
        var data = new FormData();
        data.append('report', file);
        if (paymentSource) data.append('payment_source', paymentSource);
        if (submit) submit.disabled = true;
        if (status) status.textContent = 'در حال ارسال امن تصویر و تحلیل با هوش مصنوعی…';
        if (output) output.replaceChildren();
        fetch(rest + '/labs/analyze', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'X-WP-Nonce': nonce },
          body: data
        }).then(function (response) {
          return response.json().then(function (payload) {
            if (!response.ok) {
              var error = new Error(payload && payload.message ? payload.message : 'تحلیل آزمایش انجام نشد.');
              error.payload = payload;
              throw error;
            }
            return payload;
          });
        }).then(function (payload) {
          if (status) {
            var paymentText = payload.payment && payload.payment.source === 'plan'
              ? ' از سهمیهٔ اشتراک استفاده شد.'
              : (payload.payment && Number(payload.payment.cost) > 0 ? ' هزینه: ' + fa(payload.payment.cost) + ' اعتبار.' : '');
            status.textContent = (payload.message || 'تحلیل و ثبت نتیجه‌ها انجام شد.') + paymentText;
          }
          if (!output) return;
          var heading = document.createElement('h3');
          heading.textContent = payload.title || 'خلاصهٔ نتیجه';
          output.appendChild(heading);
          var summary = document.createElement('p');
          summary.textContent = payload.summary || '';
          output.appendChild(summary);
          var tableWrap = document.createElement('div');
          tableWrap.className = 'lab-analysis-table-wrap';
          var table = document.createElement('table');
          table.className = 'lab-analysis-table';
          var head = document.createElement('thead');
          var headerRow = document.createElement('tr');
          var columnLabels = ['نشانگر', 'مقدار', 'واحد', 'وضعیت', 'توضیح کوتاه'];
          columnLabels.forEach(function (label) {
            var cell = document.createElement('th');
            cell.scope = 'col';
            cell.textContent = label;
            headerRow.appendChild(cell);
          });
          head.appendChild(headerRow);
          table.appendChild(head);
          var body = document.createElement('tbody');
          (payload.values || []).forEach(function (item) {
            var row = document.createElement('tr');
            [item.name, item.value, item.unit, item.status, item.explanation].forEach(function (value, index) {
              var cell = document.createElement('td');
              cell.setAttribute('data-label', columnLabels[index]);
              cell.textContent = value == null ? '' : String(value);
              row.appendChild(cell);
            });
            body.appendChild(row);
          });
          table.appendChild(body);
          tableWrap.appendChild(table);
          output.appendChild(tableWrap);
          if (payload.wallet) paintLabWallet(payload.wallet);
          if (payload.modules_html) refreshLabModules(payload.modules_html);
        }).catch(function (error) {
          var payload = error.payload || {};
          var errorData = payload.data || {};
          if (payload.code === 'niva_lab_payment_choice_required' && !paymentSource) {
            if (!errorData.payment_available) {
              if (status) status.textContent = error.message || 'سهمیه تمام شده است؛ برای ادامه باید اشتراک بخری.';
              if (output) {
                output.replaceChildren();
                addLabPaymentActions(output, errorData.credits_url, errorData.upgrade_url);
              }
              return;
            }
            var charge = Number(errorData.cost) || 0;
            var balance = Number(errorData.balance) || 0;
            var prompt = 'سهمیهٔ اشتراک برای تحلیل باقی نمانده است. برای این تحلیل ' + fa(charge) +
              ' اعتبار لازم است و موجودی فعلی ' + fa(balance) + ' اعتبار است. آیا استفاده از اعتبار را تأیید می‌کنی؟';
            if (window.confirm(prompt)) {
              analyze(file, 'credits');
            } else if (status) {
              status.textContent = 'تحلیل انجام نشد و هیچ اعتباری کسر نشد.';
            }
            return;
          }
          if (payload.code === 'niva_insufficient_credits') {
            if (status) status.textContent = error.message || 'اعتبار کافی نیست؛ اعتبارت را شارژ کن یا اشتراک بخر.';
            if (output) {
              output.replaceChildren();
              var insufficient = document.createElement('p');
              insufficient.textContent = error.message || 'اعتبار کافی نیست.';
              output.appendChild(insufficient);
              addLabPaymentActions(output, errorData.credits_url, errorData.upgrade_url);
            }
            return;
          }
          if (status) status.textContent = error.message || 'تحلیل آزمایش انجام نشد؛ دوباره تلاش کن.';
        }).then(function () {
          input.value = '';
          if (submit) submit.disabled = false;
        });
      }

      function addLabPaymentActions(output, creditsUrl, plansUrl) {
        var actions = document.createElement('div');
        actions.className = 'lab-payment-actions';
        [
          { label: 'شارژ اعتبار', href: creditsUrl },
          { label: 'مشاهدهٔ اشتراک‌ها', href: plansUrl }
        ].forEach(function (item) {
          if (!item.href) return;
          var link = document.createElement('a');
          link.className = 'btn btn--secondary btn--sm';
          link.href = item.href;
          link.textContent = item.label;
          actions.appendChild(link);
        });
        if (actions.childNodes.length) output.appendChild(actions);
      }

      function paintLabWallet(summary) {
        var bar = document.querySelector('[data-niva-credits]');
        if (!bar || !summary) return;
        var balance = bar.querySelector('[data-niva-balance]');
        var quota = bar.querySelector('[data-niva-quota]');
        var spent = bar.querySelector('.niva-credits__item:nth-child(2) bdi');
        if (balance) balance.textContent = fa(summary.balance);
        if (quota) quota.textContent = fa(summary.quota_left);
        if (spent) spent.textContent = fa(summary.spent_total);
        bar.classList.toggle('niva-credits--low', !!summary.low);
      }

      form.addEventListener('submit', function (event) {
        event.preventDefault();
        analyze(input.files && input.files[0]);
      });
    });
  }

  function bindCycleSymptoms() {
    var form = el('[data-cycle-symptoms]');
    if (!form || !bindOnce(form, 'cycle-symptoms')) return;
    var status = el('[data-cycle-symptoms-status]', form);
    var history = el('[data-cycle-symptoms-history]');
    var labels = {
      cramps: 'گرفتگی یا درد',
      bloating: 'نفخ',
      headache: 'سردرد',
      fatigue: 'خستگی',
      mood: 'تغییر خلق',
      spotting: 'لکه‌بینی'
    };
    var config = window.NIVA_CONFIG || {};
    var rest = config.rest || (config.plugin && config.plugin.rest);
    var nonce = config.nonce || (config.plugin && config.plugin.nonce) || '';

    function showHistory(rows) {
      if (!history) return;
      history.replaceChildren();
      var symptoms = rows.filter(function (row) { return row.kind === 'cycle_symptom' && labels[row.value]; });
      var groups = {};
      symptoms.forEach(function (row) {
        groups[row.log_date] = groups[row.log_date] || [];
        if (groups[row.log_date].indexOf(labels[row.value]) === -1) groups[row.log_date].push(labels[row.value]);
      });
      var dates = Object.keys(groups).sort().reverse().slice(0, 7);
      if (!dates.length) {
        var empty = document.createElement('p');
        empty.className = 'caption';
        empty.textContent = 'هنوز علامتی ثبت نشده است.';
        history.appendChild(empty);
        return;
      }
      dates.forEach(function (date) {
        var row = document.createElement('p');
        row.className = 'cycle-symptoms__entry';
        var dateParts = date.split('-').map(Number);
        var dayDate = new Date(Date.UTC(dateParts[0], dateParts[1] - 1, dateParts[2], 12));
        var dateText = new Intl.DateTimeFormat('fa-IR-u-ca-persian', {
          year: 'numeric', month: 'long', day: 'numeric', timeZone: 'Asia/Tehran'
        }).format(dayDate);
        row.textContent = dateText + ' · ' + groups[date].join('، ');
        history.appendChild(row);
      });
    }

    function refreshLogs() {
      if (!rest) {
        if (status) status.textContent = 'اتصال به سرور برقرار نیست.';
        return Promise.reject(new Error('اتصال به سرور برقرار نیست.'));
      }
      return fetch(rest + '/logs', {
        credentials: 'same-origin',
        headers: { 'X-WP-Nonce': nonce }
      }).then(function (response) {
        return response.json().then(function (payload) {
          if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'سابقهٔ علائم بارگذاری نشد.');
          return payload;
        });
      }).then(function (payload) {
        var rows = Array.isArray(payload.items) ? payload.items : [];
        showHistory(rows);
        var monthRows = rows.filter(function (row) {
          if (row.kind !== 'cycle_symptom') return false;
          var parts = String(row.log_date || '').split('-').map(Number);
          if (parts.length !== 3) return false;
          var date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12));
          var jalali = new Intl.DateTimeFormat('en-u-ca-persian', {
            year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'Asia/Tehran'
          }).formatToParts(date).reduce(function (result, part) {
            if (part.type !== 'literal') result[part.type] = Number(part.value.replace(/[^\d]/g, ''));
            return result;
          }, {});
          return jalali.year === CALENDAR.year && MONTHS[jalali.month - 1] === CALENDAR.monthName;
        }).map(function (row) {
          var parts = String(row.log_date).split('-').map(Number);
          var date = new Date(Date.UTC(parts[0], parts[1] - 1, parts[2], 12));
          return Number(new Intl.DateTimeFormat('en-u-ca-persian', {
            day: 'numeric', timeZone: 'Asia/Tehran'
          }).format(date));
        });
        CALENDAR.symptoms = monthRows.filter(function (day, index) { return monthRows.indexOf(day) === index; });
        document.dispatchEvent(new CustomEvent('niva:cycle-symptoms-updated'));
      });
    }

    refreshLogs().catch(function (error) {
      if (status) status.textContent = error.message;
    });
    var dateInput = el('[data-cycle-jalali-date]', form);
    var today = todayJalali();
    if (dateInput && today) dateInput.value = jalaliLabel(today);

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var convertDate = window.NIVA_JALALI_TO_GREGORIAN;
      var dateField = form.querySelector('[name="date"]');
      var date = typeof convertDate === 'function' && dateField ? convertDate(dateField.value) : null;
      if (!date) {
        if (status) status.textContent = 'تاریخ را شمسی و به‌شکل سال/ماه/روز وارد کن؛ نمونه: ۱۴۰۵/۰۱/۰۱.';
        if (dateField) dateField.focus();
        return;
      }
      if (!rest) {
        if (status) status.textContent = 'اتصال به سرور برقرار نیست.';
        return;
      }
      var selected = els('input[name="symptoms[]"]:checked', form).map(function (input) { return input.value; });
      if (!selected.length) {
        if (status) status.textContent = 'برای ذخیره، دست‌کم یک علامت انتخاب کن.';
        return;
      }
      var submit = form.querySelector('[type="submit"]');
      var noteField = form.querySelector('[name="note"]');
      var note = noteField ? noteField.value : '';
      if (submit) submit.disabled = true;
      if (status) status.textContent = 'در حال ذخیرهٔ علائم…';
      selected.reduce(function (promise, symptom) {
        return promise.then(function () {
          return fetch(rest + '/logs', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
            body: JSON.stringify({ date: date, kind: 'cycle_symptom', value: symptom, note: note })
          }).then(function (response) {
            return response.json().then(function (payload) {
              if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'ذخیرهٔ علامت انجام نشد.');
              return payload;
            });
          });
        });
      }, Promise.resolve()).then(function () {
        form.querySelectorAll('input[type="checkbox"]').forEach(function (input) { input.checked = false; });
        if (noteField) noteField.value = '';
        if (status) status.textContent = 'علائم انتخاب‌شده ذخیره شد.';
        return refreshLogs();
      }).catch(function (error) {
        if (status) status.textContent = error.message || 'ذخیرهٔ علائم انجام نشد؛ دوباره تلاش کن.';
      }).then(function () {
        if (submit) submit.disabled = false;
      });
    });
  }

  /* ------------------------------------------------------------- mood form */

  function bindMood() {
    var group = el('[data-mood]');
    if (!group) return;
    var submit = el('[data-mood-submit]');
    var success = el('[data-mood-success]');
    var moodNote = el('#mood-note');
    els('[data-mood-value]', group).forEach(function (button) {
      button.addEventListener('click', function () {
        els('[data-mood-value]', group).forEach(function (other) {
          other.classList.remove('mood-btn--selected');
          other.setAttribute('aria-pressed', 'false');
        });
        button.classList.add('mood-btn--selected');
        button.setAttribute('aria-pressed', 'true');
        if (submit) submit.disabled = false;
        if (success) success.hidden = true;
      });
    });
    if (submit) submit.addEventListener('click', function () {
      var answered = els('[data-assess-group]');
      var total = 0;
      var count = 0;
      answered.forEach(function (group) {
        var picked = el('button.chip--selected', group);
        var value = picked ? Number(picked.getAttribute('data-value') || 0) : 0;
        total += value;
        count += 1;
      });
      /*
       * The score is appended to the user's own history through the profile API,
       * so the trend chart shows real points instead of a fixed sample line.
       */
      var config = window.NIVA_CONFIG || {};
      if (config.rest) {
        var history = String((config.user && config.user.mood) || '');
        var next = (history ? history.split(',') : []).concat([String(total)]).slice(-24).join(',');
        fetch(config.rest + '/profile', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
          body: JSON.stringify({ __partial: 'mood', mood_scores: next })
        }).then(function () {
          if (result) result.textContent = 'نمرهٔ این ماه: ' + fa(total) + ' از ۲۷ (ذخیره شد)';
        });
      }
      if (result) result.textContent = 'نمرهٔ این ماه: ' + fa(total) + ' از ۲۷';

      if (submit.disabled) return;
      if (success) success.hidden = false;
    syncToServer('logs', { kind: 'mood', value: String(selected), note: moodNote && moodNote.value ? moodNote.value : '' });
      if (success) success.scrollIntoView({ behavior: 'smooth', block: 'nearest' });
    });
  }

  /* -------------------------------------------------------------- breathing */

  var PHASES = [{ name: 'دم', seconds: 4 }, { name: 'نگه‌داشتن', seconds: 7 }, { name: 'بازدم', seconds: 8 }];

  function bindBreathing() {
    var ring = el('[data-breath-ring]');
    if (!ring) return;
    var toggle = el('[data-breath-toggle]');
    var reset = el('[data-breath-reset]');
    var running = false, phase = 0, elapsed = 0, timer = null;

    /*
     * The visual used to run on its own fixed 10s CSS animation, so it grew and
     * shrank at a different rhythm than the counter next to it. The scale is now
     * driven by the current phase's real duration.
     */
    var PHASE_SCALE = [1, 1, 0.62, 0.62];

    function paint() {
      ring.innerHTML = PHASES[phase].name + ' · ' + fa(Math.max(0, PHASES[phase].seconds - elapsed));
      ring.style.transitionDuration = PHASES[phase].seconds + 's';
      ring.style.transform = 'scale(' + PHASE_SCALE[phase % PHASE_SCALE.length] + ')';
    }
    function stop() {
      running = false;
      if (timer) window.clearInterval(timer);
      timer = null;
      if (toggle) toggle.innerHTML = icon('play', 18) + 'شروع تمرین';
    }
    function tick() {
      elapsed += 1;
      if (elapsed >= PHASES[phase].seconds) { phase = (phase + 1) % PHASES.length; elapsed = 0; }
      paint();
    }

    if (toggle) toggle.addEventListener('click', function () {
      if (running) { stop(); return; }
      running = true;
      toggle.innerHTML = icon('pause', 18) + 'توقف تمرین';
      timer = window.setInterval(tick, 1000);
    });
    if (reset) reset.addEventListener('click', function () { stop(); phase = 0; elapsed = 0; ring.style.transitionDuration = '0.4s'; ring.style.transform = 'scale(0.62)'; paint(); });
    paint();
  }

  /* ------------------------------------------------------------------ chat */

  var COMPANION_REPLIES = [
    'ممنون که نوشتی. این روزها بیشتر چه چیزی حالت را سنگین می‌کند: افکار، خواب، یا رابطه‌ها؟',
    'شنیدن این جمله سخت است. اگر بخواهی، با هم یکی از این‌ها را باز کنیم یا فقط می‌خواهی از خودت بگویی؟',
    'یک قدم کوچک برای امروز پیشنهاد می‌کنم: یک تمرین تنفس سه‌دقیقه‌ای. اگر انجام دادی، حالت را ثبت کن تا روند هفتگی‌ات کامل‌تر شود.',
    'چیزی که نوشتی ارزش پیگیری دارد. اگر این حالت ادامه پیدا کرد، می‌توانی از همین‌جا درخواست مشاوره ثبت کنی.'
  ];
  var RISK_KEYWORDS = ['خودکشی', 'خودم را بکشم', 'آسیب به خودم', 'تمومش کنم', 'نمی‌خوام زنده باشم'];
  var CRISIS_REPLY = 'چیزی که نوشتی برای من مهم است و نمی‌خواهم سبک از آن رد شوم. اگر الان به فکر آسیب رساندن به خودت هستی، همین حالا با اورژانس تماس بگیر یا از یک فرد مورد اعتماد بخواه کنارت باشد. این گفت‌وگو جای کمک فوری نیست.';

  function bindChat() {
    var log = el('[data-chat-log]');
    if (!log) return;
    var form = el('[data-chat-form]');
    var input = el('#companion-input');
    var empty = el('[data-chat-empty]');
    var crisis = el('[data-chat-crisis]');
    var replyIndex = 0;

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var text = (input.value || '').trim();
      if (!text) return;
      if (empty) empty.hidden = true;
      log.insertAdjacentHTML('beforeend', '<p class="chat__bubble chat__bubble--me" dir="auto"></p>');
      log.lastElementChild.textContent = text;
      input.value = '';
      var risky = RISK_KEYWORDS.some(function (k) { return text.indexOf(k) !== -1; });
      var reply = risky ? CRISIS_REPLY : COMPANION_REPLIES[replyIndex % COMPANION_REPLIES.length];
      if (!risky) replyIndex += 1;
      log.insertAdjacentHTML('beforeend', '<p class="chat__bubble" dir="auto"></p>');
      log.lastElementChild.textContent = reply;
      log.scrollTop = log.scrollHeight;
      if (risky && crisis) crisis.hidden = false;
    });
  }

  /* ----------------------------------------------------------------- forms */

  function showError(field, message) {
    field.classList.add('field__input--error');
    var slot = el('[data-error-for="' + field.id + '"]');
    if (slot) { slot.textContent = message; slot.hidden = false; }
  }
  function clearError(field) {
    field.classList.remove('field__input--error');
    var slot = el('[data-error-for="' + field.id + '"]');
    if (slot) { slot.hidden = true; slot.textContent = ''; }
  }

  function bindThoughtRecord() {
    var form = el('[data-thought-form]');
    if (!form) return;
    var first = el('#thought-auto');
    var error = el('[data-thought-error]');
    var success = el('[data-thought-success]');
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!first.value.trim()) {
        if (error) error.hidden = false;
        first.classList.add('field__input--error');
        first.focus();
        return;
      }
      if (error) error.hidden = true;
      first.classList.remove('field__input--error');
      if (success) success.hidden = false;
    });
  }

  function bindRequestForm() {
    var form = el('[data-request-form]');
    if (!form) return;
    var name = el('#req-name'), contact = el('#req-contact'), plan = el('#req-plan');
    var success = el('[data-request-success]'), planOut = el('[data-request-plan-out]');
    [name, contact].forEach(function (field) { field.addEventListener('input', function () { clearError(field); }); });

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var valid = true;
      if (!name.value.trim()) { showError(name, 'نام و نام خانوادگی را وارد کن.'); valid = false; }
      var value = contact.value.trim();
      var okEmail = /^[^@\s]+@[^@\s]+\.[^@\s]+$/.test(value);
      var okPhone = /^[0-9+\s-]{8,}$/.test(value);
      if (!value) { showError(contact, 'یک راه تماس (شماره موبایل یا ایمیل) لازم است تا کارشناس ما پیام بدهد.'); valid = false; }
      else if (!okEmail && !okPhone) { showError(contact, 'شماره موبایل یا ایمیل معتبر وارد کن.'); valid = false; }
      if (!valid) return;

      var button = el('[data-request-submit]', form);
      button.disabled = true;
      button.innerHTML = '<span class="btn__spinner" aria-hidden="true"></span>در حال ثبت…';
      window.setTimeout(function () {
        if (planOut) planOut.textContent = plan.options[plan.selectedIndex].text;
        form.hidden = true;
        if (success) success.hidden = false;
        button.disabled = false;
        button.innerHTML = icon('send', 18) + 'ثبت درخواست اشتراک';
      }, 700);
    });

    els('[data-request-edit]').forEach(function (b) {
      b.addEventListener('click', function () { form.hidden = false; if (success) success.hidden = true; });
    });
  }

  /**
   * «درخواست فعال‌سازی پلن همکاران» jumps straight to the request form when it
   * is on the same page, and navigates normally when it is not.
   */
  function bindPartnerCta() {
    var buttons = els('[data-partner-cta]');
    if (!buttons.length) return;
    buttons.forEach(function (button) {
      button.addEventListener('click', function (event) {
        var form = el('[data-partner-form]');
        if (!form) return; // no form here: let the link do its job
        event.preventDefault();
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
        var first = form.querySelector('input, select, textarea');
        if (first) window.setTimeout(function () { first.focus({ preventScroll: true }); }, 420);
      });
    });
  }

  function bindAssessment() {
    /* The questionnaire opens inside its own module: no navigation, no reload. */
    els('[data-assessment-open]').forEach(function (button) {
      if (!bindOnce(button, 'assess-open')) return;
      button.addEventListener('click', function () {
        var sheet = el('[data-assessment-sheet]');
        if (!sheet) return;
        sheet.hidden = !sheet.hidden;
        button.textContent = sheet.hidden ? 'تکمیل پرسشنامهٔ این ماه' : 'بستن پرسشنامه';
        if (!sheet.hidden) sheet.scrollIntoView({ block: 'nearest' });
      });
    });

    els('[data-assessment-sheet]').forEach(function (sheet) {
      if (!bindOnce(sheet, 'assess-sheet')) return;

      var rows = sheet.querySelectorAll('[data-mood-row]');
      var staticGroups = sheet.querySelectorAll('[data-assess-group]');
      var out = sheet.querySelector('[data-mood-total]');
      var message = sheet.querySelector('[data-mood-msg]');

      var score = function () {
        var sum = 0, answered = 0;
        rows.forEach(function (row) {
          var on = row.querySelector('.chip--selected');
          if (on) { sum += Number(on.getAttribute('data-value')); answered++; }
        });
        return { sum: sum, answered: answered, rows: rows.length };
      };

      var paint = function () {
        if (!out) return;
        var now = score();
        out.textContent = 'نمرهٔ تو: ' + fa(now.sum) + ' از ' + fa(now.rows * 3) + ' · ' + fa(now.answered) + ' از ' + fa(now.rows) + ' پاسخ';
      };

      rows.forEach(function (row) {
        row.querySelectorAll('.chip').forEach(function (chip) {
          chip.addEventListener('click', function () {
            row.querySelectorAll('.chip').forEach(function (other) { other.classList.remove('chip--selected'); });
            chip.classList.add('chip--selected');
            paint();
          });
        });
      });

      var save = sheet.querySelector('[data-mood-save]');
      if (save) {
        save.addEventListener('click', function () {
          var now = score();
          if (now.answered < now.rows) {
            if (message) message.textContent = 'به همهٔ پرسش‌ها پاسخ بده.';
            return;
          }
          var config = window.NIVA_CONFIG || {};
          if (!config.rest) {
            if (message) message.textContent = 'اتصال به سرور برقرار نیست.';
            return;
          }
          var answers = Array.prototype.map.call(rows, function (row) {
            var selected = row.querySelector('.chip--selected');
            return selected ? Number(selected.getAttribute('data-value')) : null;
          });
          save.disabled = true;
          if (message) message.textContent = 'در حال ذخیره…';
          fetch(config.rest + '/profile/assessment', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
            body: JSON.stringify({ answers: answers })
          }).then(function (response) {
            return response.json().then(function (payload) {
              if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'ذخیره نشد؛ یک بار دیگر تلاش کن.');
              return payload;
            });
          }).then(function (payload) {
            /* Saved in place: the score is updated on screen, nothing reloads. */
            var module = sheet.closest('.niva-module');
            var last = module ? module.querySelector('[data-mood-last]') : null;
            if (last) {
              var scoreNode = last.firstChild;
              if (scoreNode && scoreNode.nodeType === Node.TEXT_NODE) scoreNode.nodeValue = fa(payload.assessment.score) + ' ';
            }
            var saved = module ? module.querySelector('[data-mood-saved]') : null;
            if ( saved ) saved.textContent = 'نمره‌ات ذخیره شد.';
            var summary = module ? module.querySelector('[data-assessment-summary]') : null;
            if (summary) summary.textContent = 'نمرهٔ این ماه: ' + fa(payload.assessment.score) + ' از ۲۷؛ ماه بعد دوباره می‌توانی ارزیابی کنی.';
            var openButton = module ? module.querySelector('[data-assessment-open]') : null;
            if (openButton) {
              openButton.disabled = true;
              openButton.textContent = 'این ماه تکمیل شده';
            }
            if (message) message.textContent = 'ذخیره شد.';
            if (module) {
              var chart = module.querySelector('.mood-trend');
              if (!chart) {
                chart = document.createElement('div');
                chart.className = 'mood-trend';
                chart.setAttribute('aria-label', 'روند ماهانهٔ نمرهٔ حال');
                module.querySelector('.card').appendChild(chart);
              }
              var month = document.createElement('div');
              month.className = 'mood-trend__row';
              var monthLabel = document.createElement('span');
              monthLabel.className = 'caption';
              monthLabel.textContent = fa(String(payload.assessment.month).replace('-', '/'));
              var track = document.createElement('span');
              track.className = 'mood-trend__track';
              var fill = document.createElement('span');
              fill.style.width = Math.round((Number(payload.assessment.score) / 27) * 100) + '%';
              track.appendChild(fill);
              var valueLabel = document.createElement('b');
              valueLabel.textContent = fa(payload.assessment.score) + ' / ۲۷';
              month.appendChild(monthLabel);
              month.appendChild(track);
              month.appendChild(valueLabel);
              chart.appendChild(month);
            }
            rows.forEach(function (row) {
              row.querySelectorAll('.chip--selected').forEach(function (chip) { chip.classList.remove('chip--selected'); });
            });
            if ( out ) out.textContent = 'نمرهٔ تو: ۰ از ' + fa( now.rows * 3 );
            sheet.hidden = true;
          }).catch(function (error) {
            if (message) message.textContent = error.message || 'ذخیره نشد؛ یک بار دیگر تلاش کن.';
            save.disabled = false;
          });
        });
      }

      var submit = sheet.querySelector('[data-assessment-submit]');
      if (submit) {
        var staticScore = function () {
          var sum = 0, answered = 0;
          staticGroups.forEach(function (group) {
            var selected = group.querySelector('.chip--selected');
            if (selected) {
              sum += Number(selected.getAttribute('data-value'));
              answered++;
            }
          });
          return { sum: sum, answered: answered, rows: staticGroups.length };
        };
        staticGroups.forEach(function (group) {
          group.querySelectorAll('[data-chip]').forEach(function (chip) {
            chip.addEventListener('click', function () {
              group.querySelectorAll('[data-chip]').forEach(function (other) {
                other.classList.remove('chip--selected');
                other.setAttribute('aria-pressed', 'false');
              });
              chip.classList.add('chip--selected');
              chip.setAttribute('aria-pressed', 'true');
              var current = staticScore();
              var result = sheet.querySelector('[data-assessment-result]');
              if (result) {
                result.hidden = false;
                result.textContent = 'نمرهٔ فعلی: ' + fa(current.sum) + ' از ' + fa(current.rows * 3);
              }
              submit.disabled = current.answered !== current.rows;
            });
          });
        });
        submit.addEventListener('click', function () {
          var current = staticScore();
          var result = sheet.querySelector('[data-assessment-result]');
          var config = window.NIVA_CONFIG || {};
          if (current.answered !== current.rows) {
            if (result) result.textContent = 'لطفاً به همهٔ پرسش‌ها پاسخ بده.';
            return;
          }
          if (!config.rest) {
            if (result) result.textContent = 'اتصال به سرور برقرار نیست.';
            return;
          }
          var oldScores = (sheet.getAttribute('data-mood-history') || '').split(',').filter(Boolean);
          oldScores.push(String(current.sum));
          oldScores = oldScores.slice(-24);
          submit.disabled = true;
          if (result) {
            result.hidden = false;
            result.textContent = 'در حال ذخیره…';
          }
          fetch(config.rest + '/profile', {
            method: 'POST',
            credentials: 'same-origin',
            headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
            body: JSON.stringify({ __partial: 'mood', mood_scores: oldScores.join(',') })
          }).then(function (response) {
            return response.json().then(function (payload) {
              if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'ذخیره نشد.');
              return payload;
            });
          }).then(function () {
            sheet.setAttribute('data-mood-history', oldScores.join(','));
            if (result) result.textContent = 'پاسخ‌ها ذخیره شد. نمرهٔ تو ' + fa(current.sum) + ' از ' + fa(current.rows * 3) + ' است.';
            var summary = sheet.closest('main') && sheet.closest('main').querySelector('[data-assessment-summary]');
            if (summary) summary.textContent = 'آخرین نمرهٔ ثبت‌شده: ' + fa(current.sum) + ' از ' + fa(current.rows * 3);
            submit.textContent = 'ذخیره شد';
          }).catch(function (error) {
            if (result) result.textContent = error.message || 'ذخیره نشد؛ اتصال را بررسی کن و دوباره تلاش کن.';
            submit.disabled = false;
          });
        });
      }

      els('[data-assessment-close]', sheet).forEach(function (button) {
        button.addEventListener('click', function () { sheet.hidden = true; });
      });
      sheet.addEventListener('click', function (event) {
        if (event.target === sheet) sheet.hidden = true;
      });
      document.addEventListener('keydown', function (event) {
        if (event.key === 'Escape') sheet.hidden = true;
      });
    });
  }

  function bindCrisisSheet() {
    var sheet = el('[data-crisis-sheet]');
    if (!sheet) return;
    els('[data-crisis-open]').forEach(function (b) { b.addEventListener('click', function () { sheet.hidden = false; }); });
    els('[data-crisis-close]').forEach(function (b) { b.addEventListener('click', function () { sheet.hidden = true; }); });
    els('.sheet__scrim', sheet).forEach(function (s) { s.addEventListener('click', function () { sheet.hidden = true; }); });
    document.addEventListener('keydown', function (event) { if (event.key === 'Escape') sheet.hidden = true; });
  }

  function bindBillingToggle() {
    var group = el('[data-billing]');
    if (!group) return;
    var buttons = els('[data-billing-value]', group);

    function paint(mode) {
      els('[data-price]').forEach(function (node) { node.textContent = faNum(node.dataset[mode]); });
      els('[data-price-period]').forEach(function (node) { node.textContent = node.dataset[mode]; });
    }

    paint('monthly');
    buttons.forEach(function (button) {
      button.addEventListener('click', function () {
        buttons.forEach(function (other) {
          other.classList.remove('billing-toggle__btn--active');
          other.setAttribute('aria-pressed', 'false');
        });
        button.classList.add('billing-toggle__btn--active');
        button.setAttribute('aria-pressed', 'true');
        paint(button.dataset.billingValue === 'yearly' ? 'yearly' : 'monthly');
      });
    });
  }

  function bindPrint() {
    els('[data-print]').forEach(function (b) { b.addEventListener('click', function () { window.print(); }); });
  }

  /* ------------------------------------------------------- baby: growth */

  /**
   * Growth check. Two honest layers:
   *  1) From the child's own records: weight trend between visits (always available).
   *  2) Against an official reference table: needs `window.NIVA_GROWTH_REFERENCE`
   *     (LMS values) supplied by the reviewing clinician. Until it is present the
   *     UI says so instead of inventing numbers.
   */
  function analyseGrowth(measures) {
    var sorted = measures.slice().sort(function (a, b) { return a.ageMonths - b.ageMonths; });
    var last = sorted[sorted.length - 1];
    var prev = sorted[sorted.length - 2];
    var out = { hasData: Boolean(last), trend: null, reference: null };

    if (!last) return out;

    if (prev) {
      var gainGrams = Math.round((last.weight - prev.weight) * 1000);
      var months = Math.max(1, last.ageMonths - prev.ageMonths);
      out.trend = {
        gainGrams: gainGrams,
        months: months,
        perMonth: Math.round(gainGrams / months),
        verdict: gainGrams < 0 ? 'alert' : gainGrams === 0 ? 'watch' : 'ok'
      };
    }

    var ref = window.NIVA_GROWTH_REFERENCE;
    if (ref && typeof ref.zScore === 'function') {
      out.reference = ref.zScore(last);
    }
    return out;
  }

  function bindBaby() {
    var root = el('[data-baby-root]');
    if (!root) return;

    var measureForm = el('[data-baby-measure]');
    var nameOut = el('[data-baby-name-out]');
    var ageOut = el('[data-baby-age]');
    var bornOut = el('[data-baby-born]');
    var verdict = el('[data-baby-verdict]');
    var history = el('[data-baby-history]');
    var refCard = el('[data-baby-reference]');
    var chart = el('[data-chart="babyWeight"]');
    var status = el('[data-baby-status]');
    var errorOut = el('[data-baby-error]');
    var birth = {
      year: toNumber(root.dataset.babyYear),
      month: toNumber(root.dataset.babyMonth),
      day: toNumber(root.dataset.babyDay)
    };
    var hasBirth = birth.year > 0 && birth.month > 0 && birth.day > 0;
    var state = {
      profile: hasBirth ? { name: root.dataset.babyName || '', birth: birth } : null,
      measures: []
    };
    var today = todayJalali();

    function requestGrowth(method, payload) {
      var config = window.NIVA_CONFIG;
      if (!config || !config.plugin || !config.plugin.rest || !config.plugin.nonce) {
        return Promise.reject(new Error('اتصال امن به پروندهٔ رشد در دسترس نیست.'));
      }
      return fetch(config.plugin.rest + '/growth', {
        method: method,
        headers: {
          'Accept': 'application/json',
          'Content-Type': 'application/json',
          'X-WP-Nonce': config.plugin.nonce
        },
        body: payload ? JSON.stringify(payload) : undefined
      }).then(function (response) {
        return response.json().then(function (data) {
          if (!response.ok) {
            var error = new Error(data.message || 'اطلاعات رشد ذخیره/بارگذاری نشد.');
            error.upgrade = data.data && data.data.upgrade ? data.data.upgrade : '';
            throw error;
          }
          return data;
        });
      });
    }

    function dateLabel(isoDate) {
      if (!isoDate || !/^\d{4}-\d{2}-\d{2}$/.test(isoDate)) return '';
      try {
        var parts = new Intl.DateTimeFormat('en-u-ca-persian', {
          year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'Asia/Tehran'
        }).formatToParts(new Date(isoDate + 'T12:00:00Z'));
        var result = {};
        parts.forEach(function (part) {
          if (part.type !== 'literal') result[part.type] = Number(part.value.replace(/[^\d]/g, ''));
        });
        return result.year && result.month && result.day
          ? jalaliLabel({ year: result.year, month: result.month, day: result.day })
          : '';
      } catch (error) {
        return '';
      }
    }

    function todayGregorian() {
      var date = tehranYmd();
      return date.year + '-' + String(date.month).padStart(2, '0') + '-' + String(date.day).padStart(2, '0');
    }

    function showFailure(error) {
      if (errorOut) {
        errorOut.hidden = false;
        errorOut.textContent = error.message || 'ذخیرهٔ اطلاعات رشد ممکن نشد.';
        if (error.upgrade) {
          var upgrade = document.createElement('a');
          upgrade.className = 'link-inline';
          upgrade.href = error.upgrade;
          upgrade.textContent = 'دیدن پلن‌ها';
          errorOut.appendChild(document.createTextNode(' '));
          errorOut.appendChild(upgrade);
        }
      } else if (status) {
        status.textContent = error.message || 'ذخیرهٔ اطلاعات رشد ممکن نشد.';
      }
    }

    function ageOf(profile) {
      if (!profile || !today) return null;
      var months = monthsBetween(profile.birth, today);
      return { months: months, label: months < 1 ? 'کمتر از یک ماه' : fa(months) + ' ماه' };
    }

    function daysWord(months) {
      if (months < 12) return fa(months) + ' ماهگی';
      var years = Math.floor(months / 12);
      var rest = months % 12;
      return fa(years) + ' سال' + (rest ? ' و ' + fa(rest) + ' ماه' : '');
    }

    function renderVerdict() {
      if (!verdict) return;
      var sorted = state.measures.slice().sort(function (a, b) { return a.ageMonths - b.ageMonths; });
      var result = analyseGrowth(state.measures);
      if (!result.hasData) {
        verdict.innerHTML =
          '<div class="growth-verdict">' +
            '<span class="growth-verdict__icon" aria-hidden="true">' + icon('trending-up', 20) + '</span>' +
            '<div><p style="font-weight:700">هنوز اندازه‌ای ثبت نشده</p>' +
            '<p class="caption">وزن و قد امروز را وارد کن تا وضعیت رشد را ببینی.</p></div></div>';
        return;
      }
      var last = sorted[sorted.length - 1];
      var blocks = [];

      if (result.trend) {
        var tone = result.trend.verdict === 'ok' ? 'ok' : result.trend.verdict === 'watch' ? 'watch' : 'alert';
        var title = result.trend.verdict === 'ok'
          ? 'افزایش وزن، روی مسیر'
          : result.trend.verdict === 'watch'
            ? 'افزایش وزن متوقف شده'
            : 'کاهش وزن نسبت به ثبت قبلی';
        var advice = result.trend.verdict === 'ok'
          ? 'در فاصله‌ی ' + fa(result.trend.months) + ' ماه، ' + fa(result.trend.gainGrams) + ' گرم افزایش ثبت شده است.'
          : 'این الگو با پزشک یا مراقب سلامت کودک در میان بگذار؛ ثبت مرتب وزن بهترین راه پیگیری است.';
        blocks.push(
          '<div class="growth-verdict growth-verdict--' + tone + '">' +
            '<span class="growth-verdict__icon" aria-hidden="true">' +
              icon(tone === 'ok' ? 'check-circle-2' : 'alert-triangle', 20) + '</span>' +
            '<div><p style="font-weight:700">' + title + '</p><p class="caption">' + advice + '</p></div></div>');
      } else {
        blocks.push('<div class="growth-verdict"><span class="growth-verdict__icon" aria-hidden="true">' + icon('info', 20) +
          '</span><div><p style="font-weight:700">اولین ثبت انجام شد</p><p class="caption">برای دیدن روند، اندازه‌ی بعدی را ثبت کن.</p></div></div>');
      }

      blocks.push('<div class="card card--flat"><div class="metric-row"><span class="metric-row__label">آخرین وزن ثبت‌شده</span>' +
        '<span class="metric-row__value">' + faDecimal(last.weight) + ' کیلوگرم</span></div>' +
        '<div class="metric-row"><span class="metric-row__label">آخرین قد ثبت‌شده</span>' +
        '<span class="metric-row__value">' + faDecimal(last.height) + ' سانتی‌متر</span></div>' +
        (last.head ? '<div class="metric-row"><span class="metric-row__label">دور سر</span><span class="metric-row__value">' + faDecimal(last.head) + ' سانتی‌متر</span></div>' : '') +
        '<div class="metric-row"><span class="metric-row__label">سن هنگام ثبت</span><span class="metric-row__value">' + daysWord(last.ageMonths) + '</span></div></div>');

      verdict.innerHTML = blocks.join('');

      if (refCard) {
        if (result.reference) {
          refCard.innerHTML = '<p style="font-weight:700">مقایسه با جدول مرجع</p><p class="caption">' + result.reference.label + '</p>';
        }
      }
    }

    function renderHistory() {
      if (!history) return;
      if (!state.measures.length) {
        history.innerHTML = '<p class="caption">سابقه‌ای ثبت نشده است.</p>';
        return;
      }
      history.innerHTML = state.measures.slice().reverse().map(function (m) {
        return '<div class="measure-item"><span>' + (m.dateLabel || '') + ' · ' + daysWord(m.ageMonths) + '</span>' +
          '<span>' + faDecimal(m.weight) + ' کیلوگرم · ' + faDecimal(m.height) + ' سانتی‌متر</span></div>';
      }).join('');
    }

    function renderProfile() {
      if (!state.profile) return;
      if (nameOut) nameOut.textContent = state.profile.name || 'نوزاد';
      if (bornOut) bornOut.textContent = jalaliLabel(state.profile.birth);
      var age = ageOf(state.profile);
      if (ageOut && age) ageOut.textContent = age.label;
      if (measureForm) measureForm.hidden = false;
    }

    function renderChart() {
      if (!chart) return;
      var sorted = state.measures.slice().sort(function (a, b) { return a.ageMonths - b.ageMonths; });
      CHART_SERIES.babyWeight.series = sorted.length
        ? sorted.map(function (m) { return { label: daysWord(m.ageMonths), value: Number(m.weight) }; })
        : [];
      chart.setAttribute('data-chart', 'babyWeight');
      renderCharts();
    }

    if (measureForm) {
      measureForm.addEventListener('submit', function (event) {
        event.preventDefault();
        var weight = el('#baby-weight'), height = el('#baby-height'), head = el('#baby-head');
        var invalid = false;
        [['#baby-weight', weight.value], ['#baby-height', height.value]].forEach(function (pair) {
          var field = el(pair[0]);
          if (!pair[1] || toNumber(pair[1]) <= 0) { showError(field, 'یک عدد معتبر وارد کن.'); invalid = true; } else { clearError(field); }
        });
        if (invalid) return;
        if (!state.profile) {
          showFailure(new Error('تاریخ تولد کودک را در تنظیمات حساب ثبت کن.'));
          return;
        }
        var age = ageOf(state.profile);
        var stamp = todayJalali();
        var measured = {
          ageMonths: age ? age.months : 0,
          weight: toNumber(weight.value),
          height: toNumber(height.value),
          head: head.value ? toNumber(head.value) : null,
          date: todayGregorian(),
          dateLabel: stamp ? jalaliLabel(stamp) : ''
        };
        var submit = measureForm.querySelector('[type="submit"]');
        if (submit) submit.disabled = true;
        if (status) status.textContent = 'در حال ذخیره روی حساب تو…';
        if (errorOut) errorOut.hidden = true;
        requestGrowth('POST', {
          profile_id: 'default',
          name: state.profile ? state.profile.name : '',
          sex: state.profile ? state.profile.sex : '',
          birth_year: state.profile ? state.profile.birth.year : '',
          birth_month: state.profile ? state.profile.birth.month : '',
          birth_day: state.profile ? state.profile.birth.day : '',
          age_months: measured.ageMonths,
          weight: measured.weight,
          height: measured.height,
          head: measured.head,
          measured_on: measured.date
        }).then(function (result) {
          measured.id = result.id;
          state.measures.push(measured);
          weight.value = ''; height.value = ''; if (head) head.value = '';
          if (status) status.textContent = 'اندازه با موفقیت در حساب تو ذخیره شد.';
          var success = el('[data-baby-saved]');
          if (success) { success.hidden = false; window.setTimeout(function () { success.hidden = true; }, 2600); }
          renderVerdict();
          renderHistory();
          renderChart();
        }).catch(showFailure).then(function () {
          if (submit) submit.disabled = false;
        });
      });
    }

    if (state.profile) renderProfile();
    renderVerdict();
    renderHistory();
    renderChart();
    if (status) status.textContent = 'در حال بارگذاری اندازه‌های ذخیره‌شده…';
    requestGrowth('GET').then(function (response) {
      state.measures = (response.items || []).filter(function (item) {
        return !item.profile_id || item.profile_id === 'default';
      }).map(function (item) {
        return {
          id: Number(item.id),
          ageMonths: Number(item.age_months) || 0,
          weight: Number(item.weight) || 0,
          height: Number(item.height) || 0,
          head: item.head === null ? null : Number(item.head),
          date: item.measured_on || '',
          dateLabel: dateLabel(item.measured_on || '')
        };
      }).reverse();
      if (status) status.textContent = '';
      renderVerdict();
      renderHistory();
      renderChart();
    }).catch(showFailure);
  }


  /* ====================================================================
     Notifications: in-page toast, browser notification, and a small
     synthesised chime (Web Audio) so there is no audio file to download.
     ==================================================================== */

  var SOUND_KEY = 'dr-niva-sound-v1';
  var SOUND_ON = true;
  try { SOUND_ON = window.localStorage.getItem(SOUND_KEY) !== 'off'; } catch (error) { /* ignore */ }
  var audioCtx = null;

  function toast(title, text) {
    var stack = el('[data-toast-stack]');
    if (!stack) {
      stack = document.createElement('div');
      stack.className = 'toast-stack';
      stack.setAttribute('data-toast-stack', '');
      document.body.appendChild(stack);
    }
    var node = document.createElement('div');
    node.className = 'toast';
    node.innerHTML = '<span aria-hidden="true">' + icon('bell', 20) + '</span>' +
      '<span><span class="toast__title"></span><span class="toast__text"></span></span>';
    el('.toast__title', node).textContent = title;
    el('.toast__text', node).textContent = text || '';
    stack.appendChild(node);
    window.setTimeout(function () { node.remove(); }, 6000);
  }

  /** Two-note chime, generated on the fly — pleasant and offline. */
  function chime() {
    if (!SOUND_ON) return;
    try {
      var Ctx = window.AudioContext || window.webkitAudioContext;
      if (!Ctx) return;
      if (!audioCtx) audioCtx = new Ctx();
      if (audioCtx.state === 'suspended' && audioCtx.resume) audioCtx.resume();
      [880, 1174.66].forEach(function (frequency, index) {
        var osc = audioCtx.createOscillator();
        var gain = audioCtx.createGain();
        osc.type = 'sine';
        osc.frequency.value = frequency;
        var at = audioCtx.currentTime + index * 0.19;
        gain.gain.setValueAtTime(0.0001, at);
        gain.gain.exponentialRampToValueAtTime(0.2, at + 0.04);
        gain.gain.exponentialRampToValueAtTime(0.0001, at + 0.6);
        osc.connect(gain);
        gain.connect(audioCtx.destination);
        osc.start(at);
        osc.stop(at + 0.65);
      });
    } catch (error) { /* audio blocked until the user interacts — fine */ }
  }

  function notify(title, text) {
    chime();
    toast(title, text);
    try {
      var N = window.Notification;
      if (N && N.permission === 'granted') new N(title, { body: text || '', lang: 'fa', dir: 'rtl' });
    } catch (error) { /* ignore */ }
  }

  /* ====================================================================
     Reminders
     ==================================================================== */

  var REM_KEY = 'dr-niva-reminders-v1';

  function remindersLoad() {
    try { return JSON.parse(window.localStorage.getItem(REM_KEY) || '[]') || []; } catch (error) { return []; }
  }
  function remindersSave(list) {
    try { window.localStorage.setItem(REM_KEY, JSON.stringify(list)); } catch (error) { /* ignore */ }
  }

  /*
   * Notification permission, the test toast and the sound switch live in the
   * `reminders_notification` module, which is its own widget. They used to sit
   * at the bottom of bindReminders(), right after `if (!list) return;` — so on
   * any page without the reminders list they were never bound at all, and the
   * buttons did nothing. They now bind on their own.
   */
  /*
   * The welcome sheet: one question at a time for a user who has no profile
   * data yet, so nobody meets a dashboard of zeros or has to hunt for the
   * settings screen. Steps the profile does not support are never rendered,
   * and the cycle step hides itself for anyone who is not a woman.
   */
  /*
   * Recording a lab result. The value goes to /labs, which appends it to the
   * user's own history — the modules then read that history back.
   */
  /*
   * Anything inside an app module that submits must be handled by JS. This
   * capture-phase guard stops a native submit (which would reload the page and
   * look like "nothing happened") even if a specific handler failed to attach.
   */
  /* A Persian date next to every date field (storage stays ISO, display is Shamsi). */
  function jalaliFromDate(date) {
    try {
      var parts = new Intl.DateTimeFormat('en-u-ca-persian', { year: 'numeric', month: 'numeric', day: 'numeric' }).formatToParts(date);
      var out = {};
      parts.forEach(function (part) { if (part.type !== 'literal') out[part.type] = part.value; });
      return { year: Number(String(out.year).replace(/[^0-9]/g, '')), month: Number(out.month), day: Number(out.day) };
    } catch (error) {
      return null;
    }
  }

  /* Choosing a plan records a request for the owner to activate. */
  function bindPlanRequest() {
    els('[data-plan-request]').forEach(function (button) {
      if (!bindOnce(button, 'plan-request')) return;
      button.addEventListener('click', function () {
        var config = window.NIVA_CONFIG || {};
        var message = button.parentNode ? button.parentNode.querySelector('[data-plan-msg]') : null;
        if (!config.rest) {
          if (message) message.textContent = 'اتصال به سرور برقرار نیست.';
          return;
        }
        button.disabled = true;
        if (message) message.textContent = 'در حال ثبت…';
        fetch(config.rest + '/plan-request', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
          body: JSON.stringify({ plan: button.getAttribute('data-plan-request') })
        }).then(function () {
          if (message) message.textContent = 'درخواستت ثبت شد؛ به‌زودی فعال می‌شود.';
        }).catch(function () {
          button.disabled = false;
          if (message) message.textContent = 'ثبت نشد؛ یک بار دیگر تلاش کن.';
        });
      });
    });
  }

  function bindExercises() {
    var root = el('[data-exercises]');
    if (!root || !bindOnce(root, 'exercise-tracker')) return;
    var buttons = els('[data-exercise-complete]', root);
    var count = root.querySelector('[data-exercise-count]');
    var rest = (window.NIVA_CONFIG || {}).rest || ((window.NIVA_CONFIG || {}).plugin || {}).rest;
    var nonce = (window.NIVA_CONFIG || {}).nonce || (((window.NIVA_CONFIG || {}).plugin || {}).nonce || '');

    function paintCount() {
      if (count) count.textContent = fa(String(els('[data-exercise-complete][data-done="1"]', root).length));
    }
    function markDone(button) {
      button.dataset.done = '1';
      button.textContent = 'انجام شد';
      button.disabled = true;
      var card = button.closest('[data-exercise-card]');
      if (card) card.classList.add('exercise-card--done');
      paintCount();
    }

    if (rest) {
      fetch(rest + '/logs', { credentials: 'same-origin', headers: { 'X-WP-Nonce': nonce } })
        .then(function (response) {
          if (!response.ok) throw new Error('سابقهٔ تمرین‌ها بارگذاری نشد.');
          return response.json();
        })
        .then(function (payload) {
          (payload.items || []).forEach(function (item) {
            if (item.kind !== 'exercise' || item.log_date !== root.dataset.today) return;
            var button = root.querySelector('[data-exercise-card][data-exercise-id="' + item.value + '"] [data-exercise-complete]');
            if (button) markDone(button);
          });
        })
        .catch(function (error) {
          var status = root.querySelector('[data-exercise-count]');
          if (status) status.setAttribute('aria-label', error.message);
        });
    }

    buttons.forEach(function (button) {
      button.addEventListener('click', function () {
        if (!rest || button.disabled) return;
        button.disabled = true;
        fetch(rest + '/logs', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
          body: JSON.stringify({ kind: 'exercise', value: button.closest('[data-exercise-card]').dataset.exerciseId })
        }).then(function (response) {
          return response.json().then(function (payload) {
            if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'ثبت تمرین انجام نشد.');
            markDone(button);
          });
        }).catch(function (error) {
          button.disabled = false;
          window.alert(error.message || 'ثبت تمرین انجام نشد.');
        });
      });
    });
  }

  function bindDateHints() {
    els('.niva-module input[type="date"], [data-onboarding] input[type="date"]').forEach(function (input) {
      if (!bindOnce(input, 'date-hint')) return;
      var hint = document.createElement('span');
      hint.className = 'caption';
      input.parentNode.appendChild(hint);
      var paint = function () {
        if (!input.value) { hint.textContent = ''; return; }
        var bits = input.value.split('-').map(Number);
        var j = jalaliFromDate(new Date(bits[0], bits[1] - 1, bits[2]));
        hint.textContent = j ? (MONTHS[j.month - 1] + ' ' + fa(j.day) + ' ' + fa(j.year)) : '';
      };
      input.addEventListener('change', paint);
      input.addEventListener('input', paint);
      paint();
    });
  }

  /* Header: the burger opens the menu drawer on small screens. */
  function bindDrawer() {
    els('[data-drawer-open]').forEach(function (button) {
      if (!bindOnce(button, 'drawer-open')) return;
      button.addEventListener('click', function () {
        var open = !document.body.classList.contains('niva-nav-open');
        document.body.classList.toggle('niva-nav-open', open);
        button.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    });
    els('[data-drawer-close]').forEach(function (button) {
      if (!bindOnce(button, 'drawer-close')) return;
      button.addEventListener('click', function () {
        document.body.classList.remove('niva-nav-open');
      });
    });
  }

  /* Profile destinations stay inside the account page, loaded into a sheet. */
  function bindProfileHubSheets() {
    var rows = els('[data-profile-sheet]');
    var sheet = el('#profile-menu-sheet');
    if (!rows.length || !sheet || !bindOnce(sheet, 'profile-sheet')) return;

    var panel = el('.profile-sheet__panel', sheet);
    var content = el('[data-profile-sheet-content]', sheet);
    var title = el('#profile-sheet-title', sheet);
    var closeButtons = els('[data-profile-sheet-close]', sheet);
    var opener = null;
    var requestId = 0;
    var sectionCache = {};
    var moduleMap = { profile: 'user_settings', wallet: 'wallet' };
    /*
     * 3.0.2 — every row of «پروفایل من» must resolve to a screen. Rows such as
     * lab / companion / pregnancy / advisor / notifications / about had no
     * mapping, so the sheet rejected them with «اتصال به سرور برقرار نیست».
     */
    var viewMap = {
      plans: 'plans', reminders: 'alarms', tools: 'tools', partners: 'partners',
      lab: 'analyze', companion: 'companion_create', notifications: 'notifications',
      pregnancy: 'pregnancy', advisor: 'advisor', about: 'about',
      cycle: 'cycle', mind: 'mind', baby: 'baby', family: 'family'
    };

    function setExpanded(expanded) {
      rows.forEach(function (row) {
        row.setAttribute('aria-expanded', expanded && row === opener ? 'true' : 'false');
      });
    }

    function close() {
      if (sheet.hidden) return;
      sheet.hidden = true;
      document.body.classList.remove('niva-profile-sheet-open');
      setExpanded(false);
      requestId += 1;
      if (opener) opener.focus();
    }

    function showError(row, id, error) {
      content.textContent = '';
      var alert = document.createElement('div');
      alert.className = 'alert alert--caution';
      alert.setAttribute('role', 'alert');
      var message = document.createElement('div');
      message.className = 'alert__text';
      message.textContent = error && error.message
        ? error.message
        : 'این بخش بارگذاری نشد. اتصال را بررسی کن و دوباره تلاش کن.';
      var retry = document.createElement('button');
      retry.type = 'button';
      retry.className = 'btn btn--secondary btn--sm';
      retry.textContent = 'تلاش دوباره';
      retry.addEventListener('click', function () { load(row, id); });
      alert.appendChild(message);
      alert.appendChild(retry);
      content.appendChild(alert);
    }

    function fetchSection(row, id) {
      var config = window.NIVA_CONFIG || {};
      var rest = config.rest;
      var module = moduleMap[id];
      var view = viewMap[id];
      if (!rest || (!module && !view)) {
        return Promise.reject(new Error('اتصال به سرور برقرار نیست.'));
      }
      var endpoint = module
        ? rest + '/profile-module?module=' + encodeURIComponent(module)
        : rest + '/view?name=' + encodeURIComponent(view);
      var headers = { 'Accept': 'application/json' };
      if (config.nonce) headers['X-WP-Nonce'] = config.nonce;
      if (!sectionCache[id] || Date.now() >= sectionCache[id].expires) {
        var cached = { expires: Date.now() + 10000, promise: null };
        sectionCache[id] = cached;
        cached.promise = fetch(endpoint, { credentials: 'same-origin', headers: headers })
        .then(function (response) {
          return response.json().then(function (payload) {
            if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'بخش پروفایل دریافت نشد.');
            return payload;
          });
        })
        .then(function (payload) {
          if (!payload || typeof payload.html !== 'string' || !payload.html) {
            throw new Error('The profile sheet response did not contain HTML.');
          }
          var html = payload.html;
          if (view) {
            var parsed = new DOMParser().parseFromString(html, 'text/html');
            var main = parsed.querySelector('#main-content');
            if (!main) throw new Error('The requested view did not contain its main content.');
            main.removeAttribute('id');
            html = main.outerHTML;
          }
          return html;
        }).catch(function (error) {
          if (sectionCache[id] === cached) delete sectionCache[id];
          throw error;
        });
      }
      return sectionCache[id].promise;
    }

    function load(row, id) {
      var currentRequest = ++requestId;
      content.innerHTML = '<div class="profile-sheet__loading" role="status" aria-label="در حال آماده‌سازی"><span></span><span></span><span></span></div>';
      fetchSection(row, id)
        .then(function (html) {
          if (currentRequest !== requestId || sheet.hidden) return;
          content.innerHTML = html;
          if (typeof window.NIVA_BOOT_CONTENT === 'function') window.NIVA_BOOT_CONTENT();
          document.dispatchEvent(new CustomEvent('niva:profile-content-ready', { detail: { section: id } }));
        })
        .catch(function (error) {
          if (currentRequest !== requestId || sheet.hidden) return;
          console.error('Profile sheet content failed to load:', error);
          showError(row, id, error);
        });
    }

    rows.forEach(function (row) {
      if (!bindOnce(row, 'profile-sheet')) return;
      var preload = function () {
        fetchSection(row, row.getAttribute('data-profile-sheet')).catch(function (error) {
          console.error('Profile sheet prefetch failed:', error);
        });
      };
      row.addEventListener('pointerenter', preload, { once: true });
      row.addEventListener('pointerdown', preload, { once: true });
      row.addEventListener('focus', preload, { once: true });
      row.addEventListener('click', function (event) {
        if (event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        event.preventDefault();
        opener = row;
        title.textContent = row.getAttribute('data-profile-title') || el('.settings-row__title', row).textContent;
        sheet.hidden = false;
        document.body.classList.add('niva-profile-sheet-open');
        setExpanded(true);
        load(row, row.getAttribute('data-profile-sheet'));
        closeButtons[1] ? closeButtons[1].focus() : panel.focus();
      });
    });

    closeButtons.forEach(function (button) {
      button.addEventListener('click', close);
    });

    sheet.addEventListener('click', function (event) {
      if (event.target === sheet) close();
    });

    document.addEventListener('keydown', function (event) {
      if (sheet.hidden) return;
      if (event.key === 'Escape') {
        close();
        return;
      }
      if (event.key !== 'Tab') return;
      var focusable = els('a[href], button:not([disabled]), input:not([disabled]), select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex="-1"])', panel)
        .filter(function (node) { return node.offsetParent !== null; });
      if (!focusable.length) {
        event.preventDefault();
        panel.focus();
      } else if (event.shiftKey && document.activeElement === focusable[0]) {
        event.preventDefault();
        focusable[focusable.length - 1].focus();
      } else if (!event.shiftKey && document.activeElement === focusable[focusable.length - 1]) {
        event.preventDefault();
        focusable[0].focus();
      }
    });

    var grab = el('[data-profile-sheet-grab]', sheet);
    var dragStart = null;
    grab.addEventListener('pointerdown', function (event) {
      dragStart = event.clientY;
      if (grab.setPointerCapture) grab.setPointerCapture(event.pointerId);
    });
    grab.addEventListener('pointerup', function (event) {
      if (dragStart !== null && event.clientY - dragStart > 70) close();
      dragStart = null;
    });
    grab.addEventListener('pointercancel', function () { dragStart = null; });
  }

  /* Bottom sheets: an action opens in place instead of sending the user away. */
  function bindSheets() {
    els('[data-sheet-open]').forEach(function (button) {
      if (!bindOnce(button, 'sheet-open')) return;
      button.addEventListener('click', function () {
        var sheet = document.getElementById(button.getAttribute('data-sheet-open'));
        if (sheet) { sheet.hidden = false; }
      });
    });
    els('.sheet').forEach(function (sheet) {
      if (!bindOnce(sheet, 'sheet')) return;
      sheet.addEventListener('click', function (event) {
        var target = event.target;
        if (target && (target.classList.contains('sheet__backdrop') || (target.closest && target.closest('[data-sheet-close]')))) {
          sheet.hidden = true;
        }
      });
    });
    if (bindOnce(document, 'sheet-keydown')) {
      document.addEventListener('keydown', function (event) {
        if (event.key !== 'Escape') return;
        els('.sheet').forEach(function (sheet) { sheet.hidden = true; });
        document.body.classList.remove('niva-nav-open');
      });
    }
  }

  /*
   * A module form that has no handler would submit to the current URL and
   * reload the screen, so the guard stops it. It must NOT stop the forms the
   * app itself handles — v2.0.0 swallowed every submit inside .niva-module,
   * which is why buttons such as «ثبت پرسش» looked dead.
   */
  function bindFormGuard() {
    if (bindOnce(document.body, 'form-guard')) return;
    document.addEventListener('submit', function (event) {
      var form = event.target;
      if (!form || !form.closest || !form.closest('.niva-module')) return;
      if (form.getAttribute('action')) return;
      if (form.hasAttribute('data-niva-form-native')) return;
      var handled = false;
      Object.keys(form.dataset || {}).forEach(function (key) {
        if (!handled && key.indexOf('niva') === 0) handled = true;
      });
      if (handled) return;
      event.preventDefault();
    }, true);
  }

  function bindLabEntry() {
    var form = el('[data-lab-form]');

    if (form && bindOnce(form, 'lab-form')) {
      form.addEventListener('submit', function (event) {
        event.preventDefault();
        var config = window.NIVA_CONFIG || {};
        var marker = el('[data-lab-marker]', form);
        var value = el('[data-lab-value]', form);
        var date = el('[data-lab-date]', form);
        var message = el('[data-lab-msg]', form);

        if (!value || !value.value) {
          if (message) message.textContent = 'مقدار آزمایش را وارد کن.';
          return;
        }
        if (!config.rest) {
          if (message) message.textContent = 'اتصال به سرور برقرار نیست.';
          return;
        }

        if (message) message.textContent = 'در حال ثبت…';
        fetch(config.rest + '/labs', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
          body: JSON.stringify({
            marker: marker ? marker.value : '',
            value: value.value,
            date: date ? date.value : ''
          })
        }).then(function (response) {
          return response.json().catch(function () { return {}; });
        }).then(function (data) {
          if (data && data.code) {
            if (message) message.textContent = 'ثبت نشد: مقدار را بررسی کن.';
            return;
          }
          if (data.modules_html) refreshLabModules(data.modules_html);
          if (message) message.textContent = 'ثبت شد.';
          value.value = '';
          var sheet = form.closest('.sheet');
          if (sheet) sheet.hidden = true;
        }).catch(function () {
          if (message) message.textContent = 'ثبت نشد؛ یک بار دیگر تلاش کن.';
        });
      });
    }

    els('[data-lab-remove]').forEach(function (button) {
      if (!bindOnce(button, 'lab-remove')) return;
      button.addEventListener('click', function () {
        var config = window.NIVA_CONFIG || {};
        if (!config.rest) return;
        fetch(config.rest + '/labs', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
          body: JSON.stringify({ delete: Number(button.getAttribute('data-lab-remove')) })
        }).then(function (response) {
          return response.json().then(function (payload) {
            if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'حذف نتیجه انجام نشد.');
            if (payload.modules_html) refreshLabModules(payload.modules_html);
          });
        }).catch(function (error) {
          window.alert(error.message || 'حذف نتیجه انجام نشد.');
        });
      });
    });
  }

  function bindOnboarding() {
    var root = el('[data-onboarding]');
    if (!root || !bindOnce(root, 'onboarding')) return;

    var steps = Array.prototype.slice.call(root.querySelectorAll('.ob-step'));
    if (!steps.length) return;

    var label = root.querySelector('[data-ob-step-label]');
    var bar = root.querySelector('[data-ob-progress]');
    var heading = root.querySelector('.onboarding__title');
    var prev = root.querySelector('[data-ob-prev]');
    var next = root.querySelector('[data-ob-next]');
    var sex = '';
    var pregnant = '';
    var index = 0;

    function wanted(step) {
      var only = step.getAttribute('data-ob-only');
      return !only || only === sex;
    }

    function visibleSteps() {
      return steps.filter(wanted);
    }

    function show() {
      var list = visibleSteps();
      if (index > list.length - 1) index = list.length - 1;
      if (index < 0) index = 0;
      steps.forEach(function (step) { step.hidden = true; });
      var current = list[index];
      if (current) current.hidden = false;
      if (heading && current) heading.textContent = current.getAttribute('data-title') || 'خوش آمدی';
      if (label) label.textContent = 'مرحله ' + fa(index + 1) + ' از ' + fa(list.length);
      if (bar) bar.style.width = Math.round(((index + 1) / list.length) * 100) + '%';
      if (prev) prev.hidden = index === 0;
      if (next) next.textContent = index === list.length - 1 ? 'ذخیره و پایان' : 'بعدی';
    }

    function close() {
      root.hidden = true;
      document.body.classList.remove('niva-has-onboarding');
    }

    function save() {
      var config = window.NIVA_CONFIG || {};
      var payload = {};
      payload.__partial = true;
      if (sex) payload.sex = sex;
      if (pregnant) payload.pregnant = pregnant;
      root.querySelectorAll('[data-ob-key]').forEach(function (input) {
        var value = (input.value || '').trim();
        if (value !== '') payload[input.getAttribute('data-ob-key')] = value;
      });
      if (!config.rest) {
        if (typeof notify === 'function') notify('اتصال امن برای ذخیرهٔ مشخصات در دسترس نیست؛ بعداً دوباره تلاش کن.');
        return;
      }
      if (next) { next.disabled = true; next.textContent = 'در حال ذخیره…'; }
      fetch(config.rest + '/profile', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config.nonce || '' },
        body: JSON.stringify(payload)
      }).then(function (response) {
        if (!response.ok) throw new Error('save failed');
        return response.json().catch(function () { return {}; });
      }).then(function () {
        close();
        if (typeof notify === 'function') notify('مشخصاتت ذخیره شد. برای امکانات و سهمیهٔ بیشتر، پلن‌های اشتراک را ببین.');
      }).catch(function () {
        if (next) { next.disabled = false; next.textContent = 'ذخیره و پایان'; }
        if (typeof notify === 'function') notify('ذخیره نشد؛ یک بار دیگر تلاش کن.');
      });
    }

    root.querySelectorAll('[data-ob-sex]').forEach(function (button) {
      button.addEventListener('click', function () {
        sex = button.getAttribute('data-ob-sex');
        root.querySelectorAll('[data-ob-sex]').forEach(function (other) { other.classList.remove('is-on'); });
        button.classList.add('is-on');
        var list = visibleSteps();
        if (index > list.length - 1) index = list.length - 1;
        show();
      });
    });

    root.querySelectorAll('[data-ob-pregnant]').forEach(function (button) {
      button.addEventListener('click', function () {
        var value = button.getAttribute('data-ob-pregnant');
        pregnant = value;
        root.querySelectorAll('[data-ob-pregnant]').forEach(function (other) { other.classList.remove('is-on'); });
        button.classList.add('is-on');
        var due = root.querySelector('[data-ob-due]');
        if (due) due.hidden = value !== '1';
      });
    });

    root.querySelectorAll('[data-ob-later]').forEach(function (button) {
      button.addEventListener('click', function () {
        document.cookie = 'dr_niva_onboard_later=1;path=/;max-age=604800;SameSite=Lax';
        close();
      });
    });

    var notifyButton = root.querySelector('[data-ob-notify]');
    if (notifyButton) {
      notifyButton.addEventListener('click', function () {
        var state = root.querySelector('[data-ob-notify-state]');
        if (!('Notification' in window)) {
          if (state) state.textContent = 'این مرورگر اعلان را پشتیبانی نمی‌کند.';
          return;
        }
        Notification.requestPermission().then(function (result) {
          if (state) {
            state.textContent = 'granted' === result
              ? 'اعلان‌ها فعال شد.'
              : 'هر وقت خواستی از تنظیمات حساب فعال کن.';
          }
        });
      });
    }

    if (prev) {
      prev.addEventListener('click', function () { index = Math.max(0, index - 1); show(); });
    }
    if (next) {
      next.addEventListener('click', function () {
        var list = visibleSteps();
        var current = list[index];
        if (current && current.getAttribute('data-step') === 'sex' && !sex) {
          if (typeof notify === 'function') notify('اول بگو مخاطب ما خانم است یا آقا.');
          return;
        }
        if (index >= list.length - 1) { save(); return; }
        index += 1;
        show();
      });
    }

    root.hidden = false;
    document.body.classList.add('niva-has-onboarding');
    show();
  }

  function bindNotifications() {
  var statusOut = el('[data-notify-status]');

  if (statusOut) {
    var N = window.Notification;
    statusOut.textContent = !N ? 'وضعیت: این مرورگر اعلان سیستمی ندارد (یادآور داخل صفحه کار می‌کند)'
      : N.permission === 'granted' ? 'وضعیت: فعال است' 
        : N.permission === 'denied' ? 'وضعیت: رد شده — از تنظیمات مرورگر اجازه بده'
          : 'وضعیت: هنوز اجازه نداده‌ای';
  }

  els('[data-notify-permission]').forEach(function (button) {
    if (!bindOnce(button, 'notify-permission')) return;
    button.addEventListener('click', function () {
      var N = window.Notification;
      if (!N) { notify('اعلان سیستمی پشتیبانی نمی‌شود', 'یادآورها داخل همین صفحه کار می‌کنند.'); return; }
        var push = window.NIVA_PUSH;
        if (push && push.enabled && push.publicKey) {
          if (statusOut) statusOut.textContent = 'وضعیت: در حال ثبت پوش برای این دستگاه…';
          return;
        }
        try {
          var asked = N.requestPermission();
          if (asked && asked.then) {
            asked.then(function (result) {
              if (statusOut) statusOut.textContent = 'وضعیت: ' + (result === 'granted'
                ? 'فقط هنگام بازبودن این صفحه فعال است؛ پوش پس‌زمینه در تنظیمات سایت راه‌اندازی نشده.'
                : 'اجازه داده نشد؛ تنظیمات اعلان مرورگر را بررسی کن.');
              if (result === 'granted') notify('اعلان‌ها فعال شد', 'یادآورها تا وقتی این صفحه باز است نمایش داده می‌شوند.');
            });
          }
        } catch (error) {
          if (statusOut) statusOut.textContent = 'وضعیت: فعال‌سازی اعلان انجام نشد.';
        }
      });
  });

  els('[data-notify-test]').forEach(function (button) {
    if (!bindOnce(button, 'notify-test')) return;
    button.addEventListener('click', function () {
      notify('یادآور دکتر نیوا', 'این یک اعلان آزمایشی با صدا است.');
    });
  });

  els('[data-sound-toggle]').forEach(function (button) {
    if (!bindOnce(button, 'sound')) return;
    var paint3 = function () {
      button.textContent = '';
      button.innerHTML = icon('activity', 18) + (SOUND_ON ? 'صدا: روشن' : 'صدا: خاموش');
      button.setAttribute('aria-pressed', SOUND_ON ? 'true' : 'false');
    };
    paint3();
    button.addEventListener('click', function () {
      SOUND_ON = !SOUND_ON;
      try { window.localStorage.setItem(SOUND_KEY, SOUND_ON ? 'on' : 'off'); } catch (error) { /* ignore */ }
      paint3();
      if (SOUND_ON) chime();
    });
  });
  }

  function bindReminderForm() {
    var form = el('[data-reminder-form]');
    if (!form || !bindOnce(form, 'reminder-form')) return;
    var titleField = form.querySelector('#reminder-title');
    var timeField = form.querySelector('#reminder-time');
    var repeatField = form.querySelector('#reminder-repeat');
    var status = form.querySelector('[data-reminder-status]');
    var reminderId = el('[data-reminder-id]', form);
    var formTitle = el('[data-reminder-form-title]');
    var submitLabel = el('[data-reminder-submit-label]', form);
    var cancelEdit = el('[data-reminder-cancel]', form);

    function resetEdit() {
      if (reminderId) reminderId.value = '';
      if (formTitle) formTitle.textContent = 'ساخت یادآور';
      if (submitLabel) submitLabel.textContent = 'افزودن یادآور';
      if (cancelEdit) cancelEdit.hidden = true;
      if (titleField) titleField.value = '';
      if (timeField) timeField.value = '21:00';
      if (repeatField) repeatField.value = 'daily';
    }

    if (cancelEdit) cancelEdit.addEventListener('click', resetEdit);
    els('[data-sheet-open="reminder-sheet"]').forEach(function (button) {
      button.addEventListener('click', resetEdit);
    });
    if (timeField) {
      timeField.addEventListener('input', function () {
        timeField.value = timeField.value.replace(/[۰-۹٠-٩]/g, function (digit) {
          var persian = '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit);
          return String(persian === -1 ? '٠١٢٣٤٥٦٧٨٩'.indexOf(digit) : persian);
        }).replace(/[٫.]/g, ':').slice(0, 5);
      });
    }
    els('[data-reminder-preset]').forEach(function (chip) {
      if (!bindOnce(chip, 'reminder-preset')) return;
      chip.addEventListener('click', function () {
        var parts = (chip.dataset.reminderPreset || '').split('|');
        if (!parts[0]) return;
        resetEdit();
        if (titleField) titleField.value = parts[0];
        if (timeField) timeField.value = parts[1] || '09:00';
        if (repeatField) repeatField.value = parts[2] || 'daily';
      });
    });
    form.addEventListener('submit', function (event) {
      event.preventDefault();
      if (!titleField || !titleField.value.trim()) {
        if (titleField) showError(titleField, 'بنویس چه کاری را یادت بیاوریم.');
        return;
      }
      clearError(titleField);
      if (timeField && !/^(?:[01]\d|2[0-3]):[0-5]\d$/.test(timeField.value)) {
        if (status) status.textContent = 'ساعت را به شکل ۲۴ساعته وارد کن؛ مثلاً ۲۱:۰۰.';
        timeField.focus();
        return;
      }
      var config = window.NIVA_CONFIG || {};
      var rest = config.rest || (config.plugin && config.plugin.rest);
      var nonce = config.nonce || (config.plugin && config.plugin.nonce) || '';
      if (!rest) {
        if (status) status.textContent = 'اتصال به سرور برقرار نیست.';
        return;
      }
      var submit = form.querySelector('[type="submit"]');
      if (submit) submit.disabled = true;
      if (status) status.textContent = 'در حال ذخیره…';
      var editing = reminderId && reminderId.value;
      fetch(rest + '/reminders', {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
        body: JSON.stringify({
          action: editing ? 'update' : 'add',
          id: editing || undefined,
          title: titleField.value.trim(),
          time: timeField ? timeField.value : '09:00',
          repeat: repeatField ? repeatField.value : 'daily'
        })
      }).then(function (response) {
        return response.json().then(function (payload) {
          if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'یادآور ذخیره نشد.');
          return payload;
        });
      }).then(function (payload) {
        document.dispatchEvent(new CustomEvent('niva:reminders-updated', { detail: payload.items || [] }));
        resetEdit();
        if (status) status.textContent = editing ? 'یادآور ویرایش شد.' : 'یادآور ذخیره شد.';
        var sheet = form.closest('.sheet');
        if (sheet) sheet.hidden = true;
      }).catch(function (error) {
        if (status) status.textContent = error.message || 'یادآور ذخیره نشد.';
      }).then(function () {
        if (submit) submit.disabled = false;
      });
    });
  }

  function bindReminders() {
    var list = el('[data-reminder-list]');
    if (!list || !bindOnce(list, 'reminder-list')) return;
    var countOut = el('[data-reminder-count]');
    var emptyOut = el('[data-reminder-empty]');
    var statusOut = el('[data-notify-status]');
    var actionStatus = el('[data-reminder-status-list]');
    var items = [];
    var firedKey = 'dr-niva-reminders-fired-' + new Date().toISOString().slice(0, 10);
    var firedToday = {};
    try { firedToday = JSON.parse(window.localStorage.getItem(firedKey) || '{}') || {}; } catch (error) { firedToday = {}; }

    function paint() {
      var active = items.filter(function (item) { return !Number(item.done); });
      if (countOut) countOut.textContent = fa(active.length);
      if (emptyOut) emptyOut.hidden = items.length > 0;
      list.replaceChildren();
      items.forEach(function (item) {
        var row = document.createElement('div');
        row.className = 'reminder-item' + (Number(item.done) ? ' reminder-item--done' : '');
        row.dataset.reminder = String(item.id);
        var body = document.createElement('span');
        body.className = 'reminder-item__body';
        var time = document.createElement('span');
        time.className = 'reminder-item__time';
        time.dir = 'ltr';
        time.textContent = fa(item.time_at || item.time || '');
        var title = document.createElement('span');
        title.className = 'reminder-item__title';
        title.textContent = item.title || '';
        var repeat = document.createElement('span');
        repeat.className = 'reminder-item__repeat';
        repeat.textContent = item.repeat_rule === 'weekly' ? 'هر هفته' : item.repeat_rule === 'once' ? 'فقط یک بار' : 'هر روز';
        body.append(time, title, repeat);
        var toggle = document.createElement('button');
        toggle.type = 'button';
        toggle.className = 'icon-btn icon-btn--bare';
        toggle.dataset.reminderToggle = '';
        toggle.setAttribute('aria-label', 'تغییر وضعیت یادآور');
        toggle.innerHTML = icon(Number(item.done) ? 'check-circle-2' : 'circle', 22);
        var edit = document.createElement('button');
        edit.type = 'button';
        edit.className = 'icon-btn icon-btn--bare reminder-item__edit';
        edit.dataset.reminderEdit = '';
        edit.setAttribute('aria-label', 'ویرایش یادآور «' + htmlText(item.title || '') + '»');
        edit.innerHTML = icon('pen-line', 18);
        var remove = document.createElement('button');
        remove.type = 'button';
        remove.className = 'reminder-item__remove';
        remove.dataset.reminderRemove = '';
        remove.innerHTML = icon('x', 16) + '<span>حذف</span>';
        remove.setAttribute('aria-label', 'حذف یادآور «' + htmlText(item.title || '') + '»');
        row.append(body, edit, toggle, remove);
        list.appendChild(row);
      });
    }

    function request(method, payload) {
      var config = window.NIVA_CONFIG || {};
      var rest = config.rest || (config.plugin && config.plugin.rest);
      var nonce = config.nonce || (config.plugin && config.plugin.nonce) || '';
      if (!rest) return Promise.reject(new Error('اتصال به سرور برقرار نیست.'));
      var options = {
        method: method,
        credentials: 'same-origin',
        headers: { 'X-WP-Nonce': nonce }
      };
      if (payload) {
        options.headers['Content-Type'] = 'application/json';
        options.body = JSON.stringify(payload);
      }
      return fetch(rest + '/reminders' + (method === 'DELETE' && payload ? '?id=' + encodeURIComponent(payload.id) : ''), options)
        .then(function (response) {
          return response.json().then(function (data) {
            if (!response.ok) throw new Error(data && data.message ? data.message : 'عملیات یادآور انجام نشد.');
            return data;
          });
        });
    }

    function refresh() {
      var config = window.NIVA_CONFIG || {};
      var rest = config.rest || (config.plugin && config.plugin.rest);
      var nonce = config.nonce || (config.plugin && config.plugin.nonce) || '';
      if (!rest) return;
      fetch(rest + '/reminders', { credentials: 'same-origin', headers: { 'X-WP-Nonce': nonce } })
        .then(function (response) {
          return response.json().then(function (data) {
            if (!response.ok) throw new Error(data && data.message ? data.message : 'یادآورها بارگذاری نشدند.');
            return data;
          });
        }).then(function (data) {
          items = Array.isArray(data.items) ? data.items : [];
          paint();
          checkDue();
        }).catch(function (error) {
          if (actionStatus) actionStatus.textContent = error.message;
          else if (statusOut) statusOut.textContent = error.message;
        });
    }

    list.addEventListener('click', function (event) {
      var button = event.target.closest('[data-reminder-edit], [data-reminder-toggle], [data-reminder-remove]');
      var row = button && button.closest('[data-reminder]');
      if (!row) return;
      if (button.hasAttribute('data-reminder-edit')) {
        var item = items.filter(function (entry) { return String(entry.id) === row.dataset.reminder; })[0];
        if (!item) return;
        var form = el('[data-reminder-form]');
        var sheet = document.getElementById('reminder-sheet');
        if (!form || !sheet) return;
        var titleField = form.querySelector('#reminder-title');
        var timeField = form.querySelector('#reminder-time');
        var repeatField = form.querySelector('#reminder-repeat');
        var reminderId = el('[data-reminder-id]', form);
        var formTitle = el('[data-reminder-form-title]');
        var submitLabel = el('[data-reminder-submit-label]', form);
        var cancelEdit = el('[data-reminder-cancel]', form);
        if (reminderId) reminderId.value = String(item.id);
        if (titleField) titleField.value = item.title || '';
        if (timeField) timeField.value = item.time_at || '21:00';
        if (repeatField) repeatField.value = item.repeat_rule || 'daily';
        if (formTitle) formTitle.textContent = 'ویرایش یادآور';
        if (submitLabel) submitLabel.textContent = 'ذخیرهٔ تغییرات';
        if (cancelEdit) cancelEdit.hidden = false;
        sheet.hidden = false;
        if (titleField) titleField.focus();
        return;
      }
      var toggle = button.hasAttribute('data-reminder-toggle');
      button.disabled = true;
      var operation = toggle
        ? request('POST', { action: 'toggle', id: row.dataset.reminder })
        : request('DELETE', { id: row.dataset.reminder });
      operation.then(function (data) {
        items = Array.isArray(data.items) ? data.items : [];
        paint();
        if (actionStatus) actionStatus.textContent = toggle ? 'وضعیت یادآور به‌روز شد.' : 'یادآور حذف شد.';
      }).catch(function (error) {
        button.disabled = false;
        if (actionStatus) actionStatus.textContent = error.message;
        else if (statusOut) statusOut.textContent = error.message;
      });
    });

    document.addEventListener('niva:reminders-updated', function (event) {
      if (event.detail && Array.isArray(event.detail)) {
        items = event.detail;
        paint();
      }
    });
    refresh();
    window.setInterval(checkDue, 15000);
  }

  /* ====================================================================
     AI advisor — topic based chat through the server-configured GapGPT model
     ==================================================================== */

  var ADVISOR_TOPICS = [
    {
      id: 'depression', title: 'افسردگی و بی‌حوصلگی', text: 'حال پایین، بی‌انگیزگی، بی‌خوابی',
      icon: 'frown', tone: 'plum',
      opener: 'سلام. هر چه در دلت هست بنویس؛ لازم نیست مرتب باشد. این چند وقت بیشتر چه چیزی حالت را سنگین می‌کند؟',
      hints: ['چطور خوابم را بهتر کنم؟', 'یک تمرین کوچک برای امروز', 'کی باید به روان‌شناس مراجعه کنم؟'],
      replies: [
        { keys: ['خواب', 'بی‌خوابی', 'بیدار'], reply: 'سه کار کوچک امتحان کن: ساعت خواب و بیداری ثابت، یک ساعت قبل از خواب نور صفحه را کم کن، و اگر فکرها زیاد شدند همان‌ها را روی کاغذ بنویس تا ذهنت خالی شود. اگر بی‌خوابی بیشتر از چند هفته طول کشید، با پزشک درباره‌اش حرف بزن.' },
        { keys: ['مراجعه', 'روان‌شناس', 'دکتر', 'پزشک'], reply: 'اگر بیشتر روزهای دو هفته‌ی گذشته حالت پایین بود، از کارهای روزمره لذت نمی‌بری یا افکار آسیب‌زدن به خودت داری، وقت مراجعه است. گفت‌وگو با یک روان‌شناس یا روان‌پزشک مسیر را روشن می‌کند و نشانه‌ی ضعف نیست.' },
        { keys: ['تمرین', 'کار', 'قدم'], reply: 'یک قدم کوچک کافی است: ۱۰ دقیقه پیاده‌روی، نوشتن سه جمله‌ی سپاسگزاری، یا تماس با یک نفر که راحت با او حرف می‌زنی. وقتی حال سنگین است، کارهای کوچک مؤثرتر از تصمیم‌های بزرگ هستند.' }
      ]
    },
    {
      id: 'family', title: 'مشکلات خانوادگی', text: 'دعوا، سوءتفاهم، خستگی از خانه',
      icon: 'users', tone: 'amber',
      opener: 'بگو ماجرا معمولاً از کجا شروع می‌شود؛ همین که الگوی تکرارش را ببینیم، کارمان راحت‌تر می‌شود.',
      hints: ['چطور بدون دعوا حرف بزنم؟', 'مرزگذاری با خانواده', 'وقتی همه‌چیز گردن من است'],
      replies: [
        { keys: ['دعوا', 'حرف', 'گفت‌وگو'], reply: 'یک قاعده‌ی ساده کمک می‌کند: با «من» شروع کن نه «تو». مثلاً «وقتی این‌طور می‌شود، خسته می‌شوم» خیلی کمتر از «تو هیچ‌وقت توجه نمی‌کنی» جبهه می‌سازد. بهتر است گفت‌وگو در زمان آرام باشد، نه در میانه‌ی دعوا.' },
        { keys: ['مرز', 'نه گفتن', 'محدود'], reply: 'مرز یعنی تصمیم بگیر کدام کارها وظیفه‌ی تو است و کدام نیست. یک جمله‌ی آماده بساز («این را نمی‌توانم قبول کنم، ولی می‌توانم این کار را بکنم») تا در لحظه مجبور نباشی از خودت دفاع کنی.' },
        { keys: ['خسته', 'تنهایی', 'بار'], reply: 'وقتی همه‌ی بار روی دوش توست، اول فهرست کن چه کارهایی را می‌توانی واگذار کنی — نه به خاطر بی‌توجهی، بلکه به خاطر ماندن. سپس یک کار مشخص را به یک نفر مشخص بسپار، نه درخواست کلی.' }
      ]
    },
    {
      id: 'marriage', title: 'رابطه زناشویی', text: 'فاصله، بی‌حوصلگی، سوءتفاهم',
      icon: 'heart', tone: 'plum',
      opener: 'این‌جا فضای امنی است. چه چیزی بین شما این روزها سنگین شده؟',
      hints: ['حرف زدن درباره نیازها', 'وقتی بحث به دعوا می‌رسد', 'چطور صمیمیت را برگردانم؟'],
      replies: [
        { keys: ['نیاز', 'حرف'], reply: 'به جای گفتن «تو نمی‌فهمی»، خواسته‌ی روشن بگو: «اگر شب‌ها ده دقیقه بدون موبایل با هم حرف بزنیم، حالم بهتر می‌شود». خواسته‌ی مشخص، شانس همکاری را بسیار بیشتر می‌کند.' },
        { keys: ['دعوا', 'بحث', 'جنگ'], reply: 'قاعده‌ی توقف را امتحان کن: وقتی ضربان بالا رفت، بیست دقیقه گفت‌وگو را کنار بگذارید و بعد ادامه بدهید. در آن بیست دقیقه هیچ‌کدام موضوع را ادامه ندهید تا گفت‌وگو از تخریب به حل‌مسئله برگردد.' },
        { keys: ['صمیمیت', 'سرد', 'فاصله'], reply: 'صمیمیت معمولاً از کارهای کوچک روزانه برمی‌گردد نه از یک گفت‌وگوی بزرگ: یک پیام کوتاه، یک کار خانه که انجام می‌دهی، یا پرسیدن حال واقعی یکدیگر. اگر فاصله طولانی شده، گفت‌وگو با یک مشاور زوج‌درمانگر راه را کوتاه می‌کند.' }
      ]
    },
    {
      id: 'pregnancy', title: 'بارداری', text: 'علائم، هفته‌به‌هفته، آماده‌سازی',
      icon: 'baby', tone: 'brand',
      opener: 'در چه هفته‌ای هستی و این روزها چه چیزی نگرانت کرده؟ هر جا لازم بود خودت را به پزشک ارجاع می‌دهم.',
      hints: ['کدام علائم خطرناک است؟', 'رژیم و آزمایش این هفته', 'چطور خوابم بهتر شود؟'],
      replies: [
        { keys: ['خطر', 'علائم', 'خونریزی'], reply: 'خونریزی از واژن، ترشح آبکی پیوسته، کاهش واضح حرکت جنین، سردرد شدید یا ورم ناگهانی صورت و دست‌ها را نباید صبر کرد؛ همین حالا با پزشک یا مامای خود تماس بگیر. این نشانه‌ها جدی هستند و بررسی سریع لازم است.' },
        { keys: ['تغذیه', 'آزمایش', 'قند'], reply: 'برای این‌که چیزی را از دست ندهی، در صفحه‌ی «مسیر بارداری» همین اپ کارهای هفته به هفته و آزمایش‌های مانده فهرست شده است. برای مواد غذایی و مکمل‌ها، الگوی خودت را با ماما یا پزشک چک کن.' },
        { keys: ['خواب', 'پهلو', 'کمر'], reply: 'از این هفته‌ها به بعد، خواب به پهلوی چپ با یک بالش بین زانوها و یک بالش کوچک زیر شکم، کمردرد و سوزش را کم می‌کند. اگر بی‌خوابی شدید شد، با پزشک درباره‌ی راه‌های بی‌خطر مطرح کن.' }
      ]
    },
    {
      id: 'nutrition', title: 'تغذیه', text: 'رژیم، وزن، اضافه‌وزن، کم‌خونی',
      icon: 'apple', tone: 'green',
      opener: 'هَدف فعلی‌ات چیست: کم‌کردن وزن، وزن‌گیری سالم، یا بهتر کردن کیفیت غذا؟',
      hints: ['برای وزن کم چه کنم؟', 'کم‌خونی و آهن', 'سه میان‌وعده سالم'],
      replies: [
        { keys: ['وزن', 'لاغر', 'رژیم'], reply: 'به جای حذف برنامه‌ای غذاها، سه چیز را ثابت کن: پروتئین در هر وعده، کربوهیدرات سبوس‌دار، و سبزیجات. برنامه‌ای که نتوانی ماه‌ها ادامه بدهی، نتیجه‌ی پایدار نمی‌دهد.' },
        { keys: ['کم‌خونی', 'آهن', 'هموگلوبین'], reply: 'بسته به شدت کم‌خونی، مکمل فقط با تجویز پزشک تعیین می‌شود؛ چون مقدار و مدت آن با آزمایش تعیین می‌شود. منابع غذایی مثل حبوبات، گوشت کم‌چرب، برگ سبز و ترکیب با ویتامین C کمک می‌کنند.' },
        { keys: ['میان‌وعده', 'سرخ کردن', 'سلام'], reply: 'سه ترکیب ساده: ماست و گردو، سیب و کره‌ی بادام‌زمینی، یا نان سبوس‌دار و پنیر با خیار. هر کدام یک شاخص گلیسمی پایین‌تر از بیسکویت و کیک دارند.' }
      ]
    },
    {
      id: 'anxiety', title: 'اضطراب و استرس', text: 'تپش قلب، نگرانی مداوم، ناآرامی',
      icon: 'wind', tone: 'teal',
      opener: 'اضطراب می‌گوید خطر نزدیک است حتی وقتی نیست. بگو نگرانی‌ات بیشتر درباره آینده است یا موقعیت‌های روزمره؟',
      hints: ['یک تمرین فوری برای تپش قلب', 'چطور نگرانی را متوقف کنم؟', 'کی خطرناک می‌شود؟'],
      replies: [
        { keys: ['تمرین', 'تپش', 'نفس'], reply: 'تنفس ۴-۷-۸: چهار ثانیه دم، هفت ثانیه نگه‌داشتن، هشت ثانیه بازدم؛ سه بار. این تمرین ضربان را پایین می‌آورد. همین تمرین در صفحه‌ی «حال من» با تایمر هم آماده است.' },
        { keys: ['نگرانی', 'فکر', 'متوقف'], reply: 'یک زمان مشخص برای نگرانی بگذار (مثلاً ۱۵ دقیقه عصر). در طول روز اگر فکر آمد، جایی یادداشتش کن و به خودت بگو «عصر بررسی می‌کنم». این کار ذهن را از درگیری مداوم بیرون می‌آورد.' },
        { keys: ['خطرناک', 'حمله', 'وحشت'], reply: 'حمله‌ی وحشت ترسناک است ولی معمولاً در چند دقیقه فروکش می‌کند. اگر تنگی نفس شدید، درد قفسه‌ی سینه‌ی فشاری یا بیهوشی داشتی، یا اضطراب کار زندگی‌ات را مختل کرده، بررسی پزشکی لازم است.' }
      ]
    },
    {
      id: 'sleep', title: 'خواب', text: 'بی‌خوابی، خواب سبک، بیداری شبانه',
      icon: 'clock', tone: 'sky',
      opener: 'بگو مشکل کدام قسمت است: به خواب رفتن، بیدار شدن در نیمه‌شب، یا خواب سبک؟',
      hints: ['روتین شب قبل خواب', 'اگر وسط شب بیدار شدم چه کنم؟', 'کافئین و خواب'],
      replies: [
        { keys: ['روتین', 'شب', 'قبل'], reply: 'یک ساعت پیش از خواب: نور صفحه کم، کار ذهنی سنگین نه، و یک کار آرام تکراری (دوش گرم، کتاب کاغذی، نوشتن کارهای فردا). بدن با تکرار همین الگو شرط می‌گیرد.' },
        { keys: ['بیدار', 'وسط', 'نیمه'], reply: 'اگر بیدار شدی و بعد از بیست دقیقه خوابت نبرد، از تخت بیرون بیا و در نور کم کاری آرام بکن تا وقتی خواب آلود شدی. در تخت نمان که با اضطراب شرط نگیرد.' },
        { keys: ['کافئین', 'قهوه', 'چای'], reply: 'اثر کافئین چند ساعت می‌ماند؛ حدود هشت ساعت پیش از خواب مصرفش را قطع کن و عصرها جایگزین‌هایی مثل دمنوش بابونه یا دم‌کرده‌ی آرام‌بخش امتحان کن.' }
      ]
    },
    {
      id: 'parenting', title: 'فرزندپروری', text: 'رفتار کودک، لجبازی، خشم کودک',
      icon: 'smile', tone: 'amber',
      opener: 'چند سالش است و بیشتر چه رفتاری خسته‌ات کرده؟ مثال کوتاه از یک روز معمولی کمک می‌کند.',
      hints: ['لجبازی را چطور مدیریت کنم؟', 'کودکم بدخوابی دارد', 'تنبیه و تشویق درست'],
      replies: [
        { keys: ['لجبازی', 'نه گوش', 'بحث'], reply: 'کودک در لحظه‌ی هیجان، منطق را نمی‌شنود. اول احساسش را نامگذاری کن («می‌دانم واقعاً ناراحتی») و بعد مرز را با جمله‌ی کوتاه بگو. قاعده‌ی دو گزینه‌ای هم خوب کار می‌کند: «می‌خواهی الان بخوابی یا بعد از یک قصه؟»' },
        { keys: ['خواب', 'شب', 'بیدار'], reply: 'روتین ثابت شبانه معجزه می‌کند: حمام آرام، چراغ کم، دو کتاب ثابت، خداحافظی کوتاه. زمانِ خواب را هفته‌ای ۱۵ دقیقه جابه‌جا کن نه یک‌باره.' },
        { keys: ['تنبیه', 'تشویق', 'پاداش'], reply: 'تنبیه شدید معمولاً رفتار را پنهان می‌کند نه اصلاح. جای آن، پیامد منطقی روشن و پیامد فوری مثبت (تشویق کلامی مشخص: «ممنون که خودت اسباب‌بازی را جمع کردی») روی نتیجه اثر بیشتری دارد.' }
      ]
    }
  ];

  function bindAdvisor() {
    var topicsHost = el('[data-topics]');
    if (!topicsHost || !bindOnce(topicsHost, 'advisor')) return;
    var topicsCard = el('[data-advisor-topics]');
    var chatCard = el('[data-advisor-chat]');
    var log = el('[data-advisor-log]');
    var hintHost = el('[data-advisor-suggest]');
    var form = el('[data-advisor-form]');
    var input = el('#advisor-input');
    var crisis = el('[data-advisor-crisis]');
    var historyList = el('[data-chat-history-list]');
    var historyStatus = el('[data-chat-history-status]');
    var current = null;
    var conversation = [];
    var chatId = 0;
    var sending = false;
    var creditBlocked = false;

    topicsHost.innerHTML = ADVISOR_TOPICS.map(function (topic) {
      return '<button type="button" class="topic-card topic-card--' + topic.tone + '" data-topic="' + topic.id + '">' +
        '<span class="topic-card__icon" aria-hidden="true">' + icon(topic.icon, 22) + '</span>' +
        '<span class="topic-card__body"><span class="topic-card__title">' + topic.title + '</span>' +
        '<span class="topic-card__text">' + topic.text + '</span></span></button>';
    }).join('');

    function bubble(text, mine) {
      var node = document.createElement('p');
      node.className = 'chat__bubble' + (mine ? ' chat__bubble--me' : '');
      node.setAttribute('dir', 'auto');
      node.textContent = text;
      log.appendChild(node);
      log.scrollTop = log.scrollHeight;
      return node;
    }

    function typing() {
      var node = document.createElement('p');
      node.className = 'chat__bubble';
      node.setAttribute('data-typing', '');
      node.innerHTML = '<span class="typing" aria-label="در حال نوشتن"><i></i><i></i><i></i></span>';
      log.appendChild(node);
      log.scrollTop = log.scrollHeight;
      return node;
    }

    function open(topic) {
      current = topic;
      chatId = 0;
      topicsCard.hidden = true;
      chatCard.hidden = false;
      el('[data-advisor-topic]').textContent = topic.title;
      el('[data-advisor-hint]').textContent = 'همراهِ موضوع «' + topic.title + '»';
      var iconHost = el('[data-advisor-icon]');
      iconHost.className = 'card__icon card__icon--' + (topic.tone === 'brand' ? 'pink' : topic.tone);
      iconHost.innerHTML = icon(topic.icon, 20);
      log.innerHTML = '';
      conversation = [];
      bubble(topic.opener, false);
      hintHost.innerHTML = topic.hints.map(function (hint) {
        return '<button type="button" class="chip" data-advisor-suggestion>' + hint + '</button>';
      }).join('');
      if (crisis) crisis.hidden = true;
      if (chatCard.scrollIntoView) { chatCard.scrollIntoView({ behavior: 'smooth', block: 'start' }); }
    }

    function loadSavedChats() {
      var cfg = window.NIVA_CONFIG || {};
      if (!historyList || !cfg.plugin || !cfg.plugin.rest) return;
      fetch(cfg.plugin.rest + '/chat/history', {
        credentials: 'same-origin',
        headers: { 'X-WP-Nonce': cfg.plugin.nonce || '' }
      }).then(function (response) {
        return response.json().then(function (payload) {
          if (!response.ok) throw new Error(payload.message || 'تاریخچهٔ گفت‌وگو بارگذاری نشد.');
          return payload;
        });
      }).then(function (payload) {
        historyList.replaceChildren();
        var rows = Array.isArray(payload.chats) ? payload.chats : [];
        if (historyStatus) historyStatus.textContent = rows.length ? '' : 'هنوز گفت‌وگوی ذخیره‌شده‌ای نداری.';
        rows.forEach(function (item) {
          var row = document.createElement('div');
          row.className = 'chat-history__row';
          var openButton = document.createElement('button');
          openButton.type = 'button';
          openButton.className = 'chat-history__open';
          openButton.dataset.chatOpen = String(item.id);
          var title = document.createElement('strong');
          title.textContent = item.title || 'گفت‌وگوی مشاور';
          var date = document.createElement('span');
          date.className = 'caption';
          date.textContent = item.updated_at_label || '';
          openButton.append(title, date);
          var remove = document.createElement('button');
          remove.type = 'button';
          remove.className = 'chat-history__delete';
          remove.dataset.chatDelete = String(item.id);
          remove.setAttribute('aria-label', 'حذف گفت‌وگو');
          remove.textContent = 'حذف';
          row.append(openButton, remove);
          historyList.appendChild(row);
        });
      }).catch(function (error) {
        if (historyStatus) historyStatus.textContent = error.message || 'تاریخچهٔ گفت‌وگو بارگذاری نشد.';
      });
    }

    function deleteSavedChat(id, row) {
      var cfg = window.NIVA_CONFIG || {};
      if (!cfg.plugin || !cfg.plugin.rest || !id) return;
      fetch(cfg.plugin.rest + '/chat/history', {
        method: 'DELETE',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.plugin.nonce || '' },
        body: JSON.stringify({ chat_id: id })
      }).then(function (response) {
        return response.json().then(function (payload) {
          if (!response.ok) throw new Error(payload.message || 'حذف گفت‌وگو انجام نشد.');
          if (chatId === id) {
            chatId = 0;
            conversation = [];
            log.replaceChildren();
            bubble('این گفت‌وگو حذف شد.', false);
          }
          if (row) row.remove();
          loadSavedChats();
        });
      }).catch(function (error) {
        if (historyStatus) historyStatus.textContent = error.message || 'حذف گفت‌وگو انجام نشد.';
      });
    }

    function openSavedChat(id) {
      var cfg = window.NIVA_CONFIG || {};
      if (!cfg.plugin || !cfg.plugin.rest || !id) return;
      fetch(cfg.plugin.rest + '/chat/history?chat_id=' + encodeURIComponent(id), {
        credentials: 'same-origin',
        headers: { 'X-WP-Nonce': cfg.plugin.nonce || '' }
      }).then(function (response) {
        return response.json().then(function (payload) {
          if (!response.ok) throw new Error(payload.message || 'گفت‌وگو باز نشد.');
          return payload;
        });
      }).then(function (payload) {
        var topic = ADVISOR_TOPICS.filter(function (item) { return item.id === payload.chat.topic; })[0] ||
          { id: payload.chat.topic || 'general', title: payload.chat.title || 'گفت‌وگوی قبلی', tone: 'sky', icon: 'message-circle', opener: '', hints: [] };
        open(topic);
        chatId = Number(payload.chat_id) || 0;
        log.replaceChildren();
        conversation = [];
        (payload.messages || []).forEach(function (message) {
          var mine = message.role === 'user';
          bubble(message.content || '', mine);
          if (mine || message.role === 'assistant') conversation.push({ role: message.role, content: message.content || '' });
        });
        if (topicsCard) topicsCard.hidden = true;
        if (chatCard) chatCard.hidden = false;
      }).catch(function (error) {
        if (historyStatus) historyStatus.textContent = error.message || 'گفت‌وگو باز نشد.';
      });
    }

    function paintWallet(summary) {
      if (!summary) return;
      var bar = el('[data-niva-credits]');
      if (bar) {
        var balance = el('[data-niva-balance]', bar);
        var quota = el('[data-niva-quota]', bar);
        if (balance) balance.textContent = fa(summary.balance);
        if (quota) quota.textContent = fa(summary.quota_left);
        bar.classList.toggle('niva-credits--low', !!summary.low);
      }
      var chatBalance = el('[data-advisor-balance]');
      var chatQuota = el('[data-advisor-quota]');
      if (chatBalance) chatBalance.textContent = fa(summary.balance);
      if (chatQuota) chatQuota.textContent = fa(summary.quota_left);
    }

    function paintChatQuota(summary) {
      if (!summary) return;
      var plan = el('[data-advisor-plan]');
      var quota = el('[data-advisor-plan-quota]');
      var expiry = el('[data-advisor-plan-expiry]');
      if (plan) plan.textContent = summary.label || 'رایگان';
      if (quota) {
        quota.textContent = summary.unlimited
          ? 'نامحدود'
          : fa(summary.remaining) + ' از ' + fa(summary.limit) + ' پیام امروز';
      }
      if (expiry) {
        expiry.textContent = summary.expires ? 'اعتبار تا ' + summary.expires : (summary.active ? 'اشتراک فعال' : 'بدون اشتراک پولی');
      }
    }
    paintChatQuota((window.NIVA_CONFIG || {}).chatQuota);

    function send(text) {
      if (!text.trim() || sending || creditBlocked) return;
      bubble(text, true);
      var pending = typing();
      sending = true;
      var sendButton = form.querySelector('[type="submit"]');
      if (sendButton) sendButton.disabled = true;

      var cfg = window.NIVA_CONFIG;
      if (cfg && cfg.plugin && cfg.plugin.rest && cfg.user && cfg.user.logged_in) {
        fetch(cfg.plugin.rest + '/chat', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': cfg.plugin.nonce },
          body: JSON.stringify({
            message: text,
            topic: current ? current.id : 'general',
            topic_title: current ? current.title : '',
            chat_id: chatId,
            history: conversation
          })
        })
          .then(function (response) {
            return response.json().then(function (data) { return { ok: response.ok, data: data }; });
          })
          .then(function (result) {
            pending.remove();
            if (!result.ok) {
              var message = (result.data && result.data.message) || 'پاسخ نگرفتیم؛ چند لحظه بعد دوباره امتحان کن.';
              bubble(message, false);
              if (result.data && result.data.code === 'niva_insufficient_credits') {
                creditBlocked = true;
                var composer = form.querySelector('input');
                if (composer) composer.disabled = true;
                var link = document.createElement('p');
                link.className = 'chat__bubble';
                link.innerHTML = '<a class="link-inline" href="' + htmlText(url('plans', 'plans.html')) + '">شارژ اعتبار</a>';
                log.appendChild(link);
                log.scrollTop = log.scrollHeight;
                fetch(cfg.plugin.rest + '/wallet', {
                  credentials: 'same-origin',
                  headers: { 'X-WP-Nonce': cfg.plugin.nonce || '' }
                }).then(function (response) {
                  return response.json();
                }).then(function (wallet) {
                  if (wallet && wallet.summary) paintWallet(wallet.summary);
                }).catch(function () { /* The server has already blocked further sends. */ });
              }
              return;
            }
            bubble(result.data.text, false);
            if (result.data.chat_id) chatId = Number(result.data.chat_id);
            conversation.push(
              { role: 'user', content: text },
              { role: 'assistant', content: result.data.text }
            );
            if (result.data.crisis && crisis) crisis.hidden = false;
            paintWallet(result.data.wallet);
            paintChatQuota(result.data.plan_quota);
            loadSavedChats();
          })
          .catch(function () {
            pending.remove();
            bubble('ارتباط با سرور برقرار نشد. اتصال اینترنت را بررسی کن.', false);
          })
          .then(function () {
            sending = false;
            if (sendButton && !creditBlocked) sendButton.disabled = false;
          });
        return;
      }

      pending.remove();
      bubble('برای استفاده از مشاور هوشمند GapGPT ابتدا وارد حساب کاربری‌ات شو.', false);
      sending = false;
      if (sendButton) sendButton.disabled = false;
    }

    topicsHost.addEventListener('click', function (event) {
      var card = event.target.closest('[data-topic]');
      if (!card) return;
      var topic = ADVISOR_TOPICS.filter(function (item) { return item.id === card.dataset.topic; })[0];
      if (topic) open(topic);
    });

    if (hintHost) {
      hintHost.addEventListener('click', function (event) {
        var chip = event.target.closest('[data-advisor-suggestion]');
        if (!chip) return;
        input.value = chip.textContent;
        send(chip.textContent);
        input.value = '';
      });
    }

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      send(input.value);
      input.value = '';
    });

    if (historyList) {
      historyList.addEventListener('click', function (event) {
        var openButton = event.target.closest('[data-chat-open]');
        if (openButton) {
          openSavedChat(Number(openButton.dataset.chatOpen));
          return;
        }
        var deleteButton = event.target.closest('[data-chat-delete]');
        if (deleteButton && window.confirm('این گفت‌وگو و پیام‌هایش حذف شود؟')) {
          deleteSavedChat(Number(deleteButton.dataset.chatDelete), deleteButton.closest('.chat-history__row'));
        }
      });
    }
    loadSavedChats();

    els('[data-advisor-reset]').forEach(function (button) {
      button.addEventListener('click', function () {
        current = null;
        chatCard.hidden = true;
        topicsCard.hidden = false;
        topicsCard.scrollIntoView({ behavior: 'smooth', block: 'start' });
      });
    });

  }

  /* ------------------------------------------------------------------ once */
  /*
   * boot() is deliberately re-callable: the WordPress bridge injects a view
   * later and calls NIVA_BOOT again. Re-binding the same element would attach a
   * second listener, so a single click would toggle twice and cancel itself —
   * which is exactly why the FAQ, the symptom chips, the checklists and the
   * sound switch all looked dead. Each element is now bound at most once.
   */
  function bindOnce(node, key) {
    if (!node) return false;
    if (node.__avaBound && node.__avaBound[key]) return false;
    node.__avaBound = node.__avaBound || {};
    node.__avaBound[key] = true;
    return true;
  }

  /* ------------------------------------------------------------------ boot */

  function bootContent() {
    bindIcons();
    renderCharts();
    bindReveal();
    bindAccordions();
    bindChips();
    bindChecklists();
    bindCounters();
    bindCalendar();
    bindCycleSymptoms();
    bindAnalyze();
    bindMood();
    bindBreathing();
    bindChat();
    bindThoughtRecord();
    bindRequestForm();
    bindPartnerCta();
    bindAssessment();
    bindBillingToggle();
    bindCrisisSheet();
    bindProfileHubSheets();
    bindPrint();
    bindBaby();
    bindAdvisor();
    bindDrawer();
    bindSheets();
    bindPlanRequest();
    bindDateHints();
    bindFormGuard();
    bindReminderForm();
    bindLabEntry();
    bindExercises();
    bindOnboarding();
    bindNotifications();
    bindReminders();
  }

  function boot() {
    paintToday();
    renderHeader();
    renderFooter();
    bootContent();
  }

  /* the WordPress bridge injects a view later and calls this again */
  window.NIVA_BOOT = boot;
  window.NIVA_BOOT_CONTENT = bootContent;

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
