/* ==========================================================================
   Dr. Niva — companion codes (2.0.0)
   Owner side: create / copy link / regenerate / revoke.
   Companion side: enter code + phone, confirm the one-time code.
   Progressive enhancement: the create form degrades to a normal POST-less form
   with a clear message, and nothing here is a security boundary.
   ========================================================================== */
(function () {
  'use strict';

  /* 3.0.1 — the screen can be replaced in place by the in-app router, so
     the initialiser runs again on every view change (bindings below are
     idempotent or attach to the freshly rendered nodes). */
  function ready(fn) {
    var run = function () { try { fn(); } catch (error) { if (window.console && console.warn) console.warn('[niva]', error); } };
    if (document.readyState !== 'loading') { run(); } else { document.addEventListener('DOMContentLoaded', run); }
    document.addEventListener('niva:view-ready', run);
    document.addEventListener('niva:view-changed', run);
  }
  function readyLegacy(fn) {
    if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function api(base, nonce, path, payload) {
    /* 2.0.1 — a non-JSON answer (server error page) becomes a sentence. */
    if (window.NIVA_FETCH && window.NIVA_FETCH.json) {
      return window.NIVA_FETCH.json(base + path, {
        method: 'POST',
        headers: nonce ? { 'X-WP-Nonce': nonce } : {},
        body: payload || {}
      });
    }
    return fetch(base + path, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
      body: JSON.stringify(payload || {})
    }).then(function (response) {
      return response.text().then(function (text) {
        var json = null;
        try { json = text ? JSON.parse(text) : null; } catch (error) { json = null; }
        if (!response.ok || json === null) {
          throw new Error(json && json.message ? json.message : 'ارتباط برقرار نشد؛ دوباره تلاش کن.');
        }
        return json;
      });
    });
  }

  function toast(text) {
    if (typeof window.NIVA_TOAST === 'function') { window.NIVA_TOAST(text); }
  }

  function closeModal(node) {
    if (typeof window.NIVA_MODAL === 'object' && window.NIVA_MODAL) {
      window.NIVA_MODAL.close(node);
      return;
    }
    var modal = node && node.closest ? node.closest('.niva-modal') : null;
    if (modal) { modal.classList.remove('is-open'); modal.hidden = true; }
  }

  ready(function () {
    var host = document.querySelector('[data-niva-companion]');
    if (!host) { return; }
    var base = host.getAttribute('data-niva-companion');
    var nonce = host.getAttribute('data-niva-nonce');
    var message = document.querySelector('[data-niva-companion-message]');

    function say(text, ok) {
      if (!message) { window.alert(text); return; }
      message.hidden = false;
      message.textContent = text;
      message.style.color = ok ? 'var(--ok, #2f8f6b)' : '';
    }

    /* ------------------------------------------------------ owner: create */
    var form = document.querySelector('[data-niva-companion-create]');
    if (form) {
      form.addEventListener('submit', function (event) {
        event.preventDefault();
        var scopes = [];
        form.querySelectorAll('input[name="scopes[]"]:checked').forEach(function (box) {
          scopes.push(box.value);
        });
        api(base, nonce, 'create', {
          name: (form.querySelector('[name="name"]') || {}).value || '',
          phone: (form.querySelector('[name="phone"]') || {}).value || '',
          days: (form.querySelector('[name="days"]') || {}).value || '',
          scopes: scopes
        }).then(function (json) {
          closeModal(form);
          form.reset();
          say('کد ساخته شد.', true);
          toast('کد همراهی ساخته شد.');
          /* 2.0.1 — the new code appears in the list; the screen is not reloaded. */
          var list = document.querySelector('.companion-list');
          if (json && json.row && list) {
            list.insertAdjacentHTML('afterbegin', json.row);
          } else if (json && json.link) {
            say('کد ساخته شد. لینک: ' + json.link, true);
          }
        }).catch(function (error) { say(error.message); });
      });
    }

    /* --------------------------------------------------- owner: row actions */
    document.querySelectorAll('[data-niva-companion-copy]').forEach(function (button) {
      button.addEventListener('click', function () {
        var link = button.getAttribute('data-niva-companion-copy');
        if (navigator.clipboard && navigator.clipboard.writeText) {
          navigator.clipboard.writeText(link).then(function () { say('لینک کپی شد.', true); })
            ['catch'](function () { say('کپی نشد؛ دستی انتخاب کن: ' + link); });
        } else {
          say('این مرورگر کپی خودکار ندارد: ' + link);
        }
      });
    });

    document.querySelectorAll('[data-niva-companion-revoke]').forEach(function (button) {
      button.addEventListener('click', function () {
        if (!window.confirm('این کد ابطال شود؟ دسترسی همراه فوراً قطع می‌شود.')) { return; }
        api(base, nonce, 'revoke', { id: button.getAttribute('data-niva-companion-revoke') })
          .then(function () {
            say('کد ابطال شد.', true);
            toast('دسترسی همراه قطع شد.');
            var row = button.closest('.companion-item');
            if (row) {
              row.classList.add('is-inactive');
              Array.prototype.forEach.call(row.querySelectorAll('button, a'), function (node) { node.remove(); });
              var badge = row.querySelector('.companion-badge');
              if (badge) { badge.textContent = 'ابطال‌شده'; badge.className = 'companion-badge'; }
            }
          })
          .catch(function (error) { say(error.message); });
      });
    });

    document.querySelectorAll('[data-niva-companion-regen]').forEach(function (button) {
      button.addEventListener('click', function () {
        api(base, nonce, 'regenerate', { id: button.getAttribute('data-niva-companion-regen') })
          .then(function (json) {
            say('کد تازه ساخته شد؛ لینک قبلی دیگر کار نمی‌کند.', true);
            toast('کد تازه ساخته شد.');
            var row = button.closest('.companion-item');
            if (row && json && json.code) {
              var code = row.querySelector('.companion-code');
              if (code) { code.textContent = json.code; }
              var copy = row.querySelector('[data-niva-companion-copy]');
              if (copy && json.link) { copy.setAttribute('data-niva-companion-copy', json.link); }
            }
          })
          .catch(function (error) { say(error.message); });
      });
    });

    /* ------------------------------------------ companion: sign in and verify */
    var gate = document.querySelector('[data-niva-companion-gate]');
    var verify = document.querySelector('[data-niva-companion-verify]');
    if (gate) {
      gate.addEventListener('submit', function (event) {
        event.preventDefault();
        api(base, nonce, 'otp', {
          mode: 'send',
          code: (gate.querySelector('[name="code"]') || {}).value || host.getAttribute('data-niva-code') || '',
          phone: (gate.querySelector('[name="phone"]') || {}).value || ''
        }).then(function () {
          say('کد تأیید پیامک شد؛ آن را وارد کن.', true);
          if (verify) { verify.hidden = false; }
        }).catch(function (error) {
          say(error.message);
          if (verify) { verify.hidden = true; }
        });
      });
    }
    if (verify) {
      verify.addEventListener('submit', function (event) {
        event.preventDefault();
        api(base, nonce, 'otp', {
          mode: 'verify',
          code: (gate && gate.querySelector('[name="code"]') ? gate.querySelector('[name="code"]').value : host.getAttribute('data-niva-code')) || '',
          otp: (verify.querySelector('[name="otp"]') || {}).value || ''
        }).then(function () {
          window.location.reload();
        }).catch(function (error) { say(error.message); });
      });
    }
  });
}());
