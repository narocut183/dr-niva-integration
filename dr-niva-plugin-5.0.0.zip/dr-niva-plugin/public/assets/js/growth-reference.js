/* ==========================================================================
   Growth reference slot — intentionally empty.
   --------------------------------------------------------------------------
   The "is my baby's height/weight normal for this age?" comparison needs the
   official reference table (WHO Child Growth Standards / the national chart).
   Those numeric LMS values are not bundled here: shipping numbers we could not
   verify against the published source would be worse than shipping none.

   A reviewer fills `table` below (one row per month of age) and the growth
   screen immediately switches from "in development" to a real z-score verdict.

   Expected shape:
     table = {
       boys:  { 0: { l: 3.3464, m: 3.3464, s: 0.14602 }, 1: { ... }, ... },
       girls: { 0: { ... }, ... }
     }
   `weight` and `height` tables can be separate objects if needed.
   ========================================================================== */

window.NIVA_GROWTH_REFERENCE = null;

window.NIVA_GROWTH_REFERENCE_TEMPLATE = {
  /**
   * LMS z-score: z = ((value / M) ^ L - 1) / (L * S)
   * Standard WHO z-score cut-offs used for the verdict bands:
   *   z < -3        severely below the reference range
   *   -3 to -2      below the reference range
   *   -2 to +2      within the reference range
   *   +2 to +3      above the reference range
   *   z > +3        far above the reference range
   */
  zScore: function (measure, table) {
    var row = (table || {})[measure.ageMonths];
    if (!row) return null;
    function z(value, l, m, s) {
      return l === 0 ? Math.log(value / m) / s : (Math.pow(value / m, l) - 1) / (l * s);
    }
    var zw = z(measure.weight, row.weightL, row.weightM, row.weightS);
    var label = zw < -3 ? 'خیلی پایین‌تر از بازه مرجع'
      : zw < -2 ? 'پایین‌تر از بازه مرجع'
        : zw <= 2 ? 'داخل بازه مرجع'
          : zw <= 3 ? 'بالاتر از بازه مرجع' : 'خیلی بالاتر از بازه مرجع';
    return { z: Number(zw.toFixed(2)), label: label };
  }
};
