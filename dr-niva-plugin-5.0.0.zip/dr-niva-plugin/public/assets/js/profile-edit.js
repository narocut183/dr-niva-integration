/* ==========================================================================
   Dr. Niva — inline section editor (3.8.0)
   --------------------------------------------------------------------------
   Why: pressing «ویرایش» used to send the user back into the questionnaire, so
   a single value meant walking the whole flow again (and a slow page load could
   drag them back to the list of answers).

   Now: a click on any «ویرایش» link that points at `?niva_step=…` never
   navigates. It opens a small dialog for that one section, saves it through the
   existing endpoint, updates the row in place, and stays exactly where the user
   is. If a section has no simple fields, the click is simply ignored (and
   logged) — navigation never happens.
   ========================================================================== */
(function () {
  'use strict';

  var FIELDS = {
    name: [
      { key: 'first_name', label: 'نام' },
      { key: 'last_name', label: 'نام خانوادگی' }
    ],
    phone: [{ key: 'phone', label: 'شمارهٔ همراه' }],
    height: [{ key: 'height', label: 'قد (سانتی‌متر)', type: 'number' }],
    weight: [{ key: 'weight', label: 'وزن (کیلوگرم)', type: 'number' }],
    birth: [{ key: 'birth_date', label: 'تاریخ تولد (شمسی)', placeholder: 'مثال: 1383-04-05' }],
    period_length: [{ key: 'period_length', label: 'طول پریود (روز)', type: 'number' }],
    cycle_length: [{ key: 'cycle_length', label: 'طول سیکل (روز)', type: 'number' }],
    lmp: [{ key: 'lmp', label: 'تاریخ آخرین پریود (شمسی)', placeholder: 'مثال: 1405-07-18' }]
  };

  function log(message, data) {
    if (window.NIVA_DEBUG && window.NIVA_DEBUG.edit) { window.NIVA_DEBUG.edit(message, data); }
  }

  function config() {
    return window.NIVA_CONFIG || {};
  }

  function stepFromHref(href) {
    var match = /[?&]niva_step=([a-z_]+)/i.exec(href || '');
    return match ? match[1] : '';
  }

  function closeModal(node) {
    if (node && node.parentNode) { node.parentNode.removeChild(node); }
    document.body.classList.remove('niva-modal-open');
  }

  function openEditor(step, row, link) {
    var fields = FIELDS[step];
    if (!fields) {
      log('no inline editor for this section; staying on the page', step);
      if (window.NIVA_TOAST) { window.NIVA_TOAST('این بخش از «پروفایل من» ویرایش می‌شود.'); }
      return;
    }

    var previous = '';
    try { previous = window.localStorage.getItem('niva_row_' + step) || ''; } catch (error) { /* ignore */ }

    var modal = document.createElement('div');
    modal.className = 'niva-modal';
    modal.setAttribute('data-niva-modal', 'niva-inline-edit');
    modal.innerHTML =
      '<div class="niva-modal__backdrop" data-close></div>' +
      '<div class="niva-modal__panel" role="dialog" aria-modal="true">' +
        '<div class="niva-modal__head"><h2 class="niva-modal__title">ویرایش این بخش</h2>' +
        '<button type="button" class="niva-modal__x" data-close aria-label="بستن">×</button></div>' +
        '<form class="niva-modal__body" data-inline-form></form>' +
      '</div>';

    var form = modal.querySelector('[data-inline-form]');
    fields.forEach(function (field) {
      var wrap = document.createElement('label');
      wrap.className = 'field';
      var span = document.createElement('span');
      span.className = 'field__label';
      span.textContent = field.label;
      var input = document.createElement('input');
      input.className = 'field__input';
      input.type = field.type || 'text';
      input.name = field.key;
      input.setAttribute('data-niva-ob-field', field.key);
      if (field.placeholder) { input.placeholder = field.placeholder; }
      wrap.appendChild(span);
      wrap.appendChild(input);
      form.appendChild(wrap);
    });

    var message = document.createElement('p');
    message.className = 'field__hint';
    message.setAttribute('data-inline-message', '');
    form.appendChild(message);

    var submit = document.createElement('button');
    submit.type = 'submit';
    submit.className = 'btn btn--primary btn--block';
    submit.textContent = 'ذخیره در همین بخش';
    form.appendChild(submit);

    // prefill from the row text / last known value, then from the server
    var first = form.querySelector('input');
    if (first && previous) { first.value = previous; }
    fetchState(step, form);

    modal.addEventListener('click', function (event) {
      if (event.target.closest && event.target.closest('[data-close]')) { closeModal(modal); }
    });

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      submit.disabled = true;
      message.textContent = 'در حال ذخیره…';
      var data = {};
      Array.prototype.forEach.call(form.querySelectorAll('input'), function (input) {
        if (input.value !== '') { data[input.name] = input.value; }
      });
      log('saving section', { step: step, data: data });
      saveStep(step, data).then(function (json) {
        submit.disabled = false;
        message.textContent = 'ذخیره شد ✓';
        log('saved', { step: step, response: json });
        try { window.localStorage.setItem('niva_row_' + step, JSON.stringify(data)); } catch (error) { /* ignore */ }
        paintRow(step, data);
        window.setTimeout(function () { closeModal(modal); }, 500);
        if (window.NIVA_TOAST) { window.NIVA_TOAST('ذخیره شد.'); }
      }).catch(function (error) {
        submit.disabled = false;
        message.textContent = error && error.message ? error.message : 'ذخیره نشد؛ دوباره تلاش کن.';
        log('save failed', { step: step, error: error && error.message });
      });
    });

    document.body.appendChild(modal);
    document.body.classList.add('niva-modal-open');
    if (first) { first.focus(); }
    log('editor opened in place (no navigation)', step);
  }

  function paintRow(step, data) {
    var link = document.querySelector('a[href*="niva_step=' + step + '"]');
    if (!link) { return; }
    var row = link.closest('li, .row, .profile-row, [data-profile-sheet]') || link.parentNode;
    Object.keys(data).forEach(function (key) {
      var node = row.querySelector('[data-niva-value="' + key + '"], .' + key);
      if (node) { node.textContent = data[key]; }
    });
    if (window.NIVA_DEBUG && window.NIVA_DEBUG.step) { window.NIVA_DEBUG.step('row repainted', { step: step }); }
  }

  function api(path, payload) {
    if (window.NIVA_FETCH && window.NIVA_FETCH.json) {
      return window.NIVA_FETCH.json(config().rest + path, {
        method: 'POST',
        body: payload,
        headers: { 'X-WP-Nonce': config().nonce || '' }
      });
    }
    return window.fetch(config().rest + path, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': config().nonce || '' },
      body: JSON.stringify(payload)
    }).then(function (response) {
      return response.text().then(function (text) {
        try {
          var json = JSON.parse(text);
          if (!response.ok) { throw new Error(json.message || 'ذخیره نشد.'); }
          return json;
        } catch (error) {
          throw new Error('پاسخ سرور قابل خواندن نبود (HTTP ' + response.status + ').');
        }
      });
    });
  }

  function fetchState(step, form) {
    if (!config().rest) { return; }
    window.fetch(config().rest + '/onboarding/state', {
      credentials: 'same-origin',
      headers: { 'X-WP-Nonce': config().nonce || '' }
    }).then(function (response) { return response.json(); }).then(function (json) {
      var values = (json && json.state && json.state.values) || {};
      log('state fetched for prefill', { step: step, values: values });
      Array.prototype.forEach.call(form.querySelectorAll('input'), function (input) {
        if (values[input.name] && !input.value) { input.value = values[input.name]; }
      });
    }).catch(function (error) {
      log('state fetch failed', error && error.message);
    });
  }

  function saveStep(step, data) {
    return api('/onboarding/step', { step: step, data: data });
  }

  // One delegated handler: never navigate, always edit in place.
  document.addEventListener('click', function (event) {
    var link = event.target.closest ? event.target.closest('a[href*="niva_step="]') : null;
    if (!link) { return; }
    var step = stepFromHref(link.getAttribute('href'));
    if (!step || !FIELDS[step]) { return; }
    event.preventDefault();
    event.stopPropagation();
    var row = link.closest('li, .row, .profile-row, [data-profile-sheet]') || link.parentNode;
    openEditor(step, row, link);
  }, true);
}());
