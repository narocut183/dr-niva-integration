/* ==========================================================================
   Dr. Niva — onboarding/panel debug log (TEMPORARY)  ·  v3.8.1
   --------------------------------------------------------------------------
   The panel is now ON BY DEFAULT, because «هیچ‌چیز ثبت نمی‌شود» usually means the
   flag was never passed. Everything is printed to the browser console as well,
   so DevTools shows the same lines even if the panel is hidden.

     · panel ON always            (no query needed)
     · turn it off                ...?niva_debug=0   (remembered)
     · turn it back on            ...?niva_debug=1

   To remove the whole feature later: delete this file and the two dr-niva-debug
   lines in public/class-niva-frontend.php. Nothing depends on it.
   ========================================================================== */
(function () {
  'use strict';

  var MAX = 500;
  var lines = [];
  var panel = null;
  var list = null;
  var chip = null;
  var on = true;

  try {
    var params = new window.URLSearchParams(location.search);
    if (params.get('niva_debug') === '1') { window.localStorage.setItem('niva_debug', '1'); }
    if (params.get('niva_debug') === '0') { window.localStorage.setItem('niva_debug', '0'); }
    // Default is ON: only an explicit «0» turns it off.
    on = window.localStorage.getItem('niva_debug') !== '0';
  } catch (error) { on = true; }

  function stamp() {
    var now = new Date();
    return now.toTimeString().slice(0, 8) + '.' + String(now.getMilliseconds()).padStart(3, '0');
  }

  function dump() {
    return ['Dr. Niva debug log', 'url: ' + location.href].concat(lines).join('\n');
  }

  function body() {
    return document.body || null;
  }

  function paint() {
    if (!on) { return; }
    if (!body()) { window.setTimeout(paint, 80); return; }

    if (!panel) {
      panel = document.createElement('div');
      panel.id = 'niva-debug-panel';
      panel.style.cssText = 'position:fixed;inset-inline:8px;inset-block-end:8px;max-height:46vh;z-index:2147483000;' +
        'background:#0f1a24;color:#dbe7ef;border-radius:14px;box-shadow:0 18px 44px rgba(0,0,0,.45);' +
        'font:12px/1.65 ui-monospace,Menlo,monospace;direction:ltr;text-align:left;display:flex;flex-direction:column;overflow:hidden';

      var head = document.createElement('div');
      head.style.cssText = 'display:flex;gap:8px;align-items:center;padding:7px 10px;background:#16232f';

      var title = document.createElement('strong');
      title.style.flex = '1';
      // 3.8.3 — show the PLUGIN version, not the logger's own build, so a stale
      // install is visible at a glance instead of being guessed.
      var stamp = document.querySelector('[data-niva-build]');
      title.textContent = 'Dr. Niva debug · plugin ' + (stamp ? stamp.getAttribute('data-niva-build') : 'unknown');
      head.appendChild(title);

      var copy = document.createElement('button');
      copy.type = 'button';
      copy.textContent = 'copy';
      copy.style.cssText = 'border:0;border-radius:8px;padding:5px 10px;background:#3368a0;color:#fff;cursor:pointer';
      copy.addEventListener('click', function () {
        var text = dump();
        try { navigator.clipboard.writeText(text); copy.textContent = 'ok'; }
        catch (error) { window.prompt('copy:', text); }
        window.setTimeout(function () { copy.textContent = 'copy'; }, 1200);
      });

      var hide = document.createElement('button');
      hide.type = 'button';
      hide.textContent = 'hide';
      hide.style.cssText = 'border:0;border-radius:8px;padding:5px 10px;background:#243240;color:#dbe7ef;cursor:pointer';
      hide.addEventListener('click', function () {
        panel.style.display = 'none';
        if (chip) { chip.style.display = 'block'; }
      });

      head.appendChild(copy);
      head.appendChild(hide);

      list = document.createElement('div');
      list.style.cssText = 'padding:8px 10px;overflow:auto;white-space:pre-wrap;word-break:break-word';

      panel.appendChild(head);
      panel.appendChild(list);
      document.body.appendChild(panel);

      chip = document.createElement('button');
      chip.type = 'button';
      chip.textContent = 'debug';
      chip.style.cssText = 'display:none;position:fixed;inset-block-end:8px;inset-inline-start:8px;z-index:2147483000;' +
        'border:0;border-radius:999px;padding:7px 12px;background:#20465c;color:#fff;font:12px/1 ui-monospace,monospace;cursor:pointer';
      chip.addEventListener('click', function () {
        chip.style.display = 'none';
        panel.style.display = 'flex';
      });
      document.body.appendChild(chip);
    }

    list.textContent = lines.slice(-160).join('\n');
    list.scrollTop = list.scrollHeight;
  }

  function add(kind, message, data) {
    var line = stamp() + ' [' + kind + '] ' + message;
    if (data !== undefined) {
      try { line += ' :: ' + (typeof data === 'string' ? data : JSON.stringify(data)); }
      catch (error) { line += ' :: [unserialisable]'; }
    }
    lines.push(line);
    if (lines.length > MAX) { lines.shift(); }
    try { window.localStorage.setItem('niva_debug_log', lines.slice(-150).join('\n')); } catch (error) { /* ignore */ }
    try { window.console.log('[niva-dbg]', kind + ': ' + message, data === undefined ? '' : data); } catch (error) { /* ignore */ }
    paint();
  }

  window.NIVA_DEBUG = {
    on: on,
    add: add,
    note: function (message, data) { add('note', message, data); },
    step: function (message, data) { add('step', message, data); },
    api: function (message, data) { add('api', message, data); },
    edit: function (message, data) { add('edit', message, data); },
    dump: dump,
    clear: function () { lines = []; try { window.localStorage.removeItem('niva_debug_log'); } catch (error) { /* ignore */ } paint(); }
  };

  window.addEventListener('error', function (event) {
    add('error', (event.message || 'unknown') + ' @ ' + String(event.filename || '').split('/').pop() + ':' + (event.lineno || 0));
  });

  window.addEventListener('unhandledrejection', function (event) {
    add('promise', event.reason && event.reason.message ? event.reason.message : String(event.reason));
  });

  ['warn', 'error'].forEach(function (level) {
    var original = console[level];
    if (typeof original !== 'function') { return; }
    console[level] = function () {
      var text = Array.prototype.slice.call(arguments).map(function (item) {
        if (item && item.message) { return item.message; }
        return typeof item === 'string' ? item : '';
      }).join(' ');
      if (text.indexOf('[niva-dbg]') !== 0) { add('console.' + level, text); }
      return original.apply(console, arguments);
    };
  });

  document.addEventListener('niva:view-ready', function () {
    add('view', 'view ready', location.pathname + location.search);
  });

  document.addEventListener('click', function (event) {
    var link = event.target.closest ? event.target.closest('a[href*="niva_step="]') : null;
    if (link) { add('edit', 'edit link clicked (capture)', link.getAttribute('href')); }
  }, true);

  // load history, then announce that this build is live
  try {
    var stored = window.localStorage.getItem('niva_debug_log');
    if (stored) { lines = stored.split('\n').slice(-100); }
  } catch (error) { /* ignore */ }

  add('boot', 'logger v3.8.1 active (panel default ON, off with ?niva_debug=0)', { panel: on });
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', function () { add('boot', 'DOM ready'); paint(); });
  } else {
    paint();
  }
}());
