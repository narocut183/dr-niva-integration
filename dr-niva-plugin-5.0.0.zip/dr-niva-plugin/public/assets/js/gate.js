/* ==========================================================================
   Dr. Niva — locked-tool gate (2.0.0)
   The faded card stays visible; this script opens the upgrade sheet, records
   the click for the admin report, and keeps keyboard/AT users able to reach it.
   Without JS the card still shows a plain link to the plans page, so nobody is
   trapped behind a dead end.
   ========================================================================== */
(function () {
  'use strict';

  /* 3.0.1 — the screen can be replaced in place by the in-app router, so
     the initialiser runs again on every view change (bindings below are
     idempotent or attach to the freshly rendered nodes). */
  function ready(fn) {
    var run = function () { try { fn(); } catch (error) { if (window.console && console.warn) console.warn('[niva]', error); } };
    if (document.readyState !== 'loading') { run(); } else { document.addEventListener('DOMContentLoaded', run); }
    document.addEventListener('niva:view-ready', run);
    document.addEventListener('niva:view-changed', run);
  }
  function readyLegacy(fn) {
    if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
  }

  ready(function () {
    var gates = document.querySelectorAll('[data-niva-gate]');
    if (!gates.length) { return; }

    function closeAll() {
      document.querySelectorAll('.niva-gate__sheet.is-open').forEach(function (sheet) {
        sheet.classList.remove('is-open');
        sheet.hidden = true;
      });
    }

    function report(gate, moduleId) {
      var url = gate.getAttribute('data-niva-gate-log');
      var nonce = gate.getAttribute('data-niva-gate-nonce');
      if (!url) { return; }
      fetch(url, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
        body: JSON.stringify({ module: moduleId })
      })['catch'](function () { /* a failed signal must never block the user */ });
    }

    Array.prototype.forEach.call(gates, function (gate) {
      var sheetId = gate.getAttribute('data-niva-gate-sheet');
      var moduleId = gate.getAttribute('data-niva-gate-module');
      var sheet = document.getElementById(sheetId);

      // The whole faded card is clickable, except the real controls inside it.
      gate.addEventListener('click', function (event) {
        if (event.target.closest('a, button[data-niva-gate-close]')) { return; }
        var trigger = event.target.closest('[data-niva-gate-open]');
        if (!trigger && !event.target.closest('.niva-feature-locked')) { return; }
        if (!sheet) { return; }
        sheet.hidden = false;
        sheet.classList.add('is-open');
        report(gate, moduleId);
        var focusable = sheet.querySelector('a, button');
        if (focusable) { focusable.focus(); }
      });

      // Keyboard users reach the card as a link, and activation works the same.
      gate.setAttribute('role', 'link');
      gate.setAttribute('tabindex', '0');
      gate.setAttribute('aria-disabled', 'true');
      gate.addEventListener('keydown', function (event) {
        if (event.key !== 'Enter' && event.key !== ' ') { return; }
        event.preventDefault();
        if (!sheet) { return; }
        sheet.hidden = false;
        sheet.classList.add('is-open');
        report(gate, moduleId);
      });

      gate.querySelectorAll('[data-niva-gate-close]').forEach(function (button) {
        button.addEventListener('click', function (event) {
          event.preventDefault();
          closeAll();
          gate.focus();
        });
      });
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { closeAll(); }
    });
  });
}());
