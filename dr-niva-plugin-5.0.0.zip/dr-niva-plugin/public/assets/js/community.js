/* ==========================================================================
   Dr. Niva — community (2.0.1)
   Progressive enhancement only: the list is already rendered by PHP, so search,
   "load more", reactions, reporting and posting keep working without this file.

   2.0.1 fixes what made the forum feel broken:
     · posting answers in the page (modal + list update) instead of sending the
       user to the home page after a reload,
     · a comment appears where it was written instead of reloading the screen,
     · server answers that are not JSON produce a readable message.
   ========================================================================== */
(function () {
  'use strict';

  /* 3.0.1 — the screen can be replaced in place by the in-app router, so
     the initialiser runs again on every view change (bindings below are
     idempotent or attach to the freshly rendered nodes). */
  function ready(fn) {
    var run = function () { try { fn(); } catch (error) { if (window.console && console.warn) console.warn('[niva]', error); } };
    if (document.readyState !== 'loading') { run(); } else { document.addEventListener('DOMContentLoaded', run); }
    document.addEventListener('niva:view-ready', run);
    document.addEventListener('niva:view-changed', run);
  }
  function readyLegacy(fn) {
    if (document.readyState !== 'loading') { fn(); } else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function faDigits(value) {
    var fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
    return String(value).replace(/\d/g, function (d) { return fa[+d]; });
  }

  function esc(text) {
    var node = document.createElement('span');
    node.textContent = text === undefined || text === null ? '' : String(text);
    return node.innerHTML;
  }

  function toast(text) {
    if (typeof window.NIVA_TOAST === 'function') { window.NIVA_TOAST(text); }
  }

  function api(base, nonce, path, payload) {
    var url = base + path;
    if (typeof window.NIVA_FETCH === 'object' && window.NIVA_FETCH) {
      return window.NIVA_FETCH.json(url, {
        method: 'POST',
        headers: nonce ? { 'X-WP-Nonce': nonce } : {},
        body: payload || {}
      });
    }
    return fetch(url, {
      method: 'POST',
      credentials: 'same-origin',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': nonce },
      body: JSON.stringify(payload || {})
    }).then(function (response) {
      return response.text().then(function (text) {
        var data = null;
        try { data = text ? JSON.parse(text) : null; } catch (error) { data = null; }
        if (!response.ok || data === null) {
          throw new Error(data && data.message ? data.message : 'ارتباط برقرار نشد؛ دوباره تلاش کن.');
        }
        return data;
      });
    });
  }

  function card(thread) {
    return '<article class="community-card">' +
      '<a class="community-card__title" href="' + esc(thread.url) + '">' + esc(thread.title) + '</a>' +
      (thread.is_pinned ? '<span class="community-badge">سنجاق‌شده</span>' : '') +
      (thread.is_featured ? '<span class="community-badge community-badge--info">ویژه</span>' : '') +
      '<p class="community-card__excerpt">' + esc(thread.excerpt) + '</p>' +
      '<div class="community-card__meta">' +
        '<span class="community-card__author">' + esc(thread.author_name) + '</span>' +
        '<span class="community-card__dot">·</span>' +
        '<span>' + esc(thread.time_ago) + '</span>' +
        (thread.category_title ? '<span class="community-chip community-chip--' + esc(thread.category_color) + '">' + esc(thread.category_title) + '</span>' : '') +
        '<span class="community-card__count">' + faDigits(thread.comment_count) + ' پاسخ</span>' +
        (thread.answered
          ? '<span class="community-badge community-badge--ok">پاسخ داده شد</span>'
          : '<span class="community-badge">در انتظار پاسخ</span>') +
      '</div></article>';
  }

  function commentNode(comment) {
    var wrap = document.createElement('article');
    wrap.className = 'community-comment community-comment--fresh';
    wrap.setAttribute('data-niva-comment', String(comment.id || ''));
    wrap.innerHTML =
      '<div class="community-comment__head">' +
        '<span class="community-card__author">' + esc(comment.author_name || 'شما') + '</span>' +
        '<span class="community-card__dot">·</span>' +
        '<span>' + esc(comment.time_ago || 'همین حالا') + '</span>' +
        (comment.pending ? '<span class="community-badge">در انتظار بازبینی</span>' : '') +
      '</div>' +
      '<div class="community-comment__body">' + esc(comment.body || '') + '</div>';
    return wrap;
  }

  ready(function () {
    var host = document.querySelector('[data-niva-community]');
    if (!host) { return; }
    var base = host.getAttribute('data-niva-community');
    var nonce = host.getAttribute('data-niva-nonce');
    var list = document.querySelector('[data-niva-community-list]');
    var message = document.querySelector('[data-niva-community-message]');

    function say(text, ok) {
      if (ok) { toast(text); }
      if (!message) { if (!ok && text) { window.alert(text); } return; }
      message.hidden = false;
      message.textContent = text;
    }

    function loadMoreUrl(extra) {
      var more = document.querySelector('[data-niva-community-more]');
      var url = base + 'threads?per_page=10';
      if (more) {
        url += '&sort=' + encodeURIComponent(more.getAttribute('data-sort') || 'newest');
        url += '&anchor=' + encodeURIComponent(more.getAttribute('data-anchor') || '');
        url += '&category=' + encodeURIComponent(more.getAttribute('data-category') || '');
      }
      return url + (extra || '');
    }

    /* ------------------------------------------------------------- search */
    var search = document.querySelector('[data-niva-community-search]');
    if (search && list) {
      var timer = null;
      search.addEventListener('input', function () {
        window.clearTimeout(timer);
        timer = window.setTimeout(function () {
          fetch(loadMoreUrl('&s=' + encodeURIComponent(search.value)), { credentials: 'same-origin' })
            .then(function (r) { return r.json(); })
            .then(function (json) {
              var items = json.items || [];
              if (!items.length) {
                list.innerHTML = '<div class="empty-state"><strong>چیزی پیدا نشد</strong><span>عبارت دیگری را امتحان کن.</span></div>';
                return;
              }
              list.innerHTML = items.map(card).join('');
            })
            .catch(function () { say('جست‌وجو انجام نشد؛ دوباره تلاش کن.'); });
        }, 300);
      });
    }

    /* ---------------------------------------------------------- load more */
    var more = document.querySelector('[data-niva-community-more]');
    if (more && list) {
      more.addEventListener('click', function () {
        var page = parseInt(more.getAttribute('data-page'), 10) + 1;
        var pages = parseInt(more.getAttribute('data-pages'), 10);
        var searchValue = more.getAttribute('data-search') || '';
        more.disabled = true;
        fetch(loadMoreUrl('&paged=' + page + '&s=' + encodeURIComponent(searchValue)), { credentials: 'same-origin' })
          .then(function (r) { return r.json(); })
          .then(function (json) {
            (json.items || []).forEach(function (thread) {
              list.insertAdjacentHTML('beforeend', card(thread));
            });
            more.setAttribute('data-page', String(page));
            more.disabled = false;
            if (page >= pages) { more.remove(); }
          })
          .catch(function () { more.disabled = false; say('بارگذاری نشد؛ دوباره تلاش کن.'); });
      });
    }

    /* ------------------------------------------------------- reactions */
    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-community-react]'), function (button) {
      if (button.__avaReact) { return; }
      button.__avaReact = true;
      button.addEventListener('click', function () {
        /*
         * 3.1.0 — the like used to appear only after the round trip, so a slow
         * connection felt broken. It flips at once and rolls back on failure.
         */
        var id = button.getAttribute('data-niva-community-react');
        var type = button.getAttribute('data-object-type') || 'thread';
        var counter = button.querySelector('[data-niva-community-likes]');
        var wasActive = button.classList.contains('is-active');
        var wasCount = counter ? (parseInt(String(counter.textContent).replace(/[^0-9۰-۹]/g, '').replace(/[۰-۹]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d); }), 10) || 0) : 0;

        button.classList.toggle('is-active', !wasActive);
        button.setAttribute('aria-pressed', wasActive ? 'false' : 'true');
        if (counter) { counter.textContent = faDigits(wasActive ? Math.max(0, wasCount - 1) : wasCount + 1); }

        api(base, nonce, 'react', { id: id, object_type: type, type: 'like' })
          .then(function (json) {
            button.classList.toggle('is-active', !!json.added);
            button.setAttribute('aria-pressed', json.added ? 'true' : 'false');
            if (counter) { counter.textContent = faDigits(json.count); }
          })
          .catch(function (error) {
            button.classList.toggle('is-active', wasActive);
            button.setAttribute('aria-pressed', wasActive ? 'true' : 'false');
            if (counter) { counter.textContent = faDigits(wasCount); }
            say(error.message);
          });
      });
    });

    /* ---------------------------------------------------------- reports */
    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-community-report]'), function (button) {
      button.addEventListener('click', function () {
        var reason = window.prompt('کوتاه بنویس چرا این مورد را گزارش می‌کنی؟');
        if (!reason) { return; }
        api(base, nonce, 'report', {
          id: button.getAttribute('data-niva-community-report'),
          object_type: button.getAttribute('data-object-type') || 'thread',
          reason: reason
        }).then(function () { say('گزارش ثبت شد؛ بررسی می‌کنیم.', true); })
          .catch(function (error) { say(error.message); });
      });
    });

    /* ------------------------------------------------------------ reply */
    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-community-reply]'), function (button) {
      button.addEventListener('click', function () {
        var form = document.querySelector('[data-niva-community-comment]');
        if (!form) { return; }
        var parent = form.querySelector('[name="parent_id"]');
        if (parent) { parent.value = button.getAttribute('data-niva-community-reply'); }
        form.scrollIntoView({ behavior: 'smooth', block: 'center' });
        var textarea = form.querySelector('[name="body"]');
        if (textarea) { textarea.focus(); }
      });
    });

    /* ------------------------------------------------- comment submit
       The answer is appended where it was written; the screen does not
       reload and the reader does not lose their place.                     */
    var commentForm = document.querySelector('[data-niva-community-comment]');
    if (commentForm) {
      commentForm.addEventListener('submit', function (event) {
        event.preventDefault();
        var body = commentForm.querySelector('[name="body"]');
        var parent = commentForm.querySelector('[name="parent_id"]');
        var submit = commentForm.querySelector('[type="submit"]');
        if (submit) { submit.disabled = true; }
        api(base, nonce, 'comment', {
          thread_id: host.getAttribute('data-niva-thread'),
          body: body ? body.value : '',
          parent_id: parent ? parent.value : 0
        }).then(function (json) {
          var target = document.querySelector('[data-niva-community-comments]') || commentForm.parentNode;
          var comment = json && json.comment ? json.comment : { body: body ? body.value : '' };
          target.appendChild(commentNode(comment));
          if (body) { body.value = ''; }
          if (parent) { parent.value = '0'; }
          if (submit) { submit.disabled = false; }
          var pending = json && json.pending
            ? 'پاسخ ثبت شد؛ بعد از بازبینی کوتاه نمایش داده می‌شود.'
            : 'پاسخ ثبت شد.';
          say(pending, true);
        }).catch(function (error) {
          if (submit) { submit.disabled = false; }
          say(error.message);
        });
      });
    }

    /* -------------------------------------------------- thread creation
       Used by the in-page modal (the form is already in the markup).        */
    Array.prototype.forEach.call(document.querySelectorAll('[data-niva-community-create]'), function (createForm) {
      if (createForm.getAttribute('data-niva-bound') === '1') { return; }
      createForm.setAttribute('data-niva-bound', '1');
      createForm.addEventListener('submit', function (event) {
        event.preventDefault();
        var submit = createForm.querySelector('[type="submit"]');
        var data = {
          title: (createForm.querySelector('[name="title"]') || {}).value || '',
          body: (createForm.querySelector('[name="body"]') || {}).value || '',
          category_id: (createForm.querySelector('[name="category_id"]') || {}).value || ''
        };
        if (submit) { submit.disabled = true; }
        api(base, nonce, 'create', data).then(function (json) {
          if (submit) { submit.disabled = false; }
          if (typeof window.NIVA_MODAL === 'object' && window.NIVA_MODAL) {
            window.NIVA_MODAL.close(createForm.closest('.niva-modal'));
          }
          createForm.reset();
          var thread = json && json.thread ? json.thread : null;
          if (thread && list) {
            var empty = list.querySelector('.empty-state');
            if (empty) { empty.parentNode.removeChild(empty); }
            list.insertAdjacentHTML('afterbegin', card(thread));
            if (thread.url && json.status === 'publish') {
              document.dispatchEvent(new CustomEvent('niva:community-thread-created', { detail: thread }));
            }
          }
          say(json && json.message ? json.message : 'پرسش ثبت شد.', true);
        }).catch(function (error) {
          if (submit) { submit.disabled = false; }
          var target = createForm.querySelector('[data-niva-community-message]') || message;
          if (target) { target.hidden = false; target.textContent = error.message; }
          else { window.alert(error.message); }
        });
      });
    });
  });
}());
