/* ==========================================================================
   Dr. Niva — WordPress bridge (v1)
   Loads one screen at a time inside the plugin shell, applies the module
   layout chosen in the admin, gates screens behind login, and keeps the
   credit bar in sync with the server.
   ========================================================================== */
(function () {
  'use strict';

  var CFG = window.NIVA_CONFIG || null;
  if (!CFG) return;

  var appShell = document.querySelector('#niva-app, .niva-shell');
  var shell = appShell ? appShell.querySelector('[data-niva-view]') : document.querySelector('[data-niva-view]');
  var viewCache = {};
  var viewRequests = {};
  var viewLoadSequence = 0;
  var viewNames = {
    home: 'home', advisor: 'advisor', lab: 'analyze', cycle: 'cycle',
    pregnancy: 'pregnancy', baby: 'baby', mind: 'mind', reminders: 'alarms',
    plans: 'plans', wallet: 'wallet', tools: 'tools', family: 'family',
    partners: 'partners', messages: 'tools', profile: 'profile', about: 'about'
  };

  /*
   * 3.0.2 — a screen may need its own query args (?id= for a thread). They were
   * dropped when the view was fetched, so the in-app swap rendered the
   * «این گفتگو پیدا نشد» state right after the thread had opened.
   */
  function viewArgs() {
    var skip = { niva_view: 1, dr_niva_route: 1, modal: 1, _wpnonce: 1 };
    var out = [];
    try {
      new URLSearchParams(location.search).forEach(function (value, key) {
        if (!skip[key] && value) {
          out.push(encodeURIComponent(key) + '=' + encodeURIComponent(value));
        }
      });
    } catch (error) { /* no URLSearchParams: fall back to no args */ }
    return out.join('&');
  }

  function viewKey(view) {
    var args = viewArgs();
    return args ? view + '?' + args : view;
  }

  function fa(input) {
    return String(input).replace(/[0-9]/g, function (d) { return '۰۱۲۳۴۵۶۷۸۹'[Number(d)]; });
  }

  /* ------------------------------------------------------------ theme chrome */

  function hideThemeChrome() {
    if (!CFG.hideThemeChrome) return;
    document.body.classList.add('niva-app-mode');
    var style = document.createElement('style');
    style.textContent =
      '.niva-app-mode #masthead, .niva-app-mode .site-header, .niva-app-mode header.wp-block-template-part,' +
      '.niva-app-mode #colophon, .niva-app-mode .site-footer, .niva-app-mode footer.wp-block-template-part,' +
      '.niva-app-mode .entry-header, .niva-app-mode .page-header, .niva-app-mode .woocommerce-breadcrumb { display: none !important; }' +
      '.niva-app-mode .entry-content, .niva-app-mode .site-content, .niva-app-mode .wp-site-blocks { padding: 0 !important; margin: 0 !important; max-width: none !important; }';
    document.head.appendChild(style);
  }

  /* ------------------------------------------------------------------ layout */

  function moduleOf(node) {
    return node.getAttribute('data-module');
  }

  function applyLayout(root) {
    var modules = CFG.modules || [];
    var order = {};
    modules.forEach(function (module) {
      order[module.id] = module;
    });

    // 1) switch off anything disabled
    root.querySelectorAll('[data-module]').forEach(function (node) {
      var module = order[moduleOf(node)];
      if (module && module.enabled === false) node.remove();
    });

    // 2) reorder the direct children of a flow container
    root.querySelectorAll('[data-niva-flow]').forEach(function (flow) {
      var children = Array.prototype.slice.call(flow.children);
      children.sort(function (a, b) {
        var oa = order[moduleOf(a)] ? order[moduleOf(a)].order : 999;
        var ob = order[moduleOf(b)] ? order[moduleOf(b)].order : 999;
        return oa - ob;
      });
      children.forEach(function (child) { flow.appendChild(child); });
    });
  }

  /* --------------------------------------------------------------- gating */

  function isLoggedIn() {
    return !!(CFG.user && (
      CFG.user.logged_in === true ||
      CFG.user.logged_in === 1 ||
      CFG.user.logged_in === '1' ||
      Number(CFG.user.id) > 0
    ));
  }

  function gate(root, view) {
    var gated = CFG.gated || [];
    var loggedIn = isLoggedIn();
    if (loggedIn) return root;
    if (gated.indexOf(view) === -1) return root;

    var lock = document.createElement('div');
    lock.className = 'niva-lock-card';
    lock.innerHTML =
      '<div class="card" style="text-align:center">' +
        '<h2>برای استفاده از این بخش وارد شو</h2>' +
        '<p class="muted">با یک شماره موبایل ثبت‌نام می‌کنی و سهمیه‌ی رایگان روزانه‌ات فعال می‌شود.</p>' +
        '<a class="btn btn--primary" href="' + (CFG.strings && CFG.strings.login_url ? CFG.strings.login_url : '/wp-login.php') + '">ورود / ثبت‌نام</a>' +
      '</div>';
    // only the screen content is replaced — the app header, dock and footer stay
    var panel = root.querySelector('.app-main') || root;
    panel.innerHTML = '';
    panel.appendChild(lock);
    return root;
  }

  /* ------------------------------------------------------------ credit bar */

  function paintCredits(summary) {
    if (!summary) return;
    var bar = document.querySelector('[data-niva-credits]');
    if (!bar) return;
    var balance = bar.querySelector('[data-niva-balance]');
    var quota = bar.querySelector('[data-niva-quota]');
    var spent = bar.querySelector('.niva-credits__item:nth-child(2) bdi');
    if (balance) balance.textContent = new String(summary.balance);
    if (quota) quota.textContent = new String(summary.quota_left);
    if (spent) spent.textContent = new String(summary.spent_total);
    bar.classList.toggle('niva-credits--low', !!summary.low);
  }

  /* ------------------------------------------------------------ view loader */

  function rewriteLinks(root) {
    root.querySelectorAll('a[href]').forEach(function (anchor) {
      var match = anchor.getAttribute('href').match(/^([a-z0-9-]+)\.html(#[^?]*)?$/i);
      if (!match) return;
      var name = match[1].toLowerCase();
      if ('index' === name) name = 'home';
      var linkKey = Object.keys(viewNames).filter(function (key) { return viewNames[key] === name; })[0] || name;
      var target = CFG.links && CFG.links[linkKey];
      if (!target) {
        var base = new URL((CFG.plugin && CFG.plugin.home) || '/', window.location.href);
        base.pathname = base.pathname.replace(/\/?$/, '/') + encodeURIComponent(name) + '/';
        target = base.href;
      }
      anchor.setAttribute('href', target + (match[2] || ''));
    });
  }

  function load(view) {
    if (!shell) return;
    var requestId = ++viewLoadSequence;
    if (viewCache[viewKey(view)]) {
      activateView(view, viewCache[viewKey(view)]);
      return;
    }
    shell.setAttribute('aria-busy', 'true');
    requestView(view).then(function (payload) {
      if (requestId !== viewLoadSequence) return;
      activateView(view, payload.html);
    }).catch(function (error) {
      if (requestId !== viewLoadSequence) return;
      shell.removeAttribute('aria-busy');
      console.error('Dr. Niva view failed to load:', error);
      shell.innerHTML = '<div class="container" style="padding-block:32px"><div class="alert alert--caution" role="alert"><div class="alert__body"><span class="alert__title">این بخش بارگذاری نشد</span><div class="alert__text">اتصال را بررسی کن و دوباره تلاش کن. اگر وارد حساب هستی، صفحه را یک‌بار تازه‌سازی کن تا نشست ورود به‌روز شود.</div><button type="button" class="btn btn--secondary btn--sm" data-view-retry>تلاش دوباره</button></div></div></div>';
      var retry = shell.querySelector('[data-view-retry]');
      if (retry) retry.addEventListener('click', function () { load(view); });
    });
  }

  function requestView(view) {
    var key = viewKey(view);
    if (viewCache[key]) return Promise.resolve({ html: viewCache[key] });
    if (viewRequests[key]) return viewRequests[key];
    var args = viewArgs();
    var url = CFG.plugin.rest + '/view?name=' + encodeURIComponent(view) + (args ? '&' + args : '');
    viewRequests[view] = fetch(url, { credentials: 'same-origin', cache: 'no-store', headers: { 'X-WP-Nonce': CFG.plugin.nonce } })
      .then(function (response) {
        return response.json().then(function (payload) {
          if (!response.ok) throw new Error(payload && payload.message ? payload.message : 'صفحه دریافت نشد.');
          return payload;
        });
      })
      .then(function (payload) {
        if (!payload || !payload.html) throw new Error('empty view');
        viewCache[key] = payload.html;
        return payload;
      }).then(function (payload) {
        delete viewRequests[view];
        return payload;
      }, function (error) {
        delete viewRequests[view];
        throw error;
      });
    return viewRequests[view];
  }

  function viewForUrl(url) {
      function normalize(name) {
        for (var key in viewNames) {
          if (Object.prototype.hasOwnProperty.call(viewNames, key) && (key === name || viewNames[key] === name)) return viewNames[key];
        }
        return null;
      }
      var queryView = url.searchParams.get('niva_view');
      if (queryView) return normalize(queryView);
      var route = url.pathname.match(/\/dr-niva\/([a-z0-9-]+)\/?$/i);
      if (route) return normalize(route[1].toLowerCase());
      var cleanRoute = url.pathname.match(/\/([a-z0-9-]+)\/?$/i);
      if (cleanRoute) {
        var cleanView = normalize(cleanRoute[1].toLowerCase());
        if (cleanView) return cleanView;
      }
      var links = CFG.links || {};
      for (var key in links) {
        if (!Object.prototype.hasOwnProperty.call(links, key) || !viewNames[key]) continue;
        try {
          var target = new URL(links[key], window.location.href);
          if (target.origin === url.origin && target.pathname.replace(/\/+$/, '/') === url.pathname.replace(/\/+$/, '/') &&
              target.search === url.search) return viewNames[key];
        } catch (error) {
          continue;
        }
      }
      return null;
  }

  function bindAppNavigation() {
      if (!shell || document.__avaNavigationBound) return;
      document.__avaNavigationBound = true;
      document.addEventListener('click', function (event) {
        if (event.defaultPrevented || event.button !== 0 || event.metaKey || event.ctrlKey || event.shiftKey || event.altKey) return;
        var anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
        if (!anchor || anchor.target || anchor.hasAttribute('download')) return;
        var target;
        try {
          target = new URL(anchor.href, window.location.href);
        } catch (error) {
          return;
        }
        if (target.origin !== window.location.origin) return;
        var view = viewForUrl(target);
        if (!view) return;
        event.preventDefault();
        if (target.href !== window.location.href) window.history.pushState({ avaView: view }, '', target.href);
        appShell.setAttribute('data-view', view);
        load(view);
      });
      document.addEventListener('pointerover', prefetchLink, { passive: true });
      document.addEventListener('focusin', prefetchLink);
      window.addEventListener('popstate', function () {
        var view = viewForUrl(new URL(window.location.href));
        if (!view) return;
        appShell.setAttribute('data-view', view);
        load(view);
      });
  }

  function prefetchLink(event) {
      var anchor = event.target instanceof Element ? event.target.closest('a[href]') : null;
      if (!anchor) return;
      var target;
      try {
        target = new URL(anchor.href, window.location.href);
      } catch (error) {
        return;
      }
      if (target.origin !== window.location.origin) return;
      var view = viewForUrl(target);
      if (!view || viewCache[viewKey(view)] || !CFG.plugin.rest) return;
      requestView(view).catch(function () { return; });
  }

  function refreshStaleSession() {
    if (!CFG.user || isLoggedIn() || !CFG.plugin.rest) return Promise.resolve(false);
    return fetch(CFG.plugin.rest + '/me', {
      credentials: 'same-origin',
      cache: 'no-store',
      headers: { Accept: 'application/json' }
    }).then(function (response) {
      if (!response.ok) throw new Error('وضعیت ورود بررسی نشد.');
      return response.json();
    }).then(function (payload) {
      if (!payload || !payload.user || !payload.user.logged_in || Number(payload.user.id) < 1) return;
      CFG.user = payload.user;
      CFG.plugin = payload.plugin || CFG.plugin;
      CFG.wallet = payload.wallet || CFG.wallet;
      if (CFG.wallet) paintCredits(CFG.wallet);
      return true;
    }).catch(function (error) {
      console.warn('Dr. Niva session refresh failed:', error);
      return false;
    });
  }

  function activateView(view, html) {
    if (!shell) return;
    if (typeof html === 'string') shell.innerHTML = html;
    applyLayout(shell);
    gate(shell, view);
    if (typeof window.NIVA_BOOT === 'function') window.NIVA_BOOT();
    rewriteLinks(shell);
    shell.removeAttribute('aria-busy');
    shell.dataset.renderedView = view;
    document.dispatchEvent(new CustomEvent('niva:view-ready', { detail: { view: view } }));
  }

  /* -------------------------------------------------- Elementor editor hook */

  /**
   * In the Elementor editor a widget is re-rendered every time it is edited, so
   * the app's bindings must run again for that widget only.
   */
  function bindElementorEditor() {
    if (!window.jQuery || !window.elementorFrontend) return;
    window.jQuery(window).on('elementor/frontend/init', function () {
      if (!window.elementorFrontend || !window.elementorFrontend.hooks) return;
      window.elementorFrontend.hooks.addAction('frontend/element_ready/widget', function ($scope) {
        if (!($scope && $scope.find && $scope.find('.niva-module').length)) return;
        if (typeof window.NIVA_BOOT === 'function') window.NIVA_BOOT();
      });
    });
  }

  /* ------------------------------------------------------- Web Push (real) */

  function base64ToBytes(base64) {
    var padding = '='.repeat((4 - (base64.length % 4)) % 4);
    var raw = window.atob((base64 + padding).replace(/-/g, '+').replace(/_/g, '/'));
    var bytes = new Uint8Array(raw.length);
    for (var i = 0; i < raw.length; i += 1) bytes[i] = raw.charCodeAt(i);
    return bytes;
  }

  function enablePushSubscription() {
    var P = window.NIVA_PUSH;
    if (!P || !P.enabled || !P.publicKey) return Promise.reject(new Error('ارسال پوش هنوز در تنظیمات سایت راه‌اندازی نشده است.'));
    if (!window.isSecureContext || !('serviceWorker' in navigator) || !('PushManager' in window) || !window.Notification) {
      return Promise.reject(new Error('این مرورگر یا اتصال امن، پوشِ پس‌زمینه را پشتیبانی نمی‌کند.'));
    }
    if ('granted' !== Notification.permission) return Promise.reject(new Error('اجازهٔ اعلان مرورگر فعال نیست.'));
    return navigator.serviceWorker.register(P.sw).then(function (registration) {
      return registration.pushManager.getSubscription().then(function (existing) {
        return existing || registration.pushManager.subscribe({
          userVisibleOnly: true,
          applicationServerKey: base64ToBytes(P.publicKey)
        });
      });
    }).then(function (subscription) {
      return fetch(P.endpoint, {
        method: 'POST',
        credentials: 'same-origin',
        headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': P.nonce },
        body: JSON.stringify(subscription.toJSON())
      }).then(function (response) {
        if (!response.ok) throw new Error('ثبت پوش در سرور انجام نشد؛ دوباره تلاش کن.');
        return response;
      });
    });
  }

  window.NIVA_ENABLE_PUSH = enablePushSubscription;

  /**
   * Registers the service worker and stores a real push subscription for the
   * signed-in user. The in-app notification from app.js keeps working when the
   * browser cannot do push, so nothing breaks on older devices.
   */
  function initPushSubscription() {
    var P = window.NIVA_PUSH;
    var button = document.querySelector('[data-notify-permission]');
    if (!button) return;
    var status = document.querySelector('[data-notify-status]');
    if (!P || !P.enabled || !P.publicKey) {
      if (status) status.textContent = 'وضعیت: اعلان داخل صفحه فعال است؛ ارسال پوشِ پس‌زمینه هنوز در تنظیمات سایت راه‌اندازی نشده است.';
      return;
    }
    if (!window.isSecureContext || !('serviceWorker' in navigator) || !('PushManager' in window) || !window.Notification) {
      if (status) status.textContent = 'وضعیت: این مرورگر یا اتصال امن، پوشِ پس‌زمینه را پشتیبانی نمی‌کند.';
      return;
    }
    if (button.__avaPushBound) return;
    button.__avaPushBound = true;

    button.addEventListener('click', function () {
      button.disabled = true;
      if (status) status.textContent = 'وضعیت: در حال فعال‌کردن پوش…';
      var permission = 'denied' === Notification.permission
        ? Promise.reject(new Error('اجازهٔ اعلان مسدود است؛ ابتدا آن را از تنظیمات مرورگر برای این سایت مجاز کن.'))
        : ('granted' === Notification.permission ? Promise.resolve('granted') : Notification.requestPermission());
      permission.then(function (result) {
        if ('granted' !== result) throw new Error('اجازهٔ اعلان داده نشد؛ از تنظیمات مرورگر اجازه بده.');
        return enablePushSubscription();
      }).then(function () {
        if (status) status.textContent = P.senderReady
          ? 'وضعیت: پوش برای این دستگاه فعال شد.'
          : 'وضعیت: این دستگاه ثبت شد، اما فرستندهٔ Web Push روی سایت تنظیم نشده؛ اعلان‌ها فعلاً در صندوق سایت می‌مانند.';
      }).catch(function (error) {
        if (status) status.textContent = 'وضعیت: ' + (error.message || 'فعال‌سازی پوش انجام نشد.');
      }).then(function () {
        button.disabled = false;
      });
    }, true);
  }

  /* ------------------------------------------------------------ user profile */

  function jalaliToGregorian(value) {
    var digits = String(value || '').replace(/[۰-۹٠-٩]/g, function (digit) {
      var persian = '۰۱۲۳۴۵۶۷۸۹'.indexOf(digit);
      return String(persian === -1 ? '٠١٢٣٤٥٦٧٨٩'.indexOf(digit) : persian);
    });
    if (!digits.trim()) return '';
    var match = digits.trim().match(/^(\d{4})[./-](\d{1,2})[./-](\d{1,2})$/);
    if (!match) return null;
    var target = [Number(match[1]), Number(match[2]), Number(match[3])];
    if (target[0] < 1200 || target[0] > 1600 || target[1] < 1 || target[1] > 12 || target[2] < 1 || target[2] > 31) return null;

    var formatter;
    try {
      formatter = new Intl.DateTimeFormat('en-u-ca-persian-nu-latn', {
        year: 'numeric', month: 'numeric', day: 'numeric', timeZone: 'UTC'
      });
    } catch (error) {
      return null;
    }
    function jalaliParts(timestamp) {
      var parts = {};
      formatter.formatToParts(new Date(timestamp)).forEach(function (part) {
        if (part.type !== 'literal') parts[part.type] = Number(part.value);
      });
      return [parts.year, parts.month, parts.day];
    }
    function ordinal(parts) {
      return parts[0] * 10000 + parts[1] * 100 + parts[2];
    }
    var wanted = ordinal(target);
    var start = Date.UTC(target[0] + 621, 0, 1);
    var end = Date.UTC(target[0] + 623, 0, 1);
    var low = Math.floor(start / 86400000);
    var high = Math.floor(end / 86400000);
    while (low < high) {
      var middle = Math.floor((low + high) / 2);
      if (ordinal(jalaliParts(middle * 86400000)) < wanted) low = middle + 1;
      else high = middle;
    }
    var found = new Date(low * 86400000);
    if (ordinal(jalaliParts(found.getTime())) !== wanted) return null;
    return found.getUTCFullYear() + '-' +
      String(found.getUTCMonth() + 1).padStart(2, '0') + '-' +
      String(found.getUTCDate()).padStart(2, '0');
  }

  window.NIVA_JALALI_TO_GREGORIAN = jalaliToGregorian;

  function bindProfile() {
    var form = document.querySelector('[data-profile-form]');
    if (!form) return;
    // boot() runs again when a view is injected: never bind the same form twice.
    if (form.__avaProfileBound) return;
    form.__avaProfileBound = true;
    var message = document.querySelector('[data-profile-message]');

    // Avatar upload: goes through the same validated onboarding endpoint, then
    // stores only the attachment id in the form, so the ordinary save keeps it.
    var avatarPick = form.querySelector('#pf-avatar-pick');
    var avatarFile = form.querySelector('#pf-avatar-file');
    var avatarId = form.querySelector('#pf-avatar-id');
    var avatarPreview = form.querySelector('#pf-avatar-preview');
    if (avatarPick && avatarFile) {
      avatarPick.addEventListener('click', function () { avatarFile.click(); });
      avatarFile.addEventListener('change', function () {
        if (!avatarFile.files || !avatarFile.files[0]) return;
        var body = new FormData();
        body.append('file', avatarFile.files[0]);
        if (message) { message.hidden = false; message.textContent = 'در حال بارگذاری عکس…'; }
        fetch(NIVA.rest + 'onboarding/avatar', {
          method: 'POST',
          credentials: 'same-origin',
          headers: { 'X-WP-Nonce': NIVA.nonce },
          body: body
        }).then(function (response) {
          return response.json().then(function (json) {
            if (!response.ok) { throw new Error(json && json.message ? json.message : 'آپلود نشد.'); }
            return json;
          });
        }).then(function (json) {
          if (avatarId && json.id) avatarId.value = json.id;
          if (avatarPreview && json.url) avatarPreview.style.backgroundImage = 'url("' + json.url + '")';
          if (message) message.textContent = 'عکس انتخاب شد؛ با «ذخیرهٔ تنظیمات» ثبت می‌شود.';
        })['catch'](function (error) {
          if (message) message.textContent = error.message;
        });
      });
    }

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var dateInputs = form.querySelectorAll('[data-jalali-date]');
      for (var i = 0; i < dateInputs.length; i += 1) {
        var dateInput = dateInputs[i];
        var gregorian = jalaliToGregorian(dateInput.value);
        if (null === gregorian) {
          if (message) { message.hidden = false; message.textContent = 'تاریخ را به‌شکل شمسی سال/ماه/روز وارد کن؛ نمونه: ۱۴۰۵/۰۱/۰۱.'; }
          dateInput.focus();
          return;
        }
        var storedDate = form.querySelector('#' + dateInput.getAttribute('data-jalali-date'));
        if (storedDate) storedDate.value = gregorian;
      }
      var val = function (id) { var node = document.querySelector(id); return node ? node.value : ''; };
      var on = function (id) { var node = document.querySelector(id); return node && node.checked ? 1 : 0; };

      var payload = {
        first_name: val('#pf-first-name'),
        last_name: val('#pf-last-name'),
        avatar_id: val('#pf-avatar-id'),
        display_name: val('#pf-display-name'),
        sex: val('#pf-sex'),
        birth_year: val('#pf-birth-year'),
        height: val('#pf-height'),
        weight: val('#pf-weight'),
        pregnant: on('#pf-pregnant'),
        lmp: val('#pf-lmp'),
        cycle_length: val('#pf-cycle-length'),
        period_length: val('#pf-period-length'),
        due_date: val('#pf-due'),
        baby_name: val('#pf-baby-name'),
        baby_birth: val('#pf-baby-birth'),
        channels: { inapp: on('#pf-ch-inapp'), push: on('#pf-ch-push'), email: on('#pf-ch-email') },
        quiet_from: val('#pf-quiet-from'),
        quiet_to: val('#pf-quiet-to'),
        theme: val('#pf-theme'),
        font_scale: val('#pf-font')
      };

      if (message) { message.hidden = false; message.textContent = 'در حال ذخیره…'; }
      api('/profile', payload).then(function () {
        if (message) message.textContent = 'ذخیره شد — پیام روزانه‌ات بر همین پایه انتخاب می‌شود.';
        // Saved in place — no reload, so the page never blinks.
        if (message) message.textContent = 'ذخیره شد.';
      })['catch'](function (error) {
        if (message) message.textContent = error.message;
      });
    });

    var remove = document.querySelector('[data-profile-delete]');
    if (remove) {
      remove.addEventListener('click', function () {
        if (!window.confirm('همه‌ی سوابق سلامت حذف شود؟ این کار برگشت‌پذیر نیست.')) return;
        remove.disabled = true;
        api('/profile/delete', {}).then(function () {
          form.querySelectorAll('input, select, textarea').forEach(function (field) {
            if ('checkbox' === field.type || 'radio' === field.type) field.checked = false;
            else if ('submit' !== field.type && 'button' !== field.type) field.value = '';
          });
          if (message) { message.hidden = false; message.textContent = 'سوابق سلامت حذف شد.'; }
          document.dispatchEvent(new CustomEvent('niva:profile-cleared'));
        }).catch(function (error) {
          if (message) { message.hidden = false; message.textContent = error.message || 'حذف اطلاعات انجام نشد.'; }
        }).then(function () {
          remove.disabled = false;
        });
      });
    }
  }

  document.addEventListener('niva:profile-content-ready', function () {
    bindProfile();
    bindPartnerForm();
  });

  /* ------------------------------------------------------------ inbox state */

  function bindInbox() {
    var markAll = document.querySelector('[data-mark-all-read]');
    var status = document.querySelector('[data-inbox-message]');
    function showError(error) {
      if (status) status.textContent = error.message || 'اعلان‌ها به‌روزرسانی نشدند.';
    }
    if (markAll && !markAll.__avaInboxBound) {
      markAll.__avaInboxBound = true;
      markAll.addEventListener('click', function () {
        markAll.disabled = true;
        api('/notifications', { id: 0 }).then(function () {
          document.querySelectorAll('[data-mark-read]').forEach(function (button) {
            var row = button.closest('article');
            if (row) row.classList.add('is-read');
            button.remove();
          });
          markAll.remove();
        }).catch(showError).then(function () {
          if (document.contains(markAll)) markAll.disabled = false;
        });
      });
    }
    var buttons = document.querySelectorAll('[data-mark-read]');
    for (var i = 0; i < buttons.length; i += 1) {
      if (buttons[i].__avaInboxBound) continue;
      buttons[i].__avaInboxBound = true;
      buttons[i].addEventListener('click', function () {
        var button = this;
        button.disabled = true;
        api('/notifications', { id: button.getAttribute('data-mark-read') }).then(function () {
          var row = button.closest('article');
          if (row) row.classList.add('is-read');
          button.remove();
        }).catch(function (error) {
          showError(error);
          if (document.contains(button)) button.disabled = false;
        });
      });
    }
  }

  /* ---------------------------------------------------------- chat history */

  /* --------------------------------------------------------------- partners */

  function bindPartnerForm() {
    var form = document.querySelector('[data-partner-form]');
    if (!form || form.__avaPartnerBound) return;
    form.__avaPartnerBound = true;
    var message = document.querySelector('[data-partner-message]');

    form.addEventListener('submit', function (event) {
      event.preventDefault();
      var value = function (id) { var node = document.querySelector(id); return node ? node.value.trim() : ''; };
      var payload = {
        name: value('#partner-name'),
        type: value('#partner-type'),
        phone: value('#partner-phone'),
        email: value('#partner-email'),
        city: value('#partner-city'),
        note: value('#partner-note')
      };
      if (!payload.name || (!payload.phone && !payload.email)) {
        if (message) { message.hidden = false; message.textContent = 'نام و یک راه ارتباطی (تلفن یا ایمیل) را وارد کن.'; }
        return;
      }
      if (message) { message.hidden = false; message.textContent = 'در حال ارسال…'; }
      api('/partners/apply', payload).then(function (data) {
        if (message) { message.hidden = false; message.textContent = 'درخواستت ثبت شد. کد پیگیری: ' + data.code; }
        form.reset();
      })['catch'](function (error) {
        if (message) { message.hidden = false; message.textContent = error.message; }
      });
    });
  }

  /* ------------------------------------------------------------- family plan */

  function api(path, payload) {
    if (!CFG || !CFG.plugin || !CFG.plugin.rest) return Promise.reject(new Error('no rest'));
    return fetch(CFG.plugin.rest + path, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'X-WP-Nonce': CFG.plugin.nonce },
      body: JSON.stringify(payload || {})
    }).then(function (response) {
      return response.json().then(function (data) {
        if (!response.ok) throw new Error((data && data.message) || 'خطا در ارتباط با سرور');
        return data;
      });
    });
  }

  function bindFamily() {
    var form = document.querySelector('[data-family-accept-form]');
    var message = document.querySelector('[data-family-message]');

    if (form) {
      if (form.__avaFamilyBound) return;
      form.__avaFamilyBound = true;
      form.addEventListener('submit', function (event) {
        event.preventDefault();
        var input = document.querySelector('#family-code');
        var code = input ? input.value.trim() : '';
        if (!code) return;
        if (message) { message.hidden = false; message.textContent = 'در حال بررسی…'; }
        api('/family/accept', { code: code }).then(function () {
          if (message) message.textContent = 'عضویت ثبت شد و از این پس امکانات اشتراک در حسابت فعال است.';
          form.reset();
        })['catch'](function (error) {
          if (message) { message.hidden = false; message.textContent = error.message; }
        });
      });
    }

    var buttons = document.querySelectorAll('[data-family-remove]');
    for (var i = 0; i < buttons.length; i += 1) {
      if (buttons[i].__avaFamilyBound) continue;
      buttons[i].__avaFamilyBound = true;
      buttons[i].addEventListener('click', function () {
        var memberId = this.getAttribute('data-family-remove');
        if (!window.confirm('این عضو از اشتراک خانوادگی حذف شود؟')) return;
        var button = this;
        button.disabled = true;
        api('/family/remove', { member_id: memberId }).then(function () {
          var row = button.closest('.plain-row, li, tr');
          if (row) row.remove();
        }).catch(function (error) {
          if (message) { message.hidden = false; message.textContent = error.message || 'عضو حذف نشد.'; }
          button.disabled = false;
        });
      });
    }
  }

  /* --------------------------------------------------------- mobile app push */

  /**
   * Registers the device token that the Android/iOS wrapper exposes through
   * window.AvaApp. Nothing happens on a plain browser, so the same build works
   * on the site, in the webview and in the app.
   */
  function initAppPush() {
    if (!CFG || !CFG.user || !CFG.user.logged_in) return;
    var bridge = window.AvaApp || window.AvaBridge;
    if (!bridge) return;

    var token = typeof bridge.getPushToken === 'function' ? bridge.getPushToken() : bridge.pushToken;
    if (!token) return;

    api('/app/push/register', {
      token: token,
      platform: (bridge.platform || 'android'),
      app_version: (bridge.version || '')
    })['catch'](function () { /* the token is retried on the next launch */ });
  }

  /* ------------------------------------------------------------------- boot */

  /** Which screen to open: the shortcode attribute first, then ?niva_view=, then home. */
  function requestedView() {
    var fromShell = appShell ? appShell.getAttribute('data-view') : '';
    if (fromShell) return fromShell;
    var fromQuery = (location.search.match(/[?&]niva_view=([a-z0-9\-]+)/i) || [])[1];
    if (fromQuery) return viewNames[fromQuery.toLowerCase()] || fromQuery.toLowerCase();
    var route = location.pathname.match(/\/dr-niva\/([a-z0-9-]+)\/?$/i);
    if (route) return viewNames[route[1].toLowerCase()] || route[1].toLowerCase();
    return 'home';
  }

  function boot() {
    bindElementorEditor();
    initAppPush();
    bindFamily();
    bindPartnerForm();
    bindProfile();
    bindInbox();
    initPushSubscription();
    hideThemeChrome();
    if (CFG.wallet) paintCredits(CFG.wallet);
    if (shell) {
      var view = requestedView();
      bindAppNavigation();
      var checkSessionFirst = (CFG.gated || []).indexOf(view) !== -1 && !isLoggedIn();
      if (checkSessionFirst) {
        shell.setAttribute('aria-busy', 'true');
        refreshStaleSession().then(function (sessionRefreshed) {
          if (sessionRefreshed) {
            delete viewCache[viewKey(view)];
            load(view);
          } else if (shell.dataset.renderedView === view && shell.querySelector('[data-niva-view]')) {
            activateView(view);
          } else {
            load(view);
          }
        });
      } else if (shell.dataset.renderedView === view && shell.querySelector('[data-niva-view]')) {
        viewCache[viewKey(view)] = shell.innerHTML;
        activateView(view);
      } else {
        load(view);
      }
    }
  }

  document.addEventListener('niva:view-ready', function () {
    bindFamily();
    bindPartnerForm();
    bindProfile();
    bindInbox();
    initPushSubscription();
  });
  document.addEventListener('niva:refresh-view', function () {
    delete viewCache[viewKey(requestedView())];
    load(requestedView());
  });

  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', boot);
  else boot();
})();
