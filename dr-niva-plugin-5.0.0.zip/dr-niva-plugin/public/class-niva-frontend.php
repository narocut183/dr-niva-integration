<?php
/**
 * Front-end shell: shortcodes, asset loading, config injection, view serving.
 *
 * The app screens live in public/pages/*.html; they are served through a REST
 * route (sanitised and link-rewritten) so the same Markup file works both as a
 * standalone static site and inside WordPress.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Frontend {

	/** Set as soon as the app shell is actually printed on this request. */
	public static $rendered = false;

	/** The heavy config payload is assembled once, no matter how many modules render. */
	private static $config_sent = false;

	/** @var Niva_Settings */
	private $settings;

	/** @var Niva_Layout */
	private $layout;

	/** @var Niva_Wallet */
	private $wallet;

	/** Which screens exist and which file renders them. */
	private const VIEWS = array(
		'home'      => 'index.html',
		'advisor'   => 'advisor.html',
		'tools'     => 'tools.html',
		'alarms'    => 'alarms.html',
		'analyze'   => 'analyze.html',
		'cycle'     => 'cycle.html',
		'pregnancy' => 'pregnancy.html',
		'baby'      => 'baby.html',
		'mind'      => 'mind.html',
		'plans'     => 'plans.html',
		'partners'  => 'partners.html',
		'about'     => 'about.html',
		'notifications' => 'notifications.html',
		'profile'   => 'index.html',
		'wallet'    => 'plans.html',
		'family'    => 'plans.html',
		// 2.0.1 — the screens added in 2.0.0 were missing here, so any request
		// for them silently fell back to «home» (the home page content showing
		// on top of every new page). They are composed from their modules.
		'community'        => 'index.html',
		'community_thread' => 'index.html',
		'community_new'    => 'index.html',
		'companion_create' => 'index.html',
		'companion_view'   => 'index.html',
		'onboarding'       => 'index.html',
		'404'       => '404.html',
	);

	public function __construct( Niva_Settings $settings, Niva_Layout $layout, Niva_Wallet $wallet ) {
		$this->settings = $settings;
		$this->layout   = $layout;
		$this->wallet   = $wallet;

		add_shortcode( 'dr_niva_app', array( $this, 'shortcode_app' ) );
		add_shortcode( 'dr_niva_credits_bar', array( $this, 'shortcode_credits_bar' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'register_assets' ) );
		add_action( 'rest_api_init', array( $this, 'view_route' ) );
		add_action( 'init', array( $this, 'register_service_worker_route' ) );
		add_filter( 'query_vars', array( $this, 'service_worker_query_var' ) );
		add_filter( 'request', array( $this, 'resolve_app_route' ) );
		add_filter( 'redirect_canonical', array( $this, 'preserve_app_route' ), 10, 2 );
		add_action( 'template_redirect', array( $this, 'redirect_legacy_app_route' ), 1 );
		add_action( 'save_post_page', array( $this, 'clear_app_shell_page_cache' ) );
		add_action( 'deleted_post', array( $this, 'clear_app_shell_page_cache' ) );
		add_action( 'template_redirect', array( $this, 'serve_service_worker' ) );
		add_action( 'wp_footer', array( $this, 'print_onboarding' ), 99 );
	}

	/** The welcome sheet rides along with the shell, on every app page. */
	public function print_onboarding() : void {
		// The sheet belongs to the app pages only — and the flag is reliable even
		// when the stylesheet handle order changes.
		if ( ! self::$rendered ) {
			return;
		}
		if ( ! Niva_Chrome::needs_onboarding() ) {
			return;
		}
		echo Niva_Chrome::onboarding_modal(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- local markup
	}

	/** Assets are only printed when a shortcode is actually used. */
	public function register_assets() : void {
		wp_register_style( 'dr-niva-base', DR_NIVA_URL . 'public/assets/css/base.css', array(), DR_NIVA_VERSION );
		wp_register_style( 'dr-niva-components', DR_NIVA_URL . 'public/assets/css/components.css', array( 'dr-niva-base' ), DR_NIVA_VERSION );
		wp_register_style( 'dr-niva-pages', DR_NIVA_URL . 'public/assets/css/pages.css', array( 'dr-niva-components' ), DR_NIVA_VERSION );

		/*
		 * 5.0.0 — the app design system. Registered last and depended upon by
		 * nothing, so it is printed after every other sheet and refines the
		 * whole product without any screen depending on it to render.
		 */
		wp_register_style( 'dr-niva-app', DR_NIVA_URL . 'public/assets/css/niva-app.css', array( 'dr-niva-pages' ), DR_NIVA_VERSION );

		// Onboarding is only enqueued by the wizard / completion-card partials.
		wp_register_style( 'dr-niva-onboarding', DR_NIVA_URL . 'public/assets/css/onboarding.css', array( 'dr-niva-base' ), DR_NIVA_VERSION );
		wp_register_script( 'dr-niva-onboarding', DR_NIVA_URL . 'public/assets/js/onboarding.js', array( 'dr-niva-icons', 'dr-niva-router' ), DR_NIVA_VERSION, true );

		wp_register_script( 'dr-niva-icons', DR_NIVA_URL . 'public/assets/js/icons.js', array(), DR_NIVA_VERSION, true );
		wp_register_script( 'dr-niva-app', DR_NIVA_URL . 'public/assets/js/app.js', array( 'dr-niva-icons' ), DR_NIVA_VERSION, true );
		wp_register_script( 'dr-niva-bridge', DR_NIVA_URL . 'public/assets/js/wp-bridge.js', array( 'dr-niva-app' ), DR_NIVA_VERSION, true );
		// 2.0.1 — modals and instant screen switching.
		wp_register_style( 'dr-niva-onboarding', DR_NIVA_URL . 'public/assets/css/onboarding.css', array( 'dr-niva-base' ), DR_NIVA_VERSION );
		wp_register_script( 'dr-niva-router', DR_NIVA_URL . 'public/assets/js/niva-router.js', array( 'dr-niva-bridge' ), DR_NIVA_VERSION, true );
		// TEMPORARY debug log (remove with its enqueue below).
		wp_register_script( 'dr-niva-debug', DR_NIVA_URL . 'public/assets/js/niva-debug.js', array(), DR_NIVA_VERSION, true );
		// Edits happen in place, never through the questionnaire.
		wp_register_script( 'dr-niva-profile-edit', DR_NIVA_URL . 'public/assets/js/profile-edit.js', array( 'dr-niva-router' ), DR_NIVA_VERSION, true );

		// The three brand colours from the settings, expanded into design tokens.
		wp_add_inline_style( 'dr-niva-pages', Niva_Chrome::brand_css() );
		if ( dr_niva()->settings->is_on( 'theme_harmonize' ) ) {
			wp_add_inline_style( 'dr-niva-pages', Niva_Chrome::theme_css() );
		}
	}

	/** The service worker must be served from the site root to control the whole site. */
	public function serve_service_worker() : void {
		if ( ! get_query_var( 'dr_niva_sw' ) ) {
			return;
		}
		$file = DR_NIVA_PATH . 'public/sw.js';
		if ( ! file_exists( $file ) ) {
			status_header( 404 );
			exit;
		}
		if ( ! headers_sent() ) {
			if ( ! headers_sent() ) {
				nocache_headers();
			}
		}
		header( 'Content-Type: application/javascript; charset=utf-8' );
		header( 'Service-Worker-Allowed: /' );
		readfile( $file ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	public function register_service_worker_route() : void {
		add_rewrite_rule( '^dr-niva-sw\.js$', 'index.php?dr_niva_sw=1', 'top' );
		add_rewrite_rule( '^dr-niva/([a-z0-9-]+)/?$', 'index.php?niva_view=$matches[1]&dr_niva_route=1', 'top' );
		$routes = array();
		foreach ( Niva_Links::registry() as $entry ) {
			$route = sanitize_key( (string) $entry[2] );
			if ( '' === $route || 'home' === $route || get_page_by_path( $route ) instanceof WP_Post ) {
				continue;
			}
			$routes[ $route ] = $route;
		}
		foreach ( $routes as $route ) {
			add_rewrite_rule(
				'^' . preg_quote( $route, '#' ) . '/?$',
				'index.php?niva_view=' . $route . '&dr_niva_route=1',
				'top'
			);
		}
		if ( get_option( 'dr_niva_rewrite_version' ) !== DR_NIVA_VERSION ) {
			flush_rewrite_rules( false );
			update_option( 'dr_niva_rewrite_version', DR_NIVA_VERSION, false );
		}
	}

	/** Redirect known old app-router paths without touching REST, assets, or other paths. */
	public function redirect_legacy_app_route() : void {
		$path = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_PATH ); // phpcs:ignore
		if ( ! preg_match( '#/dr-niva/([a-z0-9-]+)/?$#i', $path, $match ) ) {
			return;
		}
		$legacy_path = '/dr-niva/' . sanitize_key( $match[1] ) . '/';
		$legacy      = Niva_Links::normalize_legacy_router_url( home_url( $legacy_path ) );
		if ( $legacy === home_url( $legacy_path ) ) {
			return;
		}
		$query = (string) wp_parse_url( isset( $_SERVER['REQUEST_URI'] ) ? wp_unslash( $_SERVER['REQUEST_URI'] ) : '', PHP_URL_QUERY ); // phpcs:ignore
		if ( '' !== $query ) {
			$legacy .= '?' . $query;
		}
		wp_safe_redirect( $legacy, 301 );
		exit;
	}

	public function service_worker_query_var( $vars ) {
		$vars[] = 'dr_niva_sw';
		$vars[] = 'niva_view';
		$vars[] = 'dr_niva_route';
		return $vars;
	}

	/** Resolve clean app URLs to a published page that actually contains the app shell. */
	public function resolve_app_route( array $query_vars ) : array {
		if ( empty( $query_vars['dr_niva_route'] ) ) {
			return $query_vars;
		}
		/*
		 * 2.0.1 — the route must load its own page.
		 *
		 * This used to fall back to the site's front page, which is why a clean
		 * app URL rendered the home screen at the top with the requested page
		 * underneath it. Now: the page whose slug matches the route wins; if
		 * there is none the shell page renders the view; if there is no shell
		 * page either, WordPress is left alone (404) instead of showing home.
		 */
		$route = isset( $query_vars['niva_view'] ) ? sanitize_key( (string) $query_vars['niva_view'] ) : '';
		if ( '' !== $route ) {
			$page = get_page_by_path( $route );
			if ( $page instanceof WP_Post && 'publish' === $page->post_status ) {
				$query_vars['page_id'] = (string) $page->ID;
				return $query_vars;
			}
		}

		$page_id = self::app_shell_page_id();
		if ( $page_id ) {
			$query_vars['page_id'] = (string) $page_id;
		}
		return $query_vars;
	}

	/** Prevent WordPress from canonicalizing a clean app view back to the home page. */
	public function preserve_app_route( $redirect_url, string $requested_url ) {
		return get_query_var( 'dr_niva_route' ) ? false : $redirect_url;
	}

	/**
	 * Every app page as `permalink => view`, handed to the Javascript router so
	 * a click swaps the screen in place (no reload, no trip to the home page).
	 *
	 * @return array<string,string>
	 */
	public static function app_pages() : array {
		$registry = Niva_Links::registry();
		$aliases  = Niva_Links::aliases();
		$out      = array();
		foreach ( Niva_Links::page_map() as $key => $url ) {
			$key  = (string) $key;
			$view = '';
			if ( isset( $registry[ $key ] ) ) {
				$view = (string) $registry[ $key ][2];
			} elseif ( isset( $aliases[ $key ], $registry[ $aliases[ $key ] ] ) ) {
				$view = (string) $registry[ $aliases[ $key ] ][2];
			} else {
				$view = $key;
			}
			if ( '' === $view || ! isset( self::VIEWS[ $view ] ) ) {
				continue;
			}
			$out[ untrailingslashit( (string) $url ) ] = $view;
		}
		return $out;
	}

	public function clear_app_shell_page_cache( $post_id = 0 ) : void {
		delete_transient( 'dr_niva_app_shell_page' );
	}

	private static function app_shell_page_id() : int {
		$cached = get_transient( 'dr_niva_app_shell_page' );
		if ( is_array( $cached ) && isset( $cached['id'] ) ) {
			return absint( $cached['id'] );
		}

		$page_id = 0;
		$pages   = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => 'publish',
				'posts_per_page'   => -1,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'suppress_filters' => true,
			)
		);
		foreach ( $pages as $page ) {
			$elementor_data = (string) get_post_meta( $page->ID, '_elementor_data', true );
			if ( has_shortcode( $page->post_content, 'dr_niva_app' ) || false !== strpos( $elementor_data, '[dr_niva_app' ) ) {
				$page_id = (int) $page->ID;
				break;
			}
		}
		set_transient( 'dr_niva_app_shell_page', array( 'id' => $page_id ), DAY_IN_SECONDS );
		return $page_id;
	}

	public function enqueue() : void {
		self::$rendered = true;

		/*
		 * Every module shortcode calls enqueue(). On a page with dozens of modules
		 * that rebuilt the whole config payload dozens of times; build it once.
		 */
		if ( self::$config_sent ) {
			return;
		}
		self::$config_sent = true;

		wp_enqueue_style( 'dr-niva-base' );
		wp_enqueue_style( 'dr-niva-components' );
		wp_enqueue_style( 'dr-niva-pages' );
		wp_enqueue_script( 'dr-niva-icons' );
		wp_enqueue_script( 'dr-niva-app' );
		wp_enqueue_script( 'dr-niva-bridge' );
		wp_enqueue_script( 'dr-niva-router' );
		wp_enqueue_script( 'dr-niva-debug' );
		wp_enqueue_script( 'dr-niva-profile-edit' );
		// 5.0.0 — the app design system, enqueued last so it owns the final look.
		// The 3.1.0 overlay (ui-2026.css) is superseded by it: keeping both would
		// leave two competing `.niva-shell` layers on the page.
		wp_enqueue_style( 'dr-niva-app' );

		/*
		 * 3.0.1 — every screen an in-app link can reach must already be styled and
		 * scripted. These handles used to be enqueued only while their own module
		 * rendered, so a view switched in place appeared broken until a reload.
		 */
		foreach ( array( 'dr-niva-community', 'dr-niva-companion', 'dr-niva-onboarding' ) as $niva_view_style ) {
			if ( wp_style_is( $niva_view_style, 'registered' ) ) {
				wp_enqueue_style( $niva_view_style );
			}
		}
		foreach ( array( 'dr-niva-chrome', 'dr-niva-community', 'dr-niva-companion', 'dr-niva-onboarding' ) as $niva_view_script ) {
			if ( wp_script_is( $niva_view_script, 'registered' ) ) {
				wp_enqueue_script( $niva_view_script );
			}
		}

		/*
		 * Everything below is a best-effort enrichment of the page config. If one
		 * of these reads throws, the page must still render: a missing wallet row
		 * or a slow query used to take the whole shortcode output down with it,
		 * which is why the page sometimes showed no modules and no Javascript.
		 */
		try {
			$payload = ( new Niva_Rest() )->me()->get_data();
		} catch ( \Throwable $e ) {
			$payload = array();
		}
		$payload = wp_parse_args(
			(array) $payload,
			array(
				'plugin'    => array( 'version' => DR_NIVA_VERSION, 'numeral' => 'fa' ),
				'user'      => array(),
				'providers' => array(),
				'safety'    => array(),
				'costs'     => array(),
				'strings'   => array(),
				'links'     => array(),
				'chat_quota' => null,
			)
		);
		$current_user_id = get_current_user_id();

		wp_localize_script(
			'dr-niva-bridge',
			'NIVA_CONFIG',
			array(
				'plugin'    => $payload['plugin'],
				'user'      => array(
					'id'        => $current_user_id,
					'logged_in' => $current_user_id > 0,
					'name'      => $current_user_id ? wp_get_current_user()->display_name : '',
				),
				'modules'   => $this->layout ? $this->layout->config() : array(),
				'providers' => isset( $payload['providers'] ) ? $payload['providers'] : array(),
				'safety'    => isset( $payload['safety'] ) ? $payload['safety'] : array(),
				'costs'     => isset( $payload['costs'] ) ? $payload['costs'] : array(),
				'strings'   => isset( $payload['strings'] ) ? $payload['strings'] : array(),
				'wallet'    => $this->wallet_snapshot(),
				'chatQuota' => isset( $payload['chat_quota'] ) ? $payload['chat_quota'] : null,
				'links'     => isset( $payload['links'] ) ? $payload['links'] : array(),
				'menu'      => Niva_Chrome::menu_data(),
				// url => view, so a click inside the app swaps the screen in
				// place instead of loading a whole new page.
				'pages'     => self::app_pages(),
				'views'     => array_keys( self::VIEWS ),
				'notifications' => isset( $payload['notifications'] ) ? $payload['notifications'] : array( 'unread' => 0 ),
				'homeView'  => $this->view_url( 'home' ),
				'hideThemeChrome' => ! $this->settings->is_on( 'viewer_use_theme_header' ),
				'rest'      => esc_url_raw( rest_url( 'niva/v1' ) ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'gated'     => array( 'advisor', 'lab', 'cycle', 'pregnancy', 'baby', 'mind', 'reminders' ),
			)
		);
	}

	/**
	 * The wallet snapshot for the page config, or null.
	 *
	 * Never throws: a page must not fail because one profile read did.
	 */
	private function wallet_snapshot() {
		if ( ! is_user_logged_in() ) {
			return null;
		}
		try {
			return $this->wallet->summary( get_current_user_id() );
		} catch ( \Throwable $e ) {
			return null;
		}
	}

	/**
	 * [dr_niva_app view="home"]
	 */
	public function shortcode_app( $atts = array() ) : string {
		if ( ! $this->settings->is_on( 'enabled' ) ) {
			return '';
		}
		if ( is_user_logged_in() ) {
			// App pages contain user-specific state and a REST nonce; never let
			// page caches serve one member's session/configuration to another.
			if ( ! defined( 'DONOTCACHEPAGE' ) ) {
				define( 'DONOTCACHEPAGE', true );
			}
			nocache_headers();
		}
		$this->enqueue();

		$atts = shortcode_atts( array( 'view' => 'home' ), $atts, 'dr_niva_app' );
		$view = sanitize_key( $atts['view'] );
		// Explicit router links win; otherwise a page slug selects its matching app screen.
		if ( isset( $_GET['niva_view'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$view = sanitize_key( wp_unslash( $_GET['niva_view'] ) ); // phpcs:ignore
		} elseif ( get_query_var( 'niva_view' ) ) {
			$view = sanitize_key( (string) get_query_var( 'niva_view' ) );
		} elseif ( 'home' === $view ) {
			$post = get_post();
			$view = $post instanceof WP_Post ? $this->view_for_page( $post ) : 'home';
		}
		$view = array(
			'index'     => 'home',
			'lab'       => 'analyze',
			'reminders' => 'alarms',
			'messages'  => 'tools',
		)[ $view ] ?? $view;
		if ( ! isset( self::VIEWS[ $view ] ) ) {
			$view = 'home';
		}

		ob_start();
		?>
		<?php
		$view_request = new WP_REST_Request( 'GET', '/' . Niva_Rest::NS . '/view' );
		$view_request->set_param( 'name', $view );
		$view_response = $this->serve_view( $view_request );
		$view_data     = $view_response->get_data();
		$initial_html  = isset( $view_data['html'] ) ? (string) $view_data['html'] : '';
		?>
		<div class="niva-shell" id="niva-app" data-view="<?php echo esc_attr( $view ); ?>" data-rendered-view="<?php echo esc_attr( $view ); ?>">
			<?php if ( 'home' === $view ) : ?>
				<?php echo $this->credits_bar_html(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<?php endif; ?>
			<div class="niva-view" data-niva-view aria-live="polite"><?php
				// serve_view sanitizes static templates and composes private modules for the current session.
				echo $initial_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			?></div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	private function view_for_page( WP_Post $post ) : string {
		$raw_slug = strtolower( rawurldecode( $post->post_name ) );
		$slug     = sanitize_key( $raw_slug );
		if ( isset( self::VIEWS[ $slug ] ) ) {
			return $slug;
		}
		if ( 'index' === $raw_slug ) {
			return 'home';
		}

		$current_path = untrailingslashit( (string) wp_parse_url( get_permalink( $post ), PHP_URL_PATH ) );
		foreach ( Niva_Links::registry() as $key => $link ) {
			foreach ( $link[1] as $candidate ) {
				$candidate_key = sanitize_key( $candidate );
				if ( $raw_slug === strtolower( rawurldecode( $candidate ) ) || ( '' !== $candidate_key && $slug === $candidate_key ) ) {
					return $link[2];
				}
			}
			$override = trim( (string) $this->settings->get( 'link_' . $key ) );
			if ( '' === $override ) {
				continue;
			}
			$target = Niva_Compat::starts_with( $override, 'http' )
				? $override
				: home_url( '/' . ltrim( $override, '/' ) );
			$target_path = untrailingslashit( (string) wp_parse_url( $target, PHP_URL_PATH ) );
			if ( '' !== $current_path && $current_path === $target_path ) {
				return $link[2];
			}
		}
		return 'home';
	}

	/** [dr_niva_credits_bar] — usable in any theme position. */
	public function shortcode_credits_bar() : string {
		$this->enqueue();
		return $this->credits_bar_html();
	}

	public function credits_bar_html() : string {
		if ( ! $this->settings->is_on( 'credits_enabled' ) || ! $this->layout->is_enabled( 'wallet_bar' ) ) {
			return '';
		}
		if ( ! is_user_logged_in() ) {
			return '<div class="niva-credits"><span>برای شروع، وارد شو</span>'
				. '<a class="btn btn--primary btn--sm" href="' . esc_url( wp_login_url( $this->view_url( 'home' ) ) ) . '">ورود / ثبت‌نام</a></div>';
		}
		$user_id = (int) get_current_user_id();
		$summary = $this->wallet->summary( $user_id );

		/*
		 * 2.0.0 — the three spend layers are labelled and shown in the order they
		 * are consumed, so the user always knows which bucket is next. The plan
		 * layer only appears when the active plan actually grants one.
		 */
		$plan_label = '';
		$plan_expiry = '';
		if ( ! empty( $summary['plan'] ) && 'free' !== $summary['plan'] && function_exists( 'dr_niva' ) && dr_niva()->plans ) {
			$plan_label  = (string) dr_niva()->plans->label( (string) $summary['plan'] );
			$plan_info   = dr_niva()->plans->plan_of( $user_id );
			$plan_expiry = ! empty( $plan_info['expires'] ) ? Niva_Chrome::format_datetime_gmt( (string) $plan_info['expires'] ) : '';
		}
		$notice = isset( $summary['expiry_notice'] ) && is_array( $summary['expiry_notice'] ) ? $summary['expiry_notice'] : array();

		ob_start();
		?>
		<div class="niva-credits<?php echo ! empty( $summary['low'] ) ? ' niva-credits--low' : ''; ?><?php echo ! empty( $summary['announce_wallet'] ) ? ' niva-credits--notice' : ''; ?>" data-niva-credits>
			<span class="niva-credits__item" title="لایهٔ اول: هر روز خودش پر می‌شود">
				۱. سهمیهٔ امروز: <bdi data-niva-quota><?php echo esc_html( Niva_Chrome::digits( (string) $summary['quota_left'] ) ); ?></bdi>
				از <bdi><?php echo esc_html( Niva_Chrome::digits( (string) $summary['quota_limit'] ) ); ?></bdi>
			</span>
			<?php if ( (int) $summary['plan_limit'] > 0 ) : ?>
				<span class="niva-credits__item" title="لایهٔ دوم: سهمیهٔ ماهانهٔ پلن">
					۲. سهمیهٔ پلن: <bdi data-niva-plan-quota><?php echo esc_html( Niva_Chrome::digits( (string) $summary['plan_left'] ) ); ?></bdi>
					از <bdi><?php echo esc_html( Niva_Chrome::digits( (string) $summary['plan_limit'] ) ); ?></bdi>
				</span>
			<?php endif; ?>
			<span class="niva-credits__item" title="لایهٔ آخر: فقط با تأیید خودت کم می‌شود">
				۳. اعتبار کیف پول: <bdi data-niva-balance><?php echo esc_html( number_format_i18n( (int) $summary['balance'] ) ); ?></bdi>
			</span>
			<?php if ( '' !== $plan_label ) : ?>
				<span class="niva-credits__item">
					پلن: <?php echo esc_html( $plan_label ); ?><?php echo '' !== $plan_expiry ? ' تا ' . esc_html( $plan_expiry ) : ''; ?>
				</span>
			<?php endif; ?>
			<a class="btn btn--primary btn--sm" href="<?php echo esc_url( $this->packages_url() ); ?>">شارژ اعتبار</a>
		</div>
		<?php if ( ! empty( $summary['announce_wallet'] ) ) : ?>
			<div class="niva-credits__announce" role="status">
				سهمیهٔ امروزت تمام شد؛ از این به بعد از اعتبار کیف پولت کم می‌شود
				(<?php echo esc_html( number_format_i18n( (int) $summary['balance'] ) ); ?> اعتبار داری).
			</div>
		<?php endif; ?>
		<?php if ( ! empty( $notice['message'] ) ) : ?>
			<div class="niva-credits__notice" role="status">
				<?php echo esc_html( (string) $notice['message'] ); ?>
				<?php if ( ! empty( $notice['renew_url'] ) ) : ?>
					<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( (string) $notice['renew_url'] ); ?>">تمدید</a>
				<?php endif; ?>
			</div>
		<?php endif; ?>
		<?php
		return (string) ob_get_clean();
	}

	/** Where "شارژ اعتبار" should point: the WC shop or the packages section. */
	private function packages_url() : string {
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			return (string) wc_get_page_permalink( 'shop' );
		}
		return $this->view_url( 'plans' );
	}

	public function view_url( string $view ) : string {
		$link_keys = array(
			'home' => 'home', 'advisor' => 'advisor', 'analyze' => 'lab', 'cycle' => 'cycle',
			'pregnancy' => 'pregnancy', 'baby' => 'baby', 'mind' => 'mind', 'alarms' => 'reminders',
			'plans' => 'plans', 'wallet' => 'wallet', 'tools' => 'tools', 'family' => 'family',
			'partners' => 'partners', 'about' => 'about', 'profile' => 'profile',
		);
		if ( isset( $link_keys[ $view ] ) && function_exists( 'dr_niva' ) && dr_niva()->links ) {
			return dr_niva()->links->url( $link_keys[ $view ] );
		}
		return Niva_Links::router_url( $view );
	}

	public function view_route() : void {
		register_rest_route(
			Niva_Rest::NS,
			'/view',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'serve_view' ),
				'permission_callback' => '__return_true',
				'args'                => array(
					'name' => array( 'required' => true, 'sanitize_callback' => 'sanitize_key' ),
				),
			)
		);
	}

	/** Returns the sanitised body of one screen. */
	public function serve_view( WP_REST_Request $request ) : WP_REST_Response {
		$name = sanitize_key( (string) $request->get_param( 'name' ) );
		if ( ! isset( self::VIEWS[ $name ] ) ) {
			$name = '404';
		}

		$composed = $this->composed_view( $name );
		if ( null !== $composed ) {
			$response = new WP_REST_Response(
				array(
					'module' => $name,
					'html'   => '<div id="site-header"></div>' . $composed . '<div id="site-footer"></div>',
				),
				200
			);
			$response->header( 'Cache-Control', 'no-store, private, max-age=0' );
			return $response;
		}

		$file = DR_NIVA_PATH . 'public/pages/' . self::VIEWS[ $name ];
		if ( ! file_exists( $file ) ) {
			return new WP_REST_Response( array( 'html' => '', 'module' => $name ), 404 );
		}

		$raw = (string) file_get_contents( $file ); // phpcs:ignore

		// Keep the <main> element itself: its class is the content container the
		// app and the layout gate rely on, and data-module carries the module id.
		$body = $raw;
		if ( preg_match( '/<main\b([^>]*)>(.*?)<\/main>/is', $raw, $matches ) ) {
			$body = '<main' . $matches[1] . '>' . $matches[2] . '</main>';
		}

		// never ship scripts from a template file
		$body = preg_replace( '#<script\b[^>]*>.*?</script>#is', '', $body );
		$body = preg_replace( '#<noscript\b[^>]*>.*?</noscript>#is', '', $body );

		// assets live inside the plugin now
		$body = str_replace( 'assets/', DR_NIVA_URL . 'public/assets/', $body );

		// internal links become view switches
		$body = preg_replace_callback(
			'/href="([a-z0-9\-]+)\.html"/i',
			function ( $m ) {
				return 'href="' . esc_url( $this->view_url( $m[1] ) ) . '"';
			},
			$body
		);

		// The app renders its own header/footer/dock into these two hosts,
		// so they must travel with every view.
		$body = '<div id="site-header"></div>' . $body . '<div id="site-footer"></div>';

		$response = new WP_REST_Response(
			array(
				'module' => $name,
				'html'   => $body,
			),
			200
		);
		$response->header( 'Cache-Control', 'no-store, private, max-age=0' );
		return $response;
	}

	/**
	 * Renders the account and data-driven screens from the same modules Elementor uses.
	 *
	 * @return string|null Null for the static marketing screens.
	 */
	private function composed_view( string $name ) : ?string {
		$views = array(
			// 5.0.0 — the dashboard follows the approved order: hero, live status,
			// the tool grid, then today's plan and the daily message.
			'home'    => array( '', array( 'home_head', 'home_status', 'quick_actions', 'today_plan', 'home_message', 'exercises', 'home_plan' ) ),
			'profile' => array( 'حساب کاربری', array( 'profile_hub' ) ),
			'baby'    => array( 'پروندهٔ کودک', array( 'baby_baby-profile', 'baby_baby-measure', 'baby_baby-history', 'baby_baby-reference', 'baby_baby-verdict', 'baby_checklist', 'baby_chart', 'baby_print' ) ),
			'wallet'  => array( '', array( 'wallet' ) ),
			'family'  => array( 'اشتراک خانوادگی', array( 'family_panel' ) ),
			'plans'   => array( 'اشتراک‌های ماهیانه', array( 'plans_table' ) ),
			'partners' => array( 'همکاری با دکتر نیوا', array( 'partners_plan', 'partners_join', 'partner_dashboard' ) ),
			'notifications' => array( 'اعلان‌های من', array( 'notifications_inbox' ) ),
			'alarms'  => array( 'یادآورها', array( 'reminders_notification', 'reminders_reminder-form', 'reminders_reminder-list' ) ),
			'analyze' => array( 'تحلیل هوشمند آزمایش', array( 'lab_upload', 'lab_values', 'lab_chart', 'lab_print' ) ),
			'mind'    => array( 'حال من', array( 'mind_mood', 'mind_breathing', 'mind_chat', 'mind_assessment', 'mind_thought-record', 'mind_crisis' ) ),
			'cycle'   => array( 'چرخهٔ بانوان', array( 'cycle_today', 'cycle_calendar', 'cycle_checklist', 'cycle_print' ) ),
			// 2.0.1 — screens that exist as modules but had no view.
			'community'        => array( '', array( 'community_home' ) ),
			'community_thread' => array( '', array( 'community_thread' ) ),
			'community_new'    => array( '', array( 'community_new' ) ),
			'companion_create' => array( '', array( 'companion_create' ) ),
			'companion_view'   => array( '', array( 'companion_view' ) ),
			'onboarding'       => array( '', array( 'onboarding_wizard' ) ),
		);

		if ( 'pregnancy' === $name ) {
			// 5.0.0 — the pregnancy screen now carries the whole journey:
			// this week, the counter, the checklist, the hospital bag and history.
			$views['pregnancy'] = array( 'مسیر بارداری', array( 'pregnancy_week', 'pregnancy_counter', 'pregnancy_checklist', 'pregnancy_bag', 'pregnancy_timeline', 'pregnancy_print' ) );
		}

		if ( ! isset( $views[ $name ] ) ) {
			return null;
		}

		list( $title, $modules ) = $views[ $name ];
		$content = '';
		foreach ( $modules as $module ) {
			$content .= Niva_Modules::render( $module );
		}
		return '<main id="main-content" class="app-main" data-module="' . esc_attr( $name ) . '"><div class="container">'
			. '<div class="stack--lg" data-niva-flow>' . $content . '</div></div></main>';
	}
}
