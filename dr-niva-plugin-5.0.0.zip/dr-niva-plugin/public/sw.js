/* Dr. Niva service worker — receives Web Push and opens the right screen. */
/* eslint-env serviceworker */

self.addEventListener('install', function (event) {
  self.skipWaiting();
});

self.addEventListener('activate', function (event) {
  event.waitUntil(self.clients.claim());
});

self.addEventListener('push', function (event) {
  var payload = { title: 'دکتر نیوا', body: 'یادآور تازه داری.', url: '/', badge: 1 };
  try {
    payload = Object.assign(payload, event.data.json());
  } catch (error) {
    if (event.data) payload.body = event.data.text();
  }

  var options = {
    body: payload.body,
    dir: 'rtl',
    lang: 'fa',
    badge: payload.badge ? './assets/images/badge.png' : undefined,
    icon: payload.icon || undefined,
    tag: payload.tag || 'dr-niva',
    renotify: true,
    vibrate: [90, 50, 90],
    data: { url: payload.url || '/' }
  };

  event.waitUntil(self.registration.showNotification(payload.title, options));
});

self.addEventListener('notificationclick', function (event) {
  event.notification.close();
  var target = (event.notification.data && event.notification.data.url) || '/';

  event.waitUntil(
    self.clients.matchAll({ type: 'window', includeUncontrolled: true }).then(function (list) {
      for (var i = 0; i < list.length; i += 1) {
        if (list[i].url.indexOf(target) !== -1 && 'focus' in list[i]) return list[i].focus();
      }
      return self.clients.openWindow(target);
    })
  );
});
