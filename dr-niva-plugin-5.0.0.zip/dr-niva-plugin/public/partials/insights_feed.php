<?php
/**
 * Module partial: insights_feed — rule-based suggestions from the user's own data.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_items = Niva_Insights::insights( get_current_user_id(), 4 );
?>
<div class="niva-module niva-module--insights_feed" data-module="insights_feed" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">پیشنهادهای هوشمند</h2>
				<span class="caption">بر اساس فعالیت خودت در اپ — نه یک توصیه‌ی پزشکی</span>
			</div>
			<span class="card__icon card__icon--teal"><?php echo Niva_Icons::svg( 'sparkles', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		</div>

		<div class="insight-list">
			<?php foreach ( $niva_items as $niva_item ) : ?>
				<article class="insight insight--<?php echo esc_attr( $niva_item['tone'] ); ?>">
					<span class="insight__icon"><?php echo Niva_Icons::svg( $niva_item['icon'], 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<div class="insight__body">
						<span class="insight__title"><?php echo esc_html( $niva_item['title'] ); ?></span>
						<p class="insight__text"><?php echo esc_html( $niva_item['text'] ); ?></p>
						<a class="insight__cta" href="<?php echo esc_url( Niva_Modules::url( $niva_item['key'], $args ) ); ?>">
							<?php echo esc_html( $niva_item['cta'] ); ?>
							<?php echo Niva_Icons::svg( 'chevron-left', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	</section>
</div>
