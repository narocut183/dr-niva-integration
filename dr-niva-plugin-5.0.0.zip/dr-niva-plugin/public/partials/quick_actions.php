<?php
/**
 * Module partial: quick_actions — the app-style tile grid.
 *
 * The approved home screen reaches every tool through a compact grid of icon
 * tiles, not through six full-width cards. Each tile stays a link the editor
 * can retarget from inside the Elementor element («لینک‌های این بخش»).
 *
 * @var array $args
 * @package DrNiva
 */

defined( 'ABSPATH' ) || exit;

$niva_actions = Niva_Insights::quick_actions();

/* A stable, calm colour per tile — the reference uses pastel variants of the
   brand blue rather than a different hue on every corner. */
$niva_flavors = array( '', 'green', 'pink', 'cyan', 'purple', 'orange' );
?>
<div class="niva-module niva-module--quick_actions" data-module="quick_actions" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card card--flat">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">الان چه کاری داری؟</h2>
				<span class="caption">سریع‌ترین راه رسیدن به هر بخش</span>
			</div>
		</div>

		<div class="tile-grid">
			<?php foreach ( $niva_actions as $niva_index => $niva_action ) : ?>
				<?php $niva_flavor = $niva_flavors[ $niva_index % count( $niva_flavors ) ]; ?>
				<a class="tile<?php echo '' !== $niva_flavor ? ' tile--' . esc_attr( $niva_flavor ) : ''; ?>"
					href="<?php echo esc_url( Niva_Modules::url( $niva_action['key'], $args ) ); ?>">
					<span class="tile__icon"><?php echo Niva_Icons::svg( $niva_action['icon'], 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="tile__title"><?php echo esc_html( $niva_action['title'] ); ?></span>
					<span class="tile__text"><?php echo esc_html( $niva_action['text'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
</div>
