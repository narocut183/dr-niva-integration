<?php
/**
 * Module partial: exercises — the home-exercise library.
 *
 * Content is authored here on purpose: no external API, no medical claim, and
 * every item is a movement-and-breathing suggestion with a plain-language step
 * list. The editor can show or hide the whole block like any other module.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_groups = array(
	array(
		'goal'  => 'آرام‌سازی و تنفس',
		'items' => array(
			array(
				'icon'  => 'wind',
				'title' => 'تنفس ۴-۷-۸',
				'text'  => 'برای خواب بهتر و کم‌کردن اضطراب.',
				'level' => 'سبک',
				'mins'  => 5,
				'steps' => array( 'چهار شماره دم بگیر.', 'هفت شماره نگه دار.', 'هشت شماره آرام بازدم کن.', '۸ بار تکرار کن.' ),
			),
			array(
				'icon'  => 'smile',
				'title' => 'اسکن بدن',
				'text'  => 'رهاسازی تنش گردن و شانه‌ها.',
				'level' => 'سبک',
				'mins'  => 7,
				'steps' => array( 'نشسته و راحت باش.', 'از سر تا پا توجه را بچرخان.', 'هر جا تنش دیدی، دو نفس آنجا بده.' ),
			),
			array(
				'icon'  => 'refresh-cw',
				'title' => 'تنفس جعبه‌ای',
				'text'  => 'تمرکز را برمی‌گرداند؛ مناسب کار طولانی.',
				'level' => 'سبک',
				'mins'  => 6,
				'steps' => array( 'چهار شماره دم.', 'چهار شماره نگه دار.', 'چهار شماره بازدم.', 'چهار شماره نگه دار و تکرار کن.' ),
			),
		),
	),
	array(
		'goal'  => 'پشت، گردن و شانه',
		'items' => array(
			array(
				'icon'  => 'activity',
				'title' => 'کشش گردن',
				'text'  => 'مناسب کار طولانی با لپ‌تاپ.',
				'level' => 'سبک',
				'mins'  => 4,
				'steps' => array( 'شانه‌ها را پایین بگذار.', 'سر را آرام به راست خم کن.', '۲۰ ثانیه نگه دار و طرف دیگر.' ),
			),
			array(
				'icon'  => 'layers',
				'title' => 'پل باسن',
				'text'  => 'تقویت پایین‌تنه و کمر.',
				'level' => 'متوسط',
				'mins'  => 8,
				'steps' => array( 'به پشت دراز بکش و زانوها را خم کن.', 'باسن را بالا ببر.', '۳ ثانیه نگه دار.', '۱۰ بار تکرار کن.' ),
			),
			array(
				'icon'  => 'refresh-cw',
				'title' => 'گربه–شتر',
				'text'  => 'نرم‌کردن ستون فقرات.',
				'level' => 'سبک',
				'mins'  => 5,
				'steps' => array( 'روی چهار دست و پا قرار بگیر.', 'پشت را قوس بده و سر را پایین.', 'برعکس کن و ۸ بار تکرار.' ),
			),
			array(
				'icon'  => 'layers',
				'title' => 'کشش سینه با حوله',
				'text'  => 'برای قوز کردن در نشستن.',
				'level' => 'سبک',
				'mins'  => 4,
				'steps' => array( 'حوله را پشت کمر بگیر.', 'دو سر حوله را به جلو بکش.', '۲۰ ثانیه نگه دار.' ),
			),
		),
	),
	array(
		'goal'  => 'تقویت و حرکت روزانه',
		'items' => array(
			array(
				'icon'  => 'trending-up',
				'title' => 'اسکات روی صندلی',
				'text'  => 'برای زانو و پا، بدون فشار زیاد.',
				'level' => 'متوسط',
				'mins'  => 6,
				'steps' => array( 'پشت به صندلی بایست.', 'آرام بنشین و بلند شو.', '۱۲ بار تکرار کن.' ),
			),
			array(
				'icon'  => 'heart',
				'title' => 'شنای دیواری',
				'text'  => 'تقویت بازو و سینه.',
				'level' => 'سبک',
				'mins'  => 5,
				'steps' => array( 'کف دست‌ها روی دیوار.', 'آرام نزدیک شو.', '۱۰ بار تکرار کن.' ),
			),
			array(
				'icon'  => 'activity',
				'title' => 'پیاده‌روی سریع ۱۰ دقیقه',
				'text'  => 'ساده‌ترین تمرین برای قلب و قند خون.',
				'level' => 'سبک',
				'mins'  => 10,
				'steps' => array( '۱۰ دقیقه تندتر از حالت معمول راه برو.', 'اگر توانستی، دو نوبت در روز.' ),
			),
			array(
				'icon'  => 'trending-up',
				'title' => 'بالا بردن پاشنه',
				'text'  => 'گردش خون پا و مچ.',
				'level' => 'سبک',
				'mins'  => 4,
				'steps' => array( 'پشت صندلی بایست.', 'روی پنجه بلند شو.', '۱۵ بار تکرار کن.' ),
			),
		),
	),
	array(
		'goal'  => 'بارداری و پس از زایمان',
		'items' => array(
			array(
				'icon'  => 'heart',
				'title' => 'تنفس دیافراگمی',
				'text'  => 'با تأیید پزشک، برای آرامش و کنترل تنفس.',
				'level' => 'سبک',
				'mins'  => 5,
				'steps' => array( 'دست روی شکم بگذار.', 'دم آرام از بینی.', 'بازدم بلندتر از دم.' ),
			),
			array(
				'icon'  => 'baby',
				'title' => 'حرکات ملایم لگن',
				'text'  => 'فقط اگر پزشکت اجازه داده باشد.',
				'level' => 'سبک',
				'mins'  => 6,
				'steps' => array( 'روی چهار دست و پا قرار بگیر.', 'لگن را آرام بچرخان.', 'در هر وضعیت ۳ نفس بمان.' ),
			),
			array(
				'icon'  => 'shield-check',
				'title' => 'تمرین کگل',
				'text'  => 'تقویت عضلات کف لگن.',
				'level' => 'سبک',
				'mins'  => 5,
				'steps' => array( 'عضلات کف لگن را ۳ ثانیه بگیر.', '۳ ثانیه رها کن.', '۱۰ بار تکرار کن.' ),
			),
		),
	),
	array(
		'goal'  => 'تعادل و آرام‌سازی شب',
		'items' => array(
			array(
				'icon'  => 'scale',
				'title' => 'تعادل روی یک پا',
				'text'  => 'پیشگیری از زمین‌خوردن.',
				'level' => 'متوسط',
				'mins'  => 4,
				'steps' => array( 'نزدیک دیوار بایست.', 'یک پا را بلند کن.', '۲۰ ثانیه بمان و پا را عوض کن.' ),
			),
			array(
				'icon'  => 'layers',
				'title' => 'کشش همسترینگ',
				'text'  => 'برای کمر و پشت ران.',
				'level' => 'سبک',
				'mins'  => 5,
				'steps' => array( 'نشسته یک پا را دراز کن.', 'آرام به جلو خم شو.', '۲۰ ثانیه نگه دار.' ),
			),
			array(
				'icon'  => 'wind',
				'title' => 'تنفس شکمی درازکش',
				'text'  => 'پیش از خواب.',
				'level' => 'سبک',
				'mins'  => 6,
				'steps' => array( 'به پشت دراز بکش و دست روی شکم.', 'دم آرام ۴ شماره.', 'بازدم ۶ شماره.', '۲ دقیقه ادامه بده.' ),
			),
		),
	),
	array(
		'goal'  => 'برنامهٔ روزمره و تحرک ملایم',
		'items' => array(
			array(
				'icon'  => 'sun',
				'title' => 'کشش صبحگاهی دست‌ها',
				'text'  => 'شروع آرام روز پس از بیدارشدن.',
				'level' => 'سبک',
				'mins'  => 3,
				'steps' => array( 'راحت بایست یا بنشین.', 'دست‌ها را بالای سر ببر.', 'سه نفس آرام بکش و رها کن.' ),
			),
			array(
				'icon'  => 'activity',
				'title' => 'چرخش آرام شانه',
				'text'  => 'وقفهٔ حرکتی کوتاه هنگام کار.',
				'level' => 'سبک',
				'mins'  => 2,
				'steps' => array( 'صاف و راحت بنشین.', 'شانه‌ها را آرام ۸ بار به عقب بچرخان.', 'حرکت را بدون فشار تکرار کن.' ),
			),
			array(
				'icon'  => 'move',
				'title' => 'راه‌رفتن درجا',
				'text'  => 'تحرک کوتاه در فضای کوچک.',
				'level' => 'سبک',
				'mins'  => 5,
				'steps' => array( 'کنار دیوار یا صندلی بایست.', 'با سرعت راحت درجا راه برو.', 'اگر احساس ناراحتی کردی، توقف کن.' ),
			),
			array(
				'icon'  => 'wind',
				'title' => 'وقفهٔ تنفسی یک‌دقیقه‌ای',
				'text'  => 'چند نفس آرام برای بازگشت تمرکز.',
				'level' => 'سبک',
				'mins'  => 1,
				'steps' => array( 'در وضعیت راحت قرار بگیر.', 'دم و بازدم طبیعی و آرام داشته باش.', 'نیازی به حبس نفس نیست.' ),
			),
		),
	),
);
$niva_exercise_id = 0;
$niva_exercise_total = array_sum( array_map( static function ( $group ) { return count( $group['items'] ); }, $niva_groups ) );
?>
<div class="niva-module niva-module--exercises" data-module="exercises" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>" data-exercises data-today="<?php echo esc_attr( current_time( 'Y-m-d' ) ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">تمرین‌های خانگی</h2>
				<span class="caption"><span data-exercise-count>۰</span> از <?php echo esc_html( Niva_Chrome::digits( $niva_exercise_total ) ); ?> تمرین امروز انجام شده · با انتخاب هر حرکت، مراحل را ببین و یادآور بساز.</span>
			</div>
			<span class="card__icon"><?php echo Niva_Icons::svg( 'activity', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		</div>

		<?php foreach ( $niva_groups as $niva_group ) : ?>
			<div class="stack" style="gap: var(--s-3)">
				<span class="caption"><?php echo esc_html( $niva_group['goal'] ); ?></span>
				<div class="exercise-grid">
					<?php foreach ( $niva_group['items'] as $niva_item ) : ?>
						<?php ++$niva_exercise_id; ?>
						<article class="exercise-card" data-exercise-card data-exercise-id="<?php echo esc_attr( 'exercise-' . $niva_exercise_id ); ?>">
							<div class="exercise-card__art"><?php echo Niva_Icons::svg( $niva_item['icon'], 34 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></div>
							<div class="stack" style="gap: 6px">
								<span class="exercise-card__title"><?php echo esc_html( $niva_item['title'] ); ?></span>
								<span class="exercise-card__text"><?php echo esc_html( $niva_item['text'] ); ?></span>
							</div>
							<div class="exercise-card__meta">
								<span class="pill"><?php echo Niva_Icons::svg( 'clock', 12 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><?php echo esc_html( Niva_Chrome::digits( $niva_item['mins'] ) ); ?> دقیقه</span>
								<span class="pill pill--soft"><?php echo esc_html( $niva_item['level'] ); ?></span>
							</div>
							<div class="exercise-card__steps">
								<?php foreach ( $niva_item['steps'] as $niva_index => $niva_step ) : ?>
									<span class="exercise-card__step"><b><?php echo esc_html( Niva_Chrome::digits( $niva_index + 1 ) ); ?></b><span><?php echo esc_html( $niva_step ); ?></span></span>
								<?php endforeach; ?>
							</div>
							<div class="exercise-card__foot">
								<button type="button" class="btn btn--secondary btn--sm" data-exercise-complete>انجام دادم</button>
								<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'reminders', $args ) ); ?>">
									<?php echo Niva_Icons::svg( 'bell', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
									یادآور تمرین
								</a>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			</div>
		<?php endforeach; ?>

		<div class="alert alert--caution">
			<span class="alert__icon"><?php echo Niva_Icons::svg( 'alert-triangle', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<div class="alert__body">
				<span class="alert__title">قبل از شروع</span>
				<div class="alert__text">اگر بارداری، جراحی تازه، درد شدید یا بیماری زمینه‌ای داری، فقط با تأیید پزشک تمرین کن. هر حرکت را در حد راحتی انجام بده و در صورت درد قطع کن.</div>
			</div>
		</div>
	</section>
</div>
