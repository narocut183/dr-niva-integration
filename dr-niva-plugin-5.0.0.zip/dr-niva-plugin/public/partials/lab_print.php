<?php
/**
 * Module partial: lab_print
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice();
	return;
}

$niva_entries = Niva_Labs::all();
?>
<div class="niva-module niva-module--lab_print" data-module="lab_print" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
  <section class="card">
    <div class="card__head">
      <h2 class="card__title">برگهٔ آزمایش‌های من</h2>
      <button type="button" class="btn btn--secondary btn--sm" data-print>چاپ</button>
    </div>
    <?php if ( $niva_entries ) : ?>
      <div class="table-wrap lab-print-table-wrap">
        <table>
          <thead><tr><th>آزمایش</th><th>مقدار</th><th>تاریخ</th><th>وضعیت</th></tr></thead>
          <tbody>
          <?php foreach ( array_slice( $niva_entries, 0, 60 ) as $niva_entry ) : ?>
            <?php
            $niva_meta = Niva_Labs::markers()[ $niva_entry['marker'] ] ?? array( $niva_entry['name'] ?: $niva_entry['marker'], $niva_entry['unit'], 0, 0 );
            $niva_name = $niva_entry['name'] ?: $niva_meta[0];
            $niva_unit = $niva_entry['unit'] ?: $niva_meta[1];
            $niva_low = null !== $niva_entry['reference_low'] ? $niva_entry['reference_low'] : $niva_meta[2];
            $niva_high = null !== $niva_entry['reference_high'] ? $niva_entry['reference_high'] : $niva_meta[3];
            $niva_status = Niva_Labs::status( $niva_entry['marker'], $niva_entry['value'], $niva_low, $niva_high );
            ?>
            <tr>
              <td><?php echo esc_html( $niva_name ); ?></td>
              <td><?php echo esc_html( Niva_Chrome::digits( $niva_entry['value'] ) . ' ' . $niva_unit ); ?></td>
              <td><?php echo esc_html( $niva_entry['date'] ? Niva_Chrome::format_date( (string) $niva_entry['date'] ) : '—' ); ?></td>
              <td><?php echo esc_html( '' !== $niva_status ? Niva_Labs::status_label( $niva_status ) : 'محدوده ثبت نشده' ); ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table>
      </div>
    <?php else : ?>
      <?php echo Niva_Chrome::blank( 'چیزی برای چاپ نیست', 'اول یک نتیجه ثبت کن.', 'ثبت نتیجهٔ آزمایش', 'lab', $args ); ?>
    <?php endif; ?>
  </section>
</div>
