<?php
/**
 * Module partial: plans_table — the plans as they are really sold (2.0.0).
 *
 * Adds the period selector: 1 / 3 / 6 / 12 months, each with its own discount,
 * monthly equivalent and saving, all computed from the WooCommerce plan price
 * (never invented). Limits still come from the back office.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_catalog  = Niva_Plans::catalog();
$niva_mine     = ( is_user_logged_in() && dr_niva()->plans ) ? dr_niva()->plans->summary( get_current_user_id() ) : array();
$niva_current  = (string) ( $niva_mine['plan'] ?? '' );
$niva_limits   = dr_niva()->plans ? dr_niva()->plans->limits() : Niva_Plans::default_limits();
$niva_features = Niva_Plans::feature_labels();

// Periods come from the subscription engine; the selected one is remembered in
// the URL so the choice survives a reload without Javascript.
$niva_sub     = dr_niva()->subscription instanceof Niva_Subscription ? dr_niva()->subscription : new Niva_Subscription();
$niva_periods = $niva_sub->periods();
$niva_months  = isset( $_GET['period'] ) ? absint( wp_unslash( $_GET['period'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
if ( ! $niva_sub->period( $niva_months ) ) {
	$niva_months = $niva_sub->default_period();
}
$niva_sel  = $niva_sub->period( $niva_months );
$niva_base = remove_query_arg( 'period' );
?>
<div class="niva-module niva-module--plans_table" data-module="plans_table" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
  <section class="card">
    <div class="card__head">
      <div class="stack" style="gap: 2px">
        <h2 class="card__title">پلن‌ها و اشتراک</h2>
        <span class="caption">دوره را انتخاب کن؛ قیمت و تخفیف هر دوره از محصول ووکامرس همین پلن خوانده می‌شود.</span>
      </div>
      <span class="card__icon"><?php echo Niva_Icons::svg( 'credit-card', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
    </div>

    <?php if ( count( $niva_periods ) > 1 ) : ?>
      <nav class="billing-toggle" style="flex-wrap: wrap" aria-label="انتخاب دورهٔ اشتراک">
        <?php foreach ( $niva_periods as $niva_p ) : ?>
          <?php $niva_url = add_query_arg( 'period', (int) $niva_p['months'], $niva_base ); ?>
          <a class="billing-toggle__btn<?php echo (int) $niva_p['months'] === $niva_months ? ' billing-toggle__btn--active' : ''; ?>" href="<?php echo esc_url( $niva_url ); ?>"
            aria-current="<?php echo (int) $niva_p['months'] === $niva_months ? 'true' : 'false'; ?>">
            <?php echo esc_html( (string) $niva_p['label'] ); ?>
            <?php if ( (float) $niva_p['discount'] > 0 ) : ?>
              <span class="badge badge--soft"><?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_p['discount'] ) ); ?>٪</span>
            <?php endif; ?>
          </a>
        <?php endforeach; ?>
      </nav>
    <?php endif; ?>

    <div class="table-wrap" role="region" aria-label="مقایسهٔ امکانات اشتراک‌ها" tabindex="0">
      <table class="table">
        <thead>
          <tr>
            <th scope="col">امکانات</th>
            <?php foreach ( $niva_catalog as $niva_key => $niva_plan ) : ?>
              <?php $niva_price = $niva_sub->price( (string) $niva_key, $niva_months ); ?>
              <th scope="col" class="is-center<?php echo $niva_current === $niva_key ? ' is-current' : ''; ?>">
                <strong><?php echo esc_html( $niva_plan['label'] ); ?></strong>
                <span class="stack" style="gap: 2px">
                  <?php if ( ! $niva_plan['monthly'] ) : ?>
                    <strong class="plain-row__value">رایگان</strong>
                  <?php elseif ( $niva_price['available'] ) : ?>
                    <strong class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( number_format_i18n( $niva_price['total'] ) ) ); ?> تومان</strong>
                    <span class="caption">
                      برای <?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_price['months'] ) ); ?> ماه ·
                      ماهی <?php echo esc_html( Niva_Chrome::digits( number_format_i18n( $niva_price['per_month'] ) ) ); ?> تومان
                    </span>
                  <?php else : ?>
                    <span class="caption">قیمت این دوره در فروشگاه تنظیم نشده است</span>
                  <?php endif; ?>
                </span>
                <?php if ( $niva_price['available'] && (float) $niva_price['discount'] > 0 ) : ?>
                  <span class="badge badge--success">
                    <?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_price['discount'] ) ); ?>٪ تخفیف ·
                    <?php echo esc_html( Niva_Chrome::digits( number_format_i18n( (int) $niva_price['savings'] ) ) ); ?> تومان صرفه‌جویی
                  </span>
                <?php endif; ?>
              </th>
            <?php endforeach; ?>
          </tr>
        </thead>
        <tbody>
          <?php foreach ( $niva_features as $niva_feature_key => $niva_feature_label ) : ?>
            <tr>
              <th scope="row"><?php echo esc_html( $niva_feature_label ); ?></th>
              <?php foreach ( $niva_catalog as $niva_key => $niva_plan ) : ?>
                <?php
                $niva_value = (int) ( $niva_limits[ $niva_key ][ $niva_feature_key ] ?? 0 );
                if ( in_array( $niva_feature_key, array( 'pdf_export', 'doctor_review' ), true ) ) {
                  $niva_value_text = $niva_value > 0 ? 'دارد' : 'ندارد';
                } elseif ( 'family_seats' === $niva_feature_key && 0 === $niva_value ) {
                  $niva_value_text = 'ندارد';
                } else {
                  $niva_value_text = Niva_Plans::human_limit( $niva_value );
                }
                ?>
                <td class="is-center<?php echo $niva_current === $niva_key ? ' is-current' : ''; ?>"><?php echo esc_html( $niva_value_text ); ?></td>
              <?php endforeach; ?>
            </tr>
          <?php endforeach; ?>
          <tr>
            <th scope="row">انتخاب اشتراک</th>
            <?php foreach ( $niva_catalog as $niva_key => $niva_plan ) : ?>
              <?php $niva_buy = ( class_exists( 'Niva_Orders' ) && ! empty( $niva_plan['monthly'] ) ) ? add_query_arg( 'period', $niva_months, Niva_Orders::checkout_url_for_plan( (string) $niva_key ) ) : ''; ?>
              <td class="is-center<?php echo $niva_current === $niva_key ? ' is-current' : ''; ?>">
                <?php if ( '' === $niva_buy ) : ?>
                  <span class="caption"><?php echo $niva_plan['monthly'] ? 'پرداخت در دسترس نیست' : 'پلن پایه'; ?></span>
                <?php elseif ( $niva_current === $niva_key ) : ?>
                  <span class="badge badge--info">پلن فعلی</span>
                  <a class="btn btn--secondary btn--sm" href="<?php echo esc_url( $niva_buy ); ?>" rel="nofollow">تمدید</a>
                <?php elseif ( ! is_user_logged_in() ) : ?>
                  <a class="btn btn--secondary btn--sm" href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>">ورود</a>
                <?php else : ?>
                  <a class="btn btn--primary btn--sm" href="<?php echo esc_url( $niva_buy ); ?>" rel="nofollow">خرید</a>
                <?php endif; ?>
              </td>
            <?php endforeach; ?>
          </tr>
        </tbody>
      </table>
    </div>

    <p class="caption">
      در موبایل جدول را به چپ و راست بکش. تعدادها از تنظیمات پلن‌ها و قیمت‌ها از محصول ووکامرس خوانده می‌شوند؛
      اگر محصولی برای یک پلن ساخته نشده باشد، همان‌جا نوشته می‌شود و هیچ عددی حدس زده نمی‌شود.
    </p>
    <?php if ( $niva_sel ) : ?>
      <p class="caption">
        دورهٔ انتخابی: <strong><?php echo esc_html( (string) $niva_sel['label'] ); ?></strong>
        <?php if ( (float) $niva_sel['discount'] > 0 ) : ?>
          — <?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_sel['discount'] ) ); ?>٪ تخفیف نسبت به خرید ماهیانه
        <?php endif; ?>
      </p>
    <?php endif; ?>
  </section>
</div>
