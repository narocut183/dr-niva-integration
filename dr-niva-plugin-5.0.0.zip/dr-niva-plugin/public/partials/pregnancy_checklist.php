<?php
/**
 * Module partial: pregnancy_checklist
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* This screen describes a pregnancy, so it is only shown when the profile
   actually says there is one — a new account must never read someone else's
   week number. */
if ( ! in_array( strtolower( (string) Niva_Chrome::flag( 'pregnant' ) ), array( '1', 'yes', 'true' ), true ) ) {
	echo Niva_Chrome::blank( 'بارداری ثبت نشده', 'اگر باردار هستی، در تنظیمات حساب فعالش کن تا این بخش با هفتهٔ واقعی خودت ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--pregnancy_checklist" data-module="pregnancy_checklist" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">کارهای همین هفته</h2>
				<span class="caption"><bdi data-checklist-count>۰</bdi> از ۵ پیشنهاد تیک خورده</span>
			</div>
			<span class="card__icon card__icon--green" aria-hidden="true"><?php echo Niva_Icons::svg( 'clipboard-list', 20 ); ?></span>
		</div>

		<p class="caption">این فهرست پیشنهادهای عمومی است. تیک‌ها موقتی‌اند و با بارگذاری دوباره پاک می‌شوند.</p>
		<div class="checklist" data-checklist>
			<button type="button" class="checklist__item" aria-pressed="false">
				<span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
				<span class="checklist__label">سونوگرافی آنومالی</span>
			</button>
			<button type="button" class="checklist__item" aria-pressed="false">
				<span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
				<span class="checklist__label">آزمایش قند بارداری (اگر پزشک گفته)</span>
			</button>
			<button type="button" class="checklist__item" aria-pressed="false">
				<span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
				<span class="checklist__label">ویزیت ماهانه</span>
			</button>
			<button type="button" class="checklist__item" aria-pressed="false">
				<span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
				<span class="checklist__label">شمارش حرکت جنین هر روز</span>
			</button>
			<button type="button" class="checklist__item" aria-pressed="false">
				<span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
				<span class="checklist__label">ثبت وزن این هفته</span>
			</button>
		</div>
	</section>
</div>
