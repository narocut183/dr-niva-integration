<?php
/**
 * Module partial: lab_progress
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--lab_progress" data-module="lab_progress" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<div class="card">
              <span class="skeleton" style="height: 22px; width: 60%"></span>
              <span class="skeleton" style="height: 14px; width: 90%"></span>
              <span class="skeleton" style="height: 14px; width: 75%"></span>
            </div>
</div>
