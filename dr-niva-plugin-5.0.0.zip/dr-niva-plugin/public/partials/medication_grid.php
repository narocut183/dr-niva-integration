<?php
/**
 * Module partial: medication_grid — the week board.
 *
 * Rows are what the user actually does in the app (advisor, lab, image, other),
 * columns are the last seven days. Intensity comes from the real usage log, so
 * the board is always truthful — never a decorative grid of fake ticks.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_user = get_current_user_id();

/* Falls back to an empty board instead of a fatal if the engine is older. */
$niva_week = method_exists( 'Niva_Insights', 'kind_week' ) ? Niva_Insights::kind_week( $niva_user ) : array( 'days' => array(), 'rows' => array() );
$niva_days = $niva_week['days'];
$niva_rows = $niva_week['rows'];
$niva_hits = 0;

foreach ( $niva_rows as $niva_row ) {
	foreach ( $niva_row['cells'] as $niva_cell ) {
		$niva_hits += (int) $niva_cell;
	}
}
?>
<div class="niva-module niva-module--medication_grid" data-module="medication_grid" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">تابلوی هفته</h2>
				<span class="caption">هفت روز گذشته؛ هر خانه‌ی پر، یعنی آن کار را آن روز انجام داده‌ای</span>
			</div>
			<span class="badge badge--info"><?php echo esc_html( Niva_Chrome::digits( $niva_hits ) ); ?> فعالیت</span>
		</div>

		<?php if ( ! $niva_rows ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'activity', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">تابلو هنوز خالی است</span>
				<span class="caption">بعد از اولین گفت‌وگو یا تحلیل، این‌جا هفته‌ات شکل می‌گیرد.</span>
			</div>
		<?php else : ?>
			<div class="med-grid" role="img" aria-label="تابلوی فعالیت هفت روز گذشته">
				<div class="med-grid__head">
					<span></span>
					<?php foreach ( $niva_days as $niva_day ) : ?>
						<span><?php echo esc_html( $niva_day['label'] ); ?></span>
					<?php endforeach; ?>
				</div>
				<?php foreach ( $niva_rows as $niva_row ) : ?>
					<div class="med-grid__row">
						<span class="med-grid__name"><?php echo esc_html( $niva_row['label'] ); ?></span>
						<?php foreach ( $niva_row['cells'] as $niva_cell ) : ?>
							<span class="med-cell<?php echo (int) $niva_cell > 1 ? ' med-cell--on' : ( (int) $niva_cell > 0 ? ' med-cell--soft' : '' ); ?>"></span>
						<?php endforeach; ?>
					</div>
				<?php endforeach; ?>
			</div>

			<div class="med-legend">
				<span class="med-legend__item"><i class="med-legend__dot med-legend__dot--on"></i> بیشتر از یک بار</span>
				<span class="med-legend__item"><i class="med-legend__dot" style="background: var(--brand-soft)"></i> یک بار</span>
				<span class="med-legend__item"><i class="med-legend__dot"></i> انجام نشده</span>
			</div>
		<?php endif; ?>

		<p class="caption">این تابلو فقط از فعالیت خودت در اپ ساخته می‌شود؛ جای دفتر دارویی پزشک را نمی‌گیرد.</p>
	</section>
</div>
