<?php
/**
 * Module partial: advisor_safety
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--advisor_safety" data-module="advisor_safety" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <h2 class="card__title">قبل از شروع بدان</h2>
              <span class="card__icon card__icon--orange" aria-hidden="true"><?php echo Niva_Icons::svg( 'shield-check', 20 ); ?></span>
            </div>
            <div class="stack" style="gap: var(--s-2)">
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>این همراه برای گفت‌وگو، مرتب‌کردن فکرها و پیدا کردن قدم بعدی طراحی شده است.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>هر چه بنویسی روی دستگاه خودت می‌ماند.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>در موضوع‌های حساس (بارداری، دارو، افسردگی شدید) همیشه با متخصص بررسی کن.</span></span>
            </div>
          </section>
</div>
