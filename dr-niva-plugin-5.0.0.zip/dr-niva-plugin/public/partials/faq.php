<?php
/**
 * Module partial: faq
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--faq" data-module="faq" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="stack" id="faq" data-module="faq">
            <h2>سؤال‌های کوتاه</h2>

            <div class="accordion">
              <div class="accordion__item" data-accordion>
                <button type="button" class="accordion__trigger" aria-expanded="false" aria-controls="faq-1" id="faq-trigger-1">
                  <span>جای پزشک را می‌گیرد؟</span>
                  <?php echo Niva_Icons::svg( 'chevron-down', 20 ); ?>
                </button>
                <div class="accordion__panel" id="faq-1" role="region" aria-labelledby="faq-trigger-1" hidden>
                  نه. کار ما ساده‌کردن داده‌های توست تا سؤال درست‌تری از پزشک بپرسی. هر خروجی با یادآوری «با پزشک چک کن»
                  نمایش داده می‌شود.
                </div>
              </div>
              <div class="accordion__item" data-accordion>
                <button type="button" class="accordion__trigger" aria-expanded="false" aria-controls="faq-2" id="faq-trigger-2">
                  <span>داده‌هایم کجاست؟</span>
                  <?php echo Niva_Icons::svg( 'chevron-down', 20 ); ?>
                </button>
                <div class="accordion__panel" id="faq-2" role="region" aria-labelledby="faq-trigger-2" hidden>
                  هر چه ثبت می‌کنی روی همین دستگاه می‌ماند و در اختیار کسی جز خودت نیست. هر زمان می‌توانی پاکش کنی.
                </div>
              </div>
              <div class="accordion__item" data-accordion>
                <button type="button" class="accordion__trigger" aria-expanded="false" aria-controls="faq-3" id="faq-trigger-3">
                  <span>اگر حالم خیلی بد باشد چه می‌شود؟</span>
                  <?php echo Niva_Icons::svg( 'chevron-down', 20 ); ?>
                </button>
                <div class="accordion__panel" id="faq-3" role="region" aria-labelledby="faq-trigger-3" hidden>
                  در گفت‌وگو، اگر نشانه‌ی خطر جدی دیده شود مسیر عادی متوقف می‌شود و خطوط کمک فوری (اورژانس اجتماعی ۱۲۳ و
                  صدای مشاور ۱۴۸۰) بلافاصله نمایش داده می‌شود.
                </div>
              </div>
            </div>

            <div class="cols">
              <a class="btn btn--secondary" href="<?php echo esc_url( Niva_Modules::url( 'tools', $args ) ); ?>" style="flex:1 1 200px">
                <?php echo Niva_Icons::svg( 'layers', 18 ); ?>
                همه ابزارها
              </a>
              <a class="btn btn--secondary" href="<?php echo esc_url( Niva_Modules::url( 'reminders', $args ) ); ?>" style="flex:1 1 200px">
                <?php echo Niva_Icons::svg( 'bell', 18 ); ?>
                یادآور و اعلان
              </a>
            </div>
          </section>
</div>
