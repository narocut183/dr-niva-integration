<?php
/**
 * Module partial: baby_print
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* Baby screens need a baby on file. */
if ( '' === (string) Niva_Chrome::flag( 'baby_birth' ) && '' === (string) Niva_Chrome::flag( 'baby_name' ) ) {
	echo Niva_Chrome::blank( 'پروندهٔ کودک ساخته نشده', 'نام و تاریخ تولد کودک را در تنظیمات حساب ثبت کن تا این بخش با داده‌های واقعی ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--baby_print" data-baby-root data-module="baby_print" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">علائمی که نباید صبر کرد</h2>
                <span class="caption">اگر هر کدام را دیدی، با پزشک کودک تماس بگیر.</span>
              </div>
              <span class="card__icon card__icon--orange" aria-hidden="true"><?php echo Niva_Icons::svg( 'alert-triangle', 20 ); ?></span>
            </div>

            <div class="stack" style="gap: var(--s-2)">
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>تب در نوزاد زیر سه ماه</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>بی‌حالی یا بی‌قراری شدید و مداوم</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>امتناع از شیر خوردن یا کاهش پوشک خیس</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>استفراغ مکرر یا اسهال</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>رنگ‌پریدگی، نفس‌سختی یا سرفه‌ی مداوم</span></span>
            </div>

            <div class="alert alert--urgent">
              <span class="alert__icon"><?php echo Niva_Icons::svg( 'phone-call', 20 ); ?></span>
              <div class="alert__body">
                <span class="alert__title">این فهرست آموزشی است و کامل نیست</span>
                <div class="alert__text">
                  قضاوت درباره‌ی وضعیت نوزاد فقط با پزشک است. اگر نگرانی داری، معطل نکن.
                </div>
                <div class="alert__actions">
                  <button type="button" class="btn btn--danger btn--sm" data-print>
                    <?php echo Niva_Icons::svg( 'printer', 16 ); ?>
                    چاپ خلاصه‌ی رشد برای پزشک
                  </button>
                </div>
              </div>
            </div>
          </section>
</div>
