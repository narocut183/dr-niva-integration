<?php
/**
 * Module partial: health_score — the ring + breakdown card.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_user  = get_current_user_id();
$niva_data  = Niva_Insights::health_score( $niva_user );
$niva_band  = $niva_data['band'];
$niva_ring  = Niva_Insights::ring( (int) $niva_data['score'] );
$niva_score = $niva_data['score'];
?>
<div class="niva-module niva-module--health_score" data-module="health_score" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card hero-stat">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">امتیاز سلامت تو</h2>
				<span class="caption">از فعالیت، پیگیری، اشتراک و برنامه‌ی مراقبتت ساخته می‌شود</span>
			</div>
			<span class="badge badge--<?php echo esc_attr( $niva_band['tone'] ); ?>"><?php echo esc_html( $niva_band['label'] ); ?></span>
		</div>

		<div class="score-ring" data-score="<?php echo esc_attr( (int) $niva_score ); ?>">
			<svg class="score-ring__svg" viewBox="0 0 120 120" role="img"
				aria-label="امتیاز سلامت <?php echo esc_attr( Niva_Chrome::digits( $niva_score ) ); ?> از ۱۰۰">
				<circle class="score-ring__track" cx="60" cy="60" r="<?php echo esc_attr( $niva_ring['radius'] ); ?>" />
				<circle class="score-ring__fill"
					cx="60" cy="60" r="<?php echo esc_attr( $niva_ring['radius'] ); ?>"
					stroke-dasharray="<?php echo esc_attr( round( $niva_ring['circumference'], 2 ) ); ?>"
					stroke-dashoffset="<?php echo esc_attr( round( $niva_ring['offset'], 2 ) ); ?>"
					transform="rotate(-90 60 60)" />
			</svg>
			<div class="score-ring__center">
				<b class="score-ring__value"><?php echo esc_html( Niva_Chrome::digits( $niva_score ) ); ?></b>
				<span class="score-ring__unit">از ۱۰۰</span>
			</div>
		</div>

		<p class="lede"><?php echo esc_html( $niva_band['note'] ); ?></p>

		<div class="metric-grid">
			<?php foreach ( $niva_data['parts'] as $niva_part ) : ?>
				<div class="metric">
					<div class="metric__head">
						<span class="metric__label"><?php echo esc_html( $niva_part['label'] ); ?></span>
						<b class="metric__value"><?php echo esc_html( Niva_Chrome::digits( (int) $niva_part['value'] ) ); ?><span>/<?php echo esc_html( Niva_Chrome::digits( (int) $niva_part['max'] ) ); ?></span></b>
					</div>
					<div class="metric__bar">
						<i style="width: <?php echo esc_attr( (int) round( ( (int) $niva_part['value'] / max( 1, (int) $niva_part['max'] ) ) * 100 ) ); ?>%"></i>
					</div>
					<span class="caption"><?php echo esc_html( $niva_part['hint'] ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>

		<p class="caption">این امتیاز فقط از فعالیت خودت در اپ ساخته می‌شود و ارزیابی پزشکی نیست.</p>
	</section>
</div>
