<?php
/**
 * Module partial: notifications_inbox — the user's own notification list.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_box    = dr_niva()->notifications->inbox();
$niva_items  = $niva_box['items'];
?>
<div class="niva-module niva-module--notifications_inbox" data-module="notifications_inbox" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">اعلان‌های من</h2>
				<span class="caption"><?php echo esc_html( number_format_i18n( (int) $niva_box['unread'] ) ); ?> اعلان خوانده‌نشده</span>
			</div>
			<span class="card__icon card__icon--orange" aria-hidden="true"><?php echo Niva_Icons::svg( 'bell', 20 ); ?></span>
		</div>
		<p class="caption" role="status" data-inbox-message aria-live="polite"></p>

		<?php if ( ! $niva_items ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'bell', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">هنوز اعلانی نداری.</span>
				<span class="caption">یادآور بساز تا سر وقت خبرت کنیم.</span>
			</div>
		<?php else : ?>
			<div class="stack" data-inbox>
				<?php foreach ( $niva_items as $niva_item ) : ?>
					<article class="notification-card<?php echo $niva_item['is_read'] ? '' : ' notification-card--unread'; ?>" data-notification="<?php echo esc_attr( (int) $niva_item['id'] ); ?>">
						<div class="stack" style="gap: var(--s-1)">
							<strong><?php echo esc_html( $niva_item['title'] ); ?></strong>
							<p class="notification-card__text" style="margin: 0"><?php echo esc_html( (string) $niva_item['body'] ); ?></p>
							<span class="caption"><?php echo esc_html( Niva_Chrome::format_datetime( (string) $niva_item['created_at'] ) ); ?></span>
						</div>
						<?php if ( ! $niva_item['is_read'] ) : ?>
							<button type="button" class="chip" data-mark-read="<?php echo esc_attr( (int) $niva_item['id'] ); ?>">خوانده شد</button>
						<?php endif; ?>
					</article>
				<?php endforeach; ?>
			</div>
			<button type="button" class="btn btn--secondary btn--block" data-mark-all-read>همه را خوانده‌شده کن</button>
		<?php endif; ?>
	</section>
</div>
