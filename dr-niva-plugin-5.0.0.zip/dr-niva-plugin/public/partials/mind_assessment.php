<?php
/**
 * Module partial: mind_assessment — the monthly check-in, in place.
 *
 * The questionnaire lives inside this module, so the button opens it right here
 * (no navigation, no reload) and the score is written to the user's own profile.
 * The trend below is drawn from the scores the user has actually submitted.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice();
	return;
}

$niva_profile = dr_niva()->profile ? dr_niva()->profile->get() : array();
$niva_rows    = dr_niva()->profile ? dr_niva()->profile->mood_assessments() : array();
$niva_month_parts = Niva_Chrome::jalali( current_time( 'timestamp', true ) );
$niva_month_key   = sprintf( '%04d-%02d', $niva_month_parts[0], $niva_month_parts[1] );
$niva_this_month  = null;
foreach ( $niva_rows as $niva_row ) {
	if ( $niva_month_key === $niva_row['month'] ) {
		$niva_this_month = $niva_row;
		break;
	}
}
$niva_scores = array_map(
	static function ( $row ) {
		return (int) $row['score'];
	},
	array_reverse( $niva_rows )
);
$niva_last = $niva_scores ? (int) end( $niva_scores ) : null;

$niva_questions = array(
	'خلق و روحیه',
	'خواب شبانه',
	'انرژی در طول روز',
	'اشتهای غذا',
	'تمرکز و حافظه',
	'نگرانی و دلشوره',
	'علاقه به کارهای روزمره',
	'ارتباط با اطرافیان',
	'آرامش جسمی',
);
$niva_options = array( 0 => 'اصلاً', 1 => 'کم', 2 => 'متوسط', 3 => 'خوب' );
?>
<div id="assessment" class="niva-module niva-module--mind_assessment" data-module="mind_assessment" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">پرسشنامهٔ حال</h2>
				<span class="caption">۹ پرسش کوتاه — هر عدد از ۰ تا ۳</span>
			</div>
			<span class="card__icon card__icon--cyan" aria-hidden="true"><?php echo Niva_Icons::svg( 'clipboard-list', 20 ); ?></span>
			<span class="caption" data-mood-saved></span>
		</div>

		<?php if ( null !== $niva_last ) : ?>
			<div class="stat">
				<span class="stat__label">نمرهٔ آخر تو</span>
				<span class="stat__value" data-mood-last><?php echo esc_html( Niva_Chrome::digits( $niva_last ) ); ?> <small>از <?php echo esc_html( Niva_Chrome::digits( 27 ) ); ?></small></span>
				<span class="caption"><?php echo esc_html( Niva_Chrome::digits( count( $niva_scores ) ) ); ?> پرسشنامه تا حالا پر کرده‌ای</span>
			</div>
		<?php else : ?>
			<?php echo Niva_Chrome::blank( 'هنوز پرسشنامه‌ای پر نکرده‌ای', 'یک بار پر کن؛ نمره‌ات ذخیره می‌شود و روند همین‌جا ساخته می‌شود.' ); ?>
		<?php endif; ?>

		<?php if ( $niva_rows ) : ?>
			<div class="mood-trend" aria-label="روند ماهانهٔ نمرهٔ حال">
				<?php foreach ( array_reverse( $niva_rows ) as $niva_assessment ) : ?>
					<div class="mood-trend__row">
						<span class="caption"><?php echo esc_html( Niva_Chrome::digits( str_replace( '-', '/', $niva_assessment['month'] ) ) ); ?></span>
						<span class="mood-trend__track"><span style="width: <?php echo esc_attr( (string) ( (int) round( ( (int) $niva_assessment['score'] / 27 ) * 100 ) ) ); ?>%"></span></span>
						<b><?php echo esc_html( Niva_Chrome::digits( $niva_assessment['score'] ) ); ?><small> / ۲۷</small></b>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<span class="caption" data-assessment-summary aria-live="polite"><?php echo $niva_this_month ? 'پرسشنامهٔ این ماه تکمیل شده است.' : ''; ?></span>
		<button type="button" class="btn btn--primary btn--block" data-assessment-open <?php disabled( (bool) $niva_this_month ); ?>><?php echo $niva_this_month ? 'این ماه تکمیل شده' : 'تکمیل پرسشنامهٔ این ماه'; ?></button>

		<div class="sheet" data-assessment-sheet hidden>
			<button type="button" class="sheet__scrim" data-assessment-close aria-label="بستن پرسشنامه"></button>
			<div class="sheet__panel stack" role="dialog" aria-modal="true" aria-label="پرسشنامهٔ حال">
				<div class="sheet__grab" aria-hidden="true"></div>
				<div class="sheet__head">
					<h2>پرسشنامهٔ حال</h2>
					<button type="button" class="icon-btn icon-btn--bare" data-assessment-close aria-label="بستن">
						<?php echo Niva_Icons::svg( 'x', 20 ); ?>
					</button>
				</div>
				<p class="caption">حال خودت را برای هر مورد از ۰ تا ۳ ارزیابی کن.</p>
				<?php foreach ( $niva_questions as $niva_index => $niva_question ) : ?>
					<div class="stack" data-mood-row style="gap: 6px">
						<span class="field__label"><?php echo esc_html( Niva_Chrome::digits( $niva_index + 1 ) . '. ' . $niva_question ); ?></span>
						<div class="chip-row">
							<?php foreach ( $niva_options as $niva_value => $niva_label ) : ?>
								<button type="button" class="chip" data-value="<?php echo (int) $niva_value; ?>"><?php echo esc_html( $niva_label ); ?></button>
							<?php endforeach; ?>
						</div>
					</div>
				<?php endforeach; ?>

				<div class="card" style="background: var(--nv-blue-50)">
					<span class="caption" data-mood-total>نمرهٔ تو: ۰ از ۲۷</span>
					<div class="flex" style="gap: var(--s-2)">
						<button type="button" class="btn btn--primary btn--sm" data-mood-save>ذخیرهٔ نمره</button>
						<span class="caption" data-mood-msg></span>
					</div>
				</div>
			</div>
		</div>

		<p class="caption">این پرسشنامه ابزار پیگیری حالِ خودت است و تشخیص پزشکی نیست.</p>
	</section>
</div>
