<?php
/**
 * Module partial: community_my_activity — my questions and my answers (2.0.0).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

Niva_Community::enqueue();

global $wpdb;

$niva_community = dr_niva()->community instanceof Niva_Community ? dr_niva()->community : new Niva_Community();
$niva_uid       = (int) get_current_user_id();
$niva_mine      = $niva_community->threads( array( 'author' => $niva_uid, 'status' => '', 'per_page' => 20 ) );
$niva_replies   = $wpdb->get_results( // phpcs:ignore WordPress.DB
	$wpdb->prepare(
		'SELECT c.id, c.thread_id, c.body, c.status, c.created_at, t.title
		 FROM ' . Niva_DB::table( 'community_comments' ) . ' c
		 LEFT JOIN ' . Niva_DB::table( 'community_threads' ) . ' t ON t.id = c.thread_id
		 WHERE c.user_id = %d ORDER BY c.id DESC LIMIT 20',
		$niva_uid
	),
	ARRAY_A
);
?>
<div class="niva-module niva-module--community_my_activity" data-module="community_my_activity" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--cyan"><?php echo Niva_Icons::svg( 'message-circle', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h2 class="card__title">پرسش‌های من</h2>
			</div>
			<a class="btn btn--primary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'community_new', array(), home_url( '/' ) ) ); ?>">پرسش تازه</a>
		</div>
		<?php if ( ! $niva_mine['items'] ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'message-circle', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">هنوز پرسشی نپرسیده‌ای</span>
				<span class="caption">هر پرسش کوتاه می‌تواند به دیگری هم کمک کند.</span>
			</div>
		<?php else : ?>
			<ul class="community-comments">
				<?php foreach ( $niva_mine['items'] as $niva_item ) : ?>
					<li class="community-comment">
						<a class="community-card__title" href="<?php echo esc_url( $niva_item['url'] ); ?>"><?php echo esc_html( $niva_item['title'] ); ?></a>
						<div class="community-card__meta">
							<?php if ( Niva_Community::STATUS_PUBLISH === $niva_item['status'] ) : ?>
								<span class="community-badge community-badge--ok">منتشرشده</span>
							<?php elseif ( Niva_Community::STATUS_PENDING === $niva_item['status'] ) : ?>
								<span class="community-badge">در انتظار بازبینی</span>
							<?php else : ?>
								<span class="community-badge"><?php echo esc_html( (string) $niva_item['status'] ); ?></span>
							<?php endif; ?>
							<span><?php echo esc_html( $niva_item['time_ago'] ); ?></span>
							<span class="community-card__count"><?php echo esc_html( Niva_Chrome::digits( (string) $niva_item['comment_count'] ) ); ?> پاسخ</span>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>

	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--purple"><?php echo Niva_Icons::svg( 'message-heart', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h2 class="card__title">نظرهای من</h2>
			</div>
		</div>
		<?php if ( ! $niva_replies ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'message-heart', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">هنوز نظری ثبت نکرده‌ای</span>
				<span class="caption">پاسخ به پرسش دیگران، سریع‌ترین راه کمک است.</span>
			</div>
		<?php else : ?>
			<ul class="community-comments">
				<?php foreach ( $niva_replies as $niva_reply ) : ?>
					<li class="community-comment">
						<a class="community-card__title" href="<?php echo esc_url( add_query_arg( 'thread', (int) $niva_reply['thread_id'], Niva_Modules::url( 'community_thread', array(), home_url( '/' ) ) ) ); ?>">
							<?php echo esc_html( (string) ( $niva_reply['title'] ?? 'گفتگو' ) ); ?>
						</a>
						<div class="community-comment__body"><?php echo esc_html( wp_trim_words( wp_strip_all_tags( (string) $niva_reply['body'] ), 20 ) ); ?></div>
						<div class="community-card__meta">
							<?php if ( Niva_Community::STATUS_PUBLISH === $niva_reply['status'] ) : ?>
								<span class="community-badge community-badge--ok">منتشرشده</span>
							<?php else : ?>
								<span class="community-badge">در انتظار بازبینی</span>
							<?php endif; ?>
							<span><?php echo esc_html( $niva_community->relative_time( (string) $niva_reply['created_at'] ) ); ?></span>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>
</div>
