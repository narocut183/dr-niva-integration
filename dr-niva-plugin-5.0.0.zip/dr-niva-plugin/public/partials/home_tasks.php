<?php
/**
 * Module partial: home_tasks
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--home_tasks" data-module="home_tasks" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
  <section class="card">
    <div class="card__head">
      <h2 class="card__title">کارهای امروز</h2>
      <span class="caption">فقط کارهایی که خودت ساخته‌ای</span>
    </div>
    <?php echo Niva_Chrome::blank( 'کاری برای امروز ثبت نشده', 'یادآور بساز تا کارهای روزت این‌جا بیاید.', 'ساختن یادآور', 'reminders', $args ); ?>
  </section>
</div>
