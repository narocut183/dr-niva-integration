<?php
/**
 * Module partial: tools_note
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--tools_note" data-module="tools_note" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<div class="alert alert--info">
            <span class="alert__icon"><?php echo Niva_Icons::svg( 'info', 20 ); ?></span>
            <div class="alert__body">
              <span class="alert__title">ابزارها به‌زودی بیشتر می‌شوند</span>
              <div class="alert__text">
                پرونده سلامت، یادآور دارو و گزارش سالانه در نسخه‌های بعدی اضافه می‌شوند. اگر ابزار خاصی لازم داری، از
                صفحه‌ی پلن‌ها برایمان بنویس.
              </div>
            </div>
          </div>
</div>
