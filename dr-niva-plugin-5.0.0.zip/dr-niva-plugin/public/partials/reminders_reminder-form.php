<?php
/**
 * Module partial: reminders_reminder-form
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--reminders_reminder-form" data-module="reminders_reminder-form" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">یادآور تازه</h2>
				<span class="caption">مثلاً: قرص آهن — ۲۱:۰۰</span>
			</div>
		</div>

		<div class="stack" style="gap: var(--s-2)">
			<button type="button" class="btn btn--primary btn--block" data-sheet-open="reminder-sheet">ساخت یادآور</button>
		</div>

		<div class="sheet" id="reminder-sheet" hidden>
			<button type="button" class="sheet__scrim sheet__backdrop" data-sheet-close aria-label="بستن"></button>
			<div class="sheet__panel">
				<div class="sheet__head">
					<h3 class="sheet__title" data-reminder-form-title>ساخت یادآور</h3>
					<button type="button" class="sheet__close" data-sheet-close aria-label="بستن">&#215;</button>
				</div>
				<form class="stack" data-reminder-form>
					<input type="hidden" name="reminder_id" value="" data-reminder-id />
					<div class="field">
						<label class="field__label" for="reminder-title">چه کاری؟</label>
						<input id="reminder-title" class="field__input" dir="auto" placeholder="قرص آهن" />
						<p class="field__error" role="alert" data-error-for="reminder-title" hidden></p>
					</div>

					<div class="cols">
						<div class="field">
							<label class="field__label" for="reminder-time">ساعت</label>
							<input id="reminder-time" class="field__input reminder-time-input" type="text" inputmode="numeric" autocomplete="off" maxlength="5" pattern="(?:[01][0-9]|2[0-3]):[0-5][0-9]" placeholder="۲۱:۰۰" aria-describedby="reminder-time-help" dir="ltr" value="21:00" />
							<span class="caption" id="reminder-time-help">ساعت ۲۴ساعته، مثل ۲۱:۰۰</span>
						</div>
						<div class="field">
							<label class="field__label" for="reminder-repeat">تکرار</label>
							<select id="reminder-repeat" class="field__input">
								<option value="daily">هر روز</option>
								<option value="once">فقط امروز</option>
								<option value="weekly">هر هفته</option>
							</select>
						</div>
					</div>

					<button type="submit" class="btn btn--primary btn--block">
						<?php echo Niva_Icons::svg( 'plus', 18 ); ?>
						<span data-reminder-submit-label>افزودن یادآور</span>
					</button>
					<button type="button" class="btn btn--secondary btn--block" data-reminder-cancel hidden>انصراف از ویرایش</button>
					<span class="caption" data-reminder-status aria-live="polite"></span>
				</form>
			</div>
		</div>

		<div class="divider" role="presentation"></div>

		<span class="caption">پیشنهادهای آماده</span>
		<div class="chip-row" data-reminder-suggest>
			<button type="button" class="chip" data-reminder-preset="قرص آهن|21:00|daily" data-chip>قرص آهن — هر شب</button>
			<button type="button" class="chip" data-reminder-preset="شمارش حرکت جنین|10:00|daily" data-chip>شمارش حرکت جنین</button>
			<button type="button" class="chip" data-reminder-preset="وزن نوزاد|09:00|weekly" data-chip>وزن نوزاد — هفتگی</button>
			<button type="button" class="chip" data-reminder-preset="ویزیت پزشک|11:00|once" data-chip>ویزیت پزشک</button>
		</div>
	</section>
</div>
