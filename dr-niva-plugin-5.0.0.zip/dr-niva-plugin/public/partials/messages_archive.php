<?php
/**
 * Module partial: messages_archive — the full text of every message of the
 * user's current stage, with its source.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_items = dr_niva()->messages->archive();
$niva_target = dr_niva()->messages->target();
$niva_titles = array(
	'pregnancy' => 'همه‌ی پیام‌های هفته‌ی ' . number_format_i18n( (int) $niva_target['key'] ) . ' بارداری',
	'baby'      => 'پیام‌های ماه ' . number_format_i18n( (int) $niva_target['key'] ) . ' نوزاد',
	'cycle'     => 'پیام‌های این فاز از چرخه',
	'mind'      => 'پیام‌های حال روان',
	'general'   => 'پیام‌های سلامت روزانه',
);
?>
<div class="niva-module niva-module--messages_archive" data-module="messages_archive" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title"><?php echo esc_html( isset( $niva_titles[ $niva_target['audience'] ] ) ? $niva_titles[ $niva_target['audience'] ] : 'پیام‌ها' ); ?></h2>
				<span class="caption">متن کامل، بدون خلاصه‌سازی — همراه با منبع هر پیام</span>
			</div>
			<span class="card__icon"><?php echo Niva_Icons::svg( 'book-open', 20 ); ?></span>
		</div>

		<?php if ( ! $niva_items ) : ?>
			<p class="muted">پیامی برای نمایش نیست.</p>
		<?php else : ?>
			<div class="stack">
				<?php foreach ( $niva_items as $niva_item ) : ?>
					<article class="card card--soft">
						<div class="stack" style="gap: var(--s-2)">
							<strong><?php echo esc_html( $niva_item['title'] ); ?></strong>
							<p class="muted" style="margin: 0"><?php echo wp_kses_post( $niva_item['body'] ); ?></p>
							<?php if ( ! empty( $niva_item['action'] ) ) : ?>
								<p class="caption" style="margin: 0">کار پیشنهادی: <?php echo esc_html( $niva_item['action'] ); ?></p>
							<?php endif; ?>
							<?php if ( ! empty( $niva_item['source_url'] ) ) : ?>
								<p class="caption" style="margin: 0">
									منبع:
									<a href="<?php echo esc_url( $niva_item['source_url'] ); ?>" target="_blank" rel="noopener nofollow"><?php echo esc_html( $niva_item['source_name'] ); ?></a>
								</p>
							<?php endif; ?>
						</div>
					</article>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>
	</section>
</div>
