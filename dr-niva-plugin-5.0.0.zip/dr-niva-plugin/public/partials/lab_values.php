<?php
/**
 * Module partial: lab_values
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice();
	return;
}

$niva_entries = Niva_Labs::all();
?>
<div class="niva-module niva-module--lab_values" data-module="lab_values" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
  <section class="card">
    <div class="card__head">
      <div class="stack" style="gap: 2px">
        <h2 class="card__title">آخرین نتیجه‌های تو</h2>
        <span class="caption">بر اساس چیزی که خودت ثبت کرده‌ای</span>
      </div>
      <span class="card__icon card__icon--teal" aria-hidden="true"><?php echo Niva_Icons::svg( 'file-text', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
    </div>
    <?php if ( $niva_entries ) : ?>
      <div class="stack--lg">
        <?php foreach ( $niva_entries as $niva_index => $niva_entry ) : ?>
          <?php
          $niva_marker = $niva_entry['marker'];
          $niva_meta   = Niva_Labs::markers()[ $niva_marker ] ?? array( $niva_entry['name'] ?: $niva_marker, $niva_entry['unit'], 0, 0 );
          $niva_name   = $niva_entry['name'] ?: $niva_meta[0];
          $niva_unit   = $niva_entry['unit'] ?: $niva_meta[1];
          $niva_low    = null !== $niva_entry['reference_low'] ? $niva_entry['reference_low'] : $niva_meta[2];
          $niva_high   = null !== $niva_entry['reference_high'] ? $niva_entry['reference_high'] : $niva_meta[3];
          $niva_status = Niva_Labs::status( $niva_marker, $niva_entry['value'], $niva_low, $niva_high );
          $niva_range  = '' !== $niva_status ? Niva_Chrome::digits( $niva_low ) . ' تا ' . Niva_Chrome::digits( $niva_high ) . ' ' . $niva_unit : 'محدودهٔ مرجع ثبت نشده';
          ?>
          <article class="card card--flat">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h3 class="card__title"><?php echo esc_html( $niva_name ); ?></h3>
                <span class="caption"><?php echo esc_html( $niva_entry['date'] ? Niva_Chrome::format_date( (string) $niva_entry['date'] ) : 'تاریخ ثبت نشده' ); ?></span>
              </div>
              <span class="badge badge--<?php echo '' === $niva_status ? 'info' : ( 'ok' === $niva_status ? 'success' : ( 'low' === $niva_status ? 'caution' : 'urgent' ) ); ?>"><?php echo esc_html( '' !== $niva_status ? Niva_Labs::status_label( $niva_status ) : 'بدون بازه' ); ?></span>
            </div>
            <div class="stack" style="gap: 4px">
              <span class="caption">محدودهٔ مرجع: <?php echo esc_html( $niva_range ); ?></span>
              <span class="caption"><?php echo esc_html( Niva_Labs::explanation( $niva_marker, $niva_entry['value'], $niva_low, $niva_high ) ); ?></span>
            </div>
            <div class="metric-row">
              <span class="metric-row__label">مقدار</span>
              <span class="metric-row__value"><?php echo esc_html( Niva_Chrome::digits( $niva_entry['value'] ) . ( $niva_unit ? ' ' . $niva_unit : '' ) ); ?></span>
            </div>
            <button type="button" class="btn btn--danger btn--sm" data-lab-remove="<?php echo esc_attr( (string) $niva_index ); ?>" aria-label="<?php echo esc_attr( 'حذف نتیجهٔ ' . $niva_name ); ?>">حذف</button>
          </article>
        <?php endforeach; ?>
      </div>
    <?php else : ?>
      <?php echo Niva_Chrome::blank( 'هنوز آزمایشی ثبت نشده', 'با ثبت اولین مقدار، مقایسه با محدودهٔ مرجع همین‌جا نمایش داده می‌شود.', 'ثبت نتیجهٔ آزمایش', 'lab', $args ); ?>
    <?php endif; ?>
  </section>
</div>
