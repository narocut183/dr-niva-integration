<?php
/**
 * Backward-compatible module: manual lab entry now uses the shared AI uploader.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

echo Niva_Modules::render( 'lab_upload', $args ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
