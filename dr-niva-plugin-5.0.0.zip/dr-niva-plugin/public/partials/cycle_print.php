<?php
/**
 * Module partial: cycle_print
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--cycle_print" data-module="cycle_print" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">بردن به متخصص زنان</h2>
                <span class="caption">خلاصه‌ی ۳ ماه اخیر در یک برگه</span>
              </div>
            </div>
            <button type="button" class="btn btn--secondary btn--block" data-print>
              <?php echo Niva_Icons::svg( 'printer', 18 ); ?>
              چاپ گزارش چرخه
            </button>
          </section>
</div>
