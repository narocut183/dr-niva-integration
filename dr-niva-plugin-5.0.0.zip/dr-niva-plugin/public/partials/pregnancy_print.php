<?php
/**
 * Module partial: pregnancy_print
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* This screen describes a pregnancy, so it is only shown when the profile
   actually says there is one — a new account must never read someone else's
   week number. */
if ( ! in_array( strtolower( (string) Niva_Chrome::flag( 'pregnant' ) ), array( '1', 'yes', 'true' ), true ) ) {
	echo Niva_Chrome::blank( 'بارداری ثبت نشده', 'اگر باردار هستی، در تنظیمات حساب فعالش کن تا این بخش با هفتهٔ واقعی خودت ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--pregnancy_print" data-module="pregnancy_print" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">این علائم را جدی بگیر</h2>
                <span class="caption">اگر هر کدام را دیدی، معطل نکن و تماس بگیر.</span>
              </div>
              <span class="card__icon card__icon--orange" aria-hidden="true"><?php echo Niva_Icons::svg( 'alert-triangle', 20 ); ?></span>
            </div>

            <div class="stack" style="gap: var(--s-2)">
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>خونریزی از واژن یا ترشح آبکی پیوسته</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>کاهش واضح حرکت جنین در یک روز</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>سردرد شدید، تاری دید یا ورم ناگهانی صورت و دست‌ها</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'alert-triangle', 16 ); ?><span>تب، درد شدید شکم یا انقباض‌های منظم پیش از هفته ۳۷</span></span>
            </div>

            <button type="button" class="btn btn--secondary btn--block" data-print>
              <?php echo Niva_Icons::svg( 'printer', 18 ); ?>
              چاپ خلاصه‌ی این هفته
            </button>
          </section>
</div>
