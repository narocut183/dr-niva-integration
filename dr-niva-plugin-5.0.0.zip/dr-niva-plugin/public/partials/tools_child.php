<?php
/**
 * Module partial: tools_child
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--tools_child" data-module="tools_child" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <h2 class="card__title">نوزاد و کودک</h2>
              <span class="card__icon card__icon--cyan" aria-hidden="true"><?php echo Niva_Icons::svg( 'smile', 20 ); ?></span>
            </div>
            <div class="tile-grid">
              <a class="tile tile--cyan" href="<?php echo esc_url( Niva_Modules::url( 'baby', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'trending-up', 22 ); ?></span>
                رشد و اندازه‌ها
              </a>
              <a class="tile tile--cyan" href="<?php echo esc_url( Niva_Modules::url( 'baby', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'scale', 22 ); ?></span>
                ثبت وزن و قد
              </a>
              <a class="tile tile--orange" href="<?php echo esc_url( Niva_Modules::url( 'baby', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'alert-triangle', 22 ); ?></span>
                علائم هشدار
              </a>
              <a class="tile tile--orange" href="<?php echo esc_url( Niva_Modules::url( 'baby', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 22 ); ?></span>
                چک‌لیست مراجعه
              </a>
            </div>
          </section>
</div>
