<?php
/**
 * Module partial: baby_baby-measure
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
$niva_profile = dr_niva()->profile->get();
$niva_birth   = (string) ( $niva_profile['baby_birth'] ?? '' );
$niva_name    = (string) ( $niva_profile['baby_name'] ?? '' );
if ( '' === $niva_birth || ! strtotime( $niva_birth ) ) {
	echo Niva_Chrome::blank( 'پروندهٔ کودک کامل نیست', 'تاریخ تولد کودک را در تنظیمات حساب ثبت کن تا سن و روند رشد درست محاسبه شوند.', 'تنظیمات حساب', 'profile', $args );
	return;
}
$niva_birth_parts = Niva_Chrome::jalali( strtotime( $niva_birth ) );
?>
<div class="niva-module niva-module--baby_baby-measure" data-baby-root data-baby-name="<?php echo esc_attr( $niva_name ); ?>" data-baby-year="<?php echo esc_attr( $niva_birth_parts[0] ); ?>" data-baby-month="<?php echo esc_attr( $niva_birth_parts[1] ); ?>" data-baby-day="<?php echo esc_attr( $niva_birth_parts[2] ); ?>" data-module="baby_baby-measure" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">ثبت اندازه‌های امروز</h2>
                <span class="caption">هر بار که اندازه می‌گیری، این‌جا وارد کن.</span>
              </div>
              <span class="card__icon card__icon--green" aria-hidden="true"><?php echo Niva_Icons::svg( 'scale', 20 ); ?></span>
            </div>

            <form class="stack" data-baby-measure hidden>
              <div class="cols">
                <div class="field">
                  <label class="field__label" for="baby-weight">وزن (کیلوگرم)</label>
                  <input id="baby-weight" class="field__input" dir="ltr" inputmode="decimal" placeholder="5.2" />
                  <p class="field__error" role="alert" data-error-for="baby-weight" hidden></p>
                </div>
                <div class="field">
                  <label class="field__label" for="baby-height">قد (سانتی‌متر)</label>
                  <input id="baby-height" class="field__input" dir="ltr" inputmode="decimal" placeholder="58" />
                  <p class="field__error" role="alert" data-error-for="baby-height" hidden></p>
                </div>
                <div class="field">
                  <label class="field__label" for="baby-head">دور سر (اختیاری)</label>
                  <input id="baby-head" class="field__input" dir="ltr" inputmode="decimal" placeholder="39" />
                </div>
              </div>

              <button type="submit" class="btn btn--primary btn--block">
                <?php echo Niva_Icons::svg( 'plus', 18 ); ?>
                ثبت و بررسی رشد
              </button>
            </form>

            <p class="field__hint" role="status" data-baby-status aria-live="polite"></p>
            <p class="field__error" role="alert" data-baby-error hidden></p>
            <div class="alert alert--success" data-baby-saved hidden>
              <span class="alert__icon"><?php echo Niva_Icons::svg( 'check-circle-2', 20 ); ?></span>
              <div class="alert__body">
                <span class="alert__title">ثبت شد</span>
                <div class="alert__text">اندازه‌های جدید ذخیره شد و نتیجه‌ی رشد به‌روزرسانی شد.</div>
              </div>
            </div>
          </section>
</div>
