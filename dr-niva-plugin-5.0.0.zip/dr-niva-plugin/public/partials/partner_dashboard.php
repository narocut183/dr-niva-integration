<?php
/**
 * Module partial: partner_dashboard — the partner's own numbers.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_partner = dr_niva()->partners->by_user( get_current_user_id() );
if ( ! $niva_partner ) {
	echo '<div class="niva-module niva-module--partner_dashboard"><div class="alert alert--info">'
		. '<span class="alert__icon">' . Niva_Icons::svg( 'info', 20 ) . '</span>'
		. '<div class="alert__body"><span class="alert__title">هنوز همکار نیستی</span>'
		. '<div class="alert__text">فرم «همکاری با ما» را پر کن تا پس از تأیید، کد معرف و پنل همکاران برایت فعال شود.</div></div></div></div>';
	return;
}

$niva_stats  = dr_niva()->partners->stats( (int) $niva_partner['id'] );
$niva_link   = home_url( '/?ref=' . $niva_partner['code'] );
$niva_recent = dr_niva()->partners->referrals( (int) $niva_partner['id'], 10 );
?>
<div class="niva-module niva-module--partner_dashboard" data-module="partner_dashboard" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">پنل همکاران</h2>
				<span class="caption"><?php echo esc_html( $niva_partner['name'] ); ?> · پورسانت <?php echo esc_html( number_format_i18n( (float) $niva_partner['commission'] ) ); ?>٪</span>
			</div>
			<span class="card__icon"><?php echo Niva_Icons::svg( 'users', 20 ); ?></span>
		</div>

		<div class="grid-2">
			<div class="stat"><span class="stat__value"><?php echo esc_html( number_format_i18n( $niva_stats['clicks'] ) ); ?></span><span class="stat__label">کلیک روی لینک</span></div>
			<div class="stat"><span class="stat__value"><?php echo esc_html( number_format_i18n( $niva_stats['signups'] ) ); ?></span><span class="stat__label">ثبت‌نام</span></div>
			<div class="stat"><span class="stat__value"><?php echo esc_html( number_format_i18n( $niva_stats['commission'] ) ); ?></span><span class="stat__label">پورسانت کل (تومان)</span></div>
			<div class="stat"><span class="stat__value"><?php echo esc_html( number_format_i18n( $niva_stats['unpaid'] ) ); ?></span><span class="stat__label">در انتظار تسویه</span></div>
		</div>

		<div class="plain-list">
			<span class="plain-row"><span class="plain-row__name">کد معرف</span><span class="plain-row__value"><bdi dir="ltr"><?php echo esc_html( (string) $niva_partner['code'] ); ?></bdi></span></span>
			<span class="plain-row"><span class="plain-row__name">لینک اختصاصی</span><span class="plain-row__value"><bdi dir="ltr"><a href="<?php echo esc_url( $niva_link ); ?>"><?php echo esc_html( $niva_link ); ?></a></bdi></span></span>
			<span class="plain-row"><span class="plain-row__name">تسویه‌شده</span><span class="plain-row__value"><?php echo esc_html( number_format_i18n( $niva_stats['paid'] ) ); ?> تومان</span></span>
		</div>

		<?php if ( $niva_recent ) : ?>
			<h3>آخرین معرفی‌ها</h3>
			<div class="table-wrap">
				<table class="table">
					<thead><tr><th>تاریخ</th><th>وضعیت</th><th>مبلغ سفارش</th><th>پورسانت</th></tr></thead>
					<tbody>
					<?php foreach ( $niva_recent as $niva_row ) : ?>
						<tr>
							<td><?php echo esc_html( Niva_Chrome::format_datetime( (string) $niva_row['created_at'] ) ); ?></td>
							<td><?php echo 'signup' === $niva_row['status'] ? 'ثبت‌نام' : 'خرید'; ?></td>
							<td><?php echo esc_html( number_format_i18n( (float) $niva_row['amount'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( (float) $niva_row['commission'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		<?php endif; ?>

		<p class="caption">برای تسویه، پورسانت‌های «در انتظار تسویه» هر ماه پرداخت می‌شوند.</p>
	</section>
</div>
