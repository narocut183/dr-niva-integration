<?php
/**
 * Module partial: pregnancy_week
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
if ( ! is_user_logged_in() || ! dr_niva()->profile || ! dr_niva()->profile->is_pregnant() ) {
	echo Niva_Chrome::blank( 'بارداری ثبت نشده', 'اگر باردار هستی، در تنظیمات حساب فعالش کن تا این بخش با هفتهٔ واقعی خودت ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}

$niva_week = dr_niva()->profile->pregnancy_week();
$niva_left = dr_niva()->profile->days_left();
$niva_today = dr_niva()->messages ? dr_niva()->messages->today() : null;
$niva_progress = min( 100, (int) round( ( $niva_week / 40 ) * 100 ) );
?>
<div class="niva-module niva-module--pregnancy_week" data-module="pregnancy_week" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="flex" style="gap: var(--s-3); min-width: 0">
				<span class="card__icon card__icon--purple" aria-hidden="true"><?php echo Niva_Icons::svg( 'baby', 20 ); ?></span>
				<div class="stack" style="gap: 2px">
					<h2 class="card__title">این هفته چه مهم است</h2>
					<span class="caption"><?php echo esc_html( Niva_Chrome::digits( $niva_left ) . ' روز تا زایمان' ); ?></span>
				</div>
			</div>
			<span class="badge badge--purple"><?php echo esc_html( 'هفته ' . Niva_Chrome::digits( $niva_week ) ); ?> از ۴۰</span>
		</div>

		<div class="progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="<?php echo esc_attr( $niva_progress ); ?>" aria-label="پیشرفت بارداری">
			<div class="progress__fill progress__fill--warmth" style="width: <?php echo esc_attr( $niva_progress ); ?>%"></div>
		</div>

		<div class="stack" style="gap: var(--s-2)">
			<?php if ( $niva_today && 'pregnancy' === ( $niva_today['_audience'] ?? '' ) ) : ?>
				<h3 class="card__title"><?php echo esc_html( $niva_today['title'] ); ?></h3>
				<p><?php echo wp_kses_post( $niva_today['body'] ); ?></p>
				<?php if ( ! empty( $niva_today['action'] ) ) : ?>
					<div class="alert alert--info"><div class="alert__body"><span class="alert__title">یادآوری این هفته</span><div class="alert__text"><?php echo esc_html( $niva_today['action'] ); ?></div></div></div>
				<?php endif; ?>
			<?php else : ?>
				<p class="muted">محتوای تأییدشدهٔ این هفته هنوز در کتابخانهٔ سایت بارگذاری نشده است.</p>
			<?php endif; ?>
		</div>
		<p class="caption">هفته و زمان‌بندی از تاریخ‌های ثبت‌شدهٔ حساب محاسبه شده‌اند؛ این اطلاعات جای مراقبت پزشک یا ماما را نمی‌گیرند.</p>
	</section>
</div>
