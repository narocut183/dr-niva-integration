<?php
/**
 * Module partial: family_panel — seats, invite code and members of a family plan.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}
$niva_summary = dr_niva()->plans->summary( get_current_user_id() );
$niva_family  = $niva_summary['family'];
?>
<div class="niva-module niva-module--family_panel" data-module="family_panel" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">اشتراک خانوادگی</h2>
				<span class="caption">تا <?php echo esc_html( number_format_i18n( dr_niva()->plans->limit( get_current_user_id(), 'family_seats' ) ) ); ?> نفر می‌توانند از این اشتراک استفاده کنند</span>
			</div>
			<span class="card__icon"><?php echo Niva_Icons::svg( 'users', 20 ); ?></span>
		</div>

		<?php if ( $niva_family ) : ?>
			<div class="plain-list">
				<span class="plain-row">
					<span class="plain-row__name">کد دعوت</span>
					<span class="plain-row__value"><bdi dir="ltr"><?php echo esc_html( $niva_family['code'] ); ?></bdi></span>
				</span>
				<span class="plain-row">
					<span class="plain-row__name">صندلی خالی</span>
					<span class="plain-row__value"><?php echo esc_html( number_format_i18n( $niva_family['seats_left'] ) ); ?></span>
				</span>
			</div>

			<p class="caption">کد را برای اعضای خانواده بفرست؛ آن‌ها در همین بخش کد را وارد می‌کنند و سهمیه‌ی اشتراک روی حسابشان فعال می‌شود.</p>

			<?php if ( $niva_family['members'] ) : ?>
				<div class="plain-list" data-family-list>
					<?php foreach ( $niva_family['members'] as $niva_member_row ) : ?>
						<?php $niva_user = get_userdata( (int) $niva_member_row['member_id'] ); ?>
						<span class="plain-row">
							<span class="plain-row__name"><?php echo esc_html( $niva_user ? $niva_user->display_name : '#' . (int) $niva_member_row['member_id'] ); ?></span>
							<span class="plain-row__value">
								<button type="button" class="btn btn--danger btn--sm" data-family-remove="<?php echo esc_attr( (int) $niva_member_row['member_id'] ); ?>">حذف</button>
							</span>
						</span>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<div class="empty-state">
					<span class="empty-state__title">هنوز کسی اضافه نشده است.</span>
				</div>
			<?php endif; ?>

		<?php else : ?>
			<div class="empty-state">
				<span class="empty-state__title">اشتراک خانوادگی فعالی نداری.</span>
				<span class="caption">با ارتقا به پلن خانوادگی، تا چند نفر از یک سهمیه استفاده می‌کنند.</span>
				<a class="btn btn--primary btn--sm" href="<?php echo esc_url( $niva_summary['upgrade_url'] ); ?>">دیدن پلن خانوادگی</a>
			</div>
		<?php endif; ?>

		<form class="stack" data-family-accept-form>
			<label class="field">
				<span class="field__label">کد دعوت یا معرف اشتراک خانوادگی</span>
				<input class="field__input" id="family-code" name="code" type="text" dir="ltr" autocomplete="off" placeholder="A1B2C3" />
			</label>
			<button type="submit" class="btn btn--secondary btn--block">فعال‌کردن با کد</button>
			<span class="field__hint" data-family-message hidden aria-live="polite"></span>
		</form>
	</section>
</div>
