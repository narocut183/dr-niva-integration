<?php
/**
 * Module partial: tools_health
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--tools_health" data-module="tools_health" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <h2 class="card__title">سلامت و آزمایش</h2>
              <span class="card__icon card__icon--green" aria-hidden="true"><?php echo Niva_Icons::svg( 'file-text', 20 ); ?></span>
            </div>
            <div class="tile-grid">
              <a class="tile tile--green" href="<?php echo esc_url( Niva_Modules::url( 'lab', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'search', 22 ); ?></span>
                تحلیل آزمایش
              </a>
              <a class="tile tile--green" href="<?php echo esc_url( Niva_Modules::url( 'lab', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'printer', 22 ); ?></span>
                برگه پزشک
              </a>
              <a class="tile tile--teal" href="<?php echo esc_url( Niva_Modules::url( 'mind', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'clipboard-list', 22 ); ?></span>
                پرسشنامه حال
              </a>
              <a class="tile tile--teal" href="<?php echo esc_url( Niva_Modules::url( 'baby', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'syringe', 22 ); ?></span>
                یادآور واکسن
              </a>
            </div>
          </section>
</div>
