<?php
/**
 * Module partial: tools_women
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--tools_women" data-module="tools_women" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <h2 class="card__title">بانوان و بارداری</h2>
              <span class="card__icon card__icon--pink" aria-hidden="true"><?php echo Niva_Icons::svg( 'droplet', 20 ); ?></span>
            </div>
            <div class="tile-grid">
              <a class="tile tile--pink" href="<?php echo esc_url( Niva_Modules::url( 'cycle', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'calendar-days', 22 ); ?></span>
                تقویم چرخه
              </a>
              <a class="tile tile--pink" href="<?php echo esc_url( Niva_Modules::url( 'cycle', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'droplet', 22 ); ?></span>
                ثبت علائم
              </a>
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'pregnancy', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'baby', 22 ); ?></span>
                مسیر بارداری
              </a>
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'pregnancy', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'scale', 22 ); ?></span>
                پیگیری وزن
              </a>
            </div>
          </section>
</div>
