<?php
/**
 * Module partial: home_status — «وضعیت امروزت» on the dashboard.
 *
 * Nothing on this card is sample data. Each row is either built from the user's
 * own profile or says plainly that it is not filled in yet — a brand new
 * account used to see a fake cycle day, a fake pregnancy week and a fake lab
 * result all at once. Only the presentation changed in 5.0.0: every row is now
 * an icon tile + title + caption + badge, as in the approved design.
 *
 * @var array $args
 * @package DrNiva
 */

defined( 'ABSPATH' ) || exit;

$niva_cycle = Niva_Chrome::cycle_state();
$niva_sex   = strtolower( (string) Niva_Chrome::flag( 'sex' ) );
$niva_preg  = in_array( strtolower( (string) Niva_Chrome::flag( 'pregnant' ) ), array( '1', 'yes', 'true' ), true );
$niva_due   = (string) Niva_Chrome::flag( 'due_date' );
$niva_baby  = (string) Niva_Chrome::flag( 'baby_name' );
$niva_birth = (string) Niva_Chrome::flag( 'baby_birth' );
$niva_labs  = Niva_Labs::latest();
$niva_rows  = array();

if ( 'male' !== $niva_sex ) {
	if ( $niva_cycle['has_data'] ) {
		$niva_days    = (int) $niva_cycle['next_in_days'];
		$niva_rows[] = array(
			'link'  => Niva_Modules::url( 'cycle', $args ),
			'name'  => 'چرخه',
			'text'  => 'روز ' . $niva_cycle['cycle_day_fa'] . ' — پریود بعدی ' . $niva_cycle['next_date'],
			'badge' => $niva_days . ' روز تا پریود',
			'tone'  => 'info',
			'icon'  => 'droplet',
			'flavor' => 'pink',
		);
	} else {
		$niva_rows[] = array(
			'link'  => Niva_Modules::url( 'profile', $args ),
			'name'  => 'چرخه',
			'text'  => 'هنوز ثبت نشده — تاریخ آخرین پریود را وارد کن',
			'badge' => 'تنظیم کن',
			'tone'  => 'soft',
			'icon'  => 'droplet',
			'flavor' => 'pink',
		);
	}
}

if ( $niva_preg ) {
	$niva_left = 0;
	$niva_week = 0;
	if ( '' !== $niva_due && strtotime( $niva_due ) ) {
		$niva_left = (int) floor( ( strtotime( 'today', strtotime( $niva_due ) ) - strtotime( 'today' ) ) / DAY_IN_SECONDS );
		$niva_week = max( 1, min( 42, 40 - (int) ceil( $niva_left / 7 ) ) );
	}
	$niva_rows[] = array(
		'link'  => Niva_Modules::url( 'pregnancy', $args ),
		'name'  => 'بارداری',
		'text'  => $niva_week ? 'هفته ' . Niva_Chrome::digits( $niva_week ) : 'بارداری فعال است',
		'badge' => $niva_left > 0 ? Niva_Chrome::digits( $niva_left ) . ' روز مانده' : 'تاریخ زایمان ثبت نشده',
		'tone'  => 'info',
		'icon'  => 'heart',
		'flavor' => 'purple',
	);
}

if ( '' !== $niva_baby ) {
	$niva_age = '';
	if ( '' !== $niva_birth && strtotime( $niva_birth ) ) {
		$niva_days_old = (int) floor( ( strtotime( 'today' ) - strtotime( 'today', strtotime( $niva_birth ) ) ) / DAY_IN_SECONDS );
		$niva_age      = $niva_days_old < 60
			? Niva_Chrome::digits( $niva_days_old ) . ' روز'
			: Niva_Chrome::digits( (int) floor( $niva_days_old / 30 ) ) . ' ماه';
	}
	$niva_rows[] = array(
		'link'  => Niva_Modules::url( 'baby', $args ),
		'name'  => 'کودک',
		'text'  => $niva_baby . ( $niva_age ? ' — ' . $niva_age : '' ),
		'badge' => 'پرونده',
		'tone'  => 'soft',
		'icon'  => 'baby',
		'flavor' => 'cyan',
	);
}

$niva_last_lab = $niva_labs ? reset( $niva_labs ) : null;
$niva_rows[]   = array(
	'link'  => Niva_Modules::url( 'lab', $args ),
	'name'  => 'آخرین آزمایش',
	'text'  => $niva_last_lab
		? Niva_Labs::label( $niva_last_lab['marker'] ) . ' — ' . Niva_Chrome::digits( $niva_last_lab['value'] ) . ' ' . Niva_Labs::unit( $niva_last_lab['marker'] )
		: 'هنوز نتیجه‌ای ثبت نشده',
	'badge' => $niva_last_lab && ! empty( $niva_last_lab['date'] )
		? Niva_Chrome::format_date( (string) $niva_last_lab['date'] )
		: 'ثبت کن',
	'tone'  => $niva_last_lab ? 'info' : 'soft',
	'icon'  => 'file-text',
	'flavor' => 'green',
);
?>
<div class="niva-module niva-module--home_status" data-module="home_status" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">وضعیت امروزت</h2>
				<span class="caption">برای جزئیات، روی هر مورد بزن</span>
			</div>
			<span class="card__icon"><?php echo Niva_Icons::svg( 'activity', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		</div>

		<div class="plain-list">
			<?php foreach ( $niva_rows as $niva_row ) : ?>
				<?php
				$niva_flavor = isset( $niva_row['flavor'] ) ? (string) $niva_row['flavor'] : '';
				$niva_tone   = 'info' === $niva_row['tone'] ? 'badge--info' : 'badge--soft';
				?>
				<a class="settings-row" href="<?php echo esc_url( $niva_row['link'] ); ?>">
					<span class="settings-row__icon settings-row__icon--<?php echo esc_attr( $niva_flavor ); ?>">
						<?php echo Niva_Icons::svg( (string) $niva_row['icon'], 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					</span>
					<span class="settings-row__body">
						<span class="settings-row__title"><?php echo esc_html( $niva_row['name'] ); ?></span>
						<span class="settings-row__text"><?php echo esc_html( $niva_row['text'] ); ?></span>
					</span>
					<span class="badge <?php echo esc_attr( $niva_tone ); ?>"><?php echo esc_html( $niva_row['badge'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</div>
	</section>
</div>
