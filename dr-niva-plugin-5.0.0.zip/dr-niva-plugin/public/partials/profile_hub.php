<?php
/**
 * Module partial: profile_hub — the account card + settings list (2.0.0).
 *
 * Redesigned around real data: the avatar is the picture the user actually
 * uploaded, the cycle summary shows the numbers they actually entered (or says
 * they are not set), and rows that do not apply to this person (pregnancy for
 * someone who is not pregnant) are simply absent rather than greyed out.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

wp_enqueue_style( 'dr-niva-onboarding' );
wp_enqueue_script( 'dr-niva-onboarding' );

$niva_user    = wp_get_current_user();
$niva_uid     = (int) $niva_user->ID;
$niva_profile = dr_niva()->profile->get( $niva_uid );
$niva_name    = trim( (string) $niva_profile['full_name'] );
if ( '' === $niva_name ) {
	$niva_name = (string) $niva_user->display_name;
}
$niva_initial = function_exists( 'mb_substr' ) ? mb_substr( $niva_name, 0, 1 ) : substr( $niva_name, 0, 1 );
$niva_avatar  = (string) $niva_profile['avatar_url'];
$niva_phone   = '';
foreach ( array( 'niva_phone', 'billing_phone' ) as $niva_phone_key ) {
	$niva_value = (string) get_user_meta( $niva_uid, $niva_phone_key, true );
	if ( '' !== trim( $niva_value ) ) {
		$niva_phone = $niva_value;
		break;
	}
}
$niva_plan   = dr_niva()->plans ? dr_niva()->plans->plan_of( $niva_uid ) : array( 'label' => 'رایگان', 'active' => false, 'expires' => '' );
$niva_wallet = dr_niva()->wallet ? dr_niva()->wallet->summary( $niva_uid ) : array( 'balance' => 0 );
$niva_since  = $niva_user->user_registered ? Niva_Chrome::format_datetime_gmt( (string) $niva_user->user_registered ) : '';

/* Cycle summary — the user's own numbers, or an explicit "not set yet". */
$niva_cycle_len  = trim( (string) $niva_profile['cycle_length'] );
$niva_period_len = trim( (string) $niva_profile['period_length'] );
$niva_cycle_txt  = ( '' === $niva_cycle_len && '' === $niva_period_len )
	? ''
	: 'طول هر سیکل: ' . ( '' !== $niva_cycle_len ? esc_html( Niva_Chrome::digits( $niva_cycle_len ) ) . ' روز' : 'ثبت نشده' )
		. ' · مدت پریود: ' . ( '' !== $niva_period_len ? esc_html( Niva_Chrome::digits( $niva_period_len ) ) . ' روز' : 'ثبت نشده' );

$niva_completion = isset( $niva_profile['completion'] ) && is_array( $niva_profile['completion'] )
	? $niva_profile['completion']
	: array( 'percent' => 0, 'complete' => false );
$niva_show_completion = ! $niva_completion['complete'] && dr_niva()->settings->is_on( 'onboarding_wizard_enabled' );

$niva_insights = class_exists( 'Niva_Insights' );
$niva_stats    = array(
	array( 'value' => $niva_insights ? Niva_Insights::usage_count( $niva_uid, 30 ) : 0, 'label' => 'کار در ۳۰ روز' ),
	array( 'value' => $niva_insights ? Niva_Insights::open_reminders( $niva_uid ) : 0, 'label' => 'یادآور فعال' ),
	array( 'value' => $niva_insights ? Niva_Insights::streak( $niva_uid ) : 0, 'label' => 'روز پیاپی' ),
	array( 'value' => (int) $niva_wallet['balance'], 'label' => 'اعتبار' ),
);

/*
 * The rows, in the order the reference design uses. `when` is evaluated here
 * rather than in the template so an inapplicable row never renders at all.
 */
$niva_pregnant = ! empty( $niva_profile['pregnant'] );
$niva_rows     = array(
	array(
		'icon'  => 'chart-line',
		'title' => 'آمار و تحلیل',
		'text'  => 'پروندهٔ آزمایش، نمودارها و روند سلامت',
		'key'   => 'lab',
	),
	array(
		'icon'  => 'heart-handshake',
		'title' => 'همراهی',
		'text'  => 'کد همراهی برای همسر، مادر یا پزشک',
		'key'   => 'companion',
	),
	array(
		'icon'  => 'baby',
		'title' => 'بارداری',
		'text'  => 'هفتهٔ بارداری، چک‌لیست و تاریخ زایمان',
		'key'   => 'pregnancy',
		'when'  => $niva_pregnant,
	),
	array(
		'icon'  => 'message-circle',
		'title' => 'مشاوره‌های من',
		'text'  => 'گفتگوهای ذخیره‌شده با مشاور هوشمند',
		'key'   => 'advisor',
	),
	array(
		'icon'  => 'wallet',
		'title' => 'تراکنش‌ها و کیف پول',
		'text'  => 'موجودی، مصرف و تاریخچهٔ تراکنش',
		'key'   => 'wallet',
	),
	array(
		'icon'  => 'bell',
		'title' => 'اعلان‌ها',
		'text'  => 'صندوق اعلان‌های داخلی',
		'key'   => 'notifications',
	),
	array(
		'icon'  => 'clock',
		'title' => 'یادآور دارو',
		'text'  => 'دارو، ویتامین و قرار',
		'key'   => 'reminders',
	),
	array(
		'icon'  => 'moon',
		'title' => 'حالت نمایش و تنظیمات',
		'text'  => 'روشن، تیره، فونت و ساعت سکوت',
		'key'   => 'profile',
	),
	array(
		'icon'  => 'help-circle',
		'title' => 'پرسش‌های متداول',
		'text'  => 'پاسخ کوتاه به سؤال‌های رایج',
		'key'   => 'about',
	),
	array(
		'icon'  => 'info',
		'title' => 'درباره دکتر نیوا',
		'text'  => 'هدف سرویس و قواعد ایمنی',
		'key'   => 'about',
	),
);
?>
<div class="niva-module niva-module--profile_hub" data-module="profile_hub" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<div class="stack--lg">

		<section class="nv-profile-head">
			<?php if ( '' !== $niva_avatar ) : ?>
				<span class="nv-avatar nv-avatar--lg">
					<img src="<?php echo esc_url( $niva_avatar ); ?>" alt="<?php echo esc_attr( $niva_name ); ?>" />
				</span>
			<?php else : ?>
				<span class="nv-avatar nv-avatar--lg" aria-hidden="true"><?php echo esc_html( $niva_initial ); ?></span>
			<?php endif; ?>
			<span class="nv-profile-head__name"><?php echo esc_html( $niva_name ); ?></span>
			<span class="nv-profile-head__meta" dir="auto">
				<?php echo esc_html( '' !== $niva_phone ? $niva_phone : ( $niva_user->user_email ? $niva_user->user_email : $niva_user->user_login ) ); ?>
			</span>
			<span class="badge"><?php echo esc_html( $niva_plan['label'] ); ?></span>
		</section>

		<div class="stat-grid">
			<?php foreach ( $niva_stats as $niva_stat ) : ?>
				<div class="stat">
					<span class="stat__value"><?php echo esc_html( Niva_Chrome::digits( number_format_i18n( (int) $niva_stat['value'] ) ) ); ?></span>
					<span class="stat__label"><?php echo esc_html( $niva_stat['label'] ); ?></span>
				</div>
			<?php endforeach; ?>
		</div>

		<?php if ( $niva_since ) : ?>
			<p class="caption is-center">عضو از <?php echo esc_html( Niva_Chrome::digits( $niva_since ) ); ?></p>
		<?php endif; ?>

		<?php if ( $niva_show_completion ) : ?>
			<section class="alert alert--caution" data-niva-completion
				data-rest="<?php echo esc_url( rest_url( Niva_Rest::NS . '/' ) ); ?>"
				data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>">
				<span class="alert__icon"><?php echo Niva_Icons::svg( 'alert-triangle', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<div class="alert__body">
					<span class="alert__title">تکمیل پروفایل — <?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_completion['percent'] ) ); ?>٪</span>
					<div class="alert__text">
						<?php if ( '' !== $niva_cycle_txt ) : ?>
							<?php echo wp_kses_post( $niva_cycle_txt ); ?>
						<?php else : ?>
							هنوز طول سیکل و مدت پریود را ثبت نکرده‌ای.
						<?php endif; ?>
					</div>
					<div class="progress" aria-hidden="true">
						<span class="progress__fill" style="width:<?php echo esc_attr( (string) (int) $niva_completion['percent'] ); ?>%"></span>
					</div>
					<div class="alert__actions">
						<a class="btn btn--primary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'onboarding_wizard', array(), home_url( '/?dr_niva_wizard=1' ) ) ); ?>">تکمیل کن</a>
						<a class="btn btn--ghost btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>">ویرایش</a>
					</div>
				</div>
			</section>
		<?php elseif ( '' !== $niva_cycle_txt ) : ?>
			<section class="card">
				<div class="card__head">
					<div class="stack" style="gap: 2px">
						<h2 class="card__title">خلاصهٔ چرخه</h2>
						<span class="caption"><?php echo wp_kses_post( $niva_cycle_txt ); ?></span>
					</div>
					<span class="card__icon card__icon--pink"><?php echo Niva_Icons::svg( 'droplet', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				</div>
				<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>">ویرایش</a>
			</section>
		<?php endif; ?>

		<section class="card">
			<?php foreach ( $niva_rows as $niva_row ) : ?>
				<?php if ( isset( $niva_row['when'] ) && ! $niva_row['when'] ) { continue; } ?>
				<a class="settings-row" href="<?php echo esc_url( Niva_Modules::url( $niva_row['key'], $args ) ); ?>" data-profile-sheet="<?php echo esc_attr( $niva_row['key'] ); ?>" aria-controls="profile-menu-sheet" aria-expanded="false">
					<span class="settings-row__icon"><?php echo Niva_Icons::svg( $niva_row['icon'], 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="settings-row__body">
						<span class="settings-row__title"><?php echo esc_html( $niva_row['title'] ); ?></span>
						<span class="settings-row__text"><?php echo esc_html( $niva_row['text'] ); ?></span>
					</span>
					<span class="settings-row__go"><?php echo Niva_Icons::svg( 'chevron-left', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				</a>
			<?php endforeach; ?>

			<a class="settings-row" href="<?php echo esc_url( Niva_Modules::url( 'visibility', $args ) ); ?>">
				<span class="settings-row__icon settings-row__icon--teal"><?php echo Niva_Icons::svg( 'eye-off', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span class="settings-row__body">
					<span class="settings-row__title">چرا بعضی بخش‌ها را نمی‌بینم؟</span>
					<span class="settings-row__text">فهرست بخش‌های فعال و علت پنهان‌بودن بقیه</span>
				</span>
				<span class="settings-row__go"><?php echo Niva_Icons::svg( 'chevron-left', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			</a>

			<a class="settings-row settings-row--danger" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">
				<span class="settings-row__icon"><?php echo Niva_Icons::svg( 'arrow-left', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span class="settings-row__body">
					<span class="settings-row__title">خروج از حساب</span>
					<span class="settings-row__text">پایان نشست در این دستگاه</span>
				</span>
				<span class="settings-row__go"><?php echo Niva_Icons::svg( 'chevron-left', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			</a>
		</section>

		<div class="sheet profile-sheet" id="profile-menu-sheet" hidden>
			<button type="button" class="sheet__scrim profile-sheet__backdrop" data-profile-sheet-close aria-label="بستن"></button>
			<section class="sheet__panel profile-sheet__panel" role="dialog" aria-modal="true" aria-labelledby="profile-sheet-title" tabindex="-1">
				<div class="sheet__grab profile-sheet__grab" data-profile-sheet-grab aria-hidden="true"></div>
				<div class="sheet__head">
					<h2 class="profile-sheet__sr-title" id="profile-sheet-title"></h2>
					<button type="button" class="sheet__close" data-profile-sheet-close aria-label="بستن">&#215;</button>
				</div>
				<div class="profile-sheet__content" data-profile-sheet-content aria-live="polite"></div>
			</section>
		</div>

	</div>
</div>
