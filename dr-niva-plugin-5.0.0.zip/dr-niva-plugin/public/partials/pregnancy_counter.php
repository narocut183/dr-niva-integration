<?php
/**
 * Module partial: pregnancy_counter
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() || ! dr_niva()->profile || ! dr_niva()->profile->is_pregnant() ) {
	echo Niva_Chrome::blank( 'بارداری ثبت نشده', 'برای نمایش اطلاعات شخصی، تاریخ بارداری را در تنظیمات حساب ثبت کن.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--pregnancy_counter" data-module="pregnancy_counter" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">پیگیری وزن و حرکت جنین</h2>
			</div>
			<span class="card__icon card__icon--purple" aria-hidden="true"><?php echo Niva_Icons::svg( 'scale', 20 ); ?></span>
		</div>
		<div class="empty-state">
			<?php echo Niva_Icons::svg( 'scale', 26 ); ?>
			<p class="muted">هنوز داده‌ای برای وزن یا حرکت جنین در پروندهٔ تو ثبت نشده است. این نسخه چیزی را حدس نمی‌زند؛ برای پیگیری، از دستور پزشک یا مامایت پیروی کن.</p>
		</div>
	</section>
</div>
