<?php
/**
 * Module partial: wallet (data driven).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--wallet" data-module="wallet" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<?php echo dr_niva()->orders ? dr_niva()->orders->wallet_markup() : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
