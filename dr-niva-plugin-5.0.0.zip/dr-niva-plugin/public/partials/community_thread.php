<?php
/**
 * Module partial: community_thread — one question with its answers (2.0.0).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

Niva_Community::enqueue();

$niva_community = dr_niva()->community instanceof Niva_Community ? dr_niva()->community : new Niva_Community();
$niva_id        = isset( $_GET['thread'] ) ? absint( wp_unslash( $_GET['thread'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$niva_thread    = $niva_id ? $niva_community->thread( $niva_id ) : array();
$niva_back      = Niva_Modules::url( 'community_home', array(), home_url( '/' ) );
$niva_is_mod    = current_user_can( 'manage_options' );

if ( ! $niva_thread ) {
	?>
	<div class="niva-module niva-module--community_thread" data-module="community_thread" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
		<div class="empty-state">
			<?php echo Niva_Icons::svg( 'search', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span class="empty-state__title">این گفتگو پیدا نشد</span>
			<span class="caption">ممکن است حذف شده باشد یا نشانی اشتباه باشد.</span>
			<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( $niva_back ); ?>">بازگشت به فهرست گفتگوها</a>
		</div>
	</div>
	<?php
	return;
}

if ( Niva_Community::STATUS_PUBLISH !== $niva_thread['status'] && ! $niva_is_mod && (int) get_current_user_id() !== (int) $niva_thread['user_id'] ) {
	?>
	<div class="niva-module niva-module--community_thread" data-module="community_thread" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
		<div class="empty-state">
			<?php echo Niva_Icons::svg( 'clock', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span class="empty-state__title">این گفتگو در انتظار بازبینی است</span>
			<span class="caption">بعد از بررسی کوتاه توسط تیم دکتر نیوا نمایش داده می‌شود.</span>
			<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( $niva_back ); ?>">بازگشت</a>
		</div>
	</div>
	<?php
	return;
}

$niva_comments = $niva_community->comments( $niva_id, isset( $_GET['order'] ) && 'helpful' === sanitize_key( wp_unslash( $_GET['order'] ) ) ? 'helpful' : 'newest' ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$niva_closed    = Niva_Community::STATUS_CLOSED === $niva_thread['status'];
$niva_my_react  = false;
if ( is_user_logged_in() ) {
	global $wpdb;
	$niva_my_react = (bool) $wpdb->get_var( // phpcs:ignore WordPress.DB
		$wpdb->prepare( 'SELECT id FROM ' . Niva_DB::table( 'community_reactions' ) . " WHERE object_type = 'thread' AND object_id = %d AND user_id = %d AND type = 'like'", $niva_id, (int) get_current_user_id() )
	);
}
?>
<div class="niva-module niva-module--community_thread" data-module="community_thread" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>"
	data-niva-community="<?php echo esc_attr( rest_url( Niva_Rest::NS . '/community/' ) ); ?>"
	data-niva-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
	data-niva-thread="<?php echo esc_attr( (string) $niva_id ); ?>">

	<a class="community-back" href="<?php echo esc_url( $niva_back ); ?>">
		<?php echo Niva_Icons::svg( 'chevron-left', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		فهرست گفتگوها
	</a>

	<article class="card community-thread">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--cyan"><?php echo Niva_Icons::svg( 'message-heart', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<div class="stack" style="gap: 4px">
					<h1 class="card__title"><?php echo esc_html( $niva_thread['title'] ); ?></h1>
					<?php if ( $niva_thread['category_title'] ) : ?>
						<span class="community-chip community-chip--<?php echo esc_attr( (string) $niva_thread['category_color'] ); ?>"><?php echo esc_html( (string) $niva_thread['category_title'] ); ?></span>
					<?php endif; ?>
				</div>
			</div>
		</div>

		<div class="community-card__meta">
			<span class="community-avatar" aria-hidden="true">
				<?php if ( '' !== $niva_thread['author_avatar'] ) : ?>
					<img src="<?php echo esc_url( $niva_thread['author_avatar'] ); ?>" alt="" width="28" height="28" />
				<?php else : ?>
					<?php echo esc_html( $niva_thread['author_letter'] ); ?>
				<?php endif; ?>
			</span>
			<span class="community-card__author"><?php echo esc_html( $niva_thread['author_name'] ); ?></span>
			<span class="community-card__dot">·</span>
			<span><?php echo esc_html( $niva_thread['time_ago'] ); ?></span>
			<span class="community-card__count"><?php echo esc_html( Niva_Chrome::digits( (string) $niva_thread['views'] ) ); ?> بازدید</span>
			<?php if ( $niva_closed ) : ?>
				<span class="community-badge">بسته‌شده</span>
			<?php endif; ?>
		</div>

		<div class="community-thread__body"><?php echo wp_kses_post( wpautop( (string) $niva_thread['body'] ) ); ?></div>

		<div class="community-actions">
			<button type="button" class="btn btn--ghost btn--sm<?php echo $niva_my_react ? ' is-active' : ''; ?>"
				data-niva-community-react="<?php echo esc_attr( (string) $niva_id ); ?>" data-object-type="thread"
				aria-pressed="<?php echo $niva_my_react ? 'true' : 'false'; ?>">
				<?php echo Niva_Icons::svg( 'heart', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				مفید بود (<span data-niva-community-likes><?php echo esc_html( Niva_Chrome::digits( (string) $niva_thread['likes'] ) ); ?></span>)
			</button>
			<button type="button" class="btn btn--ghost btn--sm" data-niva-community-report="<?php echo esc_attr( (string) $niva_id ); ?>" data-object-type="thread">گزارش تخلف</button>
			<?php if ( $niva_thread['mine'] || $niva_is_mod ) : ?>
				<a class="btn btn--ghost btn--sm" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-community' ) ); ?>">مدیریت این گفتگو</a>
			<?php endif; ?>
		</div>
	</article>

	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--purple"><?php echo Niva_Icons::svg( 'message-circle', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h2 class="card__title">پاسخ‌ها (<?php echo esc_html( Niva_Chrome::digits( (string) count( $niva_comments ) ) ); ?>)</h2>
			</div>
			<div class="community-seg">
				<a class="<?php echo ( isset( $_GET['order'] ) && 'helpful' === $_GET['order'] ) ? 'is-active' : ''; ?>" aria-selected="<?php echo ( isset( $_GET['order'] ) && 'helpful' === $_GET['order'] ) ? 'true' : 'false'; ?>" href="<?php echo esc_url( add_query_arg( array( 'thread' => $niva_id, 'order' => 'helpful' ), $niva_back ) ); ?>">مفیدترین</a>
				<a class="<?php echo ( ! isset( $_GET['order'] ) || 'newest' === $_GET['order'] ) ? 'is-active' : ''; ?>" aria-selected="<?php echo ( ! isset( $_GET['order'] ) || 'newest' === $_GET['order'] ) ? 'true' : 'false'; ?>" href="<?php echo esc_url( add_query_arg( array( 'thread' => $niva_id ), $niva_back ) ); ?>">جدیدترین</a>
			</div>
		</div>

		<?php if ( ! $niva_comments ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'message-circle', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">هنوز پاسخی ثبت نشده</span>
				<span class="caption">می‌توانی اول از همه تجربه‌ات را بنویسی.</span>
			</div>
		<?php else : ?>
			<ul class="community-comments" data-niva-community-comments>
				<?php foreach ( $niva_comments as $niva_comment ) : ?>
					<li class="community-comment" data-comment="<?php echo esc_attr( (string) $niva_comment['id'] ); ?>">
						<div class="community-card__meta">
							<span class="community-avatar" aria-hidden="true">
								<?php if ( '' !== $niva_comment['author_avatar'] ) : ?>
									<img src="<?php echo esc_url( $niva_comment['author_avatar'] ); ?>" alt="" width="28" height="28" />
								<?php else : ?>
									<?php echo esc_html( $niva_comment['author_letter'] ); ?>
								<?php endif; ?>
							</span>
							<span class="community-card__author"><?php echo esc_html( $niva_comment['author_name'] ); ?></span>
							<span class="community-card__dot">·</span>
							<span><?php echo esc_html( $niva_comment['time_ago'] ); ?></span>
							<?php if ( (int) $niva_comment['parent_id'] > 0 ) : ?>
								<span class="community-badge">پاسخ به یک نظر</span>
							<?php endif; ?>
						</div>
						<div class="community-comment__body"><?php echo wp_kses_post( wpautop( (string) $niva_comment['body'] ) ); ?></div>
						<div class="community-actions">
							<button type="button" class="btn btn--ghost btn--sm" data-niva-community-react="<?php echo esc_attr( (string) $niva_comment['id'] ); ?>" data-object-type="comment">
								مفید بود (<span data-niva-community-likes><?php echo esc_html( Niva_Chrome::digits( (string) $niva_comment['likes'] ) ); ?></span>)
							</button>
							<button type="button" class="btn btn--ghost btn--sm" data-niva-community-reply="<?php echo esc_attr( (string) $niva_comment['id'] ); ?>">پاسخ</button>
							<button type="button" class="btn btn--ghost btn--sm" data-niva-community-report="<?php echo esc_attr( (string) $niva_comment['id'] ); ?>" data-object-type="comment">گزارش</button>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>

	<?php if ( $niva_closed ) : ?>
		<div class="alert alert--info">
			<span class="alert__icon"><?php echo Niva_Icons::svg( 'clock', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<div class="alert__body">
				<div class="alert__text">این گفتگو بسته شده است و نظر تازه نمی‌پذیرد.</div>
			</div>
		</div>
	<?php else : ?>
		<form class="card" data-niva-community-comment>
			<div class="card__head">
				<div class="flex">
					<span class="card__icon card__icon--green"><?php echo Niva_Icons::svg( 'message-plus', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="card__title">پاسخ تو</h2>
				</div>
			</div>
			<input type="hidden" name="parent_id" value="0" />
			<label class="field">
				<span class="field__label">متن پاسخ</span>
				<textarea class="field__input" name="body" rows="4" required placeholder="تجربه یا اطلاعاتت را بنویس…"></textarea>
			</label>
			<p class="caption">
				توصیهٔ دارویی یا دوز ننویس؛ چنین پاسخ‌هایی پیش از نمایش بازبینی می‌شوند.
				شماره و لینک به‌صورت خودکار پنهان می‌شود.
			</p>
			<button type="submit" class="btn btn--primary">ثبت پاسخ</button>
			<span class="field__hint" data-niva-community-message hidden></span>
		</form>
	<?php endif; ?>
</div>
