<?php
/**
 * Module partial: partners_plan — the «پلن همکاران» offer card.
 *
 * A partner plan is not sold: it is switched on for a partner (or for anyone
 * who asks for it) from the back office. This card is the shop window — it
 * lists every feature that is activated, plus the perks that come with being a
 * partner, and routes the visitor to the request form.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_title = (string) dr_niva()->settings->get( 'partner_plan_title' );
$niva_note  = (string) dr_niva()->settings->get( 'partner_plan_note' );
$niva_plan  = 'partner';
$niva_catalog = Niva_Plans::catalog();
$niva_offer = $niva_catalog['partner'] ?? array();
$niva_buy = class_exists( 'Niva_Orders' ) ? Niva_Orders::checkout_url_for_plan( 'partner' ) : '';
$niva_seats = (int) ( dr_niva()->plans->limits()['partner']['family_seats'] ?? 50 );

if ( '' === trim( $niva_title ) ) {
	$niva_title = 'پلن همکاران';
}

/* The perks are plain lines: "each line is one bullet". */
$niva_perks = array();
foreach ( preg_split( '/\r\n|\r|\n/', (string) dr_niva()->settings->get( 'partner_plan_perks' ) ) as $niva_line ) {
	$niva_line = trim( $niva_line );
	if ( '' !== $niva_line ) {
		$niva_perks[] = $niva_line;
	}
}

/* Limits that come with the plan, straight from the plan engine. */
$niva_features = dr_niva()->plans ? dr_niva()->plans->features( $niva_plan ) : array();

$niva_partner = is_user_logged_in() ? dr_niva()->partners->by_user( get_current_user_id() ) : null;
$niva_active  = is_user_logged_in() && dr_niva()->plans && dr_niva()->plans->has_plan( get_current_user_id(), $niva_plan );

$niva_status_text = 'اشتراک ماهیانهٔ پولی؛ پس از پرداخت از طریق ووکامرس فعال می‌شود.';
if ( $niva_active ) {
	$niva_status_text = 'پلن همکاران برای حساب تو فعال است.';
} elseif ( $niva_partner && 'pending' === $niva_partner['status'] ) {
	$niva_status_text = 'درخواست تو ثبت شده و در حال بررسی است؛ به‌زودی فعال می‌شود.';
} elseif ( $niva_partner && 'approved' === $niva_partner['status'] ) {
	$niva_status_text = 'همکاری تو تأیید شده است؛ اگر پلن فعال نشده با پشتیبانی تماس بگیر.';
}
?>
<div class="niva-module niva-module--partners_plan" data-module="partners_plan" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card plan-card plan-card--featured partner-plan" data-partner-plan>
		<span class="badge plan-card__flag">پلن ویژه‌ی همکاران</span>
		<div class="card__head">
			<div class="stack" style="gap: 4px">
				<h2 class="card__title card__title-lg"><?php echo esc_html( $niva_title ); ?></h2>
				<span class="caption"><?php echo esc_html( $niva_status_text ); ?></span>
			</div>
			<span class="card__icon card__icon--teal"><?php echo Niva_Icons::svg( 'users', 22 ); ?></span>
		</div>

		<?php if ( '' !== trim( $niva_note ) ) : ?>
			<p class="lede"><?php echo esc_html( $niva_note ); ?></p>
		<?php endif; ?>

		<div class="partner-plan__price">
			<?php if ( ! empty( $niva_offer['discount'] ) ) : ?>
				<span class="caption"><s><?php echo esc_html( Niva_Chrome::digits( number_format_i18n( $niva_offer['price'] ) ) ); ?> تومان</s> · <?php echo esc_html( Niva_Chrome::digits( $niva_offer['discount'] ) ); ?>٪ تخفیف</span>
			<?php endif; ?>
			<span class="plan-card__price"><?php echo esc_html( Niva_Chrome::digits( number_format_i18n( $niva_offer['payable'] ?? 0 ) ) ); ?> تومان</span>
			<span class="plan-card__period">برای ۳۰ روز</span>
		</div>

		<ul class="plan-card__list">
			<?php foreach ( $niva_features as $niva_feature ) : ?>
				<li class="list-check">
					<?php echo Niva_Icons::svg( $niva_feature['on'] ? 'check' : 'x', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span><?php echo esc_html( $niva_feature['label'] ); ?>: <b><?php echo esc_html( $niva_feature['value'] ); ?></b></span>
				</li>
			<?php endforeach; ?>
		</ul>

		<?php if ( $niva_perks ) : ?>
			<div class="divider"></div>
			<ul class="plan-card__list">
				<?php foreach ( $niva_perks as $niva_perk ) : ?>
					<li class="list-check">
						<?php echo Niva_Icons::svg( 'badge-check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span><?php echo esc_html( $niva_perk ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<div class="cta-band__actions">
			<?php if ( $niva_active ) : ?>
				<a class="btn btn--secondary" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>">
					<?php echo Niva_Icons::svg( 'user', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					تنظیمات حساب من
				</a>
			<?php elseif ( ! is_user_logged_in() ) : ?>
				<a class="btn btn--primary" href="<?php echo esc_url( wp_login_url( Niva_Modules::url( 'partners', $args ) ) ); ?>">برای خرید وارد شو</a>
			<?php elseif ( $niva_buy ) : ?>
				<a class="btn btn--primary" href="<?php echo esc_url( $niva_buy ); ?>" rel="nofollow">
					<?php echo Niva_Icons::svg( 'sparkles', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					خرید و پرداخت پلن همکاری
				</a>
			<?php else : ?>
				<span class="caption">برای خرید، ووکامرس را فعال کن و درگاه پرداخت سایت را پیکربندی کن.</span>
			<?php endif; ?>
		</div>

		<p class="caption">قیمت و تخفیف از تنظیمات پلن‌ها خوانده می‌شود. این پلن تا <?php echo esc_html( Niva_Chrome::digits( $niva_seats ) ); ?> کاربر زیرمجموعه را پشتیبانی می‌کند؛ محدودیت هر امکان در جدول پلن‌ها مشخص است.</p>
	</section>
</div>
