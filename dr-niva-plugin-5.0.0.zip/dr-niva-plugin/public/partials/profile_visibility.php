<?php
/**
 * Module partial: profile_visibility — "why don't I see this?" (2.0.0).
 *
 * Every section this person cannot see is listed with the real reason, taken
 * from the same rules the server uses to hide it (audience, profile data,
 * layout switch, plan gate). Nothing here is guessed: if a module is hidden,
 * one of these checks is why.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_uid     = (int) get_current_user_id();
$niva_profile = dr_niva()->profile->get( $niva_uid );
$niva_map     = Niva_Modules::map();
$niva_layout  = dr_niva()->layout && method_exists( dr_niva()->layout, 'all' ) ? (array) dr_niva()->layout->all() : array();
$niva_enabled = array();
foreach ( $niva_layout as $niva_id => $niva_row ) {
	$niva_enabled[ $niva_id ] = is_array( $niva_row ) ? ! empty( $niva_row['enabled'] ) : (bool) $niva_row;
}

$niva_sex       = strtolower( (string) ( $niva_profile['sex'] ?? '' ) );
$niva_pregnant  = ! empty( $niva_profile['pregnant'] );
$niva_has_baby  = ( '' !== trim( (string) ( $niva_profile['baby_name'] ?? '' ) ) || '' !== trim( (string) ( $niva_profile['baby_birth'] ?? '' ) ) );

$niva_visible = array();
$niva_hidden  = array();

foreach ( $niva_map as $niva_id => $niva_module ) {
	if ( ! empty( $niva_module['hidden'] ) ) {
		continue; // internal helper modules are not shown to users at all
	}

	$niva_reason = '';

	// 1) Plan gate — the server refuses this feature for the current plan.
	if ( class_exists( 'Niva_Plans' ) && dr_niva()->plans ) {
		$niva_parts = explode( '_', $niva_id, 2 );
		$niva_check = dr_niva()->plans->feature_access( $niva_uid, $niva_id );
		if ( is_wp_error( $niva_check ) && ! empty( $niva_parts[0] ) ) {
			$niva_reason = 'با پلن فعلی تو فعال نیست. با ارتقای پلن باز می‌شود.';
		}
	}

	// 2) Audience mismatch — this section is not for this profile.
	if ( '' === $niva_reason ) {
		$niva_wanted = Niva_Modules::audience( $niva_id );
		if ( 'female' === $niva_wanted && 'male' === $niva_sex ) {
			$niva_reason = 'چون در پروفایل، جنسیت را «آقا» انتخاب کرده‌ای.';
		} elseif ( 'male' === $niva_wanted && 'female' === $niva_sex ) {
			$niva_reason = 'چون در پروفایل، جنسیت را «خانم» انتخاب کرده‌ای.';
		}
	}

	// 3) Data conditions — pregnancy / child sections need that data to exist.
	if ( '' === $niva_reason ) {
		if ( 0 === strpos( $niva_id, 'pregnancy_' ) && ! $niva_pregnant ) {
			$niva_reason = 'چون بارداری فعالی در پروفایلت ثبت نشده است.';
		} elseif ( ( 0 === strpos( $niva_id, 'baby_' ) ) && ! $niva_has_baby ) {
			$niva_reason = 'چون فرزندی در پروفایلت ثبت نشده است.';
		}
	}

	// 4) Switched off by the site owner.
	if ( '' === $niva_reason && isset( $niva_enabled[ $niva_id ] ) && ! $niva_enabled[ $niva_id ] ) {
		$niva_reason = 'این بخش را مدیر سرویس خاموش کرده است.';
	}

	if ( '' === $niva_reason ) {
		$niva_visible[] = $niva_module;
	} else {
		$niva_hidden[] = array(
			'label'  => $niva_module['label'],
			'group'  => $niva_module['group'],
			'reason' => $niva_reason,
		);
	}
}
?>
<div class="niva-module niva-module--profile_visibility" data-module="profile_visibility" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">چرا این بخش‌ها را نمی‌بینم؟</h2>
				<span class="caption">فقط بخش‌هایی که به پروفایل تو مربوط‌اند نمایش داده می‌شوند.</span>
			</div>
			<span class="card__icon"><?php echo Niva_Icons::svg( 'eye-off', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		</div>

		<?php if ( $niva_hidden ) : ?>
			<ul class="visibility-list">
				<?php foreach ( $niva_hidden as $niva_item ) : ?>
					<li class="visibility-list__item">
						<span class="visibility-list__title"><?php echo esc_html( $niva_item['label'] ); ?></span>
						<span class="visibility-list__reason"><?php echo esc_html( $niva_item['reason'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
			<p class="caption">
				اگر اطلاعاتی را اشتباه ثبت کرده‌ای، از
				<a href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>">تنظیمات من</a>
				اصلاحش کن؛ بخش‌های مربوط بلافاصله فعال می‌شوند.
			</p>
		<?php else : ?>
			<div class="empty-state">
				<strong>همهٔ بخش‌های مربوط به تو فعال است</strong>
				<span>چیزی پنهان نشده است.</span>
			</div>
		<?php endif; ?>

		<details class="profile-advanced">
			<summary>بخش‌های فعال (<?php echo esc_html( Niva_Chrome::digits( (string) count( $niva_visible ) ) ); ?>)</summary>
			<ul class="visibility-list visibility-list--ok">
				<?php foreach ( $niva_visible as $niva_item ) : ?>
					<li class="visibility-list__item">
						<span class="visibility-list__title"><?php echo esc_html( $niva_item['label'] ); ?></span>
						<span class="visibility-list__reason"><?php echo esc_html( (string) $niva_item['group'] ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		</details>
	</section>
</div>
