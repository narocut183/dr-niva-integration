<?php
/**
 * Module partial: baby_chart
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* Baby screens need a baby on file. */
if ( '' === (string) Niva_Chrome::flag( 'baby_birth' ) && '' === (string) Niva_Chrome::flag( 'baby_name' ) ) {
	echo Niva_Chrome::blank( 'پروندهٔ کودک ساخته نشده', 'نام و تاریخ تولد کودک را در تنظیمات حساب ثبت کن تا این بخش با داده‌های واقعی ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--baby_chart" data-baby-root data-module="baby_chart" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">روند وزن نوزاد</h2>
                <span class="caption">هرچه ثبت‌ها منظم‌تر باشد، روند دقیق‌تر دیده می‌شود</span>
              </div>
              <span class="card__icon card__icon--teal" aria-hidden="true"><?php echo Niva_Icons::svg( 'chart-line', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
            </div>
            <div data-chart="babyWeight" data-height="150"></div>
          </section>
</div>
