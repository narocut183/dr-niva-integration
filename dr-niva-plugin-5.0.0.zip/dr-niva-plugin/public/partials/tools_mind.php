<?php
/**
 * Module partial: tools_mind
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--tools_mind" data-module="tools_mind" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <h2 class="card__title">حال روان</h2>
              <span class="card__icon card__icon--purple" aria-hidden="true"><?php echo Niva_Icons::svg( 'heart', 20 ); ?></span>
            </div>
            <div class="tile-grid">
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'mind', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'message-circle', 22 ); ?></span>
                گفت‌وگوی همراه
              </a>
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'mind', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'wind', 22 ); ?></span>
                تمرین آرام‌سازی
              </a>
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'mind', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'pen-line', 22 ); ?></span>
                دفترچه افکار
              </a>
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'mind', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'life-buoy', 22 ); ?></span>
                کمک فوری
              </a>
            </div>
          </section>
</div>
