<?php
/**
 * Module partial: lab_docs
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--lab_docs" data-module="lab_docs" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
              <details class="fold">
                <summary class="card__head">
                  <div class="stack" style="gap: 2px">
                    <h2 class="card__title">اسناد من</h2>
                  </div>
                  <span class="card__icon card__icon--cyan" aria-hidden="true"><?php echo Niva_Icons::svg( 'file-text', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
                </summary>
                <div class="fold__body" data-docs data-active="cbc" style="margin-block-start: var(--s-1)"></div>
              </details>
            </section>
</div>
