<?php
/**
 * Module partial: mind_breathing
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--mind_breathing" data-module="mind_breathing" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">یک تمرین سه‌دقیقه‌ای</h2>
				<span class="caption">تنفس ۴-۷-۸ — آرام‌کردن ضربان قلب و ذهن</span>
			</div>
			<span class="card__icon card__icon--purple" aria-hidden="true"><?php echo Niva_Icons::svg( 'wind', 20 ); ?></span>
		</div>

		<div class="stack is-center">
			<span class="breath-ring" data-breath-ring role="timer" aria-live="polite">دم · ۴</span>
			<p class="caption">۴ ثانیه دم، ۷ ثانیه نگه‌داشتن، ۸ ثانیه بازدم. سه بار تکرار کن.</p>
			<div class="flex wrap gap-2" style="justify-content: center">
				<button type="button" class="btn btn--primary" data-breath-toggle>
					<?php echo Niva_Icons::svg( 'play', 18 ); ?>
					شروع تمرین
				</button>
				<button type="button" class="btn btn--secondary" data-breath-reset>از نو</button>
			</div>
		</div>
	</section>
</div>
