<?php
/**
 * Module partial: reminders_reminder-list
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--reminders_reminder-list" data-module="reminders_reminder-list" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">یادآورهای من</h2>
				<span class="caption"><bdi data-reminder-count>۰</bdi> یادآور فعال</span>
			</div>
			<span class="card__icon card__icon--teal" aria-hidden="true"><?php echo Niva_Icons::svg( 'clock', 20 ); ?></span>
		</div>

		<div class="stack" data-reminder-list></div>
		<p class="caption" data-reminder-empty>هنوز یادآوری نساخته‌ای. از فرم بالا یا پیشنهادهای آماده استفاده کن.</p>
		<p class="caption" data-reminder-status-list role="status" aria-live="polite"></p>
	</section>
</div>
