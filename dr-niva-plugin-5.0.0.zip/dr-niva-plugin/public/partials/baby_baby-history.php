<?php
/**
 * Module partial: baby_baby-history
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* Baby screens need a baby on file. */
if ( '' === (string) Niva_Chrome::flag( 'baby_birth' ) && '' === (string) Niva_Chrome::flag( 'baby_name' ) ) {
	echo Niva_Chrome::blank( 'پروندهٔ کودک ساخته نشده', 'نام و تاریخ تولد کودک را در تنظیمات حساب ثبت کن تا این بخش با داده‌های واقعی ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--baby_baby-history" data-baby-root data-module="baby_baby-history" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">سابقه‌ی اندازه‌ها</h2>
              </div>
              <span class="card__icon card__icon--purple" aria-hidden="true"><?php echo Niva_Icons::svg( 'clock', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
            </div>
            <div class="stack" data-baby-history></div>
          </section>
</div>
