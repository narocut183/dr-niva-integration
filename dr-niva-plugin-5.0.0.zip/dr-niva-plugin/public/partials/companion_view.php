<?php
/**
 * Module partial: companion_view — the read-only page a companion opens (2.0.0).
 *
 * Public by design: a companion has no account. Access is granted by the signed
 * link plus their own one-time code (Niva_Companion re-checks both on every
 * request), and only the scopes the owner ticked are ever rendered.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

Niva_Companion::enqueue();

// Never index a page that shows personal health data.
if ( ! defined( 'DONOTCACHEPAGE' ) ) {
	define( 'DONOTCACHEPAGE', true );
}
add_action( 'wp_head', static function () {
	echo '<meta name="robots" content="noindex, nofollow" />' . "\n";
}, 1 );

$niva_companion = dr_niva()->companion instanceof Niva_Companion ? dr_niva()->companion : new Niva_Companion();
$niva_access    = $niva_companion->current_access();
$niva_code      = isset( $_GET['c'] ) ? sanitize_text_field( wp_unslash( $_GET['c'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$niva_scopes    = Niva_Companion::scopes();
?>
<div class="niva-module niva-module--companion_view" data-module="companion_view" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>"
	data-niva-companion="<?php echo esc_url( rawurldecode( rest_url( Niva_Rest::NS . '/companion/' ) ) ); ?>"
	data-niva-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
	data-niva-code="<?php echo esc_attr( $niva_code ); ?>">

<?php if ( ! $niva_access ) : ?>

	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--pink"><?php echo Niva_Icons::svg( 'heart-handshake', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h1 class="card__title">ورود همراه</h1>
			</div>
		</div>
		<p class="caption">
			کدی که صاحب آن برایت فرستاده را وارد کن و شمارهٔ خودت را تأیید کن.
			هیچ حساب کاربری ساخته نمی‌شود و فقط وضعیتی که صاحب کد اجازه داده نمایش داده می‌شود.
		</p>

		<form data-niva-companion-gate>
			<label class="field">
				<span class="field__label">کد همراهی</span>
				<input class="field__input" name="code" dir="ltr" required placeholder="AV-XXXX-XXXX" value="<?php echo esc_attr( $niva_code ); ?>" />
			</label>
			<label class="field">
				<span class="field__label">شمارهٔ موبایل خودت</span>
				<input class="field__input" name="phone" dir="ltr" required placeholder="09xxxxxxxxx" />
			</label>
			<button type="submit" class="btn btn--primary btn--block">دریافت کد تأیید</button>
			<span class="field__hint" data-niva-companion-message hidden></span>
		</form>

		<form data-niva-companion-verify hidden>
			<label class="field">
				<span class="field__label">کد تأیید پیامک‌شده</span>
				<input class="field__input" name="otp" dir="ltr" required inputmode="numeric" />
			</label>
			<button type="submit" class="btn btn--primary btn--block">ورود</button>
		</form>
	</section>

<?php else : ?>

	<?php
	$niva_summary = $niva_companion->summary( $niva_access );
	$niva_companion->log_view( $niva_access );
	?>
	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--pink"><?php echo Niva_Icons::svg( 'heart-handshake', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<div class="stack" style="gap:2px">
					<span class="caption">کد همراهی اختصاصی شما</span>
					<h1 class="card__title">همراهِ: <?php echo esc_html( (string) $niva_summary['owner_name'] ); ?></h1>
				</div>
			</div>
			<span class="badge badge--green">فعال</span>
		</div>
		<p class="caption">
			این صفحه فقط خواندنی است. دسترسی‌های فعال:
			<?php echo esc_html( implode( '، ', array_intersect_key( $niva_scopes, array_flip( $niva_summary['scopes'] ) ) ) ); ?>
		</p>
	</section>

	<?php foreach ( $niva_summary['sections'] as $niva_key => $niva_section ) : ?>
		<section class="card">
			<div class="card__head">
				<div class="flex">
					<span class="card__icon card__icon--<?php echo 'cycle' === $niva_key ? 'pink' : ( 'labs' === $niva_key ? 'teal' : 'purple' ); ?>"><?php echo Niva_Icons::svg( 'cycle' === $niva_key ? 'droplet' : ( 'labs' === $niva_key ? 'chart-line' : 'heart' ), 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<h2 class="card__title"><?php echo esc_html( (string) $niva_section['title'] ); ?></h2>
				</div>
			</div>

			<?php if ( 'cycle' === $niva_key ) : ?>
				<?php if ( ! empty( $niva_section['has_data'] ) ) : ?>
					<div class="metric-grid" style="--niva-day:<?php echo esc_attr( (string) (int) $niva_section['day'] ); ?>">
						<div class="nv-big-number">
							<b><?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_section['day'] ) ); ?></b>
							<span>روز چرخه</span>
						</div>
						<div class="plain-list">
							<div class="plain-row"><span class="plain-row__name">روز چرخه</span><span class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_section['day'] ) ); ?></span></div>
							<div class="plain-row"><span class="plain-row__name">طول چرخه</span><span class="plain-row__value"><?php echo esc_html( (string) $niva_section['length'] ); ?></span></div>
							<div class="plain-row"><span class="plain-row__name">پریود بعدی</span><span class="plain-row__value"><?php echo esc_html( (string) $niva_section['next_date'] ); ?> (<?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_section['next_days'] ) ); ?> روز دیگر)</span></div>
							<div class="plain-row"><span class="plain-row__name">پنجرهٔ باروری</span><span class="plain-row__value"><?php echo esc_html( '' !== (string) $niva_section['fertile'] ? (string) $niva_section['fertile'] : 'خارج از پنجره' ); ?></span></div>
						</div>
					</div>
					<?php if ( (int) $niva_section['next_days'] <= 3 ) : ?>
						<div class="alert alert--caution">
							<span class="alert__icon"><?php echo Niva_Icons::svg( 'heart', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
							<div class="alert__body"><div class="alert__text">پریود نزدیک است؛ یک روز آرام‌تر برایش بساز.</div></div>
						</div>
					<?php endif; ?>
				<?php else : ?>
					<?php if ( ! empty( $niva_section['configured'] ) ) : ?>
						<div class="empty-state">
							<?php echo Niva_Icons::svg( 'droplet', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span class="empty-state__title">هنوز پریودی ثبت نشده</span>
							<span class="caption">به‌محض ثبت، وضعیت چرخه این‌جا نشان داده می‌شود.</span>
						</div>
					<?php else : ?>
						<div class="empty-state">
							<?php echo Niva_Icons::svg( 'droplet', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<span class="empty-state__title">طول چرخه هنوز ثبت نشده</span>
							<span class="caption">تا وقتی صاحب کد طول چرخه‌اش را وارد نکند، پیش‌بینی نمایش داده نمی‌شود.</span>
						</div>
					<?php endif; ?>
				<?php endif; ?>

			<?php elseif ( 'pregnancy' === $niva_key ) : ?>
				<?php if ( ! empty( $niva_section['pregnant'] ) ) : ?>
					<div class="plain-list">
						<div class="plain-row"><span class="plain-row__name">هفتهٔ بارداری</span><span class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_section['week'] ) ); ?></span></div>
						<div class="plain-row"><span class="plain-row__name">تاریخ زایمان</span><span class="plain-row__value"><?php echo esc_html( $niva_section['due_date'] ? Niva_Chrome::format_datetime_gmt( (string) $niva_section['due_date'] ) : 'ثبت نشده' ); ?></span></div>
					</div>
				<?php else : ?>
					<div class="empty-state">
						<?php echo Niva_Icons::svg( 'heart', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span class="empty-state__title">بارداری فعالی ثبت نشده</span>
						<span class="caption">این بخش وقتی نمایش داده می‌شود که بارداری تأیید شده باشد.</span>
					</div>
				<?php endif; ?>

			<?php elseif ( 'reminders' === $niva_key ) : ?>
				<?php if ( ! empty( $niva_section['items'] ) ) : ?>
					<ul class="plain-list">
						<?php foreach ( $niva_section['items'] as $niva_item ) : ?>
							<li class="plain-row">
								<span class="plain-row__name"><?php echo esc_html( (string) $niva_item['title'] ); ?></span>
								<span class="plain-row__unit"><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $niva_item['time'] ) ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<div class="empty-state">
						<?php echo Niva_Icons::svg( 'bell', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span class="empty-state__title">یادآور فعالی نیست</span>
						<span class="caption">یادآورهای به‌اشتراک‌گذاشته‌شده این‌جا فهرست می‌شوند.</span>
					</div>
				<?php endif; ?>

			<?php elseif ( 'mood' === $niva_key ) : ?>
				<div class="plain-list">
					<div class="plain-row"><span class="plain-row__name">حال کلی</span><span class="plain-row__value"><?php echo esc_html( (string) $niva_section['label'] ); ?></span></div>
					<div class="plain-row"><span class="plain-row__name">تعداد ثبت‌ها</span><span class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( (string) (int) $niva_section['count'] ) ); ?></span></div>
				</div>
				<?php if ( 'نیازمند توجه' === $niva_section['label'] ) : ?>
					<div class="alert alert--caution">
						<span class="alert__icon"><?php echo Niva_Icons::svg( 'smile', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<div class="alert__body"><div class="alert__text">این روزها حالش خوب نیست؛ یک پیام کوتاه و یک کار کوچک می‌تواند کمک کند.</div></div>
					</div>
				<?php endif; ?>

			<?php elseif ( 'labs' === $niva_key ) : ?>
				<?php if ( ! empty( $niva_section['items'] ) ) : ?>
					<ul class="plain-list">
						<?php foreach ( $niva_section['items'] as $niva_item ) : ?>
							<li class="plain-row">
								<span class="plain-row__name"><?php echo esc_html( (string) $niva_item['title'] ); ?></span>
								<span class="plain-row__unit"><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $niva_item['date'] ) ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<div class="empty-state">
						<?php echo Niva_Icons::svg( 'file-text', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span class="empty-state__title">نتیجه‌ای ثبت نشده</span>
						<span class="caption">فقط فهرست نتایج به‌اشتراک‌گذاشته‌شده نمایش داده می‌شود.</span>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</section>
	<?php endforeach; ?>

	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--teal"><?php echo Niva_Icons::svg( 'heart-handshake', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h2 class="card__title">چطور می‌توانی کمک کنی؟</h2>
			</div>
		</div>
		<ul class="list-check">
			<li>یک یادآور کوتاه برای دارو یا قرار بگذار.</li>
			<li>در روزهای سخت، فقط «هستم کنارت» کافی است.</li>
			<li>اگر چیزی نگرانت کرد، به صاحب کد یا پزشک بگو — نه اینکه در اپ تغییر بدهی.</li>
		</ul>
		<p class="caption">این صفحه فقط برای دیدن است؛ هیچ اطلاعاتی از آن قابل ویرایش یا ارسال نیست.</p>
	</section>

<?php endif; ?>
</div>
