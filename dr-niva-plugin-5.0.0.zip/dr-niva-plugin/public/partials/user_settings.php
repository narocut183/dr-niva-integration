<?php
/**
 * Module partial: user_settings — the user's own profile and preferences (2.0.0).
 *
 * Redesigned so the numbers that matter are picked with the same controls as the
 * wizard (vertical picker / Jalali calendar) instead of raw number and text
 * boxes, and so the technical switches sit behind «تنظیمات پیشرفته».
 *
 * Every input id is unchanged, so the existing save path (/profile) keeps
 * working; the wizard controls write into the same hidden inputs.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

wp_enqueue_style( 'dr-niva-onboarding' );
wp_enqueue_script( 'dr-niva-onboarding' );

$niva_uid     = (int) get_current_user_id();
$niva_p       = dr_niva()->profile->get();
$niva_week    = dr_niva()->profile->pregnancy_week();
$niva_member  = dr_niva()->plans->summary( $niva_uid );
$niva_logic   = dr_niva()->onboarding instanceof Niva_Onboarding ? dr_niva()->onboarding : null;
$niva_percent = $niva_logic ? (int) $niva_logic->state()['profile_percent'] : 0;

$niva_jalali_date = static function ( string $value ) : string {
	if ( '' === $value || ! strtotime( $value ) ) {
		return '';
	}
	$jalali = Niva_Chrome::jalali( strtotime( $value ) );
	return Niva_Chrome::digits( sprintf( '%04d/%02d/%02d', $jalali[0], $jalali[1], $jalali[2] ) );
};
?>
<div class="niva-module niva-module--user_settings" data-module="user_settings" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<form class="card" data-profile-form>
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">تنظیمات من</h2>
				<span class="caption">اطلاعات تو فقط روی این حساب ذخیره می‌شود</span>
			</div>
			<span class="card__icon card__icon--cyan"><?php echo Niva_Icons::svg( 'settings', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		</div>

		<?php if ( $niva_percent < 100 ) : ?>
			<div class="stack" style="gap: 8px">
				<div class="progress" aria-hidden="true"><span class="progress__fill" style="width:<?php echo esc_attr( (string) $niva_percent ); ?>%"></span></div>
				<span class="caption">پروفایل <?php echo esc_html( Niva_Chrome::digits( (string) $niva_percent ) ); ?>٪ کامل است.</span>
				<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'onboarding_wizard', $args ) ); ?>">تکمیل گام‌به‌گام</a>
			</div>
		<?php endif; ?>

		<h3>مشخصات</h3>
		<div class="grid-2">
			<label class="field">
				<span class="field__label">نام</span>
				<input class="field__input" id="pf-first-name" type="text" value="<?php echo esc_attr( (string) $niva_p['first_name'] ); ?>" />
			</label>
			<label class="field">
				<span class="field__label">نام خانوادگی</span>
				<input class="field__input" id="pf-last-name" type="text" value="<?php echo esc_attr( (string) $niva_p['last_name'] ); ?>" />
			</label>
		</div>

		<label class="field">
			<span class="field__label">نام نمایشی</span>
			<input class="field__input" id="pf-display-name" type="text" value="<?php echo esc_attr( $niva_p['display_name'] ); ?>" placeholder="اگر خالی بماند، از نام و نام خانوادگی ساخته می‌شود" />
		</label>

		<?php if ( dr_niva()->settings->is_on( 'avatar_allow_user_upload' ) ) : ?>
			<div class="field">
				<span class="field__label">عکس پروفایل</span>
				<div class="flex">
					<span class="nv-avatar nv-avatar--lg" id="pf-avatar-preview"<?php echo '' !== (string) $niva_p['avatar_url'] ? ' style="background-image:url(' . esc_url( (string) $niva_p['avatar_url'] ) . ');background-size:cover;background-position:center"' : ''; ?>></span>
					<button type="button" class="btn btn--ghost btn--sm" id="pf-avatar-pick">انتخاب عکس</button>
					<input type="file" id="pf-avatar-file" class="nv-hidden" accept="image/jpeg,image/png,image/webp" />
					<input id="pf-avatar-id" type="hidden" value="<?php echo esc_attr( (string) (int) $niva_p['avatar_id'] ); ?>" />
				</div>
				<span class="field__hint">
					حداکثر <?php echo esc_html( Niva_Chrome::digits( (string) dr_niva()->settings->get( 'avatar_max_mb', 2 ) ) ); ?> مگابایت ·
					<?php echo esc_html( (string) dr_niva()->settings->get( 'avatar_allowed_types', 'jpg,jpeg,png,webp' ) ); ?>
				</span>
			</div>
		<?php endif; ?>

		<div class="grid-2">
			<label class="field">
				<span class="field__label">جنسیت</span>
				<select class="field__input" id="pf-sex">
					<option value="" <?php selected( '', $niva_p['sex'] ); ?>>انتخاب کن</option>
					<option value="female" <?php selected( 'female', $niva_p['sex'] ); ?>>زن</option>
					<option value="male" <?php selected( 'male', $niva_p['sex'] ); ?>>مرد</option>
					<option value="other" <?php selected( 'other', $niva_p['sex'] ); ?>>دیگر</option>
				</select>
			</label>
			<label class="field">
				<span class="field__label">سال تولد (شمسی)</span>
				<input class="field__input" id="pf-birth-year" type="number" dir="ltr" value="<?php echo esc_attr( $niva_p['birth_year'] ); ?>" placeholder="1370" />
				<span class="field__hint">
					<?php if ( ! empty( $niva_p['age'] ) ) : ?>
						سن فعلی: <?php echo esc_html( Niva_Chrome::digits( (string) $niva_p['age'] ) ); ?> سال
					<?php else : ?>
						برای سن دقیق‌تر، تاریخ کامل را در ویزارد وارد کن.
					<?php endif; ?>
				</span>
			</label>
			<label class="field">
				<span class="field__label">قد (سانتی‌متر)</span>
				<input class="field__input" id="pf-height" type="text" dir="ltr" value="<?php echo esc_attr( $niva_p['height'] ); ?>" />
			</label>
			<label class="field">
				<span class="field__label">وزن (کیلوگرم)</span>
				<input class="field__input" id="pf-weight" type="text" dir="ltr" value="<?php echo esc_attr( $niva_p['weight'] ); ?>" />
			</label>
		</div>

		<h3>چرخه و بارداری</h3>
		<label class="switch-row">
			<input type="checkbox" id="pf-pregnant" <?php checked( 1, (int) $niva_p['pregnant'] ); ?> />
			<span>باردار هستم</span>
		</label>

		<div class="field">
			<span class="field__label">اولین روز آخرین پریود</span>
			<div data-niva-calendar="pf-lmp" data-min-year="1300">
				<span class="field__hint" data-niva-calendar-output><?php echo esc_html( $niva_jalali_date( (string) $niva_p['lmp'] ) ); ?></span>
			</div>
			<input id="pf-lmp" type="hidden" value="<?php echo esc_attr( $niva_p['lmp'] ); ?>" />
			<span class="field__hint">اگر نمی‌دانی، خالی بگذار؛ بعداً هم می‌شود اصلاحش کرد.</span>
		</div>

		<div class="grid-2">
			<div class="field">
				<span class="field__label">طول چرخهٔ تو</span>
				<div data-niva-wheel="pf-cycle-length" data-min="21" data-max="45" data-unit="روز"></div>
				<input id="pf-cycle-length" type="hidden" value="<?php echo esc_attr( $niva_p['cycle_length'] ); ?>" />
				<span class="field__hint">از اولین روز پریود تا اولین روز پریود بعدی. <?php echo '' === (string) $niva_p['cycle_length'] ? 'هنوز ثبت نشده.' : ''; ?></span>
			</div>
			<div class="field">
				<span class="field__label">چند روز پریود می‌شوی؟</span>
				<div data-niva-wheel="pf-period-length" data-min="2" data-max="10" data-unit="روز"></div>
				<input id="pf-period-length" type="hidden" value="<?php echo esc_attr( $niva_p['period_length'] ); ?>" />
				<span class="field__hint">می‌توانی حدودی انتخاب کنی. <?php echo '' === (string) $niva_p['period_length'] ? 'هنوز ثبت نشده.' : ''; ?></span>
			</div>
		</div>

		<div class="field">
			<span class="field__label">یا تاریخ تقریبی زایمان</span>
			<div data-niva-calendar="pf-due" data-min-year="1300">
				<span class="field__hint" data-niva-calendar-output><?php echo esc_html( $niva_jalali_date( (string) $niva_p['due_date'] ) ); ?></span>
			</div>
			<input id="pf-due" type="hidden" value="<?php echo esc_attr( $niva_p['due_date'] ); ?>" />
		</div>
		<?php if ( $niva_week ) : ?>
			<p class="caption">الان در هفتهٔ <?php echo esc_html( number_format_i18n( $niva_week ) ); ?> بارداری هستی؛ پیام روزانه بر همین پایه انتخاب می‌شود.</p>
		<?php endif; ?>

		<h3>نوزاد</h3>
		<div class="grid-2">
			<label class="field">
				<span class="field__label">نام نوزاد</span>
				<input class="field__input" id="pf-baby-name" type="text" value="<?php echo esc_attr( $niva_p['baby_name'] ); ?>" />
			</label>
			<div class="field">
				<span class="field__label">تاریخ تولد نوزاد</span>
				<div data-niva-calendar="pf-baby-birth" data-min-year="1390">
					<span class="field__hint" data-niva-calendar-output><?php echo esc_html( $niva_jalali_date( (string) $niva_p['baby_birth'] ) ); ?></span>
				</div>
				<input id="pf-baby-birth" type="hidden" value="<?php echo esc_attr( $niva_p['baby_birth'] ); ?>" />
			</div>
		</div>

		<h3>اعلان‌ها</h3>
		<label class="switch-row"><input type="checkbox" id="pf-ch-inapp" <?php checked( 1, (int) $niva_p['channels']['inapp'] ); ?> /><span>اعلان داخل برنامه</span></label>
		<label class="switch-row"><input type="checkbox" id="pf-ch-push" <?php checked( 1, (int) $niva_p['channels']['push'] ); ?> /><span>پوش (مرورگر و اپ)</span></label>

		<h3>ظاهر</h3>
		<div class="grid-2">
			<label class="field">
				<span class="field__label">حالت نمایش</span>
				<select class="field__input" id="pf-theme">
					<option value="auto" <?php selected( 'auto', $niva_p['theme'] ); ?>>خودکار</option>
					<option value="light" <?php selected( 'light', $niva_p['theme'] ); ?>>روشن</option>
					<option value="dark" <?php selected( 'dark', $niva_p['theme'] ); ?>>تیره</option>
				</select>
			</label>
			<label class="field">
				<span class="field__label">اندازهٔ متن</span>
				<select class="field__input" id="pf-font">
					<option value="normal" <?php selected( 'normal', $niva_p['font_scale'] ); ?>>معمولی</option>
					<option value="large" <?php selected( 'large', $niva_p['font_scale'] ); ?>>بزرگ</option>
					<option value="xlarge" <?php selected( 'xlarge', $niva_p['font_scale'] ); ?>>بزرگ‌تر</option>
				</select>
			</label>
		</div>

		<details class="fold">
			<summary>تنظیمات پیشرفته</summary>
			<div class="fold__body">
				<p class="caption">این‌ها را کمتر لازم داری؛ پیش‌فرض‌ها برای بیشتر کاربران مناسب است.</p>
				<div class="grid-2">
					<label class="field"><span class="field__label">ساعت شروع سکوت</span><input class="field__input" id="pf-quiet-from" type="time" dir="ltr" value="<?php echo esc_attr( $niva_p['quiet_from'] ); ?>" /></label>
					<label class="field"><span class="field__label">ساعت پایان سکوت</span><input class="field__input" id="pf-quiet-to" type="time" dir="ltr" value="<?php echo esc_attr( $niva_p['quiet_to'] ); ?>" /></label>
				</div>
				<label class="switch-row"><input type="checkbox" id="pf-ch-email" <?php checked( 1, (int) $niva_p['channels']['email'] ); ?> /><span>دریافت ایمیل</span></label>
			</div>
		</details>

		<button type="submit" class="btn btn--primary btn--block">ذخیرهٔ تنظیمات</button>
		<span class="field__hint" data-profile-message hidden></span>

		<hr class="divider" />
		<h3>داده‌های من</h3>
		<p class="caption">اشتراک فعلی: <?php echo esc_html( $niva_member['label'] ); ?><?php echo $niva_member['expires'] ? ' — تا ' . esc_html( Niva_Chrome::format_datetime_gmt( (string) $niva_member['expires'] ) ) : ''; ?></p>
		<div class="flex" style="flex-wrap: wrap">
			<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( add_query_arg( '_wpnonce', wp_create_nonce( 'wp_rest' ), rest_url( Niva_Rest::NS . '/profile/export' ) ) ); ?>" target="_blank" rel="noopener">دریافت نسخهٔ داده‌هایم (JSON)</a>
			<button type="button" class="btn btn--ghost btn--sm" data-profile-delete>حذف همهٔ سوابق سلامت</button>
		</div>
	</form>
</div>
