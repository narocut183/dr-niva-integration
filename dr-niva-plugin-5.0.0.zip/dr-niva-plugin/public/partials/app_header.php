<?php
/**
 * Module partial: app_header — the app's blue header bar.
 *
 * Phone: the user's avatar, a greeting and the notification bell — exactly the
 * bar the approved design shows. The navigation lives behind the burger as a
 * drawer, as it does in a native app.
 *
 * Desktop: brand, the assigned WordPress menu (or the app's own menu) laid out
 * in one row, the notification bell and the account chip.
 *
 * Everything the behaviour layer binds to is preserved verbatim:
 * data-chrome-drawer-open / -close, data-chrome-notifications-open / -close and
 * the notification panel's data attributes.
 *
 * @var array $args
 * @package DrNiva
 */

defined( 'ABSPATH' ) || exit;

$niva_chrome_notifications = 'niva-chrome-notifications-' . wp_unique_id();
$niva_nav_id               = 'niva-nav-' . wp_unique_id();
$niva_unread               = 0;
$niva_logged_in            = is_user_logged_in();
$niva_greeting             = Niva_Chrome::greeting_name();
Niva_Chrome::enqueue_notification_assets();
?>
<div class="niva-module niva-module--app_header" data-module="app_header" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<header class="header niva-header">
		<div class="container header__inner">

			<?php if ( $niva_logged_in ) : ?>
				<a class="niva-header__user" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>" aria-label="پروفایل من">
					<?php echo Niva_Chrome::avatar(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span class="niva-header__greet">
						<span class="niva-header__hi"><?php echo esc_html( $niva_greeting ? 'سلام، ' . $niva_greeting : 'سلام' ); ?></span>
						<span class="niva-header__date"><?php echo esc_html( Niva_Chrome::today_label() ); ?></span>
					</span>
				</a>

				<a class="niva-header__brand-desktop brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php echo Niva_Chrome::logo(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span class="brand__text">
						<span class="brand__name"><?php echo esc_html( Niva_Chrome::name() ); ?></span>
						<span class="brand__tagline"><?php echo esc_html( Niva_Chrome::tagline() ); ?></span>
					</span>
				</a>
			<?php else : ?>
				<a class="brand" href="<?php echo esc_url( home_url( '/' ) ); ?>">
					<?php echo Niva_Chrome::logo(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<span class="brand__text">
						<span class="brand__name"><?php echo esc_html( Niva_Chrome::name() ); ?></span>
						<span class="brand__tagline"><?php echo esc_html( Niva_Chrome::tagline() ); ?></span>
					</span>
				</a>
			<?php endif; ?>

			<nav class="nav" id="<?php echo esc_attr( $niva_nav_id ); ?>" aria-label="ناوبری اصلی">
				<?php echo Niva_Chrome::menu(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

				<div class="nav__extra">
					<?php echo Niva_Chrome::account(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</nav>

			<div class="header__actions">
				<button type="button" class="icon-btn header__bell" data-chrome-notifications-open aria-controls="<?php echo esc_attr( $niva_chrome_notifications ); ?>" aria-label="اعلان‌ها" aria-haspopup="dialog" aria-expanded="false">
					<?php echo Niva_Icons::svg( 'bell', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php if ( $niva_unread > 0 ) : ?>
						<span class="header__badge" data-chrome-notification-badge aria-hidden="true"><?php echo esc_html( number_format_i18n( min( $niva_unread, 99 ) ) ); ?></span>
					<?php else : ?>
						<span class="header__badge" data-chrome-notification-badge aria-hidden="true" hidden></span>
					<?php endif; ?>
				</button>

				<div class="header__actions--desktop">
					<?php echo Niva_Chrome::account(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>

				<button type="button" class="icon-btn header__burger" data-chrome-drawer-open aria-label="منو" aria-controls="<?php echo esc_attr( $niva_nav_id ); ?>" aria-expanded="false">
					<?php echo Niva_Icons::svg( 'menu', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</button>
			</div>
		</div>
		<button type="button" class="header__scrim" data-chrome-drawer-close tabindex="-1" aria-hidden="true"></button>
	</header>
	<div class="niva-chrome-notifications" id="<?php echo esc_attr( $niva_chrome_notifications ); ?>" data-chrome-notifications hidden>
		<button type="button" class="niva-chrome-notifications__scrim" data-chrome-notifications-close aria-label="بستن اعلان‌ها"></button>
		<section class="niva-chrome-notifications__panel" role="dialog" aria-modal="true" aria-label="اعلان‌های شما" tabindex="-1">
			<header class="niva-chrome-notifications__head">
				<div><h2>اعلان‌های شما</h2><span data-chrome-notification-count></span></div>
				<button type="button" class="niva-chrome-notifications__close" data-chrome-notifications-close aria-label="بستن">×</button>
			</header>
			<p class="niva-chrome-notifications__status" data-chrome-notification-status role="status" aria-live="polite"></p>
			<div class="niva-chrome-notifications__items" data-chrome-notification-items></div>
		</section>
	</div>
</div>
