<?php
/**
 * Completion nudge card — module `profile_completion`.
 *
 * Shows on the home screen for an account that still needs the wizard. It is
 * hidden for the configured snooze window after the user closes it, so nobody
 * is nagged forever. Renders nothing at all when the profile is complete.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'dr-niva-onboarding' );
wp_enqueue_script( 'dr-niva-onboarding' );

if ( ! is_user_logged_in() ) {
	return;
}

$niva_ob = isset( dr_niva()->onboarding ) && dr_niva()->onboarding instanceof Niva_Onboarding ? dr_niva()->onboarding : null;
if ( ! $niva_ob || ! $niva_ob->needs_wizard() ) {
	return;
}

$niva_ob_state   = $niva_ob->state();
$niva_ob_percent = (int) $niva_ob_state['profile_percent'];
$niva_ob_url     = Niva_Modules::url( 'onboarding_wizard', array(), home_url( '/?dr_niva_wizard=1' ) );
?>
<section class="alert alert--caution niva-module" data-niva-completion
	data-rest="<?php echo esc_url( rest_url( Niva_Rest::NS . '/' ) ); ?>"
	data-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>">
	<span class="alert__icon"><?php echo Niva_Icons::svg( 'alert-triangle', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
	<div class="alert__body">
		<span class="alert__title">پروفایلت کامل نیست — ۲ دقیقه وقت می‌برد</span>
		<div class="alert__text">
			هر چه پروفایل دقیق‌تر باشد، محتوای اپ مناسب‌تر می‌شود. <?php echo esc_html( Niva_Chrome::digits( (string) $niva_ob_percent ) ); ?>٪ کامل شده است.
		</div>
		<div class="progress" aria-hidden="true">
			<span class="progress__fill" style="width:<?php echo esc_attr( (string) $niva_ob_percent ); ?>%"></span>
		</div>
		<div class="alert__actions">
			<a class="btn btn--primary btn--sm" href="<?php echo esc_url( $niva_ob_url ); ?>">کامل کن</a>
			<button type="button" class="btn btn--ghost btn--sm" data-niva-ob-snooze>فعلاً نه</button>
		</div>
	</div>
</section>
