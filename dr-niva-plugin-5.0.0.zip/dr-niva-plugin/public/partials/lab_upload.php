<?php
/**
 * Module partial: lab_upload
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--lab_upload" data-module="lab_upload" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
  <section class="card">
    <div class="card__head">
      <div class="stack" style="gap: 2px">
        <h2 class="card__title">تحلیل هوشمند برگهٔ آزمایش</h2>
        <span class="caption">تصویر واضح JPG، PNG یا WebP — اطلاعات استخراج‌شده در پروندهٔ خودت ذخیره می‌شود.</span>
      </div>
      <span class="card__icon card__icon--green" aria-hidden="true"><?php echo Niva_Icons::svg( 'upload', 20 ); ?></span>
    </div>

    <?php if ( ! is_user_logged_in() ) : ?>
      <?php echo Niva_Modules::login_notice(); ?>
    <?php else : ?>
      <form class="stack" data-lab-upload enctype="multipart/form-data">
        <label class="field">
          <span class="field__label">تصویر برگهٔ آزمایش</span>
          <input type="file" class="field__input" name="report" accept="image/jpeg,image/png,image/webp" required />
        </label>
        <button type="submit" class="btn btn--primary">تحلیل و ثبت نتیجه‌ها</button>
        <p class="caption" data-lab-status aria-live="polite"></p>
      </form>
      <div class="stack" data-lab-ai-result aria-live="polite"></div>
      <p class="caption">تصویر برای تحلیل به سرویس هوش مصنوعیِ تنظیم‌شده در سایت فرستاده می‌شود و در سایت ذخیره نمی‌شود. برای ارزیابی وضعیت، بازهٔ مرجع درج‌شده روی برگه اولویت دارد.</p>
    <?php endif; ?>
  </section>
</div>
