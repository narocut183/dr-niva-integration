<?php
/**
 * Module partial: cycle_today
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_cycle = Niva_Chrome::cycle_state();
?>
<div class="niva-module niva-module--cycle_today" data-module="cycle_today" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">امروز، <span data-niva-date-short><?php echo esc_html( Niva_Chrome::today_short() ); ?></span></h2>
				<span class="caption"><?php echo $niva_cycle['has_data'] ? 'روز ' . esc_html( $niva_cycle['cycle_day_fa'] ) . ' چرخه‌ی تو' : 'چرخه‌ات هنوز ثبت نشده'; ?></span>
			</div>
			<span class="card__icon card__icon--pink" aria-hidden="true"><?php echo Niva_Icons::svg( 'droplet', 20 ); ?></span>
		</div>

		<div class="metric-grid">
			<div class="metric-row">
				<span class="metric-row__label">پریود بعدی</span>
				<span class="metric-row__value"><?php echo $niva_cycle['has_data'] ? esc_html( $niva_cycle['next_date'] . ' · ' . $niva_cycle['next_in_fa'] . ' روز دیگر' ) : '—'; ?></span>
			</div>
			<div class="metric-row">
				<span class="metric-row__label">روزهای باروری</span>
				<span class="metric-row__value"><?php echo esc_html( $niva_cycle['has_data'] ? ( $niva_cycle['ranges']['fertile'] ?? '—' ) : '—' ); ?></span>
			</div>
			<div class="metric-row">
				<span class="metric-row__label">طول چرخه‌ی تو</span>
				<span class="metric-row__value"><?php echo esc_html( $niva_cycle['len_label'] ?? '—' ); ?></span>
			</div>
		</div>

		<?php if ( ! $niva_cycle['has_data'] ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'droplet', 26 ); ?>
				<span class="empty-state__title">چرخه‌ات هنوز ثبت نشده</span>
				<span class="caption">برای دیدن پیش‌بینی دوره و روزهای باروری، «اولین روز آخرین پریود» و «طول چرخه» را در تنظیمات حساب ثبت کن.</span>
				<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>">ثبت در تنظیمات حساب</a>
			</div>
		<?php endif; ?>
		<button type="button" class="btn btn--primary btn--block" data-mark-today data-lmp-current="<?php echo esc_attr( (string) Niva_Chrome::flag( 'lmp' ) ); ?>">
			<?php echo Niva_Icons::svg( 'plus', 18 ); ?>
			امروز پریودم شروع شد
		</button>
		<p class="caption" data-cycle-status aria-live="polite">با ثبت شروع پریود، پیش‌بینی چرخه بر اساس تاریخ واقعی تو به‌روز می‌شود.</p>
	</section>
</div>
