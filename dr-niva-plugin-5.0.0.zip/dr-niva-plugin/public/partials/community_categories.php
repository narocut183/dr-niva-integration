<?php
/**
 * Module partial: community_categories — the colour-coded category tiles (2.0.0).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

Niva_Community::enqueue();

$niva_community = dr_niva()->community instanceof Niva_Community ? dr_niva()->community : new Niva_Community();
$niva_cats      = $niva_community->categories();
$niva_base      = Niva_Modules::url( 'community_home', array(), home_url( '/' ) );
?>
<div class="niva-module niva-module--community_categories" data-module="community_categories" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--cyan"><?php echo Niva_Icons::svg( 'users', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h2 class="card__title">دسته‌بندی‌ها</h2>
			</div>
		</div>
		<nav class="community-tiles" aria-label="دسته‌بندی‌های گفتگو">
			<?php foreach ( $niva_cats as $niva_cat ) : ?>
				<a class="community-tile community-tile--<?php echo esc_attr( (string) $niva_cat['color'] ); ?>"
					href="<?php echo esc_url( add_query_arg( 'category', $niva_cat['slug'], $niva_base ) ); ?>">
					<span class="community-tile__icon"><?php echo Niva_Icons::svg( (string) $niva_cat['icon'], 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
					<span class="community-tile__title"><?php echo esc_html( (string) $niva_cat['title'] ); ?></span>
					<?php if ( ! empty( $niva_cat['description'] ) ) : ?>
						<span class="community-tile__text"><?php echo esc_html( (string) $niva_cat['description'] ); ?></span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</nav>
	</section>
</div>
