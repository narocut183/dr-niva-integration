<?php
/**
 * Module partial: about_mission
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--about_mission" data-module="about_mission" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<article class="spotlight spotlight--primary" data-component="about-visual">
            <div class="spotlight__media">
              <img
                src="<?php echo esc_url( DR_NIVA_URL . 'public/assets/'); ?>images/trust-space.jpg"
                alt="فضای آرام مشاوره با دو صندلی راحتی، میز کوچک چوبی و نور ملایم بعدازظهر روی دیوار"
                loading="lazy"
                width="1536"
                height="1024"
              />
            </div>
            <div class="spotlight__body">
              <span class="badge">مأموریت ما</span>
              <h2>داده‌ی سلامت را از سردرگمی به تصمیم تبدیل می‌کنیم</h2>
              <p class="muted">
                بیشتر مردم با انبوهی از گزارش، عدد و توصیه تنها می‌مانند. ما این داده‌ها را مرتب، خوانا و پیوسته می‌کنیم تا
                وقت ویزیت، سؤال درست بپرسی و تصمیم آگاهانه‌تری بگیری. هیچ‌گاه جای پزشک را نمی‌گیریم و هیچ خروجی‌ای بدون ذکر
                محدودیتش نمایش نمی‌دهیم.
              </p>
              <div class="spotlight__list">
                <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>طراحی فارسی و راست‌به‌چپ، دقیقاً برای کاربر ایرانی</span></span>
                <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>شماره‌های اضطراری و متن‌های بالینی قابل تنظیم توسط تیم شما</span></span>
              </div>
            </div>
          </article>
</div>
