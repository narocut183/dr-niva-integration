<?php
/**
 * Module partial: tools_advisor
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--tools_advisor" data-module="tools_advisor" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <h2 class="card__title">مشاور هوشمند و یادآور</h2>
              <span class="card__icon card__icon--purple" aria-hidden="true"><?php echo Niva_Icons::svg( 'message-circle', 20 ); ?></span>
            </div>
            <div class="tile-grid">
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'advisor', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'message-circle', 22 ); ?></span>
                گفت‌وگو با مشاور
              </a>
              <a class="tile tile--purple" href="<?php echo esc_url( Niva_Modules::url( 'advisor', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'sparkles', 22 ); ?></span>
                انتخاب موتور AI
              </a>
              <a class="tile tile--orange" href="<?php echo esc_url( Niva_Modules::url( 'reminders', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'bell', 22 ); ?></span>
                یادآور و اعلان
              </a>
              <a class="tile tile--orange" href="<?php echo esc_url( Niva_Modules::url( 'reminders', $args ) ); ?>">
                <span class="tile__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'clock', 22 ); ?></span>
                ساعت دارو
              </a>
            </div>
          </section>
</div>
