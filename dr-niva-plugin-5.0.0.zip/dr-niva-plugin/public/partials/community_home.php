<?php
/**
 * Module partial: community_home — the forum front page (2.0.0).
 *
 * Server-rendered so it works without Javascript; the script only takes over
 * for searching, sorting and "load more".
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

if ( ! dr_niva()->settings->is_on( 'community_enabled' ) ) {
	echo Niva_Chrome::blank( 'گفتگو با کاربران خاموش است', 'مدیر سرویس این بخش را موقتاً غیرفعال کرده است.', '', '', array() ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

Niva_Community::enqueue();

$niva_community = dr_niva()->community instanceof Niva_Community ? dr_niva()->community : new Niva_Community();
$niva_cats      = $niva_community->categories();
$niva_sort      = isset( $_GET['sort'] ) ? sanitize_key( wp_unslash( $_GET['sort'] ) ) : 'newest'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$niva_search    = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$niva_cat_slug  = isset( $_GET['category'] ) ? sanitize_key( wp_unslash( $_GET['category'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$niva_anchor    = isset( $_GET['anchor'] ) ? sanitize_key( wp_unslash( $_GET['anchor'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
$niva_cat_row   = '' !== $niva_cat_slug ? $niva_community->category_by_slug( $niva_cat_slug ) : array();

$niva_list = $niva_community->threads(
	array(
		'category_id' => $niva_cat_row ? (int) $niva_cat_row['id'] : 0,
		'anchor'      => $niva_anchor,
		'search'      => $niva_search,
		'sort'        => $niva_sort,
		'paged'       => max( 1, (int) ( $_GET['paged'] ?? 1 ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		'per_page'    => 10,
	)
);

$niva_anchor_filters = array(
	''         => 'همه',
	'cycle'    => 'چرخه و پریود',
	'pregnant' => 'بارداری',
	'baby'     => 'نوزاد',
	'general'  => 'عمومی',
);
?>
<div class="niva-module niva-module--community_home" data-module="community_home" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>"
	data-niva-community="<?php echo esc_attr( rest_url( Niva_Rest::NS . '/community/' ) ); ?>"
	data-niva-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>">

	<header class="community-top">
		<label class="community-search">
			<span class="screen-reader-text">جست‌وجو در گفتگوها</span>
			<input class="field__input" type="search" data-niva-community-search value="<?php echo esc_attr( $niva_search ); ?>" placeholder="جست‌وجو در موضوعات" />
		</label>
		<?php /* 2.0.1 — opens in place instead of leaving the screen. */ ?>
		<button type="button" class="btn btn--primary btn--sm" data-niva-modal-open="niva-community-new">پرسش تازه</button>
	</header>

	<nav class="community-tiles" aria-label="دسته‌بندی‌ها">
		<?php foreach ( $niva_cats as $niva_cat ) : ?>
			<a class="community-tile community-tile--<?php echo esc_attr( (string) $niva_cat['color'] ); ?><?php echo ( $niva_cat_row && (int) $niva_cat_row['id'] === (int) $niva_cat['id'] ) ? ' is-active' : ''; ?>"
				href="<?php echo esc_url( add_query_arg( 'category', $niva_cat['slug'], Niva_Modules::url( 'community_home', array(), home_url( '/' ) ) ) ); ?>">
				<span class="community-tile__icon"><?php echo Niva_Icons::svg( (string) $niva_cat['icon'], 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span class="community-tile__title"><?php echo esc_html( (string) $niva_cat['title'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</nav>

	<div class="community-toolbar">
		<div class="community-seg" role="tablist" aria-label="مرتب‌سازی">
			<?php
			$niva_sorts = array( 'newest' => 'جدیدترین', 'answers' => 'پرپاسخ', 'popular' => 'پرطرفدار', 'unanswered' => 'بدون پاسخ' );
			foreach ( $niva_sorts as $niva_key => $niva_label ) :
				?>
				<a role="tab" class="<?php echo $niva_sort === $niva_key ? 'is-active' : ''; ?>" aria-selected="<?php echo $niva_sort === $niva_key ? 'true' : 'false'; ?>"
					href="<?php echo esc_url( add_query_arg( 'sort', $niva_key, Niva_Modules::url( 'community_home', array(), home_url( '/' ) ) ) ); ?>"><?php echo esc_html( $niva_label ); ?></a>
			<?php endforeach; ?>
		</div>
		<div class="chip-row" aria-label="فیلتر مخاطب">
			<?php foreach ( $niva_anchor_filters as $niva_key => $niva_label ) : ?>
				<a class="chip<?php echo $niva_anchor === $niva_key ? ' is-selected' : ''; ?>" aria-selected="<?php echo $niva_anchor === $niva_key ? 'true' : 'false'; ?>"
					href="<?php echo esc_url( '' === $niva_key ? Niva_Modules::url( 'community_home', array(), home_url( '/' ) ) : add_query_arg( 'anchor', $niva_key, Niva_Modules::url( 'community_home', array(), home_url( '/' ) ) ) ); ?>"><?php echo esc_html( $niva_label ); ?></a>
			<?php endforeach; ?>
		</div>
	</div>

	<div class="community-list" data-niva-community-list>
		<?php if ( ! $niva_list['items'] ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'message-circle', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">هنوز گفتگویی این‌جا نیست</span>
				<span class="caption">اولین نفری باش که می‌پرسد؛ پرسش‌ها بعد از بازبینی کوتاه نمایش داده می‌شوند.</span>
				<button type="button" class="btn btn--primary btn--sm" data-niva-modal-open="niva-community-new">پرسش تازه</button>
			</div>
		<?php else : ?>
			<?php foreach ( $niva_list['items'] as $niva_thread ) : ?>
				<article class="community-card">
					<a class="community-card__title" href="<?php echo esc_url( $niva_thread['url'] ); ?>"><?php echo esc_html( $niva_thread['title'] ); ?></a>
					<?php if ( $niva_thread['is_pinned'] ) : ?>
						<span class="community-badge">سنجاق‌شده</span>
					<?php endif; ?>
					<?php if ( $niva_thread['is_featured'] ) : ?>
						<span class="community-badge community-badge--info">ویژه</span>
					<?php endif; ?>
					<p class="community-card__excerpt"><?php echo esc_html( $niva_thread['excerpt'] ); ?></p>
					<div class="community-card__meta">
						<span class="community-avatar" aria-hidden="true">
							<?php if ( '' !== $niva_thread['author_avatar'] ) : ?>
								<img src="<?php echo esc_url( $niva_thread['author_avatar'] ); ?>" alt="" width="28" height="28" />
							<?php else : ?>
								<?php echo esc_html( $niva_thread['author_letter'] ); ?>
							<?php endif; ?>
						</span>
						<span class="community-card__author"><?php echo esc_html( $niva_thread['author_name'] ); ?></span>
						<span class="community-card__dot">·</span>
						<span><?php echo esc_html( $niva_thread['time_ago'] ); ?></span>
						<?php if ( $niva_thread['category_title'] ) : ?>
							<span class="community-chip community-chip--<?php echo esc_attr( (string) $niva_thread['category_color'] ); ?>"><?php echo esc_html( (string) $niva_thread['category_title'] ); ?></span>
						<?php endif; ?>
						<span class="community-card__count">
							<?php echo esc_html( Niva_Chrome::digits( (string) $niva_thread['comment_count'] ) ); ?> پاسخ
						</span>
						<?php if ( $niva_thread['answered'] ) : ?>
							<span class="community-badge community-badge--ok">پاسخ داده شد</span>
						<?php else : ?>
							<span class="community-badge">در انتظار پاسخ</span>
						<?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>

	<?php if ( $niva_list['pages'] > 1 ) : ?>
		<button type="button" class="btn btn--secondary btn--block" data-niva-community-more
			data-page="1" data-pages="<?php echo esc_attr( (string) $niva_list['pages'] ); ?>"
			data-category="<?php echo esc_attr( $niva_cat_slug ); ?>" data-sort="<?php echo esc_attr( $niva_sort ); ?>"
			data-anchor="<?php echo esc_attr( $niva_anchor ); ?>" data-search="<?php echo esc_attr( $niva_search ); ?>">گفتگوهای بیشتر</button>
	<?php endif; ?>

	<p class="caption">
		متن پرسش‌ها بعد از بازبینی کوتاه منتشر می‌شود و شماره/لینک در متن‌ها به‌صورت خودکار پنهان می‌شود.
	</p>

	<?php /* 2.0.1 — compose in place: the form already exists in the page. */ ?>
	<div class="niva-modal" data-niva-modal="niva-community-new" hidden>
		<div class="niva-modal__backdrop" data-niva-modal-close></div>
		<div class="niva-modal__panel" role="dialog" aria-modal="true" aria-labelledby="niva-community-new-title">
			<div class="niva-modal__head">
				<h2 class="niva-modal__title" id="niva-community-new-title">پرسش تازه</h2>
				<button type="button" class="niva-modal__x" data-niva-modal-close aria-label="بستن"><?php echo Niva_Icons::svg( 'x', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			</div>
			<form class="niva-modal__body" data-niva-community-create>
				<label class="field">
					<span class="field__label">دسته‌بندی</span>
					<select class="field__input" name="category_id" data-niva-modal-focus>
						<option value="">انتخاب کن</option>
						<?php foreach ( $niva_cats as $niva_cat ) : ?>
							<option value="<?php echo esc_attr( (string) $niva_cat['id'] ); ?>" <?php selected( $niva_cat_row ? (int) $niva_cat_row['id'] : 0, (int) $niva_cat['id'] ); ?>><?php echo esc_html( (string) $niva_cat['title'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<label class="field">
					<span class="field__label">عنوان پرسش</span>
					<input class="field__input" name="title" required maxlength="120" placeholder="مثلاً: پریود نامنظم بعد از زایمان طبیعی است؟" />
				</label>
				<label class="field">
					<span class="field__label">توضیح</span>
					<textarea class="field__input" name="body" rows="5" required placeholder="کوتاه توضیح بده تا بقیه بهتر بتوانند کمک کنند."></textarea>
				</label>
				<p class="caption">شمارهٔ تماس و لینک در متن به‌صورت خودکار پنهان می‌شود.</p>
				<button type="submit" class="btn btn--primary btn--block">ثبت پرسش</button>
				<span class="field__hint" data-niva-community-message hidden></span>
				<a class="caption" href="<?php echo esc_url( Niva_Modules::url( 'community_new', array(), home_url( '/' ) ) ); ?>">باز کردن در صفحهٔ کامل</a>
			</form>
		</div>
	</div>
</div>
