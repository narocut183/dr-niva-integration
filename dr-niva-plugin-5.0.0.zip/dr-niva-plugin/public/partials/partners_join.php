<?php
/**
 * Module partial: partners_join — "همکاری با ما" application form.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_enabled = dr_niva()->settings->is_on( 'partners_enabled' );
$niva_types   = array();
foreach ( preg_split( '/\r\n|\r|\n/', (string) dr_niva()->settings->get( 'partner_types' ) ) as $niva_line ) {
	$niva_line = trim( $niva_line );
	if ( '' === $niva_line || false === strpos( $niva_line, '=' ) ) {
		continue;
	}
	list( $niva_key, $niva_label ) = array_map( 'trim', explode( '=', $niva_line, 2 ) );
	$niva_types[ $niva_key ]      = $niva_label;
}
$niva_partner = is_user_logged_in() ? dr_niva()->partners->by_user( get_current_user_id() ) : null;

/* Every line of «مزایای پلن همکاران» becomes one bullet on the form. */
$niva_perks = array();
foreach ( preg_split( '/\r\n|\r|\n/', (string) dr_niva()->settings->get( 'partner_plan_perks' ) ) as $niva_perk ) {
	$niva_perk = trim( $niva_perk );
	if ( '' !== $niva_perk ) {
		$niva_perks[] = $niva_perk;
	}
}
$niva_plan_title = (string) dr_niva()->settings->get( 'partner_plan_title' );
if ( '' === trim( $niva_plan_title ) ) {
	$niva_plan_title = 'پلن همکاران';
}
?>
<div class="niva-module niva-module--partners_join" data-module="partners_join" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">همکاری با ما</h2>
				<span class="caption">کلینیک، مطب، داروخانه، آزمایشگاه، مامایی، تغذیه یا تولید محتوا</span>
			</div>
			<span class="card__icon"><?php echo Niva_Icons::svg( 'badge-check', 20 ); ?></span>
		</div>

		<?php if ( ! $niva_enabled ) : ?>
			<p class="muted">ثبت‌نام همکاری فعلاً بسته است.</p>
		<?php elseif ( $niva_partner ) : ?>
			<div class="plain-list">
				<span class="plain-row"><span class="plain-row__name">وضعیت درخواستت</span><span class="plain-row__value">
					<?php
					$niva_status = array( 'pending' => 'در انتظار بررسی', 'approved' => 'تأییدشده', 'declined' => 'ردشده', 'suspended' => 'غیرفعال' );
					echo esc_html( isset( $niva_status[ $niva_partner['status'] ] ) ? $niva_status[ $niva_partner['status'] ] : $niva_partner['status'] );
					?>
				</span></span>
				<span class="plain-row"><span class="plain-row__name">کد معرف تو</span><span class="plain-row__value"><bdi dir="ltr"><?php echo esc_html( (string) $niva_partner['code'] ); ?></bdi></span></span>
			</div>
			<p class="caption">پنل کامل همکاران بعد از تأیید در همین صفحه نمایش داده می‌شود.</p>
		<?php else : ?>
			<div class="plain-list">
				<span class="plain-row"><span class="plain-row__name">پلنی که فعال می‌شود</span><span class="plain-row__value"><?php echo esc_html( $niva_plan_title ); ?></span></span>
				<span class="plain-row"><span class="plain-row__name">هزینه‌ی فعال‌سازی</span><span class="plain-row__value">بدون هزینه — فقط با درخواست تو</span></span>
				<span class="plain-row"><span class="plain-row__name">درصد پورسانت</span><span class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( number_format_i18n( (float) dr_niva()->settings->get( 'partner_commission' ) ) ) ); ?>٪ از هر سفارش</span></span>
				<span class="plain-row"><span class="plain-row__name">کد و لینک اختصاصی</span><span class="plain-row__value">بلافاصله پس از تأیید</span></span>
				<span class="plain-row"><span class="plain-row__name">پنل همکاران</span><span class="plain-row__value">کلیک‌ها، ثبت‌نام‌ها، فروش و تسویه</span></span>
			</div>

			<?php if ( $niva_perks ) : ?>
				<div class="partner-plan__perks">
					<span class="card__title">با فعال‌سازی این پلن چه چیزی به دست می‌آوری؟</span>
					<ul class="plan-card__list">
						<?php foreach ( $niva_perks as $niva_perk ) : ?>
							<li class="list-check">
								<?php echo Niva_Icons::svg( 'badge-check', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
								<span><?php echo esc_html( $niva_perk ); ?></span>
							</li>
						<?php endforeach; ?>
					</ul>
				</div>
			<?php endif; ?>

			<form class="stack" data-partner-form id="partner-form">
				<label class="field">
					<span class="field__label">نام یا نام مجموعه</span>
					<input class="field__input" id="partner-name" type="text" required />
				</label>
				<label class="field">
					<span class="field__label">نوع همکاری</span>
					<select class="field__input" id="partner-type">
						<?php foreach ( $niva_types as $niva_key => $niva_label ) : ?>
							<option value="<?php echo esc_attr( $niva_key ); ?>"><?php echo esc_html( $niva_label ); ?></option>
						<?php endforeach; ?>
					</select>
				</label>
				<div class="grid-2">
					<label class="field">
						<span class="field__label">تلفن</span>
						<input class="field__input" id="partner-phone" type="tel" dir="ltr" placeholder="09xxxxxxxxx" />
					</label>
					<label class="field">
						<span class="field__label">ایمیل</span>
						<input class="field__input" id="partner-email" type="email" dir="ltr" placeholder="name@example.com" />
					</label>
				</div>
				<label class="field">
					<span class="field__label">شهر</span>
					<input class="field__input" id="partner-city" type="text" />
				</label>
				<label class="field">
					<span class="field__label">توضیح کوتاه (اختیاری)</span>
					<textarea class="field__input" id="partner-note" rows="3" placeholder="چطور می‌خواهی با ما همکاری کنی؟"></textarea>
				</label>
				<button type="submit" class="btn btn--primary btn--block">ثبت درخواست همکاری</button>
				<span class="field__hint" data-partner-message hidden></span>
			</form>
		<?php endif; ?>
	</section>
</div>
