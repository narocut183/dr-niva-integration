<?php
/**
 * Module partial: lab_skeleton
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--lab_skeleton" data-module="lab_skeleton" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<div class="card">
              <span class="skeleton" style="height: 120px"></span>
            </div>
</div>
