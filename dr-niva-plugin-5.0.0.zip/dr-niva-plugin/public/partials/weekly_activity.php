<?php
/**
 * Module partial: weekly_activity — seven bars + the streak badge.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_user   = get_current_user_id();
$niva_series = Niva_Insights::weekly_series( $niva_user );
$niva_streak = Niva_Insights::streak( $niva_user );
$niva_total  = 0;
$niva_peak   = 0;

foreach ( $niva_series as $niva_day ) {
	$niva_total += (int) $niva_day['value'];
	$niva_peak   = max( $niva_peak, (int) $niva_day['value'] );
}
?>
<div class="niva-module niva-module--weekly_activity" data-module="weekly_activity" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">فعالیت این هفته</h2>
				<span class="caption">هر ستون، تعداد کارهایی است که آن روز در اپ انجام داده‌ای</span>
			</div>
			<?php if ( $niva_streak > 0 ) : ?>
				<span class="badge badge--success">
					<?php echo Niva_Icons::svg( 'trending-up', 14 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					<?php echo esc_html( Niva_Chrome::digits( $niva_streak ) ); ?> روز پیاپی
				</span>
			<?php endif; ?>
		</div>

		<?php if ( 0 === $niva_total ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'activity', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">این هفته هنوز چیزی ثبت نکرده‌ای</span>
				<span class="caption">با یک گفت‌وگو، یک اندازه‌گیری یا ثبت حال، نمودار زنده می‌شود.</span>
			</div>
		<?php else : ?>
			<div class="bar-chart" role="img"
				aria-label="فعالیت هفت روز گذشته؛ بیشترین روز <?php echo esc_attr( Niva_Chrome::digits( $niva_peak ) ); ?> کار">
				<?php foreach ( $niva_series as $niva_index => $niva_day ) : ?>
					<div class="bar-chart__col<?php echo ( count( $niva_series ) - 1 === $niva_index ) ? ' bar-chart__col--today' : ''; ?>">
						<span class="bar-chart__value"><?php echo esc_html( Niva_Chrome::digits( (int) $niva_day['value'] ) ); ?></span>
						<div class="bar-chart__track">
							<i class="bar-chart__bar" style="height: <?php echo esc_attr( max( 4, (int) $niva_day['height'] ) ); ?>%"></i>
						</div>
						<span class="bar-chart__label"><?php echo esc_html( $niva_day['label'] ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		<?php endif; ?>

		<div class="plain-list">
			<span class="plain-row">
				<span class="plain-row__name">جمع هفته</span>
				<span class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( $niva_total ) ); ?> کار</span>
			</span>
			<span class="plain-row">
				<span class="plain-row__name">پرکارترین روز</span>
				<span class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( $niva_peak ) ); ?> کار</span>
			</span>
			<span class="plain-row">
				<span class="plain-row__name">زنجیره‌ی پیوسته</span>
				<span class="plain-row__value"><?php echo esc_html( Niva_Chrome::digits( $niva_streak ) ); ?> روز</span>
			</span>
		</div>
	</section>
</div>
