<?php
/**
 * Module partial: lab_chart
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice();
	return;
}

$niva_used = array();
foreach ( Niva_Labs::latest() as $niva_marker => $niva_entry ) {
	$niva_series = Niva_Labs::series_entries( get_current_user_id(), $niva_marker );
	if ( count( $niva_series ) >= 2 ) {
		$niva_used[ $niva_marker ] = $niva_series;
	}
}
?>
<div class="niva-module niva-module--lab_chart" data-module="lab_chart" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
  <section class="card">
    <div class="card__head">
      <h2 class="card__title">روند آزمایش‌ها</h2>
      <span class="caption">فقط آزمایش‌هایی که دو بار یا بیشتر ثبت شده‌اند</span>
    </div>
    <?php if ( $niva_used ) : ?>
      <?php foreach ( $niva_used as $niva_marker => $niva_series ) : ?>
        <div class="stack" style="gap: 6px">
          <?php $niva_meta = Niva_Labs::markers()[ $niva_marker ] ?? array( $niva_series[ count( $niva_series ) - 1 ]['name'] ?: $niva_marker, $niva_series[ count( $niva_series ) - 1 ]['unit'], 0, 0 ); ?>
          <span class="caption"><?php echo esc_html( ( $niva_series[ count( $niva_series ) - 1 ]['name'] ?: $niva_meta[0] ) . ( $niva_series[ count( $niva_series ) - 1 ]['unit'] ? ' (' . $niva_series[ count( $niva_series ) - 1 ]['unit'] . ')' : '' ) ); ?></span>
          <div class="lab-trend" role="img" aria-label="<?php echo esc_attr( 'روند ' . Niva_Labs::label( $niva_marker ) ); ?>">
            <?php foreach ( $niva_series as $niva_point => $niva_item ) : ?>
              <?php $niva_height = max( 8, min( 100, (int) round( ( $niva_item['value'] / max( 1, max( array_column( $niva_series, 'value' ) ) * 1.25 ) ) * 100 ) ) ); ?>
              <div class="lab-trend__point">
                <span class="lab-trend__value"><?php echo esc_html( Niva_Chrome::digits( $niva_item['value'] ) ); ?></span>
                <span class="lab-trend__bar" style="height: <?php echo esc_attr( (string) $niva_height ); ?>%"></span>
                <span class="caption"><?php echo esc_html( $niva_item['date'] ? Niva_Chrome::format_date( (string) $niva_item['date'] ) : Niva_Chrome::digits( $niva_point + 1 ) ); ?></span>
              </div>
            <?php endforeach; ?>
          </div>
        </div>
      <?php endforeach; ?>
    <?php else : ?>
      <?php echo Niva_Chrome::blank( 'نموداری برای نمایش نیست', 'وقتی یک آزمایش را در دو تاریخ مختلف ثبت کنی، روندش این‌جا ساخته می‌شود.', 'ثبت نتیجهٔ آزمایش', 'lab', $args ); ?>
    <?php endif; ?>
  </section>
</div>
