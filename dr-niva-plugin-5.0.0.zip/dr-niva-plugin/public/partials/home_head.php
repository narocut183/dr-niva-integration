<?php
/**
 * Module partial: home_head — the dashboard hero.
 *
 * The blue band at the top of the home screen: today's date, the account's own
 * avatar and up to three *real* status figures (cycle day / pregnancy week /
 * child age / latest lab). Nothing here is sample data: a figure only appears
 * when the profile actually carries it, and a brand-new account gets a clear
 * "complete your profile" call to action instead of invented numbers.
 *
 * @var array $args
 * @package DrNiva
 */

defined( 'ABSPATH' ) || exit;

$niva_logged = is_user_logged_in();

/* Only read the profile when there is one — a guest sees the marketing band. */
$niva_cycle  = $niva_logged ? Niva_Chrome::cycle_state() : array( 'has_data' => false );
$niva_sex    = $niva_logged ? strtolower( (string) Niva_Chrome::flag( 'sex' ) ) : '';
$niva_preg   = $niva_logged && in_array( strtolower( (string) Niva_Chrome::flag( 'pregnant' ) ), array( '1', 'yes', 'true' ), true );
$niva_due    = $niva_logged ? (string) Niva_Chrome::flag( 'due_date' ) : '';
$niva_baby   = $niva_logged ? (string) Niva_Chrome::flag( 'baby_name' ) : '';
$niva_birth  = $niva_logged ? (string) Niva_Chrome::flag( 'baby_birth' ) : '';
$niva_labs   = $niva_logged && class_exists( 'Niva_Labs' ) ? Niva_Labs::latest() : array();

$niva_stats = array();

/* 1 — cycle day, only when the user actually recorded a period. */
if ( $niva_logged && 'male' !== $niva_sex ) {
	if ( ! empty( $niva_cycle['has_data'] ) ) {
		$niva_stats[] = array(
			'value' => 'روز ' . (string) $niva_cycle['cycle_day_fa'],
			'label' => 'چرخهٔ تو',
		);
	} else {
		$niva_stats[] = array( 'value' => '—', 'label' => 'چرخه ثبت نشده' );
	}
}

/* 2 — pregnancy week and days left, from the recorded due date. */
if ( $niva_preg ) {
	$niva_week = 0;
	$niva_left = 0;
	if ( '' !== $niva_due && strtotime( $niva_due ) ) {
		$niva_left = (int) floor( ( strtotime( 'today', strtotime( $niva_due ) ) - strtotime( 'today' ) ) / DAY_IN_SECONDS );
		$niva_week = max( 1, min( 42, 40 - (int) ceil( $niva_left / 7 ) ) );
	}
	if ( $niva_week > 0 ) {
		$niva_stats[] = array(
			'value' => 'هفته ' . Niva_Chrome::digits( $niva_week ),
			'label' => $niva_left > 0 ? Niva_Chrome::digits( $niva_left ) . ' روز تا زایمان' : 'بارداری فعال',
		);
	}
}

/* 3 — the child's age, from the recorded birth date. */
if ( '' !== $niva_baby ) {
	$niva_age_label = '';
	if ( '' !== $niva_birth && strtotime( $niva_birth ) ) {
		$niva_days_old  = (int) floor( ( strtotime( 'today' ) - strtotime( 'today', strtotime( $niva_birth ) ) ) / DAY_IN_SECONDS );
		$niva_age_label = $niva_days_old < 60
			? Niva_Chrome::digits( $niva_days_old ) . ' روز'
			: Niva_Chrome::digits( (int) floor( $niva_days_old / 30 ) ) . ' ماه';
	}
	$niva_stats[] = array(
		'value' => $niva_baby,
		'label' => '' !== $niva_age_label ? $niva_age_label : 'پروندهٔ رشد',
	);
}

/* 4 — the latest recorded lab marker, if any. */
if ( $niva_labs ) {
	$niva_last = reset( $niva_labs );
	if ( is_array( $niva_last ) && ! empty( $niva_last['marker'] ) ) {
		$niva_stats[] = array(
			'value' => Niva_Chrome::digits( (string) $niva_last['value'] ) . ' ' . Niva_Labs::unit( (string) $niva_last['marker'] ),
			'label' => Niva_Labs::label( (string) $niva_last['marker'] ),
		);
	}
}

$niva_stats = array_slice( $niva_stats, 0, 3 );
?>
<div class="niva-module niva-module--home_head" data-module="home_head" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="nv-hero">
		<div class="nv-hero__top">
			<div class="nv-hero__body">
				<span class="nv-hero__date" data-niva-date><?php echo esc_html( Niva_Chrome::today_label() ); ?></span>
				<h1 class="nv-hero__title"><?php echo esc_html( $niva_logged ? 'سلامت تو، همین حالا' : 'سلامت من' ); ?></h1>
				<span class="nv-hero__sub"><?php echo esc_html( $niva_logged ? 'خلاصهٔ وضعیت واقعی حساب تو' : 'همراه هوشمند بانوان — امروز، درست، آرام' ); ?></span>
			</div>
			<a class="nv-avatar" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>" aria-label="پروفایل من">
				<?php echo Niva_Chrome::avatar( '', 46 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
		</div>

		<?php if ( $niva_stats ) : ?>
			<div class="nv-hero__stats">
				<?php foreach ( $niva_stats as $niva_stat ) : ?>
					<div class="nv-hero__stat">
						<b><?php echo esc_html( $niva_stat['value'] ); ?></b>
						<span><?php echo esc_html( $niva_stat['label'] ); ?></span>
					</div>
				<?php endforeach; ?>
			</div>
		<?php elseif ( $niva_logged ) : ?>
			<div class="nv-hero__stats">
				<div class="nv-hero__stat">
					<b>پروفایل ناقص</b>
					<span>تاریخ‌ها را وارد کن تا این بخش واقعی شود</span>
				</div>
			</div>
			<a class="btn btn--secondary btn--block" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>">
				تکمیل پروفایل
			</a>
		<?php else : ?>
			<a class="btn btn--secondary btn--block" href="<?php echo esc_url( wp_login_url( get_permalink() ? get_permalink() : home_url( '/' ) ) ); ?>">
				ورود / ثبت‌نام
			</a>
		<?php endif; ?>
	</section>
</div>
