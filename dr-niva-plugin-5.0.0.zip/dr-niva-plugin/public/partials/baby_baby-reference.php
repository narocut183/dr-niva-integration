<?php
/**
 * Module partial: baby_baby-reference
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* Baby screens need a baby on file. */
if ( '' === (string) Niva_Chrome::flag( 'baby_birth' ) && '' === (string) Niva_Chrome::flag( 'baby_name' ) ) {
	echo Niva_Chrome::blank( 'پروندهٔ کودک ساخته نشده', 'نام و تاریخ تولد کودک را در تنظیمات حساب ثبت کن تا این بخش با داده‌های واقعی ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--baby_baby-reference" data-baby-root data-module="baby_baby-reference" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card" data-baby-reference>
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">مقایسه با جدول مرجع رشد</h2>
                <span class="caption">بر پایه جدول رسمی رشد (سازمان جهانی بهداشت / وزارت بهداشت)</span>
              </div>
              <span class="card__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'lock', 20 ); ?></span>
            </div>

            <p class="muted" style="font-size: var(--t-sm)">
              برای گفتن این جمله که «قد و وزن در این سن داخل محدوده طبیعی است یا نه»، جدول مرجع عددی لازم است. این جدول
              باید از منبع رسمی استخراج و توسط تیم پزشکی شما تأیید شود؛ ما عدد حدسی وارد نمی‌کنیم.
            </p>

            <div class="alert alert--caution">
              <span class="alert__icon"><?php echo Niva_Icons::svg( 'alert-triangle', 20 ); ?></span>
              <div class="alert__body">
                <span class="alert__title">این بخش در حال آماده‌سازی است</span>
                <div class="alert__text">
                  تا زمانی که جدول مرجع تأیید نشود، تحلیل «روند رشد خود کودک» (بالا) فعال است و همان مبنای پیگیری است.
                </div>
              </div>
            </div>
          </section>
</div>
