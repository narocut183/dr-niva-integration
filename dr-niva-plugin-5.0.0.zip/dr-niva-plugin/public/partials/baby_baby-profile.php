<?php
/**
 * Module partial: baby_baby-profile
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
$niva_profile = dr_niva()->profile->get();
$niva_birth   = (string) ( $niva_profile['baby_birth'] ?? '' );
$niva_name    = (string) ( $niva_profile['baby_name'] ?? '' );
if ( '' === $niva_birth || ! strtotime( $niva_birth ) ) {
	echo Niva_Chrome::blank( 'پروندهٔ کودک کامل نیست', 'تاریخ تولد کودک را در تنظیمات حساب ثبت کن تا سن و روند رشد درست محاسبه شوند.', 'تنظیمات حساب', 'profile', $args );
	return;
}
$niva_birth_parts = Niva_Chrome::jalali( strtotime( $niva_birth ) );
?>
<div class="niva-module niva-module--baby_baby-profile" data-baby-root data-baby-name="<?php echo esc_attr( $niva_name ); ?>" data-baby-year="<?php echo esc_attr( $niva_birth_parts[0] ); ?>" data-baby-month="<?php echo esc_attr( $niva_birth_parts[1] ); ?>" data-baby-day="<?php echo esc_attr( $niva_birth_parts[2] ); ?>" data-module="baby_baby-profile" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
	<div class="card__head">
		<div class="stack" style="gap: 2px">
			<h2 class="card__title">مشخصات کودک</h2>
			<span class="caption">از نام و تاریخ تولدی استفاده می‌کنیم که در پروفایلت ثبت کرده‌ای.</span>
		</div>
		<span class="card__icon card__icon--cyan" aria-hidden="true"><?php echo Niva_Icons::svg( 'baby', 20 ); ?></span>
	</div>
	<div class="metric-row"><span class="metric-row__label">نام</span><span class="metric-row__value" data-baby-name-out><?php echo esc_html( $niva_name ?: 'کودک' ); ?></span></div>
	<div class="metric-row"><span class="metric-row__label">سن</span><span class="metric-row__value" data-baby-age>—</span></div>
	<div class="metric-row"><span class="metric-row__label">تاریخ تولد</span><span class="metric-row__value" data-baby-born><?php echo esc_html( Niva_Chrome::digits( sprintf( '%04d/%02d/%02d', $niva_birth_parts[0], $niva_birth_parts[1], $niva_birth_parts[2] ) ) ); ?></span></div>
	<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'profile', $args ) ); ?>">ویرایش اطلاعات کودک</a>
</section>
</div>
