<?php
/**
 * Onboarding wizard — module `onboarding_wizard`.
 *
 * A full-page, one-question-per-step wizard. PHP is the source of truth for the
 * steps, their order and who may see them (see Niva_Onboarding); the markup here
 * only renders the shell and hands that state to the script, which builds the
 * controls and saves each step over REST.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

wp_enqueue_style( 'dr-niva-onboarding' );
wp_enqueue_script( 'dr-niva-onboarding' );

if ( ! is_user_logged_in() ) {
	?>
	<div class="niva-ob niva-ob--guest niva-module" data-niva-build="<?php echo esc_attr( DR_NIVA_VERSION ); ?>">
		<div class="card stack">
			<h2 class="card__title">برای تکمیل پروفایل اول وارد شو</h2>
			<p class="caption">بعد از ورود، چند سؤال کوتاه می‌پرسیم تا اپ دقیقاً مناسب تو شود.</p>
			<p><a class="btn btn--primary" href="<?php echo esc_url( wp_login_url( get_permalink() ) ); ?>">ورود به حساب</a></p>
		</div>
	</div>
	<?php
	return;
}

$niva_onboarding = dr_niva()->onboarding instanceof Niva_Onboarding ? dr_niva()->onboarding : new Niva_Onboarding();
$niva_state      = $niva_onboarding->state();

if ( ! dr_niva()->settings->is_on( 'onboarding_wizard_enabled' ) ) {
	?>
	<div class="niva-ob niva-module">
		<div class="empty-state">
			<span class="empty-state__title">تکمیل پروفایل غیرفعال است</span>
			<span class="caption">مدیر سرویس این بخش را خاموش کرده است. می‌توانی از «پروفایل من» اطلاعات را ویرایش کنی.</span>
		</div>
	</div>
	<?php
	return;
}

$niva_config = array(
	'state'     => $niva_state,
	'steps'     => $niva_state['steps'],
	'order'     => $niva_state['order'],
	'values'    => $niva_state['values'],
	'focus'     => Niva_Onboarding::focus_areas(),
	'months'    => Niva_Chrome::months(),
	'weekdays'  => Niva_Chrome::weekdays(),
	'rest'      => esc_url_raw( rest_url( Niva_Rest::NS . '/' ) ),
	'nonce'     => wp_create_nonce( 'wp_rest' ),
	'yearMin'   => 1300,
	'yearMax'   => (int) ( (int) gmdate( 'Y' ) - 621 + 1 ),
	'loginUrl'  => wp_login_url( get_permalink() ),
	'profileUrl' => Niva_Modules::url( 'profile_hub', array(), home_url( '/' ) ),
);
?>
<div class="niva-ob niva-module"
	data-niva-build="<?php echo esc_attr( DR_NIVA_VERSION ); ?>"
	data-niva-wizard
	data-config="<?php echo esc_attr( (string) wp_json_encode( $niva_config ) ); ?>">

	<header class="niva-ob__top">
		<a class="niva-ob__close" href="<?php echo esc_url( $niva_config['profileUrl'] ); ?>" data-niva-ob-close aria-label="خروج از ویزارد">
			<?php echo Niva_Icons::svg( 'arrow-left', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			<span>خروج</span>
		</a>
		<div class="niva-ob__progress" role="progressbar" aria-valuemin="0" aria-valuemax="100" aria-valuenow="0" aria-label="پیشرفت تکمیل پروفایل">
			<span class="niva-ob__progress-fill" data-niva-ob-progress></span>
		</div>
		<button type="button" class="niva-ob__skip" data-niva-ob-skip hidden>رد کردن</button>
	</header>

	<main class="niva-ob__body">
		<span class="niva-ob__step-label" data-niva-ob-label></span>
		<h1 class="niva-ob__title" data-niva-ob-title>اسمت را بنویس</h1>
		<p class="niva-ob__hint" data-niva-ob-hint></p>
		<p class="niva-ob__build"><small>نسخهٔ <?php echo esc_html( DR_NIVA_VERSION ); ?></small></p>
		<div class="niva-ob__control" data-niva-ob-control></div>
		<p class="niva-ob__error" data-niva-ob-error hidden></p>
	</main>

	<footer class="niva-ob__foot">
		<button type="button" class="btn btn--ghost" data-niva-ob-prev hidden>قبلی</button>
		<button type="button" class="btn btn--primary btn--block" data-niva-ob-next>مرحله بعد</button>
	</footer>

	<div class="niva-ob__summary" data-niva-ob-summary hidden></div>
</div>
