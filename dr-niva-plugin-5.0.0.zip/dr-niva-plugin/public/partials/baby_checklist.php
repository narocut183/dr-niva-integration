<?php
/**
 * Module partial: baby_checklist
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* Baby screens need a baby on file. */
if ( '' === (string) Niva_Chrome::flag( 'baby_birth' ) && '' === (string) Niva_Chrome::flag( 'baby_name' ) ) {
	echo Niva_Chrome::blank( 'پروندهٔ کودک ساخته نشده', 'نام و تاریخ تولد کودک را در تنظیمات حساب ثبت کن تا این بخش با داده‌های واقعی ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--baby_checklist" data-baby-root data-module="baby_checklist" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">چک‌لیست این ماه</h2>
                <span class="caption"><bdi data-checklist-count>۰</bdi> از ۵ مورد انجام شده</span>
              </div>
              <span class="card__icon card__icon--green" aria-hidden="true"><?php echo Niva_Icons::svg( 'clipboard-list', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
            </div>
            <div class="checklist" data-checklist>
              <button type="button" class="checklist__item" aria-pressed="false">
                <span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
                <span class="checklist__label">اندازه‌گیری قد و وزن</span>
              </button>
              <button type="button" class="checklist__item" aria-pressed="false">
                <span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
                <span class="checklist__label">ویزیت دوره‌ای کودک</span>
              </button>
              <button type="button" class="checklist__item" aria-pressed="false">
                <span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
                <span class="checklist__label">واکسن‌های این ماه طبق کارت واکسن</span>
              </button>
              <button type="button" class="checklist__item" aria-pressed="false">
                <span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
                <span class="checklist__label">بررسی الگوی خواب و تغذیه</span>
              </button>
              <button type="button" class="checklist__item" aria-pressed="false">
                <span class="checklist__box" aria-hidden="true"><?php echo Niva_Icons::svg( 'check', 14 ); ?></span>
                <span class="checklist__label">نوشتن سؤال‌های ویزیت بعدی</span>
              </button>
            </div>
          </section>
</div>
