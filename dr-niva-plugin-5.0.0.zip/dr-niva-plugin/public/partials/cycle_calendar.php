<?php
/**
 * Module partial: cycle_calendar
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
$niva_cycle = Niva_Chrome::cycle_state();
$niva_attr  = static function ( $key ) use ( $niva_cycle ) {
	$value = $niva_cycle[ $key ] ?? array();
	return is_array( $value ) ? implode( ',', array_map( 'intval', $value ) ) : (string) $value;
};
?>
<div class="niva-module niva-module--cycle_calendar" data-module="cycle_calendar" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="flex" style="gap: var(--s-3); min-width: 0">
				<span class="card__icon card__icon--teal" aria-hidden="true"><?php echo Niva_Icons::svg( 'calendar-days', 20 ); ?></span>
				<div class="stack" style="gap: 2px">
					<h2 class="card__title">تقویم <?php echo esc_html( Niva_Chrome::month_label() ); ?></h2>
					<span class="caption" data-day-title>روز <?php echo esc_html( Niva_Chrome::today_short() ); ?></span>
				</div>
			</div>
			<span class="badge" data-day-meta><?php echo ! empty( $niva_cycle['has_data'] ) ? 'در حال محاسبه' : 'اطلاعات چرخه را ثبت کن'; ?></span>
		</div>

		<div class="calendar" aria-label="تقویم <?php echo esc_attr( Niva_Chrome::month_label() ); ?>">
			<div class="calendar__head" aria-hidden="true">
				<span class="calendar__weekday">شنبه</span>
				<span class="calendar__weekday">یکشنبه</span>
				<span class="calendar__weekday">دوشنبه</span>
				<span class="calendar__weekday">سه‌شنبه</span>
				<span class="calendar__weekday">چهارشنبه</span>
				<span class="calendar__weekday">پنجشنبه</span>
				<span class="calendar__weekday">جمعه</span>
			</div>
			<div class="calendar__grid" data-calendar data-today="<?php echo esc_attr( $niva_cycle['today'] ); ?>" data-days="<?php echo esc_attr( $niva_cycle['days_in_month'] ); ?>" data-offset="<?php echo esc_attr( $niva_cycle['offset'] ); ?>" data-month="<?php echo esc_attr( $niva_cycle['month_name'] ); ?>" data-year="<?php echo esc_attr( $niva_cycle['year'] ); ?>" data-period="<?php echo esc_attr( $niva_attr( 'period' ) ); ?>" data-predicted="<?php echo esc_attr( $niva_attr( 'predicted' ) ); ?>" data-fertile="<?php echo esc_attr( $niva_attr( 'fertile' ) ); ?>" data-ovulation="<?php echo esc_attr( $niva_attr( 'ovulation' ) ); ?>" data-pms="<?php echo esc_attr( $niva_attr( 'pms' ) ); ?>" data-symptoms=""></div>
		</div>

		<div class="legend">
			<span class="legend__item">
				<span class="legend__label"><span class="legend__swatch legend__swatch--period" aria-hidden="true"></span>دوره پریود</span>
				<span class="legend__range legend__range--period"><?php echo esc_html( $niva_cycle['ranges']['period'] ?? '—' ); ?></span>
			</span>
			<span class="legend__item">
				<span class="legend__label"><span class="legend__swatch legend__swatch--fertile" aria-hidden="true"></span>دوره باروری</span>
				<span class="legend__range legend__range--fertile"><?php echo esc_html( $niva_cycle['ranges']['fertile'] ?? '—' ); ?></span>
			</span>
			<span class="legend__item">
				<span class="legend__label"><span class="legend__swatch legend__swatch--ovulation" aria-hidden="true"></span>تخمک‌گذاری</span>
				<span class="legend__range legend__range--ovulation"><?php echo esc_html( $niva_cycle['ranges']['ovulation'] ?? '—' ); ?></span>
			</span>
			<span class="legend__item">
				<span class="legend__label"><span class="legend__swatch legend__swatch--pms" aria-hidden="true"></span>دوره PMS</span>
				<span class="legend__range legend__range--pms"><?php echo esc_html( $niva_cycle['ranges']['pms'] ?? '—' ); ?></span>
			</span>
		</div>
	</section>
</div>
