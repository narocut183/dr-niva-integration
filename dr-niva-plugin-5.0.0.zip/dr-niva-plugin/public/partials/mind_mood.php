<?php
/**
 * Module partial: mind_mood
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--mind_mood" data-module="mind_mood" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">حال تو در این ماه‌ها</h2>
				<span class="caption">فقط پرسشنامه‌هایی که خودت پر کرده‌ای</span>
			</div>
			<span class="card__icon card__icon--pink" aria-hidden="true"><?php echo Niva_Icons::svg( 'smile', 20 ); ?></span>
		</div>
		<?php
		$niva_mood = array_filter( array_map( 'trim', explode( ',', (string) Niva_Chrome::flag( 'mood_scores' ) ) ), 'strlen' );
		if ( $niva_mood ) :
			$niva_last = (int) end( $niva_mood );
			?>
			<p class="muted" style="font-size: var(--t-sm)">آخرین نمرهٔ تو <b><?php echo esc_html( Niva_Chrome::digits( $niva_last ) ); ?> از ۲۷</b> بوده است. روند پایین را ببین.</p>
			<?php echo Niva_Chrome::bars( $niva_mood, 27, array() ); ?>
			<a class="btn btn--secondary btn--block" href="<?php echo esc_url( Niva_Modules::url( 'mind', $args ) ); ?>">پر کردن پرسشنامهٔ این ماه</a>
		<?php else : ?>
			<?php echo Niva_Chrome::blank( 'هنوز پرسشنامه‌ای پر نکرده‌ای', 'با یک پرسشنامهٔ دو دقیقه‌ای شروع کن؛ روند حال‌ت از همین جا ساخته می‌شود.', 'شروع پرسشنامه', 'mind', $args ); ?>
		<?php endif; ?>
	</section>
</div>
