<?php
/**
 * Module partial: home_plan — "do I have a subscription?" answered on the home
 * screen, with the free plan shown plainly when there is none.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_logged = is_user_logged_in();
$niva_member = $niva_logged ? dr_niva()->plans->summary( get_current_user_id() ) : null;
$niva_rows   = array(
	'chat_per_day'    => array( 'گفت‌وگوی امروز', 'پیام' ),
	'lab_per_month'   => array( 'تحلیل آزمایش این ماه', 'گزارش' ),
	'growth_profiles' => array( 'پرونده‌ی رشد', 'پرونده' ),
);
?>
<div class="niva-module niva-module--home_plan" data-module="home_plan" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card niva-plan-card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">اشتراک من</h2>
				<span class="caption">
					<?php echo $niva_logged ? 'وضعیت اشتراک و سهمیه‌ی امروزت' : 'با ثبت‌نام، سهمیه‌ی رایگان روزانه فعال می‌شود'; ?>
				</span>
			</div>
			<?php if ( $niva_logged && $niva_member['active'] ) : ?>
				<span class="badge badge--green"><?php echo Niva_Icons::svg( 'check', 14 ); ?>فعال</span>
			<?php else : ?>
				<span class="badge">رایگان</span>
			<?php endif; ?>
		</div>

		<?php if ( ! $niva_logged ) : ?>
			<p class="muted">وارد شو تا سهمیه‌ی رایگان روزانه‌ات را ببینی و اشتراکت را فعال کنی.</p>
			<a class="btn btn--primary" href="<?php echo esc_url( wp_login_url( get_permalink() ? get_permalink() : home_url( '/' ) ) ); ?>">ورود / ثبت‌نام</a>
		<?php else : ?>
			<div class="plain-list">
				<span class="plain-row">
					<span class="plain-row__name">پلن فعلی</span>
					<span class="plain-row__value"><?php echo esc_html( $niva_member['label'] ); ?></span>
				</span>
				<?php if ( $niva_member['active'] ) : ?>
					<span class="plain-row">
						<span class="plain-row__name">اعتبار اشتراک</span>
						<span class="plain-row__value">
							<?php echo $niva_member['expires'] ? esc_html( Niva_Chrome::format_datetime_gmt( (string) $niva_member['expires'] ) ) : 'بدون محدودیت زمانی'; ?>
						</span>
					</span>
					<?php if ( $niva_member['inherited'] ) : ?>
						<span class="plain-row">
							<span class="plain-row__name">نوع اشتراک</span>
							<span class="plain-row__value">عضو اشتراک خانوادگی</span>
						</span>
					<?php endif; ?>
				<?php endif; ?>
			</div>

			<?php foreach ( $niva_rows as $key => $row ) : ?>
				<?php
				$data  = isset( $niva_member['limits'][ $key ] ) ? $niva_member['limits'][ $key ] : null;
				if ( ! $data ) {
					continue;
				}
				$percent = $data['unlimited'] ? 100 : ( $data['limit'] > 0 ? min( 100, (int) round( ( $data['used'] / $data['limit'] ) * 100 ) ) : 0 );
				?>
				<div class="metric-row">
					<span class="metric-row__label"><?php echo esc_html( $row[0] ); ?></span>
					<span class="metric-row__value">
						<?php if ( $data['unlimited'] ) : ?>
							بی‌نهایت
						<?php else : ?>
							<?php echo esc_html( number_format_i18n( $data['remaining'] ) ); ?> از <?php echo esc_html( number_format_i18n( $data['limit'] ) ); ?> <?php echo esc_html( $row[1] ); ?> باقی
						<?php endif; ?>
					</span>
				</div>
				<?php if ( ! $data['unlimited'] ) : ?>
					<div class="progress" style="--fill: <?php echo esc_attr( $percent ); ?>%">
						<span class="progress__fill" style="width: <?php echo esc_attr( $percent ); ?>%"></span>
					</div>
				<?php endif; ?>
			<?php endforeach; ?>

			<?php if ( ! $niva_member['active'] ) : ?>
				<div class="alert alert--info">
					<span class="alert__icon"><?php echo Niva_Icons::svg( 'info', 20 ); ?></span>
					<div class="alert__body">
						<span class="alert__title">الان روی پلن رایگان هستی</span>
						<div class="alert__text">سهمیه‌ی روزانه داری؛ برای تحلیل بیشتر، پرونده‌ی خانوادگی و پشتیبانی پزشک، اشتراک بگیر.</div>
					</div>
				</div>
			<?php endif; ?>

			<a class="btn btn--primary btn--block" href="<?php echo esc_url( ! empty( $niva_member['active'] ) ? $niva_member['credits_url'] : $niva_member['upgrade_url'] ); ?>">
				<?php echo $niva_member['active'] ? 'مدیریت اشتراک و خرید اعتبار' : 'دیدن پلن‌ها و فعال‌سازی اشتراک'; ?>
			</a>
		<?php endif; ?>
	</section>
</div>
