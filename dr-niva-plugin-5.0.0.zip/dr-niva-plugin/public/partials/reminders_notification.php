<?php
/**
 * Module partial: reminders_notification
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--reminders_notification" data-module="reminders_notification" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card">
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">اجازه‌ی اعلان</h2>
                <span class="caption" data-notify-status>وضعیت: بررسی می‌شود…</span>
              </div>
              <span class="card__icon card__icon--orange" aria-hidden="true"><?php echo Niva_Icons::svg( 'bell', 20 ); ?></span>
            </div>

            <p class="muted" style="font-size: var(--t-sm)">
              برای فعال‌سازی، دکمه را بزن و اجازهٔ اعلان مرورگر را تأیید کن. اعلان داخل سایت بدون اجازهٔ مرورگر در صندوق اعلان‌ها
              ثبت می‌شود؛ اعلان سیستمی فقط تا وقتی صفحه باز است نمایش داده می‌شود.
            </p>

            <div class="flex wrap gap-2">
              <button type="button" class="btn btn--primary" data-notify-permission>
                <?php echo Niva_Icons::svg( 'bell', 18 ); ?>
                فعال‌کردن اعلان
              </button>
              <button type="button" class="btn btn--secondary" data-notify-test>
                <?php echo Niva_Icons::svg( 'play', 18 ); ?>
                اعلان آزمایشی با صدا
              </button>
              <button type="button" class="btn btn--secondary" data-sound-toggle aria-pressed="true">
                <?php echo Niva_Icons::svg( 'activity', 18 ); ?>
                صدا: روشن
              </button>
            </div>

            <div class="alert alert--info">
              <span class="alert__icon"><?php echo Niva_Icons::svg( 'info', 20 ); ?></span>
              <div class="alert__body">
                <div class="alert__text">
                  بله؛ اعلان فقط داخل خود سایت هم ممکن است و در صندوق اعلان‌ها می‌ماند. برای پوش در حالت بسته‌بودن صفحه،
                  HTTPS، مجوز کاربر، Service Worker، کلیدهای VAPID و یک فرستندهٔ رمزنگاری‌شدهٔ Web Push لازم است؛
                  بدون فرستنده فقط اعلان داخل سایت ثبت می‌شود.
                </div>
              </div>
            </div>
          </section>
</div>
