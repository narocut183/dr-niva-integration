<?php
/**
 * Module partial: about_contact
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--about_contact" data-module="about_contact" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="section section--tight" data-component="about-contact">
        <div class="container stack--lg">
          <div class="stack" data-component="section-heading">
            <span class="badge"><?php echo Niva_Icons::svg( 'mail', 14 ); ?>تماس</span>
            <h2>چطور با ما در ارتباط باشی</h2>
            <p class="lede">
              برای اینکه هیچ اطلاعات تأییدنشده‌ای روی سایت نباشد، راه‌های تماس پس از تأیید شما در تنظیمات وارد می‌شود.
            </p>
          </div>

          <div class="grid grid-3">
            <div class="card">
              <span class="card__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'mail', 20 ); ?></span>
              <h3 style="font-size: var(--text-label); margin-block: var(--space-sm) var(--space-xs)">فرم تماس و پشتیبانی</h3>
              <p class="muted" style="font-size: var(--text-body-sm)">
                سریع‌ترین راه شروع، ثبت درخواست از صفحه‌ی پلن‌ها است؛ کارشناس ما تماس می‌گیرد و مسیر را برایت باز می‌کند.
                برای پرسش‌های فنی و پزشکی هم از همین مسیر پیام بده.
              </p>
              <a class="btn btn--ghost btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'plans', $args ) ); ?>" style="margin-block-start: var(--space-sm)">
                رفتن به پلن‌ها <?php echo Niva_Icons::svg( 'arrow-left', 16 ); ?>
              </a>
            </div>

            <div class="card">
              <span class="card__icon card__icon--calm" aria-hidden="true"><?php echo Niva_Icons::svg( 'stethoscope', 20 ); ?></span>
              <h3 style="font-size: var(--text-label); margin-block: var(--space-sm) var(--space-xs)">همکاری پزشکان و مشاوران</h3>
              <p class="muted" style="font-size: var(--text-body-sm)">
                اگر پزشک، متخصص زنان یا روان‌شناس هستی و می‌خواهی در بازبینی محتوا و صف مشاوره همکاری کنی، از همین صفحه
                درخواست همکاری ثبت می‌شود.
              </p>
            </div>

            <div class="card">
              <span class="card__icon card__icon--accent" aria-hidden="true"><?php echo Niva_Icons::svg( 'user-check', 20 ); ?></span>
              <h3 style="font-size: var(--text-label); margin-block: var(--space-sm) var(--space-xs)">پلن کلینیکی</h3>
              <p class="muted" style="font-size: var(--text-body-sm)">
                برای مطب و کلینیک، پنل تیم، صف بازبینی پزشکان همکار و گزارش‌های تجمیعی در پلن کلینیکی ارائه می‌شود.
              </p>
            </div>
          </div>

          <div class="alert alert--info">
            <span class="alert__icon"><?php echo Niva_Icons::svg( 'clock', 20 ); ?></span>
            <div class="alert__body">
              <span class="alert__title">پشتیبانی، هر روز هفته</span>
              <div class="alert__text">
                پیام‌های پشتیبانی در صف بررسی قرار می‌گیرند و حداکثر یک روز کاری پاسخ داده می‌شوند. درخواست پزشکان،
                مشاوران و کلینیک‌ها در اولویت بررسی است.
              </div>
            </div>
          </div>
        </div>
      </section>
</div>
