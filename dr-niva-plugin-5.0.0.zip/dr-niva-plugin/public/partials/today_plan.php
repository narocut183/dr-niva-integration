<?php
/**
 * Module partial: today_plan — the day's care list (medication-board style).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

$niva_items = Niva_Insights::care_items( get_current_user_id(), 5 );
$niva_slots = array( 'صبح', 'ظهر', 'عصر', 'شب' );
?>
<div class="niva-module niva-module--today_plan" data-module="today_plan" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">برنامه‌ی امروز</h2>
				<span class="caption" data-niva-date-short><?php echo esc_html( Niva_Chrome::today_short() ); ?></span>
			</div>
			<a class="icon-btn icon-btn--bare" href="<?php echo esc_url( Niva_Modules::url( 'reminders', $args ) ); ?>" aria-label="همه‌ی یادآورها">
				<?php echo Niva_Icons::svg( 'bell', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			</a>
		</div>

		<div class="dose-grid">
			<?php foreach ( $niva_slots as $niva_index => $niva_slot ) : ?>
				<span class="dose<?php echo 0 === $niva_index ? ' dose--on' : ''; ?>">
					<?php echo esc_html( $niva_slot ); ?>
				</span>
			<?php endforeach; ?>
		</div>

		<?php if ( ! $niva_items ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'clipboard-list', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">امروز برنامه‌ی فعالی نداری</span>
				<span class="caption">برای دارو، ویتامین، واکسن یا قرار ملاقات یک یادآور بساز تا اینجا نشان داده شود.</span>
				<a class="btn btn--primary btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'reminders', $args ) ); ?>">
					<?php echo Niva_Icons::svg( 'plus', 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
					ساخت یادآور
				</a>
			</div>
		<?php else : ?>
			<ul class="care-list">
				<?php foreach ( $niva_items as $niva_item ) : ?>
					<li class="care-item">
						<span class="care-item__time" dir="ltr"><?php echo esc_html( $niva_item['when'] ? $niva_item['when'] : '—' ); ?></span>
						<span class="care-item__body">
							<span class="care-item__title"><?php echo esc_html( $niva_item['title'] ); ?></span>
							<span class="caption">یادآور فعال</span>
						</span>
						<a class="care-item__go" href="<?php echo esc_url( Niva_Modules::url( 'reminders', $args ) ); ?>">
							<?php echo Niva_Icons::svg( 'chevron-left', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>
</div>
