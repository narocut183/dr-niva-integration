<?php
/**
 * Module partial: mind_thought-record
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--mind_thought-record" data-module="mind_thought-record" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<details class="fold">
			<summary style="font-size: var(--t-sm)">دفترچه افکار — وقتی یک فکر آزارت می‌دهد</summary>
			<form class="stack" data-thought-form style="margin-block-start: var(--s-3)">
				<div class="field">
					<label class="field__label" for="thought-auto">چه فکری از ذهنت گذشت؟</label>
					<textarea id="thought-auto" class="field__input" dir="auto" placeholder="مثلاً: هیچ‌کس متوجه من نمی‌شود."></textarea>
					<p class="field__error" role="alert" data-thought-error hidden>نوشتن همین یک جمله کافی است تا شروع کنیم.</p>
				</div>
				<div class="field">
					<label class="field__label" for="thought-evidence">چه چیزی این فکر را تقویت می‌کند؟</label>
					<textarea id="thought-evidence" class="field__input" dir="auto" placeholder="موقعیت، زمان، یا جمله‌ی کسی"></textarea>
				</div>
				<div class="field">
					<label class="field__label" for="thought-balance">یک نگاه دیگر به همین موقعیت</label>
					<textarea id="thought-balance" class="field__input" dir="auto" placeholder="اگر دوستت همین را می‌گفت، چه می‌گفتی؟"></textarea>
				</div>
				<button type="submit" class="btn btn--primary btn--block">
					<?php echo Niva_Icons::svg( 'pen-line', 18 ); ?>
					ذخیره در دفترچه
				</button>
				<div class="alert alert--success" data-thought-success hidden>
					<div class="alert__body"><div class="alert__text">در دفترچه‌ات ذخیره شد. نگاه دوباره به همین متن در روزهای بهتر، کمک‌کننده است.</div></div>
				</div>
			</form>
		</details>
	</section>
</div>
