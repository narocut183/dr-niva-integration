<?php
/**
 * Module partial: about_privacy
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--about_privacy" data-module="about_privacy" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="section" data-component="about-privacy">
        <div class="container grid grid-2">
          <div class="card">
            <div class="card__head">
              <h2 class="card__title">حریم خصوصی داده سلامت</h2>
              <span class="card__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'lock', 20 ); ?></span>
            </div>
            <div class="stack" style="gap: var(--space-xs)">
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>هر پرونده فقط در دسترس صاحب حساب است و دسترسی‌ها ثبت می‌شود.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>برای تحلیل خودکار، جدا از متن گزارش، تصویر در تنظیمات قابل حذف خودکار است.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>داده‌ی کاربر بدون اجازه‌ی روشن، برای آموزش مدل استفاده نمی‌شود.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>حذف کامل حساب، همه‌ی پرونده‌ها، تصاویر و یادداشت‌ها را پاک می‌کند.</span></span>
            </div>
          </div>

          <div class="card">
            <div class="card__head">
              <h2 class="card__title">محدودیت‌هایی که می‌پذیریم</h2>
              <span class="card__icon card__icon--accent" aria-hidden="true"><?php echo Niva_Icons::svg( 'eye', 20 ); ?></span>
            </div>
            <div class="stack" style="gap: var(--space-xs)">
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>نتیجهٔ تحلیل تصویر، استخراج ماشینی است و ممکن است با برگهٔ اصلی تفاوت داشته باشد.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>پیش‌بینی چرخه و بارداری بر پایه‌ی داده‌های ثبت‌شده‌ی خودت است و با تغییر شرایط، تغییر می‌کند.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>گفت‌وگوی همدلانه و تمرین‌های روان، درمان روان‌شناختی نیست و جای درمانگر را نمی‌گیرد.</span></span>
              <span class="list-check"><?php echo Niva_Icons::svg( 'check', 16 ); ?><span>در وضعیت بحرانی، مسیر اپلیکیشن متوقف می‌شود و تو به مسیرهای تماس اضطراری هدایت می‌شوی.</span></span>
            </div>
          </div>
        </div>
      </section>
</div>
