<?php
/**
 * Module partial: mind_chat
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--mind_chat" data-module="mind_chat" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">می‌خواهی حرف بزنی؟</h2>
				<span class="caption">بدون نام و بدون حساب کاربری</span>
			</div>
			<span class="card__icon card__icon--teal" aria-hidden="true"><?php echo Niva_Icons::svg( 'message-circle', 20 ); ?></span>
		</div>

		<div class="chat">
			<p class="caption" data-chat-empty>
				همین‌جا بنویس؛ هر چه در دلت هست. اگر نشانه‌ی خطر جدی دیده شود، خودمان راه‌های کمک فوری را نشانت می‌دهیم.
			</p>
			<div class="chat__log" data-chat-log role="log" aria-live="polite" aria-label="گفت‌وگوی همراه"></div>

			<div class="stack" data-chat-crisis hidden>
				<div class="alert alert--urgent">
					<span class="alert__icon"><?php echo Niva_Icons::svg( 'life-buoy', 20 ); ?></span>
					<div class="alert__body">
						<span class="alert__title">همین حالا کمک بگیر</span>
						<div class="alert__text">
							اگر به فکر آسیب رساندن به خودت هستی، تنها نمان: اورژانس اجتماعی <bdi>۱۲۳</bdi> و صدای مشاور
							<bdi>۱۴۸۰</bdi> شبانه‌روزی و رایگان پاسخ می‌دهند.
						</div>
						<div class="alert__actions">
							<button type="button" class="btn btn--danger btn--sm" data-crisis-open>دیدن همه‌ی راه‌های کمک</button>
						</div>
					</div>
				</div>
			</div>

			<form class="chat__form" data-chat-form>
				<div class="field" style="flex: 1 1 auto">
					<label class="field__label" for="companion-input">بنویس…</label>
					<input id="companion-input" class="field__input" dir="auto" placeholder="امروز چطور بود؟" autocomplete="off" />
				</div>
				<button type="submit" class="btn btn--primary" aria-label="فرستادن پیام">
					<?php echo Niva_Icons::svg( 'send', 18 ); ?>
				</button>
			</form>
		</div>
	</section>
</div>
