<?php
/**
 * Module partial: packages (data driven).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--packages" data-module="packages" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<?php echo dr_niva()->orders ? dr_niva()->orders->shortcode_packages() : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
