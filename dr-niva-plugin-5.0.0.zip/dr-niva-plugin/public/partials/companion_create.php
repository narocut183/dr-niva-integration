<?php
/**
 * Module partial: companion_create — the owner builds a companion code (2.0.0).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

Niva_Companion::enqueue();

$niva_companion = dr_niva()->companion instanceof Niva_Companion ? dr_niva()->companion : new Niva_Companion();
$niva_codes     = $niva_companion->list_for_owner( (int) get_current_user_id() );
$niva_scopes    = Niva_Companion::scopes();
$niva_default   = array_map( 'trim', explode( ',', (string) dr_niva()->settings->get( 'companion_default_scopes', 'cycle' ) ) );
?>
<div class="niva-module niva-module--companion_create" data-module="companion_create" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>"
	data-niva-companion="<?php echo esc_url( rawurldecode( rest_url( Niva_Rest::NS . '/companion/' ) ) ); ?>"
	data-niva-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>">

	<section class="card companion-intro">
		<div class="card__head">
			<div class="stack" style="gap:2px">
				<h1 class="card__title">کد همراهی اختصاصی شما</h1>
				<span class="caption">یک کد بساز و آن را برای «همراه» بفرست؛ او با شمارهٔ خودش وارد می‌شود و فقط چیزی را می‌بیند که تو اجازه بدهی.</span>
			</div>
			<span class="card__icon card__icon--pink"><?php echo Niva_Icons::svg( 'heart-handshake', 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
		</div>
		<p class="caption">
			همراه فقط <strong>می‌بیند</strong>؛ نه پروفایل می‌سازد، نه می‌تواند چیزی را تغییر بدهد.
			شمارهٔ تو، ایمیلت و نشانی‌ات هرگز برای او نمایش داده نمی‌شود.
		</p>
		<?php /* 2.0.1 — the form opens in place instead of pushing a form at the user. */ ?>
		<button type="button" class="btn btn--primary btn--block" data-niva-modal-open="niva-companion-new">
			<?php echo Niva_Icons::svg( 'user-plus', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
			ساخت کد همراهی
		</button>
	</section>

	<div class="niva-modal" data-niva-modal="niva-companion-new" hidden>
		<div class="niva-modal__backdrop" data-niva-modal-close></div>
		<div class="niva-modal__panel" role="dialog" aria-modal="true" aria-labelledby="niva-companion-new-title">
			<div class="niva-modal__head">
				<h2 class="niva-modal__title" id="niva-companion-new-title">ساخت کد تازه</h2>
				<button type="button" class="niva-modal__x" data-niva-modal-close aria-label="بستن"><?php echo Niva_Icons::svg( 'x', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
			</div>
			<form class="niva-modal__body" data-niva-companion-create>

		<label class="field">
			<span class="field__label">نام همراه</span>
			<input class="field__input" name="name" required placeholder="مثال: علی‌رضا" />
		</label>

		<label class="field">
			<span class="field__label">شمارهٔ موبایل همراه</span>
			<input class="field__input" name="phone" dir="ltr" required placeholder="09xxxxxxxxx" />
			<span class="field__hint">همراه در اولین ورود، همین شماره را با کد یک‌بارمصرف تأیید می‌کند.</span>
		</label>

		<fieldset class="field companion-scopes">
			<legend class="field__label">چه چیزی را ببیند؟</legend>
			<?php foreach ( $niva_scopes as $niva_key => $niva_label ) : ?>
				<label class="switch-row">
					<input type="checkbox" name="scopes[]" value="<?php echo esc_attr( $niva_key ); ?>" <?php checked( in_array( $niva_key, $niva_default, true ) ); ?> />
					<span><?php echo esc_html( $niva_label ); ?></span>
				</label>
			<?php endforeach; ?>
		</fieldset>

		<label class="field">
			<span class="field__label">مدت اعتبار</span>
			<select class="field__input" name="days">
				<?php
				foreach ( array( 7 => '۷ روز', 30 => '۳۰ روز', 90 => '۹۰ روز', 0 => 'بدون انقضا' ) as $niva_days => $niva_label ) :
					?>
					<option value="<?php echo esc_attr( (string) $niva_days ); ?>" <?php selected( (int) dr_niva()->settings->get( 'companion_default_days', 30 ), $niva_days ); ?>><?php echo esc_html( $niva_label ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>

			<button type="submit" class="btn btn--primary btn--block">ساخت کد همراهی</button>
			<span class="field__hint" data-niva-companion-message hidden></span>
			<a class="caption" href="<?php echo esc_url( Niva_Modules::url( 'companion_create', array(), home_url( '/' ) ) ); ?>">باز کردن در صفحهٔ کامل</a>
			</form>
		</div>
	</div>

	<section class="card">
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--teal"><?php echo Niva_Icons::svg( 'qrcode', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h2 class="card__title">کدهای همراهی من</h2>
			</div>
		</div>
		<?php if ( ! $niva_codes ) : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'heart-handshake', 26 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				<span class="empty-state__title">هنوز کدی نساخته‌ای</span>
				<span class="caption">با ساخت کد، همسر، مادر یا پزشکت می‌تواند وضعیت چرخه و بارداری را ببیند.</span>
			</div>
		<?php else : ?>
			<ul class="plain-list">
				<?php foreach ( $niva_codes as $niva_row ) : ?>
					<li class="plain-row<?php echo $niva_row['usable'] ? '' : ' is-inactive'; ?>">
						<div class="plain-row__body">
							<span class="plain-row__name"><?php echo esc_html( (string) $niva_row['companion_name'] ); ?></span>
							<span><code dir="ltr" class="badge"><?php echo esc_html( (string) $niva_row['code'] ); ?></code></span>
							<span class="caption">
								<span dir="ltr"><?php echo esc_html( (string) $niva_row['companion_phone_masked'] ); ?></span>
								· <?php echo esc_html( implode( '، ', array_intersect_key( $niva_scopes, array_flip( $niva_row['scope_list'] ) ) ) ); ?>
							</span>
							<span class="caption">
								<?php echo esc_html( Niva_Chrome::digits( (string) $niva_row['views'] ) ); ?> بازدید
								· آخرین بازدید: <?php echo esc_html( $niva_row['last_view'] ? Niva_Chrome::format_datetime_gmt( (string) $niva_row['last_view'] ) : 'ندارد' ); ?>
								· انقضا: <?php echo esc_html( $niva_row['expires_at'] ? Niva_Chrome::format_datetime_gmt( (string) $niva_row['expires_at'] ) : 'بدون انقضا' ); ?>
							</span>
						</div>
						<div class="stack" style="gap: 8px; justify-items: end">
							<?php if ( ! $niva_row['usable'] ) : ?>
								<span class="badge badge--soft"><?php echo $niva_row['expired'] ? 'منقضی' : 'ابطال‌شده'; ?></span>
							<?php else : ?>
								<span class="badge badge--green">فعال</span>
							<?php endif; ?>
							<div class="flex" style="gap: 8px; flex-wrap: wrap; justify-content: flex-end">
								<?php if ( $niva_row['usable'] ) : ?>
									<button type="button" class="btn btn--ghost btn--sm" data-niva-companion-copy="<?php echo esc_attr( (string) $niva_row['link'] ); ?>">کپی لینک</button>
									<a class="btn btn--ghost btn--sm" target="_blank" rel="noopener" href="<?php echo esc_url( 'https://wa.me/?text=' . rawurlencode( 'کد همراهی دکتر نیوا: ' . $niva_row['link'] ) ); ?>">اشتراک در واتس‌اپ</a>
									<a class="btn btn--ghost btn--sm" href="<?php echo esc_url( 'sms:?&body=' . rawurlencode( $niva_row['link'] ) ); ?>">پیامک</a>
								<?php endif; ?>
								<button type="button" class="btn btn--ghost btn--sm" data-niva-companion-regen="<?php echo esc_attr( (string) $niva_row['id'] ); ?>">کد تازه</button>
								<button type="button" class="btn btn--danger btn--sm" data-niva-companion-revoke="<?php echo esc_attr( (string) $niva_row['id'] ); ?>">ابطال</button>
							</div>
						</div>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</section>
</div>
