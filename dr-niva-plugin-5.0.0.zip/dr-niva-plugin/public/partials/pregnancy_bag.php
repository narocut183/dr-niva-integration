<?php
/**
 * Module partial: pregnancy_bag
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
/* This screen describes a pregnancy, so it is only shown when the profile
   actually says there is one — a new account must never read someone else's
   week number. */
if ( ! in_array( strtolower( (string) Niva_Chrome::flag( 'pregnant' ) ), array( '1', 'yes', 'true' ), true ) ) {
	echo Niva_Chrome::blank( 'بارداری ثبت نشده', 'اگر باردار هستی، در تنظیمات حساب فعالش کن تا این بخش با هفتهٔ واقعی خودت ساخته شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}
?>
<div class="niva-module niva-module--pregnancy_bag" data-module="pregnancy_bag" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<details class="fold">
			<summary class="card__head">
				<div class="stack" style="gap: 2px">
					<h2 class="card__title">کیف بیمارستان</h2>
					<span class="caption">چه چیزی لازم است؟</span>
				</div>
				<span class="card__icon card__icon--cyan" aria-hidden="true"><?php echo Niva_Icons::svg( 'file-text', 20 ); ?></span>
			</summary>
			<div class="fold__body">
				<p>مدارک: کارت ملی، دفترچه‌ی بارداری، نتایج سونوگرافی و آزمایش‌ها.</p>
				<p>برای مادر: لباس راحت، دمپایی، لوازم بهداشتی، پد، سوتین شیردهی، شارژر.</p>
				<p>برای نوزاد: لباس و کلاه، پتوی سبک، پوشک، دستمال مرطوب، پد زیرانداز.</p>
				<p>از هفته ۳۴ این کیف را کنار در بگذار.</p>
			</div>
		</details>
	</section>
</div>
