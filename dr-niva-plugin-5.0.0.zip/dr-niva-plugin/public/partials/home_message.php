<?php
/**
 * Module partial: home_message — today's message, chosen by the user's own
 * stage (pregnancy week / baby month / cycle phase) and rotated every 24 hours.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

$niva_today = dr_niva()->messages->today();
$niva_prev  = dr_niva()->messages->previous( 0, 7 );
$niva_preg  = is_user_logged_in() && dr_niva()->profile->is_pregnant();
$niva_week  = $niva_preg ? dr_niva()->profile->pregnancy_week() : 0;
$niva_left  = $niva_preg ? dr_niva()->profile->days_left() : 0;
$niva_audience = $niva_today ? $niva_today['_audience'] : 'general';

$niva_labels = array(
	'pregnancy' => 'هفته‌ی ' . number_format_i18n( $niva_week ) . ' بارداری',
	'baby'      => 'نوزاد',
	'cycle'     => 'چرخه‌ی تو',
	'mind'      => 'حال روان',
	'general'   => 'سلامت روزانه',
);
?>
<div class="niva-module niva-module--home_message" data-module="home_message" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<article class="card msg-card">
		<div class="msg-card__head">
			<?php echo Niva_Icons::svg( 'message-circle', 18 ); ?>
			<span>پیام امروز</span>
			<span class="badge"><?php echo esc_html( isset( $niva_labels[ $niva_audience ] ) ? $niva_labels[ $niva_audience ] : '' ); ?></span>
		</div>

		<div class="msg-card__body">
			<?php if ( $niva_today ) : ?>
				<?php if ( $niva_preg ) : ?>
					<div class="metric-row">
						<span class="metric-row__label">پیشرفت بارداری</span>
						<span class="metric-row__value">هفته <?php echo esc_html( number_format_i18n( $niva_week ) ); ?> · <?php echo esc_html( number_format_i18n( $niva_left ) ); ?> روز مانده</span>
					</div>
					<div class="progress"><span class="progress__fill" style="width: <?php echo esc_attr( min( 100, (int) round( ( $niva_week / 40 ) * 100 ) ) ); ?>%"></span></div>
				<?php endif; ?>

				<h3 class="card__title"><?php echo esc_html( $niva_today['title'] ); ?></h3>
				<p class="msg-card__text"><?php echo wp_kses_post( $niva_today['body'] ); ?></p>

				<?php if ( ! empty( $niva_today['action'] ) ) : ?>
					<div class="alert alert--info">
						<span class="alert__icon"><?php echo Niva_Icons::svg( 'check-circle-2', 20 ); ?></span>
						<div class="alert__body">
							<span class="alert__title">کار امروز</span>
							<div class="alert__text"><?php echo esc_html( $niva_today['action'] ); ?></div>
						</div>
					</div>
				<?php endif; ?>

				<?php if ( ! empty( $niva_today['source_url'] ) ) : ?>
					<p class="caption">
						منبع:
						<a href="<?php echo esc_url( $niva_today['source_url'] ); ?>" target="_blank" rel="noopener nofollow">
							<?php echo esc_html( $niva_today['source_name'] ); ?>
						</a>
					</p>
				<?php endif; ?>

				<?php if ( $niva_prev ) : ?>
					<details class="fold">
						<summary>پیام‌های قبلی (<?php echo esc_html( number_format_i18n( count( $niva_prev ) ) ); ?> روز گذشته)</summary>
						<div class="fold__body">
							<?php foreach ( $niva_prev as $niva_item ) : ?>
								<div class="plain-row">
									<span class="plain-row__name">
										<?php
										$niva_ago = (int) $niva_item['_ago'];
										echo esc_html( 1 === $niva_ago ? 'دیروز' : number_format_i18n( $niva_ago ) . ' روز پیش' );
										?>
									</span>
									<span class="plain-row__value"><strong><?php echo esc_html( $niva_item['title'] ); ?></strong></span>
								</div>
								<p class="caption" style="margin: 0 0 var(--s-3)"><?php echo wp_kses_post( $niva_item['body'] ); ?></p>
							<?php endforeach; ?>
						</div>
					</details>
				<?php endif; ?>

				<a class="btn btn--secondary btn--block" href="<?php echo esc_url( Niva_Modules::url( 'messages', $args ) ); ?>">
					مشاهده‌ی همه‌ی پیام‌های این دوره
				</a>
			<?php else : ?>
				<p class="muted">فهرست پیام‌ها خالی است. از پنل مدیریت، بخش «پیام‌های روزانه» کتابخانه‌ی پیش‌فرض را بارگذاری کن.</p>
			<?php endif; ?>
		</div>
	</article>
</div>
