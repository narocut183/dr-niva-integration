<?php
/**
 * Module partial: credits_bar (data driven).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--credits_bar" data-module="credits_bar" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<?php echo dr_niva()->frontend ? dr_niva()->frontend->credits_bar_html() : ''; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
