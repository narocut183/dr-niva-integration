<?php
/**
 * Module partial: advisor_topics
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--advisor_topics" data-module="advisor_topics" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card" data-advisor-topics>
            <div class="card__head">
              <div class="stack" style="gap: 2px">
                <h2 class="card__title">موضوع گفت‌وگو</h2>
                <span class="caption">یک موضوع را بزن تا همراهِ مخصوص همان موضوع را داشته باشی.</span>
              </div>
              <span class="card__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'message-circle', 20 ); ?></span>
            </div>
            <div class="topic-grid" data-topics></div>
            <div class="chat-history" data-chat-history>
              <h3 class="card__title">گفت‌وگوهای ذخیره‌شده</h3>
              <p class="caption" data-chat-history-status aria-live="polite">در حال بارگذاری…</p>
              <div class="chat-history__list" data-chat-history-list></div>
            </div>
          </section>
</div>
