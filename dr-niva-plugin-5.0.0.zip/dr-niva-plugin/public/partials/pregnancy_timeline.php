<?php
/**
 * Module partial: pregnancy_timeline
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() || ! dr_niva()->profile || ! dr_niva()->profile->is_pregnant() ) {
	echo Niva_Chrome::blank( 'بارداری ثبت نشده', 'اگر باردار هستی، تاریخ را در تنظیمات حساب وارد کن تا هفتهٔ واقعی نمایش داده شود.', 'تنظیمات حساب', 'profile', $args );
	return;
}

$niva_week = dr_niva()->profile->pregnancy_week();
$niva_today = dr_niva()->messages ? dr_niva()->messages->today() : null;
?>
<div class="niva-module niva-module--pregnancy_timeline" data-module="pregnancy_timeline" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">هفتهٔ بارداری تو</h2>
				<span class="caption"><?php echo esc_html( 'هفتهٔ ' . Niva_Chrome::digits( $niva_week ) ); ?></span>
			</div>
			<span class="card__icon card__icon--purple" aria-hidden="true"><?php echo Niva_Icons::svg( 'calendar-heart', 20 ); ?></span>
		</div>
		<?php if ( $niva_today && 'pregnancy' === ( $niva_today['_audience'] ?? '' ) ) : ?>
			<h3 class="card__title"><?php echo esc_html( $niva_today['title'] ); ?></h3>
			<p><?php echo wp_kses_post( $niva_today['body'] ); ?></p>
		<?php else : ?>
			<div class="empty-state">
				<?php echo Niva_Icons::svg( 'info', 26 ); ?>
				<p class="muted">محتوای تأییدشدهٔ این هفته هنوز در کتابخانهٔ سایت بارگذاری نشده است.</p>
			</div>
		<?php endif; ?>
		<p class="caption">اطلاعات هفتگی راهنمای عمومی است و جای پیگیری پزشک یا ماما را نمی‌گیرد.</p>
	</section>
</div>
