<?php
/**
 * Module partial: about_review
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--about_review" data-module="about_review" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="section section--mint" data-component="about-review">
        <div class="container stack--lg">
          <div class="stack" data-component="section-heading">
            <span class="badge"><?php echo Niva_Icons::svg( 'user-check', 14 ); ?>بازبینی پزشکی</span>
            <h2>محتوای این سایت چطور تأیید می‌شود</h2>
            <p class="lede">
              این فرایند در پنل مدیریت قابل پیگیری است و وضعیت هر مطلب (در حال نوشتن، در بازبینی، منتشرشده) مشخص است.
            </p>
          </div>

          <div class="grid grid-2">
            <div class="review-step">
              <span class="review-step__index" aria-hidden="true">1</span>
              <div>
                <p style="font-weight: 600">نوشتن مطلب بر پایه منابع معتبر</p>
                <p class="muted" style="font-size: var(--text-body-sm)">
                  هر متن آموزشی با ارجاع به منابع بین‌المللی و راهنماهای بالینی نوشته می‌شود، نه بر پایه حدس یا تجربه‌ی
                  شخصی.
                </p>
              </div>
            </div>

            <div class="review-step">
              <span class="review-step__index" aria-hidden="true">2</span>
              <div>
                <p style="font-weight: 600">بازبینی توسط پزشک همکار</p>
                <p class="muted" style="font-size: var(--text-body-sm)">
                  پیش از انتشار، یک بازبین پزشکی متن را از نظر درستی، کامل بودن و لحن غیرتشخیصی بررسی و اصلاح می‌کند.
                </p>
              </div>
            </div>

            <div class="review-step">
              <span class="review-step__index" aria-hidden="true">3</span>
              <div>
                <p style="font-weight: 600">درج تاریخ بازبینی و نسخه</p>
                <p class="muted" style="font-size: var(--text-body-sm)">
                  روی هر مطلب، نام بازبین و تاریخ آخرین بازبینی می‌آید تا بدانی محتوا چقدر تازه است.
                </p>
              </div>
            </div>

            <div class="review-step">
              <span class="review-step__index" aria-hidden="true">4</span>
              <div>
                <p style="font-weight: 600">بازبینی دوره‌ای</p>
                <p class="muted" style="font-size: var(--text-body-sm)">
                  مطالب حساس در بازه‌های زمانی مشخص بازبینی و در صورت نیاز به‌روزرسانی می‌شوند.
                </p>
              </div>
            </div>
          </div>
        </div>
      </section>
</div>
