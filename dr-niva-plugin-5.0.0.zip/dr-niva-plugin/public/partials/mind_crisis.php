<?php
/**
 * Module partial: mind_crisis
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--mind_crisis" data-module="mind_crisis" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="alert alert--urgent">
			<span class="alert__icon"><?php echo Niva_Icons::svg( 'life-buoy', 24 ); ?></span>
			<div class="alert__body">
				<span class="alert__title">کمک فوری، همیشه در دسترس</span>
				<p class="alert__text">
					اگر حالت خیلی بد است، لازم نیست با این اپ ادامه بدهی. این خطوط شبانه‌روزی و رایگان هستند و می‌توانند همین
					حالا با تو حرف بزنند.
				</p>
				<div class="alert__actions">
					<button type="button" class="btn btn--danger btn--block" data-crisis-open>
						<?php echo Niva_Icons::svg( 'phone-call', 18 ); ?>
						دیدن راه‌های کمک فوری
					</button>
				</div>
			</div>
		</div>
	</section>
</div>
