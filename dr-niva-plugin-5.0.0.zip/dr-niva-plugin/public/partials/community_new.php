<?php
/**
 * Module partial: community_new — composer for a new question (2.0.0).
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! is_user_logged_in() ) {
	echo Niva_Modules::login_notice(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	return;
}

Niva_Community::enqueue();

$niva_community = dr_niva()->community instanceof Niva_Community ? dr_niva()->community : new Niva_Community();
$niva_cats      = $niva_community->categories();
$niva_muted     = $niva_community->is_muted( (int) get_current_user_id() );
?>
<div class="niva-module niva-module--community_new" data-module="community_new" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>"
	data-niva-community="<?php echo esc_url( rawurldecode( rest_url( Niva_Rest::NS . '/community/' ) ) ); ?>"
	data-niva-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>"
	data-niva-back="<?php echo esc_attr( Niva_Modules::url( 'community_home', array(), home_url( '/' ) ) ); ?>">

	<a class="community-back" href="<?php echo esc_url( Niva_Modules::url( 'community_home', array(), home_url( '/' ) ) ); ?>">
		<?php echo Niva_Icons::svg( 'chevron-left', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
		فهرست گفتگوها
	</a>

	<form class="card" data-niva-community-create>
		<div class="card__head">
			<div class="flex">
				<span class="card__icon card__icon--cyan"><?php echo Niva_Icons::svg( 'message-plus', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<h1 class="card__title">پرسش تازه</h1>
			</div>
		</div>

		<?php if ( $niva_muted ) : ?>
			<div class="alert alert--caution">
				<span class="alert__icon"><?php echo Niva_Icons::svg( 'alert-triangle', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<div class="alert__body">
					<div class="alert__text">امکان نوشتن برای این حساب موقتاً محدود شده است. اگر فکر می‌کنی اشتباهی رخ داده با پشتیبانی تماس بگیر.</div>
				</div>
			</div>
		<?php endif; ?>

		<label class="field">
			<span class="field__label">دسته</span>
			<select class="field__input" name="category_id" required>
				<option value="">انتخاب کن…</option>
				<?php foreach ( $niva_cats as $niva_cat ) : ?>
					<option value="<?php echo esc_attr( (string) $niva_cat['id'] ); ?>"><?php echo esc_html( (string) $niva_cat['title'] ); ?></option>
				<?php endforeach; ?>
			</select>
		</label>

		<label class="field">
			<span class="field__label">عنوان پرسش</span>
			<input class="field__input" name="title" type="text" required minlength="6" maxlength="120" placeholder="مثلاً: پریود نامنظم بعد از زایمان طبیعی است؟" />
		</label>

		<label class="field">
			<span class="field__label">توضیح</span>
			<textarea class="field__input" name="body" rows="6" required placeholder="چه اتفاقی افتاده، از کی شروع شده و چه چیزی را امتحان کرده‌ای؟"></textarea>
		</label>

		<p class="caption">
			توصیهٔ دارویی یا دوز ننویس؛ این پرسش‌ها پیش از نمایش بازبینی می‌شوند.
			شمارهٔ تماس، لینک و آیدی در متن به‌صورت خودکار پنهان می‌شود.
		</p>

		<button type="submit" class="btn btn--primary btn--block" <?php echo $niva_muted ? 'disabled' : ''; ?>>ثبت پرسش</button>
		<span class="field__hint" data-niva-community-message hidden></span>
	</form>
</div>
