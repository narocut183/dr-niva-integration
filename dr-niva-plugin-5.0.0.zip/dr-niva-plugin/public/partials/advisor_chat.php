<?php
/**
 * Module partial: advisor_chat
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
$niva_wallet = is_user_logged_in() && dr_niva()->wallet ? dr_niva()->wallet->summary( get_current_user_id() ) : array();
$niva_chat_quota = is_user_logged_in() && dr_niva()->plans ? dr_niva()->plans->chat_quota_summary( get_current_user_id() ) : array();
?>
<div class="niva-module niva-module--advisor_chat" data-module="advisor_chat" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
<section class="card" data-advisor-chat hidden>
            <div class="advisor-head">
              <span class="card__icon" data-advisor-icon aria-hidden="true"><?php echo Niva_Icons::svg( 'message-circle', 20 ); ?></span>
              <span class="advisor-head__body">
                <span class="card__title" data-advisor-topic>موضوع</span>
                <span class="caption" data-advisor-hint>همراهِ این موضوع</span>
              </span>
              <button type="button" class="btn btn--secondary btn--sm" data-advisor-reset>تغییر موضوع</button>
            </div>
            <aside class="advisor-usage" aria-live="polite" aria-label="اعتبار و سهمیهٔ مشاور">
              <div><span>اشتراک</span><strong data-advisor-plan><?php echo esc_html( $niva_chat_quota['label'] ?? 'رایگان' ); ?></strong><small data-advisor-plan-expiry><?php echo esc_html( $niva_chat_quota['expires'] ?? ( ! empty( $niva_chat_quota['active'] ) ? 'اشتراک فعال' : 'بدون اشتراک پولی' ) ); ?></small></div>
              <div><span>سهمیهٔ مشاور</span><strong data-advisor-plan-quota><?php echo esc_html( ! empty( $niva_chat_quota['unlimited'] ) ? 'نامحدود' : Niva_Chrome::digits( (int) ( $niva_chat_quota['remaining'] ?? 0 ) ) . ' از ' . Niva_Chrome::digits( (int) ( $niva_chat_quota['limit'] ?? 0 ) ) . ' پیام امروز' ); ?></strong></div>
              <div><span>اعتبار کیف پول</span><strong><bdi data-advisor-balance><?php echo esc_html( Niva_Chrome::digits( $niva_wallet['balance'] ?? 0 ) ); ?></bdi></strong><small>سهمیهٔ رایگان امروز: <bdi data-advisor-quota><?php echo esc_html( Niva_Chrome::digits( $niva_wallet['quota_left'] ?? 0 ) ); ?></bdi></small></div>
              <nav aria-label="مدیریت اعتبار مشاور"><a href="<?php echo esc_url( Niva_Modules::url( 'plans', $args ) ); ?>">مشاهدهٔ اشتراک</a><a href="<?php echo esc_url( Niva_Modules::url( 'wallet', $args ) ); ?>">شارژ اعتبار</a></nav>
            </aside>

            <div class="chat" style="margin-block-start: var(--s-2)">
              <div class="chat__log" data-advisor-log role="log" aria-live="polite" aria-label="گفت‌وگوی مشاور"></div>

              <div class="chat__suggest" data-advisor-suggest></div>

              <div class="stack" data-advisor-crisis hidden>
                <div class="alert alert--urgent">
                  <span class="alert__icon"><?php echo Niva_Icons::svg( 'life-buoy', 20 ); ?></span>
                  <div class="alert__body">
                    <span class="alert__title">این گفت‌وگو جای کمک فوری نیست</span>
                    <div class="alert__text">
                      همین حالا با اورژانس اجتماعی <bdi>۱۲۳</bdi> یا صدای مشاور <bdi>۱۴۸۰</bdi> تماس بگیر
                      (شبانه‌روزی و رایگان) و یک فرد مورد اعتماد را کنارت نگه دار.
                    </div>
                    <div class="alert__actions">
                      <a class="btn btn--danger btn--sm" href="<?php echo esc_url( Niva_Modules::url( 'mind', $args ) ); ?>">
                        <?php echo Niva_Icons::svg( 'life-buoy', 16 ); ?>
                        صفحه‌ی کمک فوری
                      </a>
                    </div>
                  </div>
                </div>
              </div>

              <form class="chat__form" data-advisor-form>
                <div class="field" style="flex: 1 1 auto">
                  <label class="field__label" for="advisor-input">پیامت را بنویس…</label>
                  <input id="advisor-input" class="field__input" dir="auto" placeholder="مثلاً: این چند وقت خوابم به‌هم ریخته" autocomplete="off" />
                </div>
                <button type="submit" class="btn btn--primary" aria-label="فرستادن پیام">
                  <?php echo Niva_Icons::svg( 'send', 18 ); ?>
                </button>
              </form>
            </div>
          </section>
</div>
