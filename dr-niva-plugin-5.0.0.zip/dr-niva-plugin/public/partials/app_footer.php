<?php
/**
 * Module partial: app_footer
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--app_footer" data-module="app_footer" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<footer class="footer niva-footer">
		<div class="container">
			<div class="footer__grid">
				<div class="stack">
					<span class="brand">
						<?php echo Niva_Chrome::logo(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
						<span class="brand__name"><?php echo esc_html( Niva_Chrome::name() ); ?></span>
					</span>
					<p class="caption"><?php echo esc_html( (string) dr_niva()->settings->get( 'footer_note' ) ); ?></p>
				</div>
				<div class="stack">
					<span class="footer__title">دسترسی سریع</span>
					<?php echo Niva_Chrome::menu( 'footer' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
				<div class="stack">
					<span class="footer__title">حساب کاربری</span>
					<?php echo Niva_Chrome::account(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
				</div>
			</div>
		</div>
	</footer>
	<?php echo Niva_Chrome::dock(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
</div>
