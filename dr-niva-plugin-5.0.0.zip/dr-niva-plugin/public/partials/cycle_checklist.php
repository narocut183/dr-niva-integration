<?php
/**
 * Module partial: cycle_checklist
 *
 * Rendered by Niva_Modules::render() — the single source of truth for both the
 * Elementor widgets and the [dr_niva_module] shortcode.
 *
 * @var array $args
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;
?>
<div class="niva-module niva-module--cycle_checklist" data-module="cycle_checklist" data-niva-hide="<?php echo esc_attr( $args['hide'] ); ?>">
	<section class="card">
		<div class="card__head">
			<div class="stack" style="gap: 2px">
				<h2 class="card__title">ثبت علائم</h2>
				<span class="caption">ثبت شخصی و محرمانهٔ علائم روزانه</span>
			</div>
			<span class="card__icon card__icon--cyan" aria-hidden="true"><?php echo Niva_Icons::svg( 'clipboard-list', 20 ); ?></span>
		</div>
		<form class="cycle-symptoms" data-cycle-symptoms>
			<label class="field">
				<span class="field__label">تاریخ</span>
				<input class="input" type="text" name="date" data-cycle-jalali-date inputmode="numeric" placeholder="۱۴۰۵/۰۱/۰۱" autocomplete="off" required />
			</label>
			<fieldset class="cycle-symptoms__choices">
				<legend class="field__label">چه علائمی داشتی؟</legend>
				<?php
				$niva_cycle_symptoms = array(
					'cramps'   => 'گرفتگی یا درد',
					'bloating' => 'نفخ',
					'headache' => 'سردرد',
					'fatigue'  => 'خستگی',
					'mood'     => 'تغییر خلق',
					'spotting' => 'لکه‌بینی',
				);
				foreach ( $niva_cycle_symptoms as $niva_symptom_key => $niva_symptom_label ) :
					?>
					<label class="chip cycle-symptoms__choice">
						<input type="checkbox" name="symptoms[]" value="<?php echo esc_attr( $niva_symptom_key ); ?>" />
						<span><?php echo esc_html( $niva_symptom_label ); ?></span>
					</label>
				<?php endforeach; ?>
			</fieldset>
			<label class="field">
				<span class="field__label">یادداشت (اختیاری)</span>
				<textarea class="input" name="note" rows="2" maxlength="500" placeholder="شدت یا توضیح کوتاه"></textarea>
			</label>
			<button class="btn btn--primary" type="submit">ذخیرهٔ علائم</button>
			<p class="caption" data-cycle-symptoms-status role="status" aria-live="polite"></p>
		</form>
		<div class="cycle-symptoms__history" data-cycle-symptoms-history aria-live="polite"></div>
	</section>
</div>
