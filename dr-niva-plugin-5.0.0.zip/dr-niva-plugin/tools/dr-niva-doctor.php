<?php
/**
 * Dr. Niva doctor — standalone diagnostic.
 *
 * Upload this single file to the WordPress root (next to wp-config.php) and open
 * it in the browser: http://your-site/dr-niva-doctor.php
 * It reports, step by step, what the plugin needs and where it fails, without
 * activating anything. Delete it when you are done.
 *
 * @package DrAva
 */

header( 'Content-Type: text/html; charset=utf-8' );
?>
<!doctype html>
<html lang="fa" dir="rtl">
<head>
	<meta charset="utf-8" />
	<title>دکتر نیوا — عیب‌یابی</title>
	<style>
		body { font-family: Tahoma, sans-serif; background: #f4f7fb; color: #17242f; padding: 24px; }
		h1 { font-size: 20px; }
		table { width: 100%; border-collapse: collapse; background: #fff; border-radius: 12px; overflow: hidden; box-shadow: 0 6px 18px -14px rgba(0,0,0,.4); }
		th, td { padding: 10px 12px; border-bottom: 1px solid #e2e8ef; text-align: right; font-size: 13px; }
		th { background: #f7f9fb; }
		.ok { color: #1d7a4f; font-weight: 700; }
		.warn { color: #8a5b12; font-weight: 700; }
		.fail { color: #b3261e; font-weight: 700; }
		code { background: #f0f3f7; padding: 2px 6px; border-radius: 6px; direction: ltr; display: inline-block; }
		pre { background: #1c2430; color: #fff; padding: 14px; border-radius: 10px; overflow: auto; direction: ltr; text-align: left; }
	</style>
</head>
<body>
<h1>دکتر نیوا — عیب‌یابی نصب</h1>
<p>این صفحه فقط وضعیت را گزارش می‌دهد و چیزی را تغییر نمی‌دهد.</p>
<table>
	<tbody>
	<?php
	$root = __DIR__;
	$plugin = $root . '/wp-content/plugins/dr-niva-plugin';

	$rows   = array();
	$rows[] = array( 'خود فایل عیب‌یابی', true, 'درست اجرا شد' );

	$config = file_exists( $root . '/wp-config.php' );
	$rows[] = array( 'wp-config.php', $config, $config ? 'پیدا شد' : 'پیدا نشد — این فایل را در پوشه‌ی اصلی سایت بگذار' );

	$exists = is_dir( $plugin );
	$rows[] = array( 'پوشه‌ی افزونه', $exists, $exists ? $plugin : 'پیدا نشد: ' . $plugin );

	$main = $plugin . '/dr-niva.php';
	$rows[] = array( 'فایل اصلی افزونه', file_exists( $main ), file_exists( $main ) ? 'dr-niva.php موجود است' : 'dr-niva.php پیدا نشد' );

	$rows[] = array( 'نسخه‌ی PHP', version_compare( PHP_VERSION, '7.4', '>=' ), PHP_VERSION . ' (حداقل ۷.۴)' );

	foreach ( array( 'openssl_pkey_new', 'json_decode', 'glob', 'curl_init', 'mb_substr' ) as $function ) {
		$ready  = function_exists( $function );
		$rows[] = array( 'تابع ' . $function, $ready, $ready ? 'در دسترس' : 'غیرفعال — با هاست تماس بگیر' );
	}

	if ( $exists ) {
		$php_files = glob( $plugin . '/*.php' ) ?: array();
		$rows[]    = array( 'فایل‌های سطح افزونه', count( $php_files ) > 0, implode( ', ', array_map( 'basename', $php_files ) ) );

		$missing = array();
		foreach ( array( 'includes', 'admin', 'public/partials', 'public/assets/js', 'elementor', 'data' ) as $dir ) {
			if ( ! is_dir( $plugin . '/' . $dir ) ) {
				$missing[] = $dir;
			}
		}
		$rows[] = array( 'پوشه‌های لازم', ! $missing, $missing ? 'کم است: ' . implode( ', ', $missing ) : 'همه موجود' );

		$partial_count = count( glob( $plugin . '/public/partials/*.php' ) ?: array() );
		$rows[]        = array( 'فایل بخش‌ها (پارشال)', $partial_count >= 60, $partial_count . ' فایل' );

		$library = count( glob( $plugin . '/data/messages-*.json' ) ?: array() );
		$rows[]  = array( 'کتابخانه‌ی پیام‌ها', $library >= 3, $library . ' فایل JSON' );
	}

	foreach ( $rows as $row ) {
		$class = $row[1] ? 'ok' : 'fail';
		$text  = $row[1] ? 'سالم' : 'مشکل';
		echo '<tr><td>' . htmlspecialchars( (string) $row[0], ENT_QUOTES, 'UTF-8' ) . '</td>'
			. '<td class="' . $class . '">' . $text . '</td>'
			. '<td><code>' . htmlspecialchars( (string) $row[2], ENT_QUOTES, 'UTF-8' ) . '</code></td></tr>';
	}
	?>
	</tbody>
</table>

<?php if ( $config && $exists ) : ?>
	<h1>آزمون بارگذاری واقعی</h1>
	<p>این بخش وردپرس را بارگذاری می‌کند و فایل‌های افزونه را یکی‌یکی می‌خواند تا دقیقاً معلوم شود کدام فایل خطا می‌دهد.</p>
	<pre><?php
	define( 'WP_USE_THEMES', false );
	require_once $root . '/wp-load.php';

	$files = array();
	foreach ( array( 'includes', 'admin', 'elementor', 'public' ) as $dir ) {
		foreach ( glob( $plugin . '/' . $dir . '/*.php' ) ?: array() as $file ) {
			$files[] = $file;
		}
	}
	sort( $files );

	foreach ( $files as $file ) {
		try {
			require_once $file;
			echo 'OK      ' . str_replace( $plugin, '', $file ) . "\n";
		} catch ( \Throwable $error ) {
			echo 'FAILED  ' . str_replace( $plugin, '', $file ) . '  →  ' . $error->getMessage() . ' (line ' . $error->getLine() . ")\n";
		}
	}

	echo "\n" . 'WordPress: ' . get_bloginfo( 'version' ) . "\n";
	echo 'WooCommerce: ' . ( class_exists( 'WooCommerce' ) ? 'فعال' : 'غیرفعال' ) . "\n";
	echo 'Elementor: ' . ( did_action( 'elementor/loaded' ) ? 'فعال' : 'غیرفعال' ) . "\n";
	// tables: existence, and a one-click repair
	$expected = array( 'wallets', 'ledger', 'usage', 'documents', 'reviews', 'reminders', 'notifications', 'push_subs', 'chats', 'chat_messages', 'growth', 'daily_logs', 'memberships', 'family_members', 'partners', 'partner_referrals', 'payouts', 'push_devices', 'messages' );
	$prefix   = $GLOBALS['wpdb']->prefix . 'niva_';
	$missing  = array();
	echo "\n--- جدول‌های افزونه ---\n";
	foreach ( $expected as $name ) {
		$table = $prefix . $name;
		$found = $GLOBALS['wpdb']->get_var( $GLOBALS['wpdb']->prepare( 'SHOW TABLES LIKE %s', $table ) );
		if ( $found === $table ) {
			echo 'OK      ' . $name . "\n";
		} else {
			$missing[] = $name;
			echo 'MISSING ' . $name . "\n";
		}
	}

	if ( $missing ) {
		echo "\nدکمه‌ی زیر جدول‌های گم‌شده را می‌سازد:\n";
		echo '<form method="post"><input type="hidden" name="repair" value="1" /><button style="padding:8px 16px;border-radius:8px;border:0;background:#3368a0;color:#fff;font-size:14px">ساخت جدول‌های گم‌شده</button></form>';
	}

	if ( isset( $_POST['repair'] ) && class_exists( 'Niva_DB' ) ) {
		Niva_DB::install();
		delete_transient( 'dr_niva_tables_ok' );
		echo '<p style="color:#1d7a4f;font-weight:700">جدول‌ها ساخته شد. حالا افزونه را فعال کن.</p>';
	}

	echo 'آخرین خطای ثبت‌شده‌ی افزونه: ' . wp_json_encode( get_option( 'dr_niva_last_fatal' ) ) . "\n";
	echo 'خطای فعال‌سازی: ' . (string) get_option( 'dr_niva_activation_error', 'ندارد' ) . "\n";
	?></pre>
	<p>هر خطی که با <code>FAILED</code> شروع شود، علت دقیق مشکل است. همان خط را بفرست.</p>
<?php endif; ?>

<p style="color:#5c6b7a">پس از پایان عیب‌یابی، این فایل را از سایت حذف کن.</p>
</body>
</html>
