/* ==========================================================================
   Dr. Niva — admin app shell behaviour (2.0.0)
   Vanilla JS, no dependency, only active on the plugin's own screens.
   ========================================================================== */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') { fn(); }
    else { document.addEventListener('DOMContentLoaded', fn); }
  }

  function toast(message, kind) {
    var area = document.querySelector('.avadm-toast-area');
    if (!area) {
      area = document.createElement('div');
      area.className = 'avadm-toast-area';
      document.body.appendChild(area);
    }
    var node = document.createElement('div');
    node.className = 'avadm-toast' + (kind ? ' avadm-toast--' + kind : '');
    node.setAttribute('role', 'status');
    node.textContent = message;
    area.appendChild(node);
    window.setTimeout(function () {
      node.style.opacity = '0';
      window.setTimeout(function () { node.remove(); }, 250);
    }, 3200);
  }

  ready(function () {
    var root = document.querySelector('.avadm');

    /* ---------------------------------------------------------- live search */
    document.querySelectorAll('[data-avadm-search]').forEach(function (input) {
      var scope = document.querySelector(input.getAttribute('data-avadm-search'));
      if (!scope) { return; }
      input.addEventListener('input', function () {
        var term = input.value.trim().toLowerCase();
        var hitGroups = 0;
        scope.querySelectorAll('[data-avadm-group]').forEach(function (group) {
          var hits = 0;
          group.querySelectorAll('[data-avadm-field]').forEach(function (field) {
            var match = !term || (field.textContent || '').toLowerCase().indexOf(term) !== -1;
            field.hidden = !match;
            if (match) { hits++; }
          });
          group.hidden = hits === 0;
          if (hits > 0) { hitGroups++; }
        });
        var empty = document.querySelector('[data-avadm-noresult]');
        if (empty) { empty.hidden = hitGroups > 0; }
      });
    });

    /* ------------------------------------------------------- inline help "?" */
    document.querySelectorAll('[data-avadm-help]').forEach(function (button) {
      button.addEventListener('click', function () {
        var panel = document.getElementById(button.getAttribute('data-avadm-help'));
        if (!panel) { return; }
        var open = panel.hidden;
        panel.hidden = !open;
        button.setAttribute('aria-expanded', open ? 'true' : 'false');
      });
    });

    /* ---------------------------------------------------------- reset a field */
    document.querySelectorAll('[data-avadm-reset]').forEach(function (button) {
      button.addEventListener('click', function () {
        var field = button.closest('[data-avadm-field]');
        if (!field) { return; }
        var value = button.getAttribute('data-avadm-reset');
        field.querySelectorAll('input, select, textarea').forEach(function (input) {
          if (input.type === 'checkbox') {
            input.checked = value === '1';
          } else if (input.type !== 'hidden') {
            input.value = value;
          }
          input.dispatchEvent(new Event('change', { bubbles: true }));
        });
        markDirty(field.closest('form'));
      });
    });

    /* ------------------------------------------------------ secret set/unset */
    document.querySelectorAll('[data-avadm-secret-toggle]').forEach(function (button) {
      button.addEventListener('click', function () {
        var wrap = button.closest('.avadm-secret');
        if (!wrap) { return; }
        wrap.classList.add('is-open');
        button.setAttribute('aria-expanded', 'true');
        var input = wrap.querySelector('input');
        if (input) { input.focus(); }
      });
    });

    /* ------------------------------------------------------- live validation */
    function validate(input) {
      var field = input.closest('[data-avadm-field]');
      if (!field) { return true; }
      var error = field.querySelector('.avadm-field__error');
      var message = '';
      var value = input.value.trim();
      var rule = input.getAttribute('data-avadm-rule');

      if (value !== '' && rule) {
        if (rule === 'number' && !/^-?\d+(\.\d+)?$/.test(value)) {
          message = 'فقط عدد وارد کن.';
        } else if (rule === 'int' && !/^-?\d+$/.test(value)) {
          message = 'فقط عدد صحیح وارد کن.';
        } else if (rule === 'time' && !/^([01]\d|2[0-3]):[0-5]\d$/.test(value)) {
          message = 'ساعت را به شکل ۲۴ساعته بنویس، مثلاً 23:30.';
        } else if (rule === 'color' && !/^#[0-9a-fA-F]{6}$/.test(value)) {
          message = 'کد رنگ باید مثل #3368A0 باشد.';
        } else if (rule === 'url' && !/^https?:\/\/.+/i.test(value)) {
          message = 'نشانی باید با http یا https شروع شود.';
        } else if (rule === 'list' && /[|]/.test(value) && !input.matches('[data-avadm-allow-pipe]')) {
          message = 'هر مقدار را با کاما جدا کن، نه خط عمودی.';
        }
      }

      var min = input.getAttribute('min');
      var max = input.getAttribute('max');
      if (!message && value !== '' && (min !== null || max !== null)) {
        var num = Number(value);
        if (!isNaN(num)) {
          if (min !== null && num < Number(min)) { message = 'کمتر از حد مجاز (' + min + ') است.'; }
          if (!message && max !== null && num > Number(max)) { message = 'بیشتر از حد مجاز (' + max + ') است.'; }
        }
      }

      field.classList.toggle('avadm-field--invalid', message !== '');
      if (error) { error.textContent = message; error.hidden = message === ''; }
      return message === '';
    }

    document.querySelectorAll('[data-avadm-rule], .avadm [min], .avadm [max]').forEach(function (input) {
      if (!input.closest('[data-avadm-field]')) { return; }
      input.addEventListener('blur', function () { validate(input); });
      input.addEventListener('change', function () { validate(input); });
    });

    /* --------------------------------------------------- unsaved changes bar */
    var dirtyForms = new Set();

    function markDirty(form) {
      if (!form) { return; }
      dirtyForms.add(form);
      updateSticky();
    }

    function updateSticky() {
      var bar = document.querySelector('.avadm-sticky');
      if (!bar) { return; }
      var count = 0;
      dirtyForms.forEach(function (form) {
        if (form.isConnected) { count++; }
      });
      bar.classList.toggle('is-visible', count > 0);
      var label = bar.querySelector('[data-avadm-dirty-count]');
      if (label) { label.textContent = count; }
    }

    document.querySelectorAll('.avadm form').forEach(function (form) {
      form.addEventListener('input', function () { markDirty(form); });
      form.addEventListener('change', function () { markDirty(form); });
      form.addEventListener('submit', function () {
        dirtyForms.delete(form);
        var invalid = false;
        form.querySelectorAll('input, select, textarea').forEach(function (input) {
          if (!validate(input)) { invalid = true; }
        });
        if (invalid) {
          dirtyForms.add(form);
          toast('چند مقدار معتبر نیست؛ همان‌ها را درست کن.', 'warn');
        }
      });
    });

    /* ------------------------------------------------------------- Ctrl/⌘+S */
    document.addEventListener('keydown', function (event) {
      if (!(event.ctrlKey || event.metaKey) || event.key.toLowerCase() !== 's') { return; }
      if (!root) { return; }
      var target = document.activeElement;
      var form = target && target.closest ? target.closest('.avadm form') : null;
      var pending = form || (dirtyForms.size ? Array.from(dirtyForms)[0] : null);
      if (pending) {
        event.preventDefault();
        var button = pending.querySelector('[type="submit"]');
        if (button) { button.click(); }
      }
    });

    window.addEventListener('beforeunload', function (event) {
      var visible = document.querySelector('.avadm-sticky.is-visible');
      if (!visible) { return; }
      event.preventDefault();
      event.returnValue = '';
    });

    /* --------------------------------------------------------- drawers/tabs */
    function closeDrawer() {
      document.querySelectorAll('.avadm-drawer.is-open').forEach(function (drawer) {
        drawer.classList.remove('is-open');
        drawer.setAttribute('aria-hidden', 'true');
      });
      document.querySelectorAll('.avadm-scrim').forEach(function (scrim) { scrim.hidden = true; });
    }

    document.querySelectorAll('[data-avadm-drawer-open]').forEach(function (trigger) {
      trigger.addEventListener('click', function () {
        var drawer = document.getElementById(trigger.getAttribute('data-avadm-drawer-open'));
        if (!drawer) { return; }
        drawer.classList.add('is-open');
        drawer.setAttribute('aria-hidden', 'false');
        var scrim = document.querySelector('[data-avadm-scrim]');
        if (scrim) { scrim.hidden = false; }
        var close = drawer.querySelector('[data-avadm-drawer-close]');
        if (close) { close.focus(); }
      });
    });

    document.querySelectorAll('[data-avadm-drawer-close], [data-avadm-scrim]').forEach(function (node) {
      node.addEventListener('click', closeDrawer);
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') { closeDrawer(); }
    });

    document.querySelectorAll('.avadm-tabs').forEach(function (tabs) {
      var buttons = tabs.querySelectorAll('button[aria-controls]');
      buttons.forEach(function (button) {
        button.addEventListener('click', function () {
          buttons.forEach(function (other) {
            other.setAttribute('aria-selected', other === button ? 'true' : 'false');
            var panel = document.getElementById(other.getAttribute('aria-controls'));
            if (panel) { panel.hidden = other !== button; }
          });
        });
      });
    });

    /* ------------------------------------------------- bulk selection helper */
    document.querySelectorAll('[data-avadm-checkall]').forEach(function (master) {
      master.addEventListener('change', function () {
        var scope = document.querySelector(master.getAttribute('data-avadm-checkall'));
        if (!scope) { return; }
        scope.querySelectorAll('input[name="ids[]"]').forEach(function (box) { box.checked = master.checked; });
        updateBulk();
      });
    });

    function updateBulk() {
      var boxes = document.querySelectorAll('[data-avadm-bulk-list] input[name="ids[]"]');
      if (!boxes.length) { return; }
      var count = 0;
      boxes.forEach(function (box) { if (box.checked) { count++; } });
      document.querySelectorAll('[data-avadm-bulk-count]').forEach(function (node) { node.textContent = count; });
      document.querySelectorAll('[data-avadm-bulk]').forEach(function (node) { node.disabled = count === 0; });
    }

    document.querySelectorAll('[data-avadm-bulk-list] input[name="ids[]"]').forEach(function (box) {
      box.addEventListener('change', updateBulk);
    });
    document.querySelectorAll('[data-avadm-bulk]').forEach(function (node) {
      node.addEventListener('click', function (event) {
        var count = node.getAttribute('data-avadm-bulk-confirm');
        if (count && !window.confirm(count.replace('{n}', document.querySelector('[data-avadm-bulk-count]').textContent))) {
          event.preventDefault();
        }
      });
    });
    updateBulk();

    /* -------------------------------------------------------------- misc */
    document.querySelectorAll('[data-avadm-confirm]').forEach(function (node) {
      node.addEventListener('click', function (event) {
        if (!window.confirm(node.getAttribute('data-avadm-confirm') || 'مطمئنی؟')) { event.preventDefault(); }
      });
    });

    if (document.body.classList.contains('avadm-show-saved')) {
      toast('ذخیره شد.', 'ok');
    }
  });
})();
