/* Dr. Niva admin behaviour: local only, no external dependency. */
(function () {
  'use strict';

  function ready(fn) {
    if (document.readyState !== 'loading') fn();
    else document.addEventListener('DOMContentLoaded', fn);
  }

  ready(function () {
    document.querySelectorAll('[data-niva-sidebar-toggle]').forEach(function (button) {
      button.addEventListener('click', function () {
        var settings = button.closest('.niva-settings');
        if (!settings) return;
        var collapsed = settings.classList.toggle('niva-settings--collapsed');
        button.setAttribute('aria-expanded', collapsed ? 'false' : 'true');
        button.textContent = collapsed ? 'بازکردن فهرست تنظیمات' : 'جمع‌کردن فهرست';
      });
    });

    // confirm destructive links/buttons
    document.querySelectorAll('[data-niva-confirm]').forEach(function (node) {
      node.addEventListener('click', function (event) {
        if (!window.confirm(node.getAttribute('data-niva-confirm') || 'مطمئنی؟')) event.preventDefault();
      });
    });

    // media picker for logo / attachment fields
    document.querySelectorAll('[data-niva-media]').forEach(function (button) {
      button.addEventListener('click', function (event) {
        event.preventDefault();
        var target = document.querySelector(button.getAttribute('data-niva-media'));
        if (!target || !window.wp || !window.wp.media) return;
        var frame = window.wp.media({ title: 'انتخاب تصویر', multiple: false });
        frame.on('select', function () {
          var item = frame.state().get('selection').first().toJSON();
          target.value = item.id || item.url;
          var preview = button.parentNode.querySelector('.niva-media-preview');
          if (preview) preview.innerHTML = '<img src="' + item.url + '" alt="" style="max-width:120px;border-radius:10px" />';
        });
        frame.open();
      });
    });

    // client-side filter for long module lists
    document.querySelectorAll('[data-niva-filter]').forEach(function (input) {
      var list = document.querySelector(input.getAttribute('data-niva-filter'));
      if (!list) return;
      input.addEventListener('input', function () {
        var needle = input.value.trim().toLowerCase();
        list.querySelectorAll('[data-niva-item]').forEach(function (row) {
          var text = row.textContent.toLowerCase();
          row.style.display = !needle || text.indexOf(needle) !== -1 ? '' : 'none';
        });
        list.querySelectorAll('[data-niva-gate-group]').forEach(function (group) {
          var visible = Array.prototype.some.call(group.querySelectorAll('tbody tr'), function (row) {
            return row.style.display !== 'none';
          });
          group.hidden = !visible;
        });
      });
    });
  });
})();
