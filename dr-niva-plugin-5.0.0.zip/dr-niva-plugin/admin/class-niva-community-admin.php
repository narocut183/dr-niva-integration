<?php
/**
 * Community back office (2.0.0): review queue, moderation and categories.
 *
 * Deliberately plain forms + nonces: moderation must work even if the admin
 * script fails to load, and every action is re-checked on the server.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Community_Admin {


	/** One shared instance: the class starts at boot (for admin-post) and again on its screen. */
	private static $instance = null;

	public static function instance() : self {
		if ( null === self::$instance ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function __construct() {
		add_action( 'admin_notices', array( $this, 'notices' ) );
		add_action( 'admin_post_dr_niva_community_action', array( $this, 'handle_action' ) );
		add_action( 'admin_post_dr_niva_community_category', array( $this, 'handle_category' ) );
	}

	private function community() : Niva_Community {
		return dr_niva()->community instanceof Niva_Community ? dr_niva()->community : new Niva_Community();
	}

	/** Renders inside the admin app shell (called by Niva_Admin). */
	public function render() : void {
		$community = $this->community();

		global $wpdb;
		$threads_table = Niva_DB::table( 'community_threads' );
		$comment_table = Niva_DB::table( 'community_comments' );
		$report_table  = Niva_DB::table( 'community_reports' );

		$view     = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'queue'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$category = isset( $_GET['category'] ) ? absint( wp_unslash( $_GET['category'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		$pending_threads  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$threads_table} WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB
		$pending_comments = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$comment_table} WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB
		$open_reports     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$report_table} WHERE status = 'open'" ); // phpcs:ignore WordPress.DB
		$published        = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$threads_table} WHERE status = 'publish'" ); // phpcs:ignore WordPress.DB
		$total_threads    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$threads_table}" ); // phpcs:ignore WordPress.DB
		?>
		<div class="avadm-grid avadm-grid--kpi">
			<?php
			Niva_Admin_Shell::stat( 'گفتگوهای منتشرشده', number_format_i18n( $published ), 'در دسترس کاربران' );
			Niva_Admin_Shell::stat( 'در انتظار بازبینی', number_format_i18n( $pending_threads + $pending_comments ), 'گفتگو و نظر', ( $pending_threads + $pending_comments ) ? 'warn' : '' );
			Niva_Admin_Shell::stat( 'گزارش‌های باز', number_format_i18n( $open_reports ), 'صف بررسی تخلف', $open_reports ? 'danger' : '' );
			Niva_Admin_Shell::stat( 'نرخ پاسخ', $total_threads ? number_format_i18n( (int) round( ( (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$threads_table} WHERE comment_count > 0" ) / max( 1, $total_threads ) ) * 100 ) ) . '٪' : '—', 'گفتگوهای دارای پاسخ' );
			?>
		</div>

		<nav class="avadm-seg" style="margin:14px 0" aria-label="نمای مدیریت گفتگوها">
			<?php
			$views = array(
				'queue'      => 'صف بازبینی (' . number_format_i18n( $pending_threads + $pending_comments ) . ')',
				'threads'    => 'همهٔ گفتگوها',
				'reports'    => 'گزارش‌ها (' . number_format_i18n( $open_reports ) . ')',
				'categories' => 'دسته‌بندی‌ها',
			);
			foreach ( $views as $key => $label ) :
				?>
				<a href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-community&view=' . $key ) ); ?>" aria-current="<?php echo $view === $key ? 'true' : 'false'; ?>"><?php echo esc_html( $label ); ?></a>
			<?php endforeach; ?>
		</nav>

		<?php
		if ( 'categories' === $view ) {
			$this->categories_view( $community );
		} elseif ( 'reports' === $view ) {
			$this->reports_view();
		} elseif ( 'threads' === $view ) {
			$this->threads_view( $community, $category );
		} else {
			$this->queue_view();
		}
	}

	private function action_button( string $action, string $object_type, int $object_id, string $label, string $tone = '' ) : string {
		$url = wp_nonce_url(
			add_query_arg(
				array( 'action' => 'dr_niva_community_action', 'do' => $action, 'object_type' => $object_type, 'object_id' => $object_id ),
				admin_url( 'admin-post.php' )
			),
			'dr_niva_community_action'
		);
		return '<a class="button' . ( $tone ? ' button-' . $tone : '' ) . ' button-small" href="' . esc_url( $url ) . '">' . esc_html( $label ) . '</a>';
	}

	private function queue_view() : void {
		global $wpdb;
		$threads  = $wpdb->get_results( "SELECT id, title, user_id, category_id, created_at, anchor FROM " . Niva_DB::table( 'community_threads' ) . " WHERE status = 'pending' ORDER BY id DESC LIMIT 50", ARRAY_A ); // phpcs:ignore WordPress.DB
		$comments = $wpdb->get_results( "SELECT id, thread_id, user_id, body, created_at FROM " . Niva_DB::table( 'community_comments' ) . " WHERE status = 'pending' ORDER BY id DESC LIMIT 50", ARRAY_A ); // phpcs:ignore WordPress.DB
		?>
		<section class="avadm-card">
			<header class="avadm-card__head"><h2 class="avadm-card__title">گفتگوهای در انتظار بازبینی</h2></header>
			<?php if ( ! $threads ) : ?>
				<?php Niva_Admin_Shell::empty_state( 'صف گفتگو خالی است', 'هر پرسش تازه‌ای که به بازبینی نیاز داشته باشد این‌جا می‌آید.' ); ?>
			<?php else : ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>عنوان</th><th>نویسنده</th><th>مخاطب</th><th>زمان</th><th>اقدام</th></tr></thead>
						<tbody>
						<?php foreach ( $threads as $row ) : ?>
							<tr>
								<td><?php echo esc_html( (string) $row['title'] ); ?></td>
								<td><?php echo esc_html( $this->user_label( (int) $row['user_id'] ) ); ?></td>
								<td><code><?php echo esc_html( (string) $row['anchor'] ); ?></code></td>
								<td><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ); ?></td>
								<td>
									<?php echo wp_kses_post( $this->action_button( 'approve', 'thread', (int) $row['id'], 'تأیید', 'primary' ) ); ?>
									<?php echo wp_kses_post( $this->action_button( 'hide', 'thread', (int) $row['id'], 'پنهان' ) ); ?>
									<?php echo wp_kses_post( $this->action_button( 'delete', 'thread', (int) $row['id'], 'حذف' ) ); ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>

		<section class="avadm-card">
			<header class="avadm-card__head"><h2 class="avadm-card__title">نظرهای در انتظار بازبینی</h2></header>
			<?php if ( ! $comments ) : ?>
				<?php Niva_Admin_Shell::empty_state( 'صف نظر خالی است', 'نظرهای حاوی توصیهٔ دارویی این‌جا برای بررسی می‌آیند.' ); ?>
			<?php else : ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>متن</th><th>نویسنده</th><th>گفتگو</th><th>اقدام</th></tr></thead>
						<tbody>
						<?php foreach ( $comments as $row ) : ?>
							<tr>
								<td><?php echo esc_html( wp_trim_words( wp_strip_all_tags( (string) $row['body'] ), 14 ) ); ?></td>
								<td><?php echo esc_html( $this->user_label( (int) $row['user_id'] ) ); ?></td>
								<td>#<?php echo esc_html( Niva_Chrome::digits( (string) (int) $row['thread_id'] ) ); ?></td>
								<td>
									<?php echo wp_kses_post( $this->action_button( 'approve', 'comment', (int) $row['id'], 'تأیید', 'primary' ) ); ?>
									<?php echo wp_kses_post( $this->action_button( 'hide', 'comment', (int) $row['id'], 'پنهان' ) ); ?>
									<?php echo wp_kses_post( $this->action_button( 'delete', 'comment', (int) $row['id'], 'حذف' ) ); ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	private function threads_view( Niva_Community $community, int $category ) : void {
		$cats   = $community->categories( false );
		$result = $community->threads( array( 'status' => '', 'category_id' => $category, 'per_page' => 50 ) );
		?>
		<div class="avadm-toolbar">
			<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
				<input type="hidden" name="page" value="dr-niva-community" />
				<input type="hidden" name="view" value="threads" />
				<label class="screen-reader-text" for="niva-cat">دسته</label>
				<select id="niva-cat" name="category">
					<option value="0">همهٔ دسته‌ها</option>
					<?php foreach ( $cats as $cat ) : ?>
						<option value="<?php echo esc_attr( (string) $cat['id'] ); ?>" <?php selected( $category, (int) $cat['id'] ); ?>><?php echo esc_html( (string) $cat['title'] ); ?></option>
					<?php endforeach; ?>
				</select>
				<button type="submit" class="button">اعمال</button>
			</form>
		</div>

		<section class="avadm-card">
			<?php if ( ! $result['items'] ) : ?>
				<?php Niva_Admin_Shell::empty_state( 'گفتگویی پیدا نشد', 'با فیلتر دیگری امتحان کن.' ); ?>
			<?php else : ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>عنوان</th><th>دسته</th><th>نویسنده</th><th>وضعیت</th><th>پاسخ</th><th>بازدید</th><th>اقدام</th></tr></thead>
						<tbody>
						<?php foreach ( $result['items'] as $row ) : ?>
							<tr>
								<td><a href="<?php echo esc_url( $row['url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $row['title'] ); ?></a></td>
								<td><?php echo esc_html( (string) $row['category_title'] ); ?></td>
								<td><?php echo esc_html( $row['author_name'] ); ?></td>
								<td><code><?php echo esc_html( (string) $row['status'] ); ?></code></td>
								<td><?php echo esc_html( number_format_i18n( (int) $row['comment_count'] ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (int) $row['views'] ) ); ?></td>
								<td>
									<?php if ( (int) $row['is_pinned'] ) : ?>
										<?php echo wp_kses_post( $this->action_button( 'unpin', 'thread', (int) $row['id'], 'برداشتن سنجاق' ) ); ?>
									<?php else : ?>
										<?php echo wp_kses_post( $this->action_button( 'pin', 'thread', (int) $row['id'], 'سنجاق' ) ); ?>
									<?php endif; ?>
									<?php echo wp_kses_post( $this->action_button( 'close', 'thread', (int) $row['id'], 'بستن' ) ); ?>
									<?php echo wp_kses_post( $this->action_button( 'hide', 'thread', (int) $row['id'], 'پنهان' ) ); ?>
									<?php echo wp_kses_post( $this->action_button( 'mute', 'user', (int) $row['user_id'], 'محدودکردن نویسنده' ) ); ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	private function reports_view() : void {
		global $wpdb;
		$rows = $wpdb->get_results( "SELECT * FROM " . Niva_DB::table( 'community_reports' ) . " WHERE status = 'open' ORDER BY id DESC LIMIT 100", ARRAY_A ); // phpcs:ignore WordPress.DB
		?>
		<section class="avadm-card">
			<header class="avadm-card__head"><h2 class="avadm-card__title">گزارش‌های در انتظار بررسی</h2></header>
			<?php if ( ! $rows ) : ?>
				<?php Niva_Admin_Shell::empty_state( 'گزارشی ثبت نشده است', 'گزارش‌های کاربران دربارهٔ گفتگو یا نظرها این‌جا می‌آید.' ); ?>
			<?php else : ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>نوع</th><th>شناسه</th><th>گزارش‌دهنده</th><th>دلیل</th><th>زمان</th><th>اقدام</th></tr></thead>
						<tbody>
						<?php foreach ( $rows as $row ) : ?>
							<tr>
								<td><code><?php echo esc_html( (string) $row['object_type'] ); ?></code></td>
								<td>#<?php echo esc_html( Niva_Chrome::digits( (string) (int) $row['object_id'] ) ); ?></td>
								<td><?php echo esc_html( $this->user_label( (int) $row['user_id'] ) ); ?></td>
								<td><?php echo esc_html( (string) $row['reason'] ); ?></td>
								<td><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ); ?></td>
								<td>
									<?php echo wp_kses_post( $this->action_button( 'hide', (string) $row['object_type'], (int) $row['object_id'], 'پنهان‌کردن محتوا' ) ); ?>
									<?php echo wp_kses_post( $this->action_button( 'resolve_report', 'report', (int) $row['id'], 'بسته‌شدن گزارش', 'primary' ) ); ?>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	private function categories_view( Niva_Community $community ) : void {
		$cats = $community->categories( false );
		?>
		<div class="avadm-grid avadm-grid--2">
			<section class="avadm-card">
				<header class="avadm-card__head"><h2 class="avadm-card__title">دسته‌های فعلی</h2></header>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>عنوان</th><th>شناسه</th><th>رنگ</th><th>آیکون</th><th>وضعیت</th></tr></thead>
						<tbody>
						<?php foreach ( $cats as $cat ) : ?>
							<tr>
								<td><?php echo esc_html( (string) $cat['title'] ); ?></td>
								<td><code><?php echo esc_html( (string) $cat['slug'] ); ?></code></td>
								<td><span class="avadm-pill"><?php echo esc_html( (string) $cat['color'] ); ?></span></td>
								<td><code><?php echo esc_html( (string) $cat['icon'] ); ?></code></td>
								<td><?php echo ! empty( $cat['is_active'] ) ? '<span class="avadm-pill avadm-pill--ok">فعال</span>' : '<span class="avadm-pill avadm-pill--muted">خاموش</span>'; ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			</section>

			<section class="avadm-card">
				<header class="avadm-card__head"><h2 class="avadm-card__title">افزودن / ویرایش دسته</h2></header>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
					<input type="hidden" name="action" value="dr_niva_community_category" />
					<?php wp_nonce_field( 'dr_niva_community_category' ); ?>
					<label class="field"><span class="field__label">شناسهٔ لاتین (slug)</span><input class="field__input" name="slug" dir="ltr" required /></label>
					<label class="field"><span class="field__label">عنوان</span><input class="field__input" name="title" required /></label>
					<label class="field"><span class="field__label">توضیح</span><input class="field__input" name="description" /></label>
					<div class="grid-2">
						<label class="field"><span class="field__label">رنگ</span>
							<select class="field__input" name="color">
								<?php foreach ( array( 'pink', 'green', 'violet', 'blue', 'orange', 'purple' ) as $color ) : ?>
									<option value="<?php echo esc_attr( $color ); ?>"><?php echo esc_html( $color ); ?></option>
								<?php endforeach; ?>
							</select>
						</label>
						<label class="field"><span class="field__label">آیکون (نام آیکون دکتر نیوا)</span><input class="field__input" name="icon" dir="ltr" value="message-circle" /></label>
					</div>
					<label class="field"><span class="field__label">ترتیب</span><input class="field__input" name="sort_order" type="number" value="0" /></label>
					<label class="switch-row"><input type="checkbox" name="is_active" value="1" checked /><span>فعال باشد</span></label>
					<button type="submit" class="button button-primary">ذخیرهٔ دسته</button>
				</form>
			</section>
		</div>
		<?php
	}

	private function user_label( int $user_id ) : string {
		$user = get_userdata( $user_id );
		return $user ? (string) $user->display_name : '#' . $user_id;
	}

	/* ---------------------------------------------------------------- actions */

	public function handle_action() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		check_admin_referer( 'dr_niva_community_action' );

		$do          = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		$object_type = isset( $_GET['object_type'] ) ? sanitize_key( wp_unslash( $_GET['object_type'] ) ) : 'thread';
		$object_id   = isset( $_GET['object_id'] ) ? absint( wp_unslash( $_GET['object_id'] ) ) : 0;

		$map = array(
			'approve'        => 'approve',
			'hide'           => 'hide',
			'close'          => 'close',
			'pin'            => 'pin',
			'unpin'          => 'pin',
			'feature'        => 'feature',
			'delete'         => 'delete',
			'resolve_report' => 'resolve_report',
			'mute'           => 'mute',
		);

		$result = 'invalid';

		if ( isset( $map[ $do ] ) && $object_id > 0 ) {
			$action = $map[ $do ];
			$extra  = array( 'value' => in_array( $do, array( 'pin', 'feature', 'mute' ), true ) );
			try {
				$ok     = $this->community()->moderate( $action, 'user' === $object_type ? 'thread' : $object_type, $object_id, $extra );
				$result = $ok ? 'done' : 'failed';
			} catch ( \Throwable $error ) {
				$result = 'error';
				if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
					error_log( '[dr-niva] community action failed: ' . $error->getMessage() ); // phpcs:ignore
				}
			}
		}

		/*
		 * 3.0.1 — always return to a registered screen with a visible result.
		 * The old code redirected to wp_get_referer(), which is false when the
		 * referer is missing or identical to the current URL; wp_safe_redirect()
		 * then sent nothing and the request ended as a blank page.
		 */
		$target = add_query_arg(
			array(
				'page'       => 'dr-niva-community',
				'niva_action' => $do,
				'niva_result' => $result,
			),
			admin_url( 'admin.php' )
		);
		nocache_headers();
		if ( ! wp_safe_redirect( $target ) ) {
			wp_die( esc_html__( 'بازگشت به فهرست گفتگوها ممکن نشد؛ از «دکتر نیوا → گفتگوهای کاربران» ادامه بده.', 'dr-niva' ) );
		}
		exit;
	}

	public function handle_category() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		check_admin_referer( 'dr_niva_community_category' );

		$id = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0;
		$this->community()->save_category(
			array(
				'slug'        => isset( $_POST['slug'] ) ? sanitize_key( wp_unslash( $_POST['slug'] ) ) : '',
				'title'       => isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '',
				'description' => isset( $_POST['description'] ) ? sanitize_text_field( wp_unslash( $_POST['description'] ) ) : '',
				'icon'        => isset( $_POST['icon'] ) ? sanitize_key( wp_unslash( $_POST['icon'] ) ) : 'message-circle',
				'color'       => isset( $_POST['color'] ) ? sanitize_key( wp_unslash( $_POST['color'] ) ) : 'blue',
				'sort_order'  => isset( $_POST['sort_order'] ) ? (int) wp_unslash( $_POST['sort_order'] ) : 0,
				'is_active'   => isset( $_POST['is_active'] ),
			),
			$id
		);

		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-community&view=categories' ) );
		exit;
	}

	/** Result banner for the moderation links (approve/hide/pin/…). */
	public function notices() : void {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : '';
		if ( 'dr-niva-community' !== $page ) {
			return;
		}
		$result = isset( $_GET['niva_result'] ) ? sanitize_key( wp_unslash( $_GET['niva_result'] ) ) : '';
		$map    = array(
			'done'    => array( 'success', 'انجام شد.' ),
			'failed'  => array( 'warning', 'تغییری اعمال نشد؛ دوباره تلاش کن.' ),
			'error'   => array( 'error', 'اجرای این کار با خطا روبه‌رو شد. اگر تکرار شد لاگ خطا را بررسی کن.' ),
			'invalid' => array( 'error', 'درخواست نامعتبر بود.' ),
		);
		if ( ! isset( $map[ $result ] ) ) {
			return;
		}
		printf(
			'<div class="notice notice-%1$s is-dismissible"><p>%2$s</p></div>',
			esc_attr( $map[ $result ][0] ),
			esc_html( $map[ $result ][1] )
		);
	}

}
