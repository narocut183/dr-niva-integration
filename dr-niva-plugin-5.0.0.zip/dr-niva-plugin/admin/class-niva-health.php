<?php
/**
 * Health screen: runs the checks that would otherwise surface as a fatal error
 * or a silent failure on a live site, and reports them in plain language.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Health {

	public function menu() : void {
		add_submenu_page( 'dr-niva', 'بررسی سلامت', 'بررسی سلامت', 'manage_options', 'dr-niva-health', array( $this, 'page' ) );
	}

	/** @return array<int,array{label:string,status:string,detail:string}> */
	public function checks() : array {
		global $wpdb;
		$rows = array();

		$fatal = Niva_Compat::last_fatal();
		$rows[] = array(
			'label'  => 'آخرین خطای مهلک افزونه',
			'status' => $fatal ? 'fail' : 'ok',
			'detail' => $fatal
				? $fatal['message'] . ' — ' . basename( (string) $fatal['file'] ) . ':' . $fatal['line'] . ' (' . $fatal['when'] . ')'
				: 'خطایی ثبت نشده است',
		);

		$boot_errors = (array) get_option( 'dr_niva_boot_errors', array() );
		$rows[] = array(
			'label'  => 'بارگذاری بخش‌ها',
			'status' => $boot_errors ? 'fail' : 'ok',
			'detail' => $boot_errors
				? implode( ' | ', array_map( static function ( $row ) { return $row['class'] . ': ' . $row['message']; }, array_slice( $boot_errors, -3 ) ) )
				: 'همه‌ی بخش‌ها بدون خطا بارگذاری شدند',
		);

		$activation_error = (string) get_option( 'dr_niva_activation_error', '' );
		$rows[] = array(
			'label'  => 'خطای فعال‌سازی',
			'status' => $activation_error ? 'fail' : 'ok',
			'detail' => $activation_error ? $activation_error : 'ندارد',
		);

		$rows[] = array(
			'label'  => 'نسخه‌ی PHP (حداقل ۷.۴)',
			'status' => Niva_Compat::php_ok() ? 'ok' : 'fail',
			'detail' => PHP_VERSION,
		);

		$rows[] = array(
			'label'  => 'نسخه‌ی PHP',
			'status' => version_compare( PHP_VERSION, '8.1', '>=' ) ? 'ok' : 'fail',
			'detail' => PHP_VERSION . ' — حداقل لازم: 8.1',
		);

		$rows[] = array(
			'label'  => 'نسخه‌ی وردپرس',
			'status' => version_compare( get_bloginfo( 'version' ), '6.4', '>=' ) ? 'ok' : 'warn',
			'detail' => get_bloginfo( 'version' ),
		);

		$rows[] = array(
			'label'  => 'ووکامرس',
			'status' => class_exists( 'WooCommerce' ) ? 'ok' : 'warn',
			'detail' => class_exists( 'WooCommerce' ) ? 'فعال — فروش اعتبار و اشتراک کار می‌کند' : 'غیرفعال — فروش اعتبار و اشتراک غیرفعال می‌ماند',
		);

		$rows[] = array(
			'label'  => 'المنتور',
			'status' => Niva_Elementor::is_active() ? 'ok' : 'warn',
			'detail' => Niva_Elementor::is_active() ? 'فعال — ۶۱ ویجت در دسته‌ی «دکتر نیوا»' : 'غیرفعال — از شورت‌کدها استفاده کن',
		);

		// every module must have a partial, otherwise its widget renders empty
		$missing = array();
		foreach ( array_keys( Niva_Modules::map() ) as $module_id ) {
			if ( in_array( $module_id, array( 'credits_bar', 'wallet', 'packages' ), true ) ) {
				continue;
			}
			if ( ! file_exists( DR_NIVA_PATH . 'public/partials/' . $module_id . '.php' ) ) {
				$missing[] = $module_id;
			}
		}
		$rows[] = array(
			'label'  => 'فایل بخش‌ها',
			'status' => $missing ? 'fail' : 'ok',
			'detail' => $missing ? 'بدون فایل: ' . implode( ', ', $missing ) : count( Niva_Modules::map() ) . ' بخش، همه با فایل',
		);

		// tables
		$expected = array( 'wallets', 'ledger', 'usage', 'documents', 'reviews', 'reminders', 'notifications', 'push_subs', 'chats', 'chat_messages', 'growth', 'daily_logs', 'memberships', 'family_members', 'partners', 'partner_referrals', 'payouts', 'push_devices' );
		$absent   = array();
		foreach ( $expected as $table ) {
			$name = Niva_DB::table( $table );
			if ( $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $name ) ) !== $name ) { // phpcs:ignore WordPress.DB
				$absent[] = $table;
			}
		}
		$missing_tables = Niva_DB::missing_tables();
		$rows[] = array(
			'label'  => 'جدول‌های گم‌شده',
			'status' => $missing_tables ? 'fail' : 'ok',
			'detail' => $missing_tables ? 'کم است: ' . implode( ', ', $missing_tables ) . ' — دکمه‌ی «ترمیم جدول‌ها» را بزن' : 'همه‌ی جدول‌ها موجودند',
		);

		$rows[] = array(
			'label'  => 'جدول‌های داده',
			'status' => $absent ? 'fail' : 'ok',
			'detail' => $absent ? 'ساخته نشده: ' . implode( ', ', $absent ) . ' — افزونه را غیرفعال و دوباره فعال کن' : count( $expected ) . ' جدول آماده',
		);

		$rows[] = array(
			'label'  => 'کلیدهای پوش (VAPID)',
			'status' => ( dr_niva()->settings->get( 'vapid_public' ) && dr_niva()->settings->get( 'vapid_private' ) ) ? 'ok' : 'warn',
			'detail' => ( dr_niva()->settings->get( 'vapid_public' ) ? 'ساخته شده' : 'ساخته نشده — افزونه را دوباره فعال کن یا کلیدها را دستی بگذار' ),
		);

		$rows[] = array(
			'label'  => 'فرستندهٔ رمزنگاری Web Push',
			'status' => false !== has_filter( 'dr_niva_webpush_sender' ) ? 'ok' : 'warn',
			'detail' => false !== has_filter( 'dr_niva_webpush_sender' ) ? 'آمادهٔ ارسال' : 'تنظیم نشده — اعلان داخل سایت برقرار است، اما پوش پس‌زمینه ارسال نمی‌شود',
		);

		$rows[] = array(
			'label'  => 'کلید سرور FCM (پوش اپ)',
			'status' => dr_niva()->settings->get( 'push_fcm_key' ) ? 'ok' : 'warn',
			'detail' => dr_niva()->settings->get( 'push_fcm_key' ) ? 'ثبت شده' : 'خالی — پوش اپ ارسال نمی‌شود (اعلان داخل برنامه کار می‌کند)',
		);

		foreach ( array( 'Niva_Settings', 'Niva_AI', 'Niva_Safety', 'Niva_Wallet', 'Niva_Plans', 'Niva_Partners', 'Niva_Push', 'Niva_Notifications', 'Niva_Modules', 'Niva_Chrome', 'Niva_Data', 'Niva_Links', 'Niva_Profile', 'Niva_Messages' ) as $class ) {
			if ( ! class_exists( $class ) ) {
				$rows[] = array( 'label' => 'کلاس ' . $class, 'status' => 'fail', 'detail' => 'بارگذاری نشده' );
			}
		}

		$rows[] = array(
			'label'  => 'کرون‌ها',
			'status' => ( wp_next_scheduled( 'dr_niva_every_minute' ) && wp_next_scheduled( 'dr_niva_daily_maintenance' ) ) ? 'ok' : 'warn',
			'detail' => wp_next_scheduled( 'dr_niva_every_minute' ) ? 'زمان‌بندی شده' : 'زمان‌بندی نشده — یک بار صفحه‌ای از سایت را باز کن',
		);

		$uploads = wp_upload_dir();
		$rows[]  = array(
			'label'  => 'پوشه‌ی آپلود',
			'status' => empty( $uploads['error'] ) && wp_is_writable( $uploads['basedir'] ) ? 'ok' : 'warn',
			'detail' => empty( $uploads['error'] ) ? $uploads['basedir'] : (string) $uploads['error'],
		);

		$provider = 'local';
		if ( dr_niva()->ai ) {
			$available = dr_niva()->ai->available();
			$provider  = $available ? implode( ', ', array_keys( $available ) ) : 'موتور آفلاین داخلی';
		}
		$rows[] = array(
			'label'  => 'موتور هوش مصنوعی',
			'status' => ( 'local' !== (string) dr_niva()->settings->get( 'ai_provider' ) && dr_niva()->ai && dr_niva()->ai->available() ) ? 'ok' : 'warn',
			'detail' => 'در دسترس: ' . $provider,
		);

		return $rows;
	}

	public function __construct() {
		// The menu entry is owned by Niva_Admin (single app shell); this class
		// only renders its screen and handles the health-check request.
		add_action( 'admin_post_dr_niva_health', array( $this, 'handle' ) );
	}

	public function handle() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_health' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}

		if ( 'repair' === ( $_POST['do'] ?? '' ) ) {
			Niva_DB::install();
			delete_transient( 'dr_niva_tables_ok' );
			update_option( 'dr_niva_missing_tables', Niva_DB::missing_tables(), false );
			wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-health&repaired=1' ) );
			exit;
		}
		Niva_Compat::clear_fatal();
		delete_option( 'dr_niva_boot_errors' );
		delete_option( 'dr_niva_activation_error' );
		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-health&cleared=1' ) );
		exit;
	}

	public function page() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		$rows  = $this->checks();
		$fails = 0;
		$warns = 0;
		foreach ( $rows as $row ) {
			$fails += 'fail' === $row['status'] ? 1 : 0;
			$warns += 'warn' === $row['status'] ? 1 : 0;
		}
		?>
		<div class="wrap niva-admin">
			<h1>بررسی سلامت افزونه</h1>

			<div class="niva-cards">
				<div class="niva-card"><span class="niva-card__value"><?php echo esc_html( count( $rows ) ); ?></span><span class="niva-card__label">بررسی انجام‌شده</span></div>
				<div class="niva-card"><span class="niva-card__value"><?php echo esc_html( $fails ); ?></span><span class="niva-card__label">مشکل جدی</span></div>
				<div class="niva-card"><span class="niva-card__value"><?php echo esc_html( $warns ); ?></span><span class="niva-card__label">هشدار</span></div>
			</div>

			<table class="widefat striped">
				<thead><tr><th style="width: 240px">بررسی</th><th style="width: 90px">نتیجه</th><th>جزئیات</th></tr></thead>
				<tbody>
				<?php foreach ( $rows as $row ) : ?>
					<tr>
						<td><strong><?php echo esc_html( $row['label'] ); ?></strong></td>
						<td>
							<?php if ( 'ok' === $row['status'] ) : ?>
								<span class="niva-badge niva-badge--ok">سالم</span>
							<?php elseif ( 'warn' === $row['status'] ) : ?>
								<span class="niva-badge niva-badge--warn">هشدار</span>
							<?php else : ?>
								<span class="niva-badge niva-badge--fail">مشکل</span>
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( $row['detail'] ); ?></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin: 0 0 10px">
				<?php wp_nonce_field( 'dr_niva_health' ); ?>
				<input type="hidden" name="action" value="dr_niva_health" />
				<input type="hidden" name="do" value="repair" />
				<button class="button button-primary">ترمیم و ساخت جدول‌های گم‌شده</button>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top: 12px">
				<?php wp_nonce_field( 'dr_niva_health' ); ?>
				<input type="hidden" name="action" value="dr_niva_health" />
				<input type="hidden" name="do" value="clear" />
				<button class="button">پاک‌کردن خطاهای ثبت‌شده</button>
			</form>

			<p class="description">این صفحه هر بار باز شدن، وضعیت واقعی افزونه را بررسی می‌کند. اگر «مشکل جدی» دیدی، متن همان ردیف را بفرست.</p>
		</div>
		<?php
	}
}
