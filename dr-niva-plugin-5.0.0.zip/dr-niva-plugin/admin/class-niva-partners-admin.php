<?php
/**
 * Back office for the partner programme: pipeline, commission, payouts.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Partners_Admin {

	public function __construct() {
		// Registered as a hidden screen by Niva_Admin and linked from the
		// «پلن‌ها و اعتبار» area, so the sidebar stays a single 13-item shell.
	}

	public function menu() : void {
		add_submenu_page( 'dr-niva', 'همکاران', 'همکاران و پورسانت', 'manage_options', 'dr-niva-partners', array( $this, 'page' ) );
	}

	public function page() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		global $wpdb;

		$status  = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$table   = Niva_DB::table( 'partners' );
		$where   = $status ? $wpdb->prepare( 'WHERE status = %s', $status ) : ''; // phpcs:ignore WordPress.DB
		$rows    = $wpdb->get_results( "SELECT * FROM {$table} {$where} ORDER BY id DESC LIMIT 200", ARRAY_A ); // phpcs:ignore WordPress.DB
		$counts  = array();
		foreach ( array( 'pending', 'approved', 'declined', 'suspended' ) as $key ) {
			$counts[ $key ] = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE status = %s", $key ) ); // phpcs:ignore WordPress.DB
		}
		$labels = array(
			'pending'   => 'در انتظار بررسی',
			'approved'  => 'تأییدشده',
			'declined'  => 'ردشده',
			'suspended' => 'غیرفعال',
		);

		$plan_key   = (string) dr_niva()->settings->get( 'partner_plan', 'partner' );
		$plan_label = dr_niva()->plans->label( $plan_key );
		$holders    = dr_niva()->plans->holders( $plan_key );
		$assignable = Niva_Plans::assignable();
		$plan_done  = isset( $_GET['plan_done'] ) ? sanitize_key( wp_unslash( $_GET['plan_done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$plan_error = isset( $_GET['plan_error'] ) ? sanitize_key( wp_unslash( $_GET['plan_error'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		?>
		<div class="wrap niva-admin">
			<h1>همکاران و پورسانت</h1>

			<?php if ( $plan_done ) : ?>
				<div class="notice notice-success is-dismissible"><p><?php echo 'revoke' === $plan_done ? 'پلن همکاران برای این کاربر غیرفعال شد.' : 'پلن همکاران برای این کاربر فعال شد.'; ?></p></div>
			<?php endif; ?>
			<?php if ( 'user' === $plan_error ) : ?>
				<div class="notice notice-error is-dismissible"><p>کاربری با این شناسه، نام کاربری یا ایمیل پیدا نشد.</p></div>
			<?php endif; ?>

			<div class="niva-panel">
				<h2>فعال‌سازی «<?php echo esc_html( $plan_label ); ?>» برای یک کاربر</h2>
				<p class="niva-card__hint">
					هر کاربری که درخواست بدهد، از همین‌جا پلن همکاران برایش روشن می‌شود؛ بدون پرداخت و بدون خرید اشتراک.
					خالی گذاشتن «مدت» یعنی پلن بدون تاریخ انقضا فعال می‌ماند.
				</p>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="niva-plan-form">
					<?php wp_nonce_field( 'dr_niva_partner_plan' ); ?>
					<input type="hidden" name="action" value="dr_niva_partner_plan" />
					<input type="hidden" name="do" value="assign" />

					<label>
						<span>کاربر (ایمیل، نام کاربری یا شناسه)</span>
						<input type="text" name="user" class="regular-text" dir="ltr" placeholder="user@example.com" required />
					</label>

					<label>
						<span>پلن</span>
						<select name="plan">
							<?php foreach ( $assignable as $key => $label ) : ?>
								<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $key, $plan_key ); ?>><?php echo esc_html( $label ); ?></option>
							<?php endforeach; ?>
						</select>
					</label>

					<label>
						<span>مدت اعتبار (روز — ۰ = بدون انقضا)</span>
						<input type="number" name="days" min="0" max="3650" step="1" value="<?php echo esc_attr( (int) dr_niva()->settings->get( 'partner_plan_days' ) ); ?>" />
					</label>

					<button class="button button-primary">فعال‌سازی پلن</button>
				</form>
			</div>

			<div class="niva-panel">
				<h2>کاربرانی که «<?php echo esc_html( $plan_label ); ?>» دارند (<?php echo esc_html( number_format_i18n( count( $holders ) ) ); ?>)</h2>
				<?php if ( ! $holders ) : ?>
					<p class="niva-card__hint">هنوز هیچ کاربری این پلن را فعال نکرده است.</p>
				<?php else : ?>
					<table class="widefat striped">
						<thead>
							<tr><th>کاربر</th><th>ایمیل</th><th>وضعیت</th><th>انقضا</th><th>منبع</th><th>اقدام</th></tr>
						</thead>
						<tbody>
						<?php foreach ( $holders as $holder ) : ?>
							<tr>
								<td><strong><?php echo esc_html( $holder['display_name'] ); ?></strong><br /><span class="description">#<?php echo esc_html( (int) $holder['user_id'] ); ?></span></td>
								<td><bdi dir="ltr"><?php echo esc_html( $holder['email'] ); ?></bdi></td>
								<td><?php echo $holder['active'] ? '<span class="niva-badge niva-badge--ok">فعال</span>' : '<span class="niva-badge niva-badge--warn">منقضی</span>'; ?></td>
								<td><?php echo esc_html( empty( $holder['expires_at'] ) || '0000-00-00 00:00:00' === $holder['expires_at'] ? 'بدون انقضا' : (string) $holder['expires_at'] ); ?></td>
								<td><?php echo esc_html( (string) $holder['source'] ); ?></td>
								<td>
									<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
										<?php wp_nonce_field( 'dr_niva_partner_plan' ); ?>
										<input type="hidden" name="action" value="dr_niva_partner_plan" />
										<input type="hidden" name="do" value="revoke" />
										<input type="hidden" name="user_id" value="<?php echo esc_attr( (int) $holder['user_id'] ); ?>" />
										<button class="button button-small">غیرفعال کن</button>
									</form>
								</td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				<?php endif; ?>
			</div>

			<div class="niva-cards">
				<?php foreach ( $labels as $key => $label ) : ?>
					<div class="niva-card">
						<span class="niva-card__value"><?php echo esc_html( number_format_i18n( $counts[ $key ] ) ); ?></span>
						<span class="niva-card__label"><?php echo esc_html( $label ); ?></span>
					</div>
				<?php endforeach; ?>
				<div class="niva-card">
					<span class="niva-card__value"><?php echo esc_html( number_format_i18n( (float) dr_niva()->settings->get( 'partner_commission' ) ) ); ?>٪</span>
					<span class="niva-card__label">پورسانت پیش‌فرض</span>
				</div>
			</div>

			<ul class="subsubsub">
				<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-partners' ) ); ?>" class="<?php echo '' === $status ? 'current' : ''; ?>">همه</a> |</li>
				<?php foreach ( $labels as $key => $label ) : ?>
					<li><a href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-partners&status=' . $key ) ); ?>" class="<?php echo $status === $key ? 'current' : ''; ?>"><?php echo esc_html( $label ); ?></a> |</li>
				<?php endforeach; ?>
			</ul>

			<table class="widefat striped">
				<thead>
					<tr>
						<th>همکار</th><th>نوع</th><th>تماس</th><th>کد</th><th>پورسانت</th>
						<th>کلیک</th><th>ثبت‌نام</th><th>فروش</th><th>در انتظار تسویه</th><th>وضعیت</th><th>اقدام</th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="11">هنوز همکاری ثبت نشده است.</td></tr>
				<?php endif; ?>
				<?php foreach ( (array) $rows as $row ) : ?>
					<?php $stats = dr_niva()->partners->stats( (int) $row['id'] ); ?>
					<tr>
						<td>
							<strong><?php echo esc_html( $row['name'] ); ?></strong>
							<?php if ( $row['city'] ) : ?><br /><span class="description"><?php echo esc_html( $row['city'] ); ?></span><?php endif; ?>
						</td>
						<td><?php echo esc_html( $row['type'] ); ?></td>
						<td>
							<?php if ( $row['phone'] ) : ?><bdi dir="ltr"><?php echo esc_html( $row['phone'] ); ?></bdi><br /><?php endif; ?>
							<?php if ( $row['email'] ) : ?><bdi dir="ltr"><?php echo esc_html( $row['email'] ); ?></bdi><?php endif; ?>
						</td>
						<td><code><?php echo esc_html( $row['code'] ); ?></code></td>
						<td>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: flex; gap: 4px">
								<?php wp_nonce_field( 'dr_niva_partner_action' ); ?>
								<input type="hidden" name="action" value="dr_niva_partner_action" />
								<input type="hidden" name="partner_id" value="<?php echo esc_attr( (int) $row['id'] ); ?>" />
								<input type="hidden" name="do" value="commission" />
								<input type="number" name="commission" value="<?php echo esc_attr( (float) $row['commission'] ); ?>" min="0" max="90" step="1" style="width: 64px" />
								<button class="button button-small">ذخیره</button>
							</form>
						</td>
						<td><?php echo esc_html( number_format_i18n( $stats['clicks'] ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $stats['signups'] ) ); ?></td>
						<td><?php echo esc_html( number_format_i18n( $stats['sales'] ) ); ?></td>
						<td><strong><?php echo esc_html( number_format_i18n( $stats['unpaid'] ) ); ?></strong></td>
						<td><?php echo esc_html( isset( $labels[ $row['status'] ] ) ? $labels[ $row['status'] ] : $row['status'] ); ?></td>
						<td style="display: flex; flex-direction: column; gap: 4px">
							<?php if ( 'approved' !== $row['status'] ) : ?>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<?php wp_nonce_field( 'dr_niva_partner_action' ); ?>
									<input type="hidden" name="action" value="dr_niva_partner_action" />
									<input type="hidden" name="partner_id" value="<?php echo esc_attr( (int) $row['id'] ); ?>" />
									<input type="hidden" name="do" value="approve" />
									<button class="button button-primary button-small">تأیید</button>
								</form>
							<?php endif; ?>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: flex; gap: 4px">
								<?php wp_nonce_field( 'dr_niva_partner_action' ); ?>
								<input type="hidden" name="action" value="dr_niva_partner_action" />
								<input type="hidden" name="partner_id" value="<?php echo esc_attr( (int) $row['id'] ); ?>" />
								<input type="hidden" name="do" value="payout" />
								<input type="number" name="amount" placeholder="تسویه" style="width: 80px" />
								<button class="button button-small">پرداخت</button>
							</form>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'dr_niva_partner_action' ); ?>
								<input type="hidden" name="action" value="dr_niva_partner_action" />
								<input type="hidden" name="partner_id" value="<?php echo esc_attr( (int) $row['id'] ); ?>" />
								<input type="hidden" name="do" value="decline" />
								<button class="button button-small">رد</button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		</div>
		<?php
	}
}
