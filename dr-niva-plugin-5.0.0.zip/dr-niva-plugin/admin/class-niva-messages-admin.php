<?php
/**
 * Back office for the daily message library: browse, filter, add, edit, seed.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Messages_Admin {

	public function __construct() {
		// The menu entry is owned by Niva_Admin (single app shell). menu() is
		// kept only for backwards compatibility with external callers.
	}

	public function menu() : void {
		add_submenu_page( 'dr-niva', 'پیام‌های روزانه', 'پیام‌های روزانه', 'manage_options', 'dr-niva-messages', array( $this, 'page' ) );
	}

	public function page() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}

		$edit_requested = isset( $_GET['edit'] ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$edit_id        = $edit_requested ? absint( $_GET['edit'] ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $edit_requested ) {
			$this->edit_form( $edit_id );
			return;
		}

		$audience = isset( $_GET['audience'] ) ? sanitize_key( wp_unslash( $_GET['audience'] ) ) : ''; // phpcs:ignore
		$search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore
		$page     = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore
		$result   = dr_niva()->messages->all_rows( array( 'audience' => $audience, 'search' => $search, 'page' => $page, 'per_page' => 50 ) );
		$labels   = Niva_Messages::audiences();
		global $wpdb;
		$audience_counts = $wpdb->get_results( 'SELECT audience, COUNT(*) AS total FROM ' . Niva_DB::table( 'messages' ) . ' WHERE active = 1 GROUP BY audience', ARRAY_A ); // phpcs:ignore WordPress.DB
		$active_by_audience = array_fill_keys( array_keys( $labels ), 0 );
		foreach ( (array) $audience_counts as $count_row ) {
			if ( isset( $active_by_audience[ $count_row['audience'] ] ) ) {
				$active_by_audience[ $count_row['audience'] ] = (int) $count_row['total'];
			}
		}
		?>
		<div class="wrap niva-admin">
			<?php $this->header( 'پیام‌های روزانه', (int) $result['total'] ); ?>

			<?php if ( isset( $_GET['seeded'] ) ) : // phpcs:ignore ?>
				<div class="notice notice-success"><p><?php echo esc_html( number_format_i18n( absint( $_GET['seeded'] ) ) ); // phpcs:ignore ?> پیام از کتابخانه‌ی پیش‌فرض اضافه شد.</p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['seed_error'] ) ) : // phpcs:ignore ?>
				<div class="notice notice-error"><p>همگام‌سازی کتابخانه انجام نشد. گزارش خطا را در لاگ PHP بررسی کن.</p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['saved'] ) ) : // phpcs:ignore ?>
				<div class="notice notice-success"><p>پیام با موفقیت ذخیره شد.</p></div>
			<?php endif; ?>
			<?php if ( isset( $_GET['deleted'] ) ) : // phpcs:ignore ?>
				<div class="notice notice-success"><p>پیام حذف شد.</p></div>
			<?php endif; ?>

			<div class="niva-panel">
				<h2>کتابخانه‌ی پیش‌فرض</h2>
				<p class="niva-panel__sub">
					کتابخانه‌ی همراه افزونه شامل ۱۱۰ پیام آماده برای بارداری، چرخه‌ی بانوان، رشد نوزاد، حال روان و سلامت عمومی است. پیام‌ها در پایگاه داده‌ی سایت ذخیره می‌شوند و قابل جست‌وجو، ویرایش و تکمیل هستند.
				</p>
				<div class="niva-message-counts">
					<?php foreach ( $labels as $key => $label ) : ?>
						<div><span><?php echo esc_html( $label ); ?></span><strong><?php echo esc_html( number_format_i18n( $active_by_audience[ $key ] ) ); ?></strong></div>
					<?php endforeach; ?>
				</div>
				<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: flex; gap: 8px; align-items: center">
					<?php wp_nonce_field( 'dr_niva_messages' ); ?>
					<input type="hidden" name="action" value="dr_niva_messages" />
					<input type="hidden" name="do" value="seed" />
					<?php submit_button( 'همگام‌سازی کتابخانه', 'primary', '', false ); ?>
				</form>
				<p class="description">تعداد پیام‌های موجود در سایت: <strong><?php echo esc_html( number_format_i18n( dr_niva()->messages->count() ) ); ?></strong>. همگام‌سازی فقط پیام‌های جاافتاده را اضافه می‌کند و پیام‌های فعلی را تکراری نمی‌سازد.</p>
			</div>

			<form method="get" style="display: flex; gap: 8px; align-items: center; margin: 12px 0">
				<input type="hidden" name="page" value="dr-niva-messages" />
				<select name="audience">
					<option value="">همه‌ی گروه‌ها</option>
					<?php foreach ( $labels as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $audience, $key ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<input type="search" name="s" value="<?php echo esc_attr( $search ); ?>" placeholder="جست‌وجو در متن…" />
				<?php submit_button( 'فیلتر', 'secondary', '', false ); ?>
				<a class="button button-primary" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-messages&edit=0' ) ); ?>">افزودن پیام تازه</a>
			</form>

			<table class="widefat striped">
				<thead>
					<tr>
						<th style="width: 70px">کد</th>
						<th style="width: 130px">گروه</th>
						<th style="width: 110px">دوره</th>
						<th>عنوان</th>
						<th style="width: 150px">منبع</th>
						<th style="width: 90px">وضعیت</th>
						<th style="width: 170px">اقدام</th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! $result['rows'] ) : ?>
					<tr><td colspan="7">پیامی پیدا نشد. کتابخانه را بارگذاری کن.</td></tr>
				<?php endif; ?>
				<?php foreach ( $result['rows'] as $row ) : ?>
					<tr>
						<td><?php echo esc_html( number_format_i18n( (int) $row['id'] ) ); ?></td>
						<td><?php echo esc_html( $labels[ $row['audience'] ] ?? $row['audience'] ); ?></td>
						<td>
							<?php
							if ( null !== $row['week'] && '' !== $row['week'] ) {
								echo 'هفته ' . esc_html( number_format_i18n( (int) $row['week'] ) );
							} elseif ( null !== $row['month'] && '' !== $row['month'] ) {
								echo 'ماه ' . esc_html( number_format_i18n( (int) $row['month'] ) );
							} else {
								echo esc_html( (string) $row['phase'] );
							}
							?>
						</td>
						<td>
							<strong><?php echo esc_html( $row['title'] ); ?></strong><br />
							<span class="description"><?php echo esc_html( mb_strimwidth( wp_strip_all_tags( (string) $row['body'] ), 0, 120, '…' ) ); ?></span>
						</td>
						<td>
							<?php if ( $row['source_url'] ) : ?>
								<a href="<?php echo esc_url( $row['source_url'] ); ?>" target="_blank" rel="noopener"><?php echo esc_html( $row['source_name'] ); ?></a>
							<?php endif; ?>
						</td>
						<td><?php echo $row['active'] ? 'فعال' : 'خاموش'; ?></td>
						<td style="display: flex; gap: 6px">
							<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-messages&edit=' . (int) $row['id'] ) ); ?>">ویرایش</a>
							<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
								<?php wp_nonce_field( 'dr_niva_messages' ); ?>
								<input type="hidden" name="action" value="dr_niva_messages" />
								<input type="hidden" name="do" value="delete" />
								<input type="hidden" name="id" value="<?php echo esc_attr( (int) $row['id'] ); ?>" />
								<button class="button button-small" data-niva-confirm="این پیام حذف شود؟">حذف</button>
							</form>
						</td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $result['pages'] > 1 ) : ?>
				<div class="tablenav"><div class="tablenav-pages">
					<?php
					echo paginate_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						array(
							'base'    => add_query_arg( 'paged', '%#%' ),
							'format'  => '',
							'current' => $page,
							'total'   => $result['pages'],
						)
					);
					?>
				</div></div>
			<?php endif; ?>
		</div>
		<?php
	}

	private function edit_form( int $id ) : void {
		global $wpdb;
		$row = $id ? $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'messages' ) . ' WHERE id = %d', $id ), ARRAY_A ) : null; // phpcs:ignore WordPress.DB
		$row     = $row ? $row : array( 'id' => 0, 'audience' => 'pregnancy', 'week' => 4, 'month' => '', 'phase' => '', 'day_index' => 0, 'title' => '', 'body' => '', 'action' => '', 'source_name' => '', 'source_url' => '', 'active' => 1 );
		$labels  = Niva_Messages::audiences();
		?>
		<div class="wrap niva-admin">
			<?php $this->header( $id ? 'ویرایش پیام' : 'پیام تازه' ); ?>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="niva-panel">
				<?php wp_nonce_field( 'dr_niva_messages' ); ?>
				<input type="hidden" name="action" value="dr_niva_messages" />
				<input type="hidden" name="do" value="save" />
				<input type="hidden" name="id" value="<?php echo esc_attr( (int) $row['id'] ); ?>" />

				<table class="form-table">
					<tr>
						<th>گروه مخاطب</th>
						<td>
							<select name="audience">
								<?php foreach ( $labels as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $row['audience'], $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
						</td>
					</tr>
					<tr>
						<th>هفته‌ی بارداری / ماه نوزاد / فاز چرخه</th>
						<td style="display: flex; gap: 8px">
							<input type="number" name="week" value="<?php echo esc_attr( (string) $row['week'] ); ?>" placeholder="هفته (۴ تا ۴۱)" style="width: 130px" />
							<input type="number" name="month" value="<?php echo esc_attr( (string) $row['month'] ); ?>" placeholder="ماه (۰ تا ۱۲)" style="width: 130px" />
							<select name="phase">
								<option value="">— فاز چرخه —</option>
								<?php foreach ( array( 'period' => 'روزهای پریود', 'fertile' => 'پنجره‌ی باروری', 'luteal' => 'پیش از پریود', 'irregular' => 'نامنظم و هشدار' ) as $key => $label ) : ?>
									<option value="<?php echo esc_attr( $key ); ?>" <?php selected( (string) $row['phase'], $key ); ?>><?php echo esc_html( $label ); ?></option>
								<?php endforeach; ?>
							</select>
							<input type="number" name="day_index" value="<?php echo esc_attr( (int) $row['day_index'] ); ?>" placeholder="ترتیب روز" style="width: 110px" />
						</td>
					</tr>
					<tr><th>عنوان</th><td><input type="text" class="regular-text" name="title" value="<?php echo esc_attr( $row['title'] ); ?>" required /></td></tr>
					<tr><th>متن پیام</th><td><textarea name="body" rows="5" class="large-text"><?php echo esc_textarea( (string) $row['body'] ); ?></textarea></td></tr>
					<tr><th>کار پیشنهادی</th><td><input type="text" class="regular-text" name="action_text" value="<?php echo esc_attr( $row['action'] ); ?>" /></td></tr>
					<tr><th>نام منبع</th><td><input type="text" class="regular-text" name="source_name" value="<?php echo esc_attr( $row['source_name'] ); ?>" placeholder="مثلاً NHS — هفته ۱۲ بارداری" /></td></tr>
					<tr><th>نشانی منبع</th><td><input type="url" class="regular-text" dir="ltr" name="source_url" value="<?php echo esc_attr( $row['source_url'] ); ?>" /></td></tr>
					<tr><th>فعال باشد</th><td><input type="checkbox" name="active" value="1" <?php checked( 1, (int) $row['active'] ); ?> /></td></tr>
				</table>

				<?php submit_button( $id ? 'ذخیره‌ی تغییرات' : 'افزودن پیام' ); ?>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-messages' ) ); ?>">بازگشت</a>
			</form>
			<p class="description">اگر برای یک هفته دو پیام بگذاری، هر روز یکی از آن‌ها به کاربر نشان داده می‌شود و روز بعدی پیام بعدی — پس محتوا هر ۲۴ ساعت عوض می‌شود.</p>
		</div>
		<?php
	}

	private function header( string $screen, int $total = 0 ) : void {
		?>
		<div class="niva-header">
			<span class="niva-header__mark"><?php echo Niva_Icons::svg( 'book-open', 24 ); ?></span>
			<span class="niva-header__text">
				<span class="niva-header__title"><?php echo esc_html( $screen ); ?></span>
				<span class="niva-header__sub">
					<?php echo esc_html( number_format_i18n( $total ) ); ?> پیام در سایت ·
					کتابخانه‌ی همراه: ۱۱۰ پیام با منبع رسمی
				</span>
			</span>
			<span class="niva-header__actions">
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-health' ) ); ?>">بررسی سلامت</a>
			</span>
		</div>
		<?php
	}
}
