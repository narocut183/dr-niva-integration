<?php
/**
 * Back office for everything the users produce.
 *
 * One screen per entity with search, user filter, date range, pagination,
 * CSV export, detail view, delete and (for credits) a manual adjustment.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Data {

	/** @var Niva_Settings */
	private $settings;

	/** @var Niva_Wallet */
	private $wallet;

	public function __construct( Niva_Settings $settings, Niva_Wallet $wallet ) {
		$this->settings = $settings;
		$this->wallet   = $wallet;

		// Registered as a hidden screen by Niva_Admin (linked from «کاربران» and
		// «ابزارهای تشخیصی»), so the sidebar stays a single 13-item shell.
		add_action( 'admin_post_dr_niva_data_delete', array( $this, 'handle_delete' ) );
		add_action( 'admin_post_dr_niva_data_export', array( $this, 'handle_export' ) );
		add_action( 'admin_post_dr_niva_data_credit', array( $this, 'handle_credit' ) );
		add_action( 'admin_post_dr_niva_notify', array( $this, 'handle_notify' ) );
	}

	public function menu() : void {
		add_submenu_page( 'dr-niva', 'داده‌های کاربران', 'داده‌های کاربران', 'manage_options', 'dr-niva-data', array( $this, 'page' ) );
	}

	/** Every entity the back office can browse. */
	public function entities() : array {
		return array(
			'users'         => array(
				'label'   => 'همه‌ی کاربران و دسترسی‌ها',
				'columns' => array(
					'user'       => 'کاربر',
					'email'      => 'ایمیل',
					'phone'      => 'تلفن',
					'role'       => 'نقش وردپرس',
					'plan'       => 'اشتراک',
					'plan_expires' => 'پایان اشتراک',
					'balance'    => 'اعتبار',
					'spent'      => 'مصرف کل',
					'quota'      => 'مصرف سهمیه امروز',
					'ai_calls'   => 'درخواست هوش مصنوعی',
					'last_active' => 'آخرین فعالیت',
					'profile'    => 'وضعیت پرونده',
					'registered' => 'عضویت',
				),
			),
			'chats'         => array(
				'label'   => 'گفت‌وگوهای مشاور',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'topic' => 'موضوع', 'title' => 'شروع‌کننده', 'provider' => 'موتور', 'updated_at' => 'آخرین پیام' ),
			),
			'documents'     => array(
				'label'   => 'تحلیل‌های آزمایش',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'title' => 'عنوان', 'kind' => 'نوع', 'status' => 'وضعیت', 'created_at' => 'تاریخ' ),
			),
			'growth'        => array(
				'label'   => 'رشد نوزاد',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'name' => 'نام کودک', 'measured_on' => 'تاریخ اندازه‌گیری', 'age_months' => 'سن (ماه)', 'weight' => 'وزن', 'height' => 'قد', 'head' => 'دور سر' ),
			),
			'reminders'     => array(
				'label'   => 'یادآورها',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'title' => 'یادآور', 'time_at' => 'ساعت', 'repeat_rule' => 'تکرار', 'done' => 'وضعیت' ),
			),
			'logs'          => array(
				'label'   => 'اقدامات روزانه',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'log_date' => 'تاریخ', 'kind' => 'نوع', 'value' => 'مقدار', 'note' => 'یادداشت' ),
			),
			'ledger'        => array(
				'label'   => 'دفتر اعتبار',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'delta' => 'تغییر', 'reason' => 'دلیل', 'balance_after' => 'موجودی بعد', 'created_at' => 'تاریخ' ),
			),
			'usage'         => array(
				'label'   => 'مصرف هوش مصنوعی',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'kind' => 'نوع', 'provider' => 'موتور', 'cost' => 'هزینه', 'created_at' => 'تاریخ' ),
			),
			'reviews'       => array(
				'label'   => 'صف بازبینی پزشک',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'reason' => 'دلیل', 'status' => 'وضعیت', 'created_at' => 'تاریخ' ),
			),
			'notifications' => array(
				'label'   => 'اعلان‌ها',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'title' => 'عنوان', 'body' => 'متن', 'is_read' => 'خوانده‌شده', 'created_at' => 'تاریخ' ),
			),
			'push_subs'     => array(
				'label'   => 'دستگاه‌های ثبت‌شده برای پوش',
				'columns' => array( 'id' => 'کد', 'user' => 'کاربر', 'device' => 'دستگاه', 'created_at' => 'تاریخ', 'last_seen' => 'آخرین بازدید' ),
			),
		);
	}

	private function table_for( string $entity ) : string {
		return Niva_DB::table( 'users' === $entity ? 'wallets' : $entity );
	}

	/** Builds the WHERE clause from the filter bar. */
	private function where( string $entity, array $filters, array &$params ) : string {
		global $wpdb;
		$bits = array();

		if ( 'users' === $entity ) {
			if ( $filters['user'] ) {
				$bits[]   = 'u.ID = %d';
				$params[] = (int) $filters['user'];
			}
			if ( $filters['status'] ) {
				$bits[] = 'low' === $filters['status'] ? 'COALESCE(w.balance, 0) < 1' : 'COALESCE(w.balance, 0) >= 1';
			}
			if ( $filters['search'] ) {
				$like     = '%' . $wpdb->esc_like( $filters['search'] ) . '%';
				$bits[]   = '(u.display_name LIKE %s OR u.user_login LIKE %s OR u.user_email LIKE %s)';
				$params[] = $like;
				$params[] = $like;
				$params[] = $like;
			}
			return $bits ? 'WHERE ' . implode( ' AND ', $bits ) : '';
		}

		if ( $filters['user'] ) {
			$bits[]   = 'user_id = %d';
			$params[] = (int) $filters['user'];
		}
		if ( $filters['from'] ) {
			$column   = in_array( $entity, array( 'growth', 'logs' ), true ) ? ( 'growth' === $entity ? 'measured_on' : 'log_date' ) : 'created_at';
			$bits[]   = $column . ' >= %s';
			$params[] = $filters['from'] . ' 00:00:00';
		}
		if ( $filters['to'] ) {
			$column   = in_array( $entity, array( 'growth', 'logs' ), true ) ? ( 'growth' === $entity ? 'measured_on' : 'log_date' ) : 'created_at';
			$bits[]   = $column . ' <= %s';
			$params[] = $filters['to'] . ' 23:59:59';
		}
		if ( $filters['search'] ) {
			$like     = '%' . $wpdb->esc_like( $filters['search'] ) . '%';
			switch ( $entity ) {
				case 'chats':
					$bits[] = '(title LIKE %s OR topic LIKE %s)';
					$params[] = $like;
					$params[] = $like;
					break;
				case 'documents':
					$bits[] = 'title LIKE %s';
					$params[] = $like;
					break;
				case 'growth':
					$bits[] = 'name LIKE %s';
					$params[] = $like;
					break;
				case 'reminders':
					$bits[] = 'title LIKE %s';
					$params[] = $like;
					break;
				case 'notifications':
					$bits[] = '(title LIKE %s OR body LIKE %s)';
					$params[] = $like;
					$params[] = $like;
					break;
				default:
					break;
			}
		}
		return $bits ? 'WHERE ' . implode( ' AND ', $bits ) : '';
	}

	private function filters() : array {
		return array(
			'entity' => isset( $_GET['entity'] ) ? sanitize_key( wp_unslash( $_GET['entity'] ) ) : 'users', // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			'user'   => isset( $_GET['user'] ) ? absint( $_GET['user'] ) : 0, // phpcs:ignore
			'from'   => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '', // phpcs:ignore
			'to'     => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '', // phpcs:ignore
			'search' => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '', // phpcs:ignore
			'status' => isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : '', // phpcs:ignore
			'paged'  => isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1, // phpcs:ignore
		);
	}

	/* ---------------------------------------------------------------- screen */

	public function page() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}

		$entities = $this->entities();
		$filters  = $this->filters();
		$entity   = isset( $entities[ $filters['entity'] ] ) ? $filters['entity'] : 'users';

		if ( isset( $_GET['id'], $_GET['entity'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			if ( 'users' === $entity ) {
				$this->user_detail( absint( $_GET['id'] ) ); // phpcs:ignore
			} else {
				$this->detail( $entity, absint( $_GET['id'] ) ); // phpcs:ignore
			}
			return;
		}

		global $wpdb;
		$per_page = 25;
		$params   = array();
		$where    = $this->where( $entity, $filters, $params );
		$table    = $this->table_for( $entity );
		$offset   = ( $filters['paged'] - 1 ) * $per_page;

		if ( 'users' === $entity ) {
			$usage_table = Niva_DB::table( 'usage' );
			$sql = "SELECT u.ID AS user_id, u.display_name, u.user_login, u.user_email, u.user_registered,
				COALESCE(w.balance, 0) AS balance, COALESCE(w.spent_total, 0) AS spent,
				COALESCE(w.quota_used, 0) AS quota_used, COALESCE(ua.ai_calls, 0) AS ai_calls,
				ua.last_active
				FROM {$wpdb->users} u
				LEFT JOIN {$table} w ON w.user_id = u.ID
				LEFT JOIN (
					SELECT user_id, COUNT(*) AS ai_calls, MAX(created_at) AS last_active
					FROM {$usage_table} GROUP BY user_id
				) ua ON ua.user_id = u.ID
				{$where} ORDER BY u.user_registered DESC LIMIT %d OFFSET %d";
		} else {
			$order_column = in_array( $entity, array( 'growth', 'logs' ), true ) ? ( 'growth' === $entity ? 'measured_on' : 'log_date' ) : ( 'reminders' === $entity ? 'id' : 'created_at' );
			$sql          = "SELECT * FROM {$table} {$where} ORDER BY {$order_column} DESC LIMIT %d OFFSET %d";
		}
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( $sql, array_merge( $params, array( $per_page, $offset ) ) ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		$data_query_error = $wpdb->last_error;

		$count_sql = 'users' === $entity
			? "SELECT COUNT(*) FROM {$wpdb->users} u LEFT JOIN {$table} w ON w.user_id = u.ID {$where}"
			: "SELECT COUNT(*) FROM {$table} {$where}";
		$total = (int) ( $params
			? $wpdb->get_var( $wpdb->prepare( $count_sql, $params ) ) // phpcs:ignore WordPress.DB
			: $wpdb->get_var( $count_sql ) ); // phpcs:ignore WordPress.DB
		$count_query_error = $wpdb->last_error;
		$query_errors      = array_filter( array( $data_query_error, $count_query_error ) );

		$pending_reviews = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'reviews' ) . " WHERE status = 'pending'" ); // phpcs:ignore WordPress.DB
		$push_devices    = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'push_subs' ) ); // phpcs:ignore WordPress.DB
		?>
		<div class="wrap niva-admin">
			<h1>داده‌های کاربران</h1>

			<?php if ( $query_errors ) : ?>
				<div class="notice notice-error"><p>خواندن داده‌ها از پایگاه داده ناموفق بود: <?php echo esc_html( implode( ' | ', array_unique( $query_errors ) ) ); ?></p></div>
			<?php endif; ?>
			<?php if ( $pending_reviews ) : ?>
				<div class="notice notice-warning"><p><?php echo esc_html( number_format_i18n( $pending_reviews ) ); ?> پاسخ در صف بازبینی پزشک است.</p></div>
			<?php endif; ?>

			<h2 class="nav-tab-wrapper">
				<?php foreach ( $entities as $key => $def ) : ?>
					<a class="nav-tab <?php echo $key === $entity ? 'nav-tab-active' : ''; ?>" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=' . $key ) ); ?>">
						<?php echo esc_html( $def['label'] ); ?>
					</a>
				<?php endforeach; ?>
			</h2>

			<form method="get" style="margin: 12px 0; display: flex; gap: 8px; flex-wrap: wrap; align-items: center">
				<input type="hidden" name="page" value="dr-niva-data" />
				<input type="hidden" name="entity" value="<?php echo esc_attr( $entity ); ?>" />
				<input type="search" name="s" value="<?php echo esc_attr( $filters['search'] ); ?>" placeholder="جست‌وجو…" />
				<input type="number" name="user" value="<?php echo $filters['user'] ? esc_attr( $filters['user'] ) : ''; ?>" placeholder="شناسه کاربر" style="width: 120px" />
				<label>از <input type="date" name="from" value="<?php echo esc_attr( $filters['from'] ); ?>" /></label>
				<label>تا <input type="date" name="to" value="<?php echo esc_attr( $filters['to'] ); ?>" /></label>
				<?php submit_button( 'فیلتر', 'secondary', '', false ); ?>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=' . $entity ) ); ?>">پاک‌کردن</a>
				<?php
				$export = wp_nonce_url(
					admin_url( 'admin-post.php?action=dr_niva_data_export&entity=' . $entity . '&user=' . $filters['user'] . '&from=' . $filters['from'] . '&to=' . $filters['to'] . '&s=' . urlencode( $filters['search'] ) ),
					'dr_niva_data_export'
				);
				?>
				<a class="button button-primary" href="<?php echo esc_url( $export ); ?>">خروجی CSV</a>
			</form>

			<p class="description">
				<?php echo esc_html( number_format_i18n( $total ) ); ?> رکورد · دستگاهای پوش ثبت‌شده: <?php echo esc_html( number_format_i18n( $push_devices ) ); ?>
			</p>

			<table class="widefat striped">
				<thead>
					<tr>
						<?php foreach ( $entities[ $entity ]['columns'] as $label ) : ?>
							<th><?php echo esc_html( $label ); ?></th>
						<?php endforeach; ?>
						<th style="width: 180px">اقدام</th>
					</tr>
				</thead>
				<tbody>
				<?php if ( ! $rows ) : ?>
					<tr><td colspan="<?php echo count( $entities[ $entity ]['columns'] ) + 1; ?>">رکوردی با این فیلترها پیدا نشد.</td></tr>
				<?php else : ?>
					<?php foreach ( $rows as $row ) : ?>
						<?php
						$user_id   = (int) $row['user_id'];
						$user_plan = 'users' === $entity && dr_niva()->plans ? dr_niva()->plans->plan_of( $user_id ) : array();
						$user_profile = 'users' === $entity && dr_niva()->profile ? dr_niva()->profile->get( $user_id ) : array();
						$profile_bits = array();
						if ( ! empty( $user_profile['sex'] ) ) {
							$profile_bits[] = array( 'female' => 'بانوان', 'male' => 'آقایان', 'other' => 'سایر' )[ $user_profile['sex'] ] ?? '';
						}
						if ( ! empty( $user_profile['pregnant'] ) ) {
							$pregnancy_week = dr_niva()->profile->pregnancy_week( $user_id );
							$profile_bits[] = $pregnancy_week ? 'بارداری، هفته ' . number_format_i18n( $pregnancy_week ) : 'بارداری ثبت شده';
						}
						if ( ! empty( $user_profile['baby_birth'] ) ) {
							$profile_bits[] = 'پروندهٔ کودک';
						}
						?>
						<tr>
							<?php foreach ( array_keys( $entities[ $entity ]['columns'] ) as $column ) : ?>
								<td>
									<?php
									if ( 'user' === $column ) {
										$name = isset( $row['display_name'] ) ? $row['display_name'] : '';
										if ( ! $name ) {
											$u    = get_userdata( (int) $row['user_id'] );
											$name = $u ? $u->display_name . ' (' . $u->user_email . ')' : '#' . (int) $row['user_id'];
										}
										echo esc_html( $name . ' · ' . ( $row['user_login'] ?? '' ) );
									} elseif ( 'role' === $column ) {
										$user_data = get_userdata( $user_id );
										$roles = $user_data ? array_map( 'translate_user_role', $user_data->roles ) : array();
										echo esc_html( $roles ? implode( '، ', $roles ) : 'بدون نقش' );
									} elseif ( 'plan' === $column ) {
										echo esc_html( $user_plan['label'] ?? 'رایگان' );
									} elseif ( 'plan_expires' === $column ) {
										echo ! empty( $user_plan['expires'] )
											? esc_html( Niva_Chrome::format_datetime_gmt( (string) $user_plan['expires'] ) )
											: '—';
									} elseif ( 'quota' === $column ) {
										$limit = (int) $this->settings->get( 'free_daily_quota' );
										echo esc_html( number_format_i18n( (int) $row['quota_used'] ) . ' / ' . ( $limit > 0 ? number_format_i18n( $limit ) : 'نامحدود' ) );
									} elseif ( 'ai_calls' === $column ) {
										echo esc_html( number_format_i18n( (int) $row['ai_calls'] ) );
									} elseif ( 'last_active' === $column ) {
										echo ! empty( $row['last_active'] )
											? esc_html( Niva_Chrome::format_datetime( (string) $row['last_active'] ) )
											: '—';
									} elseif ( 'profile' === $column ) {
										echo esc_html( implode( '، ', array_filter( $profile_bits ) ) ?: 'پرونده هنوز تکمیل نشده' );
									} elseif ( 'registered' === $column ) {
										echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['user_registered'] ) );
									} elseif ( 'email' === $column ) {
										echo esc_html( (string) $row['user_email'] );
									} elseif ( 'phone' === $column ) {
										$phone = get_user_meta( $user_id, 'billing_phone', true );
										echo esc_html( (string) ( $phone ?: get_user_meta( $user_id, 'phone', true ) ) ?: '—' );
									} elseif ( 'done' === $column ) {
										echo $row['done'] ? '<span class="badge">انجام شد</span>' : '<span class="badge">باز</span>';
									} elseif ( 'is_read' === $column ) {
										echo $row['is_read'] ? 'بله' : '—';
									} elseif ( in_array( $column, array( 'measured_on', 'log_date' ), true ) ) {
										$date = isset( $row[ $column ] ) ? Niva_Chrome::format_date( (string) $row[ $column ] ) : '';
										echo esc_html( $date ?: '—' );
									} elseif ( in_array( $column, array( 'created_at', 'updated_at' ), true ) ) {
										$date = isset( $row[ $column ] ) ? Niva_Chrome::format_datetime( (string) $row[ $column ] ) : '';
										echo esc_html( $date ?: '—' );
									} else {
										$value = isset( $row[ $column ] ) ? (string) $row[ $column ] : '';
										echo esc_html( mb_strimwidth( $value, 0, 80, '…' ) );
									}
									?>
								</td>
							<?php endforeach; ?>
							<td>
								<?php if ( 'users' === $entity ) : ?>
									<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=users&id=' . $user_id ) ); ?>">پروندهٔ اپ</a>
									<a class="button button-small" href="<?php echo esc_url( get_edit_user_link( (int) $row['user_id'] ) ); ?>">پروفایل کاربر</a>
									<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=ledger&user=' . (int) $row['user_id'] ) ); ?>">تراکنش‌ها</a>
								<?php else : ?>
									<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=' . $entity . '&id=' . (int) $row['id'] ) ); ?>">مشاهده</a>
									<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( admin_url( 'admin-post.php?action=dr_niva_data_delete&entity=' . $entity . '&id=' . (int) $row['id'] ), 'dr_niva_data_delete' ) ); ?>"
										onclick="return confirm('این رکورد برای همیشه حذف شود؟')">حذف</a>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php endif; ?>
				</tbody>
			</table>

			<?php
			$pages = (int) ceil( $total / $per_page );
			if ( $pages > 1 ) :
				?>
				<div class="tablenav"><div class="tablenav-pages">
					<?php
					echo paginate_links( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
						array(
							'base'    => add_query_arg( 'paged', '%#%' ),
							'format'  => '',
							'current' => $filters['paged'],
							'total'   => $pages,
						)
					);
					?>
				</div></div>
			<?php endif; ?>

			<?php $this->credit_tools(); ?>
			<?php $this->notify_tools(); ?>
		</div>
		<?php
	}

	/** Manual credit adjustment + a broadcast form. */
	private function credit_tools() : void {
		?>
		<hr />
		<h2>تنظیم دستی اعتبار</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center">
			<?php wp_nonce_field( 'dr_niva_data_credit' ); ?>
			<input type="hidden" name="action" value="dr_niva_data_credit" />
			<input type="number" name="user_id" placeholder="شناسه کاربر" required />
			<input type="number" name="amount" placeholder="مثلاً 100 یا -50" required />
			<input type="text" name="reason" placeholder="دلیل (برای دفتر اعتبار)" value="پشتیبانی" />
			<?php submit_button( 'اعمال', 'primary', '', false ); ?>
		</form>
		<?php
	}

	private function notify_tools() : void {
		?>
		<hr />
		<h2>ارسال اعلان</h2>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="display: flex; gap: 8px; flex-wrap: wrap; align-items: center">
			<?php wp_nonce_field( 'dr_niva_notify' ); ?>
			<input type="hidden" name="action" value="dr_niva_notify" />
			<input type="text" name="title" placeholder="عنوان" required style="min-width: 220px" />
			<input type="text" name="body" placeholder="متن کوتاه" required style="min-width: 320px" />
			<select name="audience">
				<option value="all">همه کاربران</option>
				<option value="subscribers">فقط دستگاه‌های ثبت‌شده برای پوش</option>
			</select>
			<?php submit_button( 'ارسال', 'primary', '', false ); ?>
		</form>
		<p class="description">اعلان در صندوق داخل برنامه‌ی کاربر ذخیره می‌شود؛ پوش و ایمیل هم اگر فعال باشند ارسال می‌شوند.</p>
		<?php
	}

	/** Full account snapshot from WordPress and the plugin's live data stores. */
	private function user_detail( int $user_id ) : void {
		global $wpdb;
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			echo '<div class="wrap niva-admin"><p>کاربر پیدا نشد.</p></div>';
			return;
		}

		$profile = dr_niva()->profile ? dr_niva()->profile->get( $user_id ) : array();
		$wallet  = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'wallets' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		$plan    = dr_niva()->plans ? dr_niva()->plans->plan_of( $user_id ) : array();
		$usage   = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'SELECT kind, provider, cost, created_at FROM ' . Niva_DB::table( 'usage' ) . ' WHERE user_id = %d ORDER BY id DESC LIMIT 20', $user_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		$reminders = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'SELECT title, time_at, repeat_rule, done FROM ' . Niva_DB::table( 'reminders' ) . ' WHERE user_id = %d ORDER BY id DESC LIMIT 20', $user_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		$user_entities = array(
			'chats'         => 'گفت‌وگوها',
			'documents'     => 'آزمایش‌ها و اسناد',
			'growth'        => 'اندازه‌های رشد',
			'logs'          => 'اقدامات روزانه',
			'ledger'        => 'تراکنش‌ها',
			'notifications' => 'اعلان‌ها',
		);
		$user_entity_counts = array();
		foreach ( $user_entities as $key => $label ) {
			$user_entity_counts[ $key ] = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $this->table_for( $key ) . ' WHERE user_id = %d', $user_id ) ); // phpcs:ignore WordPress.DB
		}
		$roles = array_map( 'translate_user_role', $user->roles );
		$sexes = array( 'female' => 'بانوان', 'male' => 'آقایان', 'other' => 'سایر' );
		$profile_rows = array(
			'نام نمایشی پرونده' => $profile['display_name'] ?? '',
			'جنسیت' => $sexes[ $profile['sex'] ?? '' ] ?? 'ثبت نشده',
			'سال تولد شمسی' => $profile['birth_year'] ?? '',
			'قد' => ! empty( $profile['height'] ) ? $profile['height'] . ' سانتی‌متر' : '',
			'وزن' => ! empty( $profile['weight'] ) ? $profile['weight'] . ' کیلوگرم' : '',
			'وضعیت بارداری' => ! empty( $profile['pregnant'] ) ? 'ثبت شده' : 'ثبت نشده',
			'تاریخ آخرین قاعدگی' => $profile['lmp'] ?? '',
			'تاریخ زایمان' => $profile['due_date'] ?? '',
			'طول چرخه' => ! empty( $profile['cycle_length'] ) ? $profile['cycle_length'] . ' روز' : '',
			'نام کودک' => $profile['baby_name'] ?? '',
			'تولد کودک' => $profile['baby_birth'] ?? '',
		);
		?>
		<div class="wrap niva-admin niva-user-detail">
			<h1>پروندهٔ دکتر نیوا — <?php echo esc_html( $user->display_name ); ?></h1>
			<p class="niva-user-detail__actions">
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=users' ) ); ?>">بازگشت به کاربران</a>
				<a class="button" href="<?php echo esc_url( get_edit_user_link( $user_id ) ); ?>">ویرایش کاربر وردپرس</a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=ledger&user=' . $user_id ) ); ?>">دفتر اعتبار</a>
			</p>
			<p class="description">این صفحه داده‌های زندهٔ حساب وردپرس و افزونه را نشان می‌دهد؛ اطلاعات پروندهٔ سلامت فقط برای مدیران مجاز نمایش داده می‌شود.</p>
			<nav class="niva-user-detail__records" aria-label="داده‌های کاربر در افزونه">
				<?php foreach ( $user_entities as $key => $label ) : ?>
					<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=' . $key . '&user=' . $user_id ) ); ?>"><?php echo esc_html( $label ); ?> <b><?php echo esc_html( number_format_i18n( $user_entity_counts[ $key ] ) ); ?></b></a>
				<?php endforeach; ?>
			</nav>
			<div class="niva-user-detail__grid">
				<section class="niva-panel">
					<h2>حساب وردپرس</h2>
					<table class="widefat striped"><tbody>
						<tr><th>شناسه</th><td><?php echo esc_html( (string) $user_id ); ?></td></tr>
						<tr><th>نام کاربری</th><td><?php echo esc_html( $user->user_login ); ?></td></tr>
						<tr><th>ایمیل</th><td><?php echo esc_html( $user->user_email ); ?></td></tr>
						<tr><th>تلفن</th><td><?php echo esc_html( (string) ( get_user_meta( $user_id, 'billing_phone', true ) ?: get_user_meta( $user_id, 'phone', true ) ?: 'ثبت نشده' ) ); ?></td></tr>
						<tr><th>نقش</th><td><?php echo esc_html( $roles ? implode( '، ', $roles ) : 'بدون نقش' ); ?></td></tr>
						<tr><th>عضویت</th><td><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $user->user_registered ) ); ?></td></tr>
					</tbody></table>
				</section>
				<section class="niva-panel">
					<h2>اشتراک و اعتبار</h2>
					<table class="widefat striped"><tbody>
						<tr><th>پلن</th><td><?php echo esc_html( $plan['label'] ?? 'رایگان' ); ?></td></tr>
						<tr><th>وضعیت اشتراک</th><td><?php echo ! empty( $plan['active'] ) ? 'فعال' : 'رایگان / غیرفعال'; ?></td></tr>
						<tr><th>پایان اشتراک</th><td><?php echo ! empty( $plan['expires'] ) ? esc_html( Niva_Chrome::format_datetime_gmt( (string) $plan['expires'] ) ) : '—'; ?></td></tr>
						<tr><th>موجودی</th><td><?php echo esc_html( number_format_i18n( (int) ( $wallet['balance'] ?? 0 ) ) ); ?></td></tr>
						<tr><th>مصرف کل</th><td><?php echo esc_html( number_format_i18n( (int) ( $wallet['spent_total'] ?? 0 ) ) ); ?></td></tr>
						<tr><th>مصرف سهمیهٔ امروز</th><td><?php echo esc_html( number_format_i18n( (int) ( $wallet['quota_used'] ?? 0 ) ) ); ?></td></tr>
					</tbody></table>
				</section>
				<section class="niva-panel">
					<h2>پروندهٔ سلامت</h2>
					<table class="widefat striped"><tbody>
						<?php foreach ( $profile_rows as $label => $value ) : ?>
							<tr><th><?php echo esc_html( $label ); ?></th><td><?php echo esc_html( '' !== (string) $value ? (string) $value : 'ثبت نشده' ); ?></td></tr>
						<?php endforeach; ?>
					</tbody></table>
				</section>
			</div>
			<section class="niva-panel">
				<h2>آخرین درخواست‌های هوش مصنوعی</h2>
				<table class="widefat striped"><thead><tr><th>نوع</th><th>موتور</th><th>اعتبار</th><th>تاریخ</th></tr></thead><tbody>
					<?php if ( $usage ) : foreach ( $usage as $entry ) : ?>
						<tr><td><?php echo esc_html( (string) $entry['kind'] ); ?></td><td><?php echo esc_html( (string) $entry['provider'] ); ?></td><td><?php echo esc_html( number_format_i18n( (int) $entry['cost'] ) ); ?></td><td><?php echo esc_html( Niva_Chrome::format_datetime( (string) $entry['created_at'] ) ); ?></td></tr>
					<?php endforeach; else : ?>
						<tr><td colspan="4">هنوز درخواستی ثبت نشده است.</td></tr>
					<?php endif; ?>
				</tbody></table>
			</section>
			<section class="niva-panel">
				<h2>یادآورها</h2>
				<table class="widefat striped"><thead><tr><th>عنوان</th><th>ساعت</th><th>تکرار</th><th>وضعیت</th></tr></thead><tbody>
					<?php if ( $reminders ) : foreach ( $reminders as $reminder ) : ?>
						<tr><td><?php echo esc_html( $reminder['title'] ); ?></td><td><?php echo esc_html( $reminder['time_at'] ); ?></td><td><?php echo esc_html( $reminder['repeat_rule'] ); ?></td><td><?php echo ! empty( $reminder['done'] ) ? 'انجام شده' : 'فعال'; ?></td></tr>
					<?php endforeach; else : ?>
						<tr><td colspan="4">یادآوری ثبت نشده است.</td></tr>
					<?php endif; ?>
				</tbody></table>
			</section>
		</div>
		<?php
	}

	/** Full record, including the chat transcript when there is one. */
	private function detail( string $entity, int $id ) : void {
		global $wpdb;
		$table = $this->table_for( $entity );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $row ) {
			echo '<div class="wrap"><p>رکورد پیدا نشد.</p></div>';
			return;
		}
		$user = get_userdata( (int) $row['user_id'] );
		?>
		<div class="wrap niva-admin">
			<h1>جزئیات رکورد #<?php echo esc_html( $id ); ?></h1>
			<p><a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=' . $entity ) ); ?>">بازگشت به فهرست</a></p>
			<p>کاربر: <strong><?php echo esc_html( $user ? $user->display_name . ' — ' . $user->user_email : '#' . (int) $row['user_id'] ); ?></strong></p>

			<table class="widefat striped" style="max-width: 900px">
				<tbody>
				<?php foreach ( $row as $key => $value ) : ?>
					<tr>
						<th style="width: 220px"><?php echo esc_html( $key ); ?></th>
						<td><textarea readonly rows="<?php echo min( 12, max( 2, (int) ( strlen( (string) $value ) / 80 ) ) ); ?>" style="width: 100%"><?php echo esc_textarea( (string) $value ); ?></textarea></td>
					</tr>
				<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( 'chats' === $entity ) : ?>
				<h2>متن گفت‌وگو</h2>
				<table class="widefat striped" style="max-width: 900px">
					<thead><tr><th style="width: 120px">نقش</th><th>متن</th><th style="width: 140px">زمان</th></tr></thead>
					<tbody>
					<?php
					$messages = $wpdb->get_results( // phpcs:ignore WordPress.DB
						$wpdb->prepare( 'SELECT role, content, created_at FROM ' . Niva_DB::table( 'chat_messages' ) . ' WHERE chat_id = %d ORDER BY id ASC', $id ), // phpcs:ignore WordPress.DB
						ARRAY_A
					);
					foreach ( (array) $messages as $message ) :
						?>
						<tr>
							<td><?php echo 'user' === $message['role'] ? 'کاربر' : 'مشاور'; ?></td>
							<td><?php echo nl2br( esc_html( (string) $message['content'] ) ); ?></td>
							<td><?php echo esc_html( Niva_Chrome::format_datetime( (string) $message['created_at'] ) ); ?></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
		<?php
	}

	/* --------------------------------------------------------------- actions */

	public function handle_delete() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_data_delete' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		global $wpdb;
		$entity = isset( $_GET['entity'] ) ? sanitize_key( wp_unslash( $_GET['entity'] ) ) : '';
		$id     = isset( $_GET['id'] ) ? absint( $_GET['id'] ) : 0;
		if ( $id && array_key_exists( $entity, $this->entities() ) ) {
			$wpdb->delete( $this->table_for( $entity ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB
			if ( 'chats' === $entity ) {
				$wpdb->delete( Niva_DB::table( 'chat_messages' ), array( 'chat_id' => $id ) ); // phpcs:ignore WordPress.DB
			}
		}
		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-data&entity=' . $entity . '&deleted=1' ) );
		exit;
	}

	public function handle_credits( int $user_id, int $amount, string $reason ) : void {
		if ( ! $user_id || ! $amount ) {
			return;
		}
		if ( $amount < 0 ) {
			$this->wallet->deduct( $user_id, $amount, $reason ? $reason : 'manual' );
			return;
		}
		$this->wallet->grant( $user_id, $amount, $reason ? $reason : 'manual' );
	}

	public function handle_export() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_data_export' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		global $wpdb;
		$entities = $this->entities();
		$entity   = isset( $_GET['entity'] ) ? sanitize_key( wp_unslash( $_GET['entity'] ) ) : 'users';
		if ( ! array_key_exists( $entity, $entities ) ) {
			wp_die( 'موجودیت نامعتبر.' );
		}

		$filters = $this->filters();
		$params  = array();
		$where   = $this->where( $entity, $filters, $params );
		$table   = $this->table_for( $entity );
		$sql     = "SELECT * FROM {$table} {$where} ORDER BY id DESC LIMIT 5000";
		$rows    = $params
			? $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ) // phpcs:ignore WordPress.DB
			: $wpdb->get_results( $sql, ARRAY_A ); // phpcs:ignore WordPress.DB

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=dr-niva-' . $entity . '-' . gmdate( 'Ymd-His' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" ); // Excel-friendly UTF-8 BOM
		if ( $rows ) {
			fputcsv( $out, array_keys( (array) $rows[0] ) );
			foreach ( $rows as $row ) {
				fputcsv( $out, array_map( 'strval', $row ) );
			}
		}
		fclose( $out );
		exit;
	}

	public function handle_credit() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_data_credit' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		$amount  = isset( $_POST['amount'] ) ? (int) $_POST['amount'] : 0;
		$reason  = isset( $_POST['reason'] ) ? sanitize_text_field( wp_unslash( $_POST['reason'] ) ) : 'manual';
		if ( $amount < 0 ) {
			$this->wallet->deduct( $user_id, $amount, $reason );
		} else {
			$this->wallet->grant( $user_id, $amount, $reason );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-data&entity=users&credited=1' ) );
		exit;
	}

	public function handle_notify() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_notify' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		$title    = isset( $_POST['title'] ) ? sanitize_text_field( wp_unslash( $_POST['title'] ) ) : '';
		$body     = isset( $_POST['body'] ) ? sanitize_text_field( wp_unslash( $_POST['body'] ) ) : '';
		$audience = isset( $_POST['audience'] ) ? sanitize_key( wp_unslash( $_POST['audience'] ) ) : 'all';
		if ( $title && $body ) {
			Niva_Notifications::broadcast( $title, $body, home_url( '/' ), $audience );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-data&entity=notifications&sent=1' ) );
		exit;
	}
}
