<?php
/**
 * Admin app shell (2.0.0).
 *
 * One sidebar, one content region, used by every plugin screen so the panel
 * reads as one app instead of a stack of forms. Purely presentation: it renders
 * nothing that the page callbacks do not pass in.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( class_exists( 'Niva_Admin_Shell' ) ) {
	return;
}

class Niva_Admin_Shell {

	/**
	 * The 13 areas of the panel, in sidebar order.
	 *
	 * Each area owns its own settings groups (see group_owner()), so a single
	 * setting is never editable from two screens.
	 *
	 * @return array<string,array<string,string>>
	 */
	public static function areas() : array {
		return array(
			'dashboard' => array( 'label' => 'داشبورد', 'slug' => 'dr-niva', 'icon' => 'home', 'group' => 'مدیریت' ),
			'users'     => array( 'label' => 'کاربران', 'slug' => 'dr-niva-users', 'icon' => 'users', 'group' => 'مدیریت' ),
			'community' => array( 'label' => 'گفتگوهای کاربران', 'slug' => 'dr-niva-community', 'icon' => 'message-heart', 'group' => 'مدیریت' ),
			'companion' => array( 'label' => 'کدهای همراهی', 'slug' => 'dr-niva-companion', 'icon' => 'heart-handshake', 'group' => 'مدیریت' ),
			'plans'     => array( 'label' => 'پلن‌ها و اعتبار', 'slug' => 'dr-niva-plans', 'icon' => 'crown', 'group' => 'کسب‌وکار' ),
			'payments'  => array( 'label' => 'پرداخت‌ها', 'slug' => 'dr-niva-payments', 'icon' => 'wallet', 'group' => 'کسب‌وکار' ),
			'messages'  => array( 'label' => 'پیام‌های روزانه', 'slug' => 'dr-niva-messages', 'icon' => 'message-circle', 'group' => 'محتوا' ),
			'access'    => array( 'label' => 'ابزارها و دسترسی', 'slug' => 'dr-niva-access', 'icon' => 'lock', 'group' => 'پیکربندی' ),
			'brand'     => array( 'label' => 'ظاهر و برند', 'slug' => 'dr-niva-brand', 'icon' => 'sparkles', 'group' => 'پیکربندی' ),
			'notify'    => array( 'label' => 'اطلاع‌رسانی', 'slug' => 'dr-niva-notify', 'icon' => 'bell', 'group' => 'پیکربندی' ),
			'ai'        => array( 'label' => 'هوش مصنوعی', 'slug' => 'dr-niva-ai', 'icon' => 'stethoscope', 'group' => 'پیکربندی' ),
			'health'    => array( 'label' => 'سلامت افزونه', 'slug' => 'dr-niva-health', 'icon' => 'shield-check', 'group' => 'سیستم' ),
			'tools'     => array( 'label' => 'ابزارهای تشخیصی', 'slug' => 'dr-niva-tools', 'icon' => 'settings', 'group' => 'سیستم' ),
		);
	}

	/**
	 * Which settings groups belong to which area — the single source of truth
	 * that keeps every field on exactly one screen.
	 *
	 * @return array<string,string[]> area key => settings group keys
	 */
	public static function group_owner() : array {
		return array(
			'users'     => array( 'account', 'onboarding', 'avatar' ),
			'community' => array( 'community' ),
			'companion' => array( 'companion' ),
			'plans'     => array( 'subscription', 'credits', 'partners' ),
			'payments'  => array( 'store' ),
			'access'    => array( 'feature_access' ),
			'brand'     => array( 'branding', 'chrome', 'general', 'layout', 'links' ),
			'notify'    => array( 'notifications', 'app_push', 'notify' ),
			'ai'        => array( 'ai', 'safety', 'lab' ),
		);
	}

	/** Reverse lookup: which area owns a settings group. */
	public static function area_for_group( string $group ) : string {
		foreach ( self::group_owner() as $area => $groups ) {
			if ( in_array( $group, $groups, true ) ) {
				return $area;
			}
		}
		return 'brand';
	}

	/** URL of an area (or a specific settings group inside it). */
	public static function url( string $area, string $group = '' ) : string {
		$areas = self::areas();
		if ( ! isset( $areas[ $area ] ) ) {
			$area = 'dashboard';
		}
		$url = admin_url( 'admin.php?page=' . $areas[ $area ]['slug'] );
		if ( '' !== $group ) {
			$url .= '#niva-group-' . $group;
		}
		return $url;
	}

	/** Opens the app shell: sidebar + top bar + content region. */
	public static function open( string $current, string $title, array $args = array() ) : void {
		$areas = self::areas();
		if ( ! isset( $areas[ $current ] ) ) {
			$current = 'dashboard';
		}
		$subtitle = isset( $args['subtitle'] ) ? (string) $args['subtitle'] : '';
		$actions  = isset( $args['actions'] ) ? (string) $args['actions'] : '';

		$grouped = array();
		foreach ( $areas as $key => $area ) {
			$grouped[ $area['group'] ][ $key ] = $area;
		}
		?>
		<div class="wrap avadm" dir="rtl">
			<div class="avadm__app">
				<aside class="avadm__side">
					<div class="avadm__brand">
						<span class="avadm__brand-mark" aria-hidden="true"><?php echo Niva_Icons::svg( 'activity', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span class="avadm__brand-text">
							<span class="avadm__brand-name">دکتر نیوا</span>
							<span class="avadm__brand-sub">نسخهٔ <?php echo esc_html( DR_NIVA_VERSION ); ?></span>
						</span>
					</div>
					<nav class="avadm__nav" aria-label="بخش‌های مدیریت دکتر نیوا">
						<?php foreach ( $grouped as $group_label => $items ) : ?>
							<span class="avadm__nav-group"><?php echo esc_html( $group_label ); ?></span>
							<?php foreach ( $items as $key => $area ) : ?>
								<a href="<?php echo esc_url( self::url( $key ) ); ?>" <?php echo $key === $current ? 'aria-current="page"' : ''; ?>>
									<span class="avadm__ic" aria-hidden="true"><?php echo Niva_Icons::svg( $area['icon'], 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
									<span><?php echo esc_html( $area['label'] ); ?></span>
								</a>
							<?php endforeach; ?>
						<?php endforeach; ?>
					</nav>
				</aside>

				<div class="avadm__main">
					<header class="avadm__top">
						<span class="avadm__ic" aria-hidden="true"><?php echo Niva_Icons::svg( $areas[ $current ]['icon'], 22 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
						<span>
							<h1><?php echo esc_html( $title ); ?></h1>
							<span class="avadm__top-meta">
								<?php echo esc_html( get_bloginfo( 'name' ) ); ?> ·
								<?php echo esc_html( $subtitle ); ?>
							</span>
						</span>
						<span class="avadm__top-actions">
							<?php echo $actions; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>
							<a class="button" href="<?php echo esc_url( home_url( '/' ) ); ?>" target="_blank" rel="noopener">مشاهدهٔ سایت</a>
						</span>
					</header>
					<div class="avadm__body">
		<?php
	}

	/** Closes the shell and prints the shared sticky save bar + toast host. */
	public static function close() : void {
		?>
					</div><!-- .avadm__body -->
				</div><!-- .avadm__main -->
			</div><!-- .avadm__app -->
			<div class="avadm-sticky" role="status">
				<strong><span data-avadm-dirty-count>0</span> کارت تغییر ذخیره‌نشده داری</strong>
				<span class="avadm-sticky__spacer"></span>
				<span>با Ctrl + S هم می‌توانی ذخیره کنی.</span>
			</div>
			<div class="avadm-toast-area" aria-live="polite"></div>
			<div class="avadm-scrim" data-avadm-scrim hidden></div>
		</div>
		<?php
	}

	/** Empty state block, used by every screen instead of fake data. */
	public static function empty_state( string $title, string $text, string $cta_label = '', string $cta_url = '' ) : void {
		?>
		<div class="avadm-card avadm-empty">
			<strong><?php echo esc_html( $title ); ?></strong>
			<span><?php echo esc_html( $text ); ?></span>
			<?php if ( '' !== $cta_label && '' !== $cta_url ) : ?>
				<p><a class="button button-primary" href="<?php echo esc_url( $cta_url ); ?>"><?php echo esc_html( $cta_label ); ?></a></p>
			<?php endif; ?>
		</div>
		<?php
	}

	/** One KPI stat card. */
	public static function stat( string $label, string $value, string $foot = '', string $tone = '' ) : void {
		$class = 'avadm-stat' . ( '' !== $tone ? ' avadm-stat--' . $tone : '' );
		?>
		<div class="<?php echo esc_attr( $class ); ?>">
			<span class="avadm-stat__label"><?php echo esc_html( $label ); ?></span>
			<strong class="avadm-stat__value"><?php echo esc_html( $value ); ?></strong>
			<?php if ( '' !== $foot ) : ?>
				<span class="avadm-stat__foot"><?php echo esc_html( $foot ); ?></span>
			<?php endif; ?>
		</div>
		<?php
	}
}
