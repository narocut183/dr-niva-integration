<?php
/**
 * Admin: settings (tabbed), layout builder, dashboard, review queue.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Admin {

	/** @var Niva_Settings */
	private $settings;

	/** @var Niva_Layout */
	private $layout;

	/** @var Niva_Wallet */
	private $wallet;

	public function __construct( Niva_Settings $settings, Niva_Layout $layout, Niva_Wallet $wallet ) {
		$this->settings = $settings;
		$this->layout   = $layout;
		$this->wallet   = $wallet;

		require_once DR_NIVA_PATH . 'admin/views/shell.php';

		add_action( 'admin_menu', array( $this, 'menu' ) );
		add_action( 'admin_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_dr_niva_save_settings', array( $this, 'save_settings' ) );
		add_action( 'admin_post_dr_niva_save_gates', array( $this, 'save_gates' ) );
		add_action( 'admin_post_dr_niva_build_menu', array( $this, 'build_menu' ) );
		add_action( 'admin_post_dr_niva_test_ai', array( $this, 'test_ai' ) );
		add_action( 'admin_post_dr_niva_save_plans', array( $this, 'save_plans' ) );
		add_action( 'admin_post_dr_niva_save_layout', array( $this, 'save_layout' ) );
		add_action( 'admin_post_dr_niva_review', array( $this, 'handle_review' ) );
	}

	/** Local admin styling + behaviour, only on our own screens. */
	public function assets( $hook ) : void {
		if ( false === strpos( (string) $hook, 'dr-niva' ) ) {
			return;
		}
		// Our own admin screens list Elementor icon classes (eicon-*). The icon
		// font only ships with Elementor's own screens, so without this every
		// module icon rendered as an empty box.
		if ( wp_style_is( 'elementor-icons', 'registered' ) ) {
			wp_enqueue_style( 'elementor-icons' );
		}
		wp_enqueue_style( 'dr-niva-admin', DR_NIVA_URL . 'admin/assets/admin.css', array(), DR_NIVA_VERSION );
		wp_enqueue_style( 'dr-niva-admin-v2', DR_NIVA_URL . 'admin/assets/admin-v2.css', array( 'dr-niva-admin' ), DR_NIVA_VERSION );
		wp_enqueue_script( 'dr-niva-admin', DR_NIVA_URL . 'admin/assets/admin.js', array(), DR_NIVA_VERSION, true );
		wp_enqueue_script( 'dr-niva-admin-v2', DR_NIVA_URL . 'admin/assets/admin-v2.js', array( 'dr-niva-admin' ), DR_NIVA_VERSION, true );
		wp_add_inline_style( 'dr-niva-admin-v2', $this->brand_tokens() );
		if ( function_exists( 'wp_enqueue_media' ) ) {
			wp_enqueue_media();
		}
	}

	/** Brand colours as CSS variables, so the panel follows the site palette. */
	private function brand_tokens() : string {
		$brand   = sanitize_hex_color( (string) $this->settings->get( 'brand_color', '#3368A0' ) ) ?: '#3368A0';
		$brand_2 = sanitize_hex_color( (string) $this->settings->get( 'brand_color_2', '#66A3BF' ) ) ?: '#66A3BF';
		$brand_3 = sanitize_hex_color( (string) $this->settings->get( 'brand_color_3', '#C8DFDB' ) ) ?: '#C8DFDB';
		return '.avadm{--avadm-brand:' . $brand . ';--avadm-brand-2:' . $brand_2 . ';--avadm-brand-3:' . $brand_3 . ';}';
	}

	public function menu() : void {
		// Local inline SVG instead of a dashicon, so the menu never shows a broken box.
		$icon = 'data:image/svg+xml;base64,' . base64_encode(
			'<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 24 24" fill="none" stroke="black" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M22 12h-4l-3 9L9 3l-3 9H2"/></svg>'
		);
		add_menu_page( 'دکتر نیوا', 'دکتر نیوا', 'manage_options', 'dr-niva', array( $this, 'render_area' ), $icon, 58 );

		// One entry per area of the app shell. The dashboard entry reuses the
		// parent slug, which is how WordPress renames the first submenu item.
		foreach ( Niva_Admin_Shell::areas() as $area ) {
			add_submenu_page( 'dr-niva', $area['label'], $area['label'], 'manage_options', $area['slug'], array( $this, 'render_area' ) );
		}

		// Legacy slugs stay routable (old bookmarks, in-page links) but are not
		// shown in the menu — they forward into the area that owns them.
		foreach ( array( 'dr-niva-settings', 'dr-niva-layout', 'dr-niva-widgets' ) as $legacy ) {
			add_submenu_page( 'dr-niva', $legacy, $legacy, 'manage_options', $legacy, array( $this, 'render_legacy' ) );
			remove_submenu_page( 'dr-niva', $legacy );
		}

		// Screens owned by dedicated classes, linked from inside the shell
		// instead of adding more items to the sidebar.
		foreach ( array( 'dr-niva-data', 'dr-niva-partners' ) as $hidden ) {
			add_submenu_page( 'dr-niva', $hidden, $hidden, 'manage_options', $hidden, array( $this, 'render_hidden' ) );
			remove_submenu_page( 'dr-niva', $hidden );
		}
	}

	/** Renders the screens that live in their own class but inside our shell. */
	public function render_hidden() : void {
		$this->guard();
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'dr-niva-data' === $page ) {
			( new Niva_Data( $this->settings, $this->wallet ) )->page();
			return;
		}
		if ( 'dr-niva-partners' === $page ) {
			( new Niva_Partners_Admin() )->page();
			return;
		}
	}

	/** Routes every area slug to its page callback. */
	public function render_area() : void {
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : 'dr-niva'; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$map  = array(
			'dr-niva'           => 'page_dashboard',
			'dr-niva-users'     => 'page_users',
			'dr-niva-community' => 'page_community',
			'dr-niva-companion' => 'page_companion',
			'dr-niva-plans'     => 'page_plans',
			'dr-niva-payments'  => 'page_payments',
			'dr-niva-messages'  => 'page_messages',
			'dr-niva-access'    => 'page_access',
			'dr-niva-brand'     => 'page_brand',
			'dr-niva-notify'    => 'page_notify',
			'dr-niva-ai'        => 'page_ai',
			'dr-niva-health'    => 'page_health',
			'dr-niva-tools'     => 'page_tools',
		);
		$method = $map[ $page ] ?? 'page_dashboard';
		$this->$method();
	}

	/** Forwards the pre-2.0.0 settings slugs that pages still link to. */
	public function render_legacy() : void {
		$this->guard();
		$page = isset( $_GET['page'] ) ? sanitize_key( wp_unslash( $_GET['page'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended

		if ( 'dr-niva-layout' === $page ) {
			$this->page_layout();
			return;
		}
		if ( 'dr-niva-widgets' === $page ) {
			$this->page_widgets();
			return;
		}

		// dr-niva-settings: send the visitor to the area that owns the group.
		$group = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$area  = '' !== $group ? Niva_Admin_Shell::area_for_group( $group ) : 'brand';
		wp_safe_redirect( Niva_Admin_Shell::url( $area, $group ) );
		exit;
	}

	/* ------------------------------------------------------------------ pages */

	/**
	 * One settings area: intro + the cards of the groups it owns.
	 *
	 * Group ownership lives in Niva_Admin_Shell::group_owner(), so a single
	 * setting is only ever editable from one screen.
	 */
	private function area_page( string $area, string $title, string $intro = '', string $extra_html = '' ) : void {
		$this->guard();
		$owners = Niva_Admin_Shell::group_owner();
		$keys   = isset( $owners[ $area ] ) ? $owners[ $area ] : array();

		Niva_Admin_Shell::open( $area, $title, array( 'subtitle' => 'تنظیمات و کنترل‌های این بخش' ) );
		$this->notice();

		if ( '' !== $intro ) {
			echo '<div class="avadm-card"><p style="margin:0">' . esc_html( $intro ) . '</p></div>';
		}
		echo $extra_html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- assembled from escaped fragments
		$this->group_cards( $keys );
		Niva_Admin_Shell::close();
	}

	/** The group cards of one area, with live search and a save button per card. */
	private function group_cards( array $group_keys ) : void {
		$groups = Niva_Settings::groups();
		$all    = $this->settings->all();
		$keys   = array_values(
			array_filter(
				$group_keys,
				static function ( $key ) use ( $groups ) {
					return isset( $groups[ $key ] ) && ! empty( $groups[ $key ]['fields'] );
				}
			)
		);

		if ( ! $keys ) {
			Niva_Admin_Shell::empty_state( 'تنظیمی در این بخش نیست', 'همهٔ تنظیمات این بخش در همین صفحه قرار می‌گیرند.' );
			return;
		}
		?>
		<div class="avadm-toolbar">
			<label class="screen-reader-text" for="niva-cfg-search">جست‌وجو در تنظیمات این بخش</label>
			<input id="niva-cfg-search" type="search" class="regular-text" placeholder="جست‌وجو در عنوان و توضیح فیلدها…" data-avadm-search="#niva-cfg-groups" />
			<span class="avadm-pill"><?php echo esc_html( number_format_i18n( count( $keys ) ) ); ?> کارت</span>
			<span class="avadm-toolbar__spacer"></span>
			<span class="description">با Ctrl + S هم ذخیره می‌شود.</span>
		</div>
		<p class="description" data-avadm-noresult hidden>چیزی با این عبارت پیدا نشد.</p>

		<div id="niva-cfg-groups">
			<?php foreach ( $keys as $key ) : ?>
				<?php $group = $groups[ $key ]; ?>
				<?php if ( 'ai' === $key ) : ?>
					<?php $this->ai_test_panel(); ?>
				<?php endif; ?>
				<section class="avadm-card" id="niva-group-<?php echo esc_attr( $key ); ?>" data-avadm-group>
					<header class="avadm-card__head">
						<h2 class="avadm-card__title"><?php echo esc_html( $group['label'] ); ?></h2>
						<span class="avadm-card__note"><?php echo esc_html( number_format_i18n( count( $group['fields'] ) ) ); ?> تنظیم</span>
					</header>
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
						<input type="hidden" name="action" value="dr_niva_save_settings" />
						<input type="hidden" name="tab" value="<?php echo esc_attr( $key ); ?>" />
						<?php wp_nonce_field( 'dr_niva_save_settings' ); ?>
						<div class="niva-fields">
							<?php foreach ( $group['fields'] as $fkey => $field ) : ?>
								<?php $this->render_field_row( $fkey, $field, isset( $all[ $fkey ] ) ? $all[ $fkey ] : $field['default'] ); ?>
							<?php endforeach; ?>
						</div>
						<footer class="niva-group__foot">
							<button type="submit" class="button button-primary">ذخیرهٔ «<?php echo esc_html( $group['label'] ); ?>»</button>
						</footer>
					</form>
				</section>
			<?php endforeach; ?>
		</div>
		<?php
	}

	/** One field row: label, inline "?" help, per-field reset, control, error slot. */
	private function render_field_row( string $key, array $field, $value ) : void {
		$help_id = 'niva-help-' . sanitize_html_class( $key );
		$locked  = ! empty( $field['locked'] );
		$default = isset( $field['default'] ) && is_scalar( $field['default'] ) ? (string) $field['default'] : '';
		?>
		<div class="avadm-field" data-avadm-field>
			<div class="avadm-field__label">
				<label for="niva-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $field['label'] ); ?></label>
				<?php if ( $locked ) : ?><span class="avadm-pill avadm-pill--muted">قفل ایمنی</span><?php endif; ?>
				<?php if ( ! empty( $field['hint'] ) ) : ?>
					<button type="button" class="avadm-help" data-avadm-help="<?php echo esc_attr( $help_id ); ?>" aria-expanded="true" aria-controls="<?php echo esc_attr( $help_id ); ?>">؟</button>
				<?php endif; ?>
				<?php if ( ! $locked ) : ?>
					<button type="button" class="avadm-reset" data-avadm-reset="<?php echo esc_attr( $default ); ?>">بازگردانی به پیش‌فرض</button>
				<?php endif; ?>
			</div>
			<?php if ( ! empty( $field['hint'] ) ) : ?>
				<div class="avadm-help__panel" id="<?php echo esc_attr( $help_id ); ?>"><?php echo esc_html( $field['hint'] ); ?></div>
			<?php endif; ?>
			<div class="avadm-field__control"><?php $this->render_field( $key, $field, $value ); ?></div>
			<span class="avadm-field__error" hidden></span>
		</div>
		<?php
	}

	/** Renders one control according to its declared type. */
	private function render_field( string $key, array $field, $value ) : void {
		$name = 'dr_niva[' . $key . ']';
		switch ( $field['type'] ) {
			case 'toggle':
				printf(
					'<label class="niva-switch"><input type="checkbox" id="niva-%1$s" name="%2$s" value="1" %3$s /><span></span></label>',
					esc_attr( $key ),
					esc_attr( $name ),
					checked( (int) $value, 1, false )
				);
				break;

			case 'number':
				printf(
					'<input type="number" class="small-text" id="niva-%1$s" name="%2$s" value="%3$s" data-avadm-rule="int" />',
					esc_attr( $key ),
					esc_attr( $name ),
					esc_attr( (string) $value )
				);
				break;

			case 'color':
				printf(
					'<label class="niva-color-control"><input type="color" id="niva-%1$s" name="%2$s" value="%3$s" data-avadm-rule="color" /><code>%3$s</code></label>',
					esc_attr( $key ),
					esc_attr( $name ),
					esc_attr( sanitize_hex_color( (string) $value ) ?: '#3368A0' )
				);
				break;

			case 'media':
				$media_id = absint( $value );
				$media_url = $media_id ? wp_get_attachment_image_url( $media_id, 'medium' ) : '';
				printf(
					'<div class="niva-media-field"><input type="hidden" id="niva-%1$s" name="%2$s" value="%3$d" /><button type="button" class="button" data-niva-media="#niva-%1$s">انتخاب از کتابخانهٔ رسانه</button><span class="niva-media-preview">%4$s</span></div>',
					esc_attr( $key ),
					esc_attr( $name ),
					$media_id,
					$media_url ? '<img src="' . esc_url( $media_url ) . '" alt="" />' : '<span class="description">هنوز لوگویی انتخاب نشده است.</span>'
				);
				break;

			case 'time':
				printf(
					'<input type="time" id="niva-%1$s" name="%2$s" value="%3$s" data-avadm-rule="time" />',
					esc_attr( $key ),
					esc_attr( $name ),
					esc_attr( (string) $value )
				);
				break;

			case 'select':
				printf( '<select id="niva-%1$s" name="%2$s">', esc_attr( $key ), esc_attr( $name ) );
				foreach ( (array) $field['options'] as $option_value => $option_label ) {
					printf(
						'<option value="%1$s" %2$s>%3$s</option>',
						esc_attr( (string) $option_value ),
						selected( (string) $value, (string) $option_value, false ),
						esc_html( $option_label )
					);
				}
				echo '</select>';
				break;

			case 'secret':
				/*
				 * A stored secret is never printed back into the HTML. The panel
				 * shows only its state (set / not set) plus a short mask, and the
				 * input stays empty so an accidental save cannot blank the key.
				 */
				$masked = (string) $this->settings->masked( $key );
				$has    = '' !== (string) $this->settings->get( $key, '' );
				?>
				<span class="avadm-secret<?php echo $has ? '' : ' is-open'; ?>">
					<span class="avadm-secret__state">
						<?php if ( $has ) : ?>
							<span class="avadm-pill avadm-pill--ok">تنظیم شده</span>
							<code dir="ltr"><?php echo esc_html( $masked ); ?></code>
						<?php else : ?>
							<span class="avadm-pill avadm-pill--warn">تنظیم نشده</span>
						<?php endif; ?>
					</span>
					<?php if ( $has ) : ?>
						<button type="button" class="button button-small" data-avadm-secret-toggle aria-expanded="false">تغییر</button>
					<?php endif; ?>
					<span class="avadm-secret__input">
						<input type="password" class="regular-text" dir="ltr" id="niva-<?php echo esc_attr( $key ); ?>" name="<?php echo esc_attr( $name ); ?>" value="" autocomplete="new-password"
							placeholder="<?php echo esc_attr( $has ? 'برای تغییر، مقدار تازه را اینجا بنویس' : 'مقدار را اینجا وارد کن' ); ?>" />
					</span>
				</span>
				<?php
				break;

			case 'url':
				printf(
					'<input type="url" class="regular-text" dir="ltr" id="niva-%1$s" name="%2$s" value="%3$s" placeholder="https://" data-avadm-rule="url" />',
					esc_attr( $key ),
					esc_attr( $name ),
					esc_attr( (string) $value )
				);
				break;

			case 'lines':
				printf(
					'<textarea rows="5" class="large-text" dir="auto" id="niva-%1$s" name="%2$s" data-avadm-allow-pipe="1">%3$s</textarea>',
					esc_attr( $key ),
					esc_attr( $name ),
					esc_textarea( (string) $value )
				);
				break;

			case 'feature_gates':
				$this->render_feature_gates( $value );
				break;

			case 'rows':
				$rows = is_array( $value ) ? $value : array();
				echo '<table class="widefat niva-rows" style="max-width:640px"><thead><tr><th>اعتبار</th><th>قیمت (تومان)</th></tr></thead><tbody>';
				$index = 0;
				foreach ( $rows as $row ) {
					printf(
						'<tr><td><input type="number" name="%1$s[%2$d][0]" value="%3$s" /></td><td><input type="number" name="%1$s[%2$d][1]" value="%4$s" /></td></tr>',
						esc_attr( $name ),
						$index,
						esc_attr( (string) ( $row[0] ?? '' ) ),
						esc_attr( (string) ( $row[1] ?? '' ) )
					);
					$index++;
				}
				// three empty rows so the admin can add packages without touching code
				for ( $i = 0; $i < 3; $i++ ) {
					printf(
						'<tr><td><input type="number" name="%1$s[%2$d][0]" value="" /></td><td><input type="number" name="%1$s[%2$d][1]" value="" /></td></tr>',
						esc_attr( $name ),
						$index + $i
					);
				}
				echo '</tbody></table>';
				break;

			default:
				printf(
					'<input type="text" class="regular-text" dir="auto" id="niva-%1$s" name="%2$s" value="%3$s" />',
					esc_attr( $key ),
					esc_attr( $name ),
					esc_attr( (string) $value )
				);
		}
	}

	/** A searchable plan matrix; the stored legacy option remains line-based. */
	private function render_feature_gates( $value ) : void {
		$catalog = Niva_Plans::feature_gate_catalog();
		$matrix  = Niva_Plans::feature_gate_matrix( is_scalar( $value ) ? (string) $value : '' );
		$plans   = Niva_Plans::labels();
		$groups  = array();
		foreach ( $catalog as $id => $feature ) {
			$groups[ $feature['group'] ][ $id ] = $feature;
		}
		?>
		<div class="niva-feature-gates">
			<label class="screen-reader-text" for="niva-feature-gate-search">جست‌وجوی امکانات</label>
			<input id="niva-feature-gate-search" type="search" class="regular-text" placeholder="جست‌وجوی امکان…" data-niva-filter="#niva-feature-gate-list" />
			<p class="description">تیک هر خانه یعنی آن پلن به این امکان دسترسی دارد. تعداد مصرف و سهمیه را از ویرایشگر پلن‌ها تنظیم کن.</p>
			<input type="hidden" name="dr_niva[feature_plan_gates][_matrix_present]" value="1" />
			<div id="niva-feature-gate-list" class="niva-feature-gates__groups">
				<?php foreach ( $groups as $group => $features ) : ?>
					<section class="niva-feature-gates__group" data-niva-gate-group>
						<h3><?php echo esc_html( $group ); ?></h3>
						<div class="niva-feature-gates__scroll">
							<table class="widefat striped niva-feature-gates__table">
								<thead><tr><th scope="col">امکان</th>
									<?php foreach ( $plans as $plan => $label ) : ?>
										<th scope="col"><?php echo esc_html( $label ); ?></th>
									<?php endforeach; ?>
								</tr></thead>
								<tbody>
								<?php foreach ( $features as $id => $feature ) : ?>
									<tr data-niva-item>
										<th scope="row"><?php echo esc_html( $feature['label'] ); ?></th>
										<?php foreach ( $plans as $plan => $label ) : ?>
											<td>
												<label class="niva-gate-check">
													<span class="screen-reader-text"><?php echo esc_html( $feature['label'] . ' — ' . $label ); ?></span>
													<input type="checkbox"
														name="dr_niva[feature_plan_gates][<?php echo esc_attr( $id ); ?>][]"
														value="<?php echo esc_attr( $plan ); ?>"
														<?php checked( in_array( $plan, $matrix[ $id ] ?? array(), true ) ); ?> />
												</label>
											</td>
										<?php endforeach; ?>
									</tr>
								<?php endforeach; ?>
								</tbody>
							</table>
						</div>
					</section>
				<?php endforeach; ?>
			</div>
		</div>
		<?php
	}

	public function page_layout() : void {
		$this->guard();
		$rows    = $this->layout->all();
		$modules = Niva_Layout::modules();
		Niva_Admin_Shell::open( 'access', 'چیدمان و ماژول‌ها', array( 'subtitle' => 'ترتیب و روشن/خاموشی ماژول‌ها' ) );
		$this->notice();
		?>
			<p>هر ماژول را می‌توانی خاموش کنی یا با دکمه‌های بالا/پایین جابه‌جا کنی. ترتیب همین جدول، ترتیب نمایش در سایت است.</p>
			<?php if ( Niva_Elementor::is_active() ) : ?>
				<div class="notice notice-info"><p>
					المنتور فعال است. اگر صفحه‌ها را با ویجت‌های المنتور می‌سازی، این صفحه لازم نیست —
					چیدمان را همان‌جا با کشیدن‌و‌رهاکردن ویجت‌ها تعیین کن.
				</p></div>
			<?php endif; ?>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dr_niva_save_layout" />
				<?php wp_nonce_field( 'dr_niva_save_layout' ); ?>

				<table class="widefat striped" style="max-width:820px">
					<thead>
						<tr><th style="width:60px">ترتیب</th><th>ماژول</th><th style="width:120px">گروه</th><th style="width:90px">فعال</th></tr>
					</thead>
					<tbody>
					<?php foreach ( $rows as $index => $row ) : ?>
						<?php $module = $modules[ $row['id'] ]; ?>
						<tr>
							<td>
								<input type="hidden" name="rows[<?php echo (int) $index; ?>][id]" value="<?php echo esc_attr( $row['id'] ); ?>" />
								<input type="hidden" name="rows[<?php echo (int) $index; ?>][order]" value="<?php echo (int) $index; ?>" />
								<button type="submit" class="button button-small" name="move" value="<?php echo esc_attr( $row['id'] . ':up' ); ?>">▲</button>
								<button type="submit" class="button button-small" name="move" value="<?php echo esc_attr( $row['id'] . ':down' ); ?>">▼</button>
							</td>
							<td>
								<strong><?php echo esc_html( $module['label'] ); ?></strong>
								<div class="description"><code><?php echo esc_html( $row['id'] ); ?></code></div>
							</td>
							<td><?php echo esc_html( $module['group'] ); ?></td>
							<td>
								<input type="checkbox" name="rows[<?php echo (int) $index; ?>][enabled]" value="1" <?php checked( ! empty( $row['enabled'] ) ); ?> />
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
				<?php submit_button( 'ذخیره‌ی چیدمان' ); ?>
			</form>
		<?php
		Niva_Admin_Shell::close();
	}

	/** Lists every widget so the editor can find them without guessing. */
	public function page_widgets() : void {
		$this->guard();
		$map      = Niva_Modules::map();
		$elementor = Niva_Elementor::is_active();
		$groups   = array();
		foreach ( $map as $id => $module ) {
			$groups[ $module['group'] ][ $id ] = $module;
		}
		Niva_Admin_Shell::open( 'access', 'ویجت‌های المنتور', array( 'subtitle' => 'هر ماژول یک ویجت و یک شورت‌کد' ) );
		$this->notice();
		?>

			<?php if ( $elementor ) : ?>
				<div class="notice notice-success"><p>
					المنتور فعال است. در ویرایشگر، از پنل سمت چپ دسته‌ی <strong>«دکتر نیوا»</strong> را باز کن؛
					هر بخش زیر یک ویجت جداگانه است که می‌توانی هر جا بکشی، جابه‌جا کنی، تکرار کنی یا پاک کنی.
				</p></div>
			<?php else : ?>
				<div class="notice notice-warning"><p>
					المنتور روی این سایت فعال نیست. تا فعال‌شدن آن، از شورت‌کد ستون «شورت‌کد» استفاده کن —
					همان بخش، با همان امکانات.
				</p></div>
			<?php endif; ?>

			<p>هر بخش هم ویجت المنتور دارد و هم شورت‌کد. گزینه‌های «نمایش عنوان» و «پنهان‌کردن بخش‌های داخلی» در هر ویجت موجود است.</p>

			<?php foreach ( $groups as $group_label => $modules ) : ?>
				<h2><?php echo esc_html( $group_label ); ?></h2>
				<table class="widefat striped" style="max-width: 1000px">
					<thead>
						<tr>
							<th style="width: 30%">نام ویجت در المنتور</th>
							<th style="width: 20%">شناسه</th>
							<th>شورت‌کد</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $modules as $id => $module ) : ?>
						<tr>
							<td><strong><?php echo esc_html( $module['label'] ); ?></strong></td>
							<td><code><?php echo esc_html( $id ); ?></code></td>
							<td><code>[dr_niva_module id="<?php echo esc_attr( $id ); ?>"]</code></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			<?php endforeach; ?>

			<h2>بخش‌های پنهان‌کردنی</h2>
			<p>در فیلد «پنهان‌کردن بخش‌های داخلی» هر ویجت می‌توانی این نام‌ها را بنویسی:</p>
			<table class="widefat striped" style="max-width: 620px">
				<tbody>
				<?php foreach ( Niva_Modules::tokens() as $token => $label ) : ?>
					<tr><td style="width: 140px"><code><?php echo esc_html( $token ); ?></code></td><td><?php echo esc_html( $label ); ?></td></tr>
				<?php endforeach; ?>
				</tbody>
			</table>
		<?php
		Niva_Admin_Shell::close();
	}

	public function page_dashboard() : void {
		$this->guard();
		global $wpdb;
		$wallet_table = Niva_DB::table( 'wallets' );
		$ledger_table = Niva_DB::table( 'ledger' );
		$usage_table  = Niva_DB::table( 'usage' );
		$review_table = Niva_DB::table( 'reviews' );
		$reminder_table = Niva_DB::table( 'reminders' );
		$message_table  = Niva_DB::table( 'messages' );
		$notification_table = Niva_DB::table( 'notifications' );

		$users         = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wpdb->users}" ); // phpcs:ignore
		$wallets       = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$wallet_table}" ); // phpcs:ignore
		$balance_total = (int) $wpdb->get_var( "SELECT COALESCE(SUM(balance),0) FROM {$wallet_table}" ); // phpcs:ignore
		$granted       = (int) $wpdb->get_var( "SELECT COALESCE(SUM(delta),0) FROM {$ledger_table} WHERE delta > 0" ); // phpcs:ignore
		$spent         = (int) $wpdb->get_var( "SELECT COALESCE(SUM(cost),0) FROM {$usage_table} WHERE charged_from NOT IN ('refunded', 'plan_reserved')" ); // phpcs:ignore
		$calls         = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$usage_table} WHERE charged_from NOT IN ('refunded', 'plan_reserved')" ); // phpcs:ignore
		$active_reminders = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$reminder_table} WHERE done = 0" ); // phpcs:ignore
		$active_messages  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$message_table} WHERE active = 1" ); // phpcs:ignore
		$notifications    = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$notification_table}" ); // phpcs:ignore
		$now_utc          = current_time( 'mysql', true );
		$membership_table = Niva_DB::table( 'memberships' );
		$active_plans     = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$membership_table} WHERE status = 'active' AND (expires_at IS NULL OR expires_at = '0000-00-00 00:00:00' OR expires_at > %s)", $now_utc ) ); // phpcs:ignore WordPress.DB
		$expired_plans    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$membership_table} WHERE status = 'expired' OR (status = 'active' AND expires_at IS NOT NULL AND expires_at <> '0000-00-00 00:00:00' AND expires_at <= %s)", $now_utc ) ); // phpcs:ignore WordPress.DB
		$today_usage      = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$usage_table} WHERE charged_from NOT IN ('refunded', 'plan_reserved') AND created_at >= %s", current_time( 'Y-m-d 00:00:00' ) ) ); // phpcs:ignore WordPress.DB
		$lab_analyses     = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$usage_table} WHERE kind = 'lab' AND charged_from NOT IN ('refunded', 'plan_reserved')" ); // phpcs:ignore
		$menu_ready       = has_nav_menu( 'dr_niva_app' );
		$by_kind       = $wpdb->get_results( "SELECT kind, COUNT(*) calls, COALESCE(SUM(cost),0) credits FROM {$usage_table} WHERE charged_from NOT IN ('refunded', 'plan_reserved') GROUP BY kind ORDER BY calls DESC", ARRAY_A ); // phpcs:ignore
		$reviews       = $wpdb->get_results( "SELECT * FROM {$review_table} WHERE status = 'open' ORDER BY id DESC LIMIT 20", ARRAY_A ); // phpcs:ignore

		/* ---- 2.0.0 dashboard figures — every number comes from a real table ---- */

		$audit_table     = Niva_DB::table( 'audit_log' );
		$community_table = Niva_DB::table( 'community_threads' );
		$codes_table     = Niva_DB::table( 'companion_codes' );
		$day_start       = current_time( 'Y-m-d 00:00:00' );
		$month_start     = current_time( 'Y-m-01 00:00:00' );

		$credits_today = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(cost),0) FROM {$usage_table} WHERE charged_from NOT IN ('refunded','plan_reserved') AND created_at >= %s", $day_start ) ); // phpcs:ignore WordPress.DB
		$credits_month = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(cost),0) FROM {$usage_table} WHERE charged_from NOT IN ('refunded','plan_reserved') AND created_at >= %s", $month_start ) ); // phpcs:ignore WordPress.DB

		// Revenue is shown only when WooCommerce is present and has real orders.
		$revenue = null;
		if ( function_exists( 'wc_get_orders' ) ) {
			$order_ids = wc_get_orders(
				array(
					'limit'        => -1,
					'status'       => array( 'wc-completed', 'wc-processing' ),
					'date_created' => '>=' . $month_start,
					'return'       => 'ids',
				)
			);
			$sum = 0.0;
			foreach ( (array) $order_ids as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( $order ) {
					$sum += (float) $order->get_total();
				}
			}
			$revenue = array( 'orders' => count( (array) $order_ids ), 'total' => $sum );
		}

		// 14-day series: credits spent and new sign-ups, straight from the DB.
		$window_start = gmdate( 'Y-m-d 00:00:00', strtotime( current_time( 'Y-m-d' ) . ' -13 days' ) );
		$usage_series = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(created_at) d, COALESCE(SUM(cost),0) c FROM {$usage_table} WHERE charged_from NOT IN ('refunded','plan_reserved') AND created_at >= %s GROUP BY DATE(created_at)", $window_start ), ARRAY_A ); // phpcs:ignore WordPress.DB
		$signup_series = $wpdb->get_results( $wpdb->prepare( "SELECT DATE(user_registered) d, COUNT(*) c FROM {$wpdb->users} WHERE user_registered >= %s GROUP BY DATE(user_registered)", $window_start ), ARRAY_A ); // phpcs:ignore WordPress.DB

		$series = array();
		for ( $i = 13; $i >= 0; $i-- ) {
			$stamp  = strtotime( current_time( 'Y-m-d' ) . ' -' . $i . ' days' );
			$jalali = Niva_Chrome::jalali( $stamp );
			$series[ gmdate( 'Y-m-d', $stamp ) ] = array(
				'label'   => Niva_Chrome::digits( (string) ( $jalali[2] ?? '' ) ),
				'credits' => 0,
				'users'   => 0,
			);
		}
		foreach ( (array) $usage_series as $row ) {
			if ( isset( $series[ (string) $row['d'] ] ) ) {
				$series[ (string) $row['d'] ]['credits'] = (int) $row['c'];
			}
		}
		foreach ( (array) $signup_series as $row ) {
			if ( isset( $series[ (string) $row['d'] ] ) ) {
				$series[ (string) $row['d'] ]['users'] = (int) $row['c'];
			}
		}
		$series_max = 1;
		foreach ( $series as $row ) {
			$series_max = max( $series_max, (int) $row['credits'], (int) $row['users'] );
		}

		$recent_audit      = $wpdb->get_results( "SELECT * FROM {$audit_table} ORDER BY id DESC LIMIT 8", ARRAY_A ); // phpcs:ignore
		$pending_community = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$community_table} WHERE status = 'pending'" ); // phpcs:ignore
		$active_companions = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$codes_table} WHERE status = 'active'" ); // phpcs:ignore
		$db_version        = (string) get_option( 'dr_niva_db_version', '0' );
		$missing_tables    = Niva_DB::missing_tables();
		$cron_ok           = (bool) wp_next_scheduled( 'dr_niva_daily_maintenance' );
		?>
		<?php
		Niva_Admin_Shell::open(
			'dashboard',
			'داشبورد',
			array(
				'subtitle' => 'نمای کلی افزونه',
				'actions'  => '<a class="button button-primary" href="' . esc_url( Niva_Admin_Shell::url( 'plans' ) ) . '">پلن‌ها و اعتبار</a>',
			)
		);
		$this->notice();
		?>

			<div class="avadm-grid avadm-grid--kpi">
				<?php
				Niva_Admin_Shell::stat( 'کاربران فعال (۳۰ روز)', number_format_i18n( $this->active_users_30d() ), 'کاربری که در ۳۰ روز گذشته فعال بوده' );
				Niva_Admin_Shell::stat( 'اشتراک فعال', number_format_i18n( $active_plans ), 'پلن معتبر با تاریخ انقضای آینده' );
				Niva_Admin_Shell::stat( 'مصرف اعتبار امروز', number_format_i18n( $credits_today ), 'مصرف نهایی امروز' );
				Niva_Admin_Shell::stat( 'مصرف اعتبار این ماه', number_format_i18n( $credits_month ), 'از ابتدای ماه میلادی جاری' );

				if ( null === $revenue ) {
					?>
					<div class="avadm-stat avadm-stat--muted">
						<span class="avadm-stat__label">درآمد این ماه</span>
						<strong class="avadm-stat__value">اتصال فروشگاه برقرار نیست</strong>
						<span class="avadm-stat__foot">ووکامرس روی این سایت فعال نیست؛ پس درآمدی برای نمایش وجود ندارد.</span>
					</div>
					<?php
				} else {
					Niva_Admin_Shell::stat( 'درآمد این ماه', number_format_i18n( (int) round( $revenue['total'] ) ), $revenue['orders'] . ' سفارش تکمیل/در حال انجام' );
				}
				?>
			</div>

			<div class="avadm-grid avadm-grid--2">
				<section class="avadm-card">
					<header class="avadm-card__head">
						<h2 class="avadm-card__title">روند ۱۴ روز گذشته</h2>
						<span class="avadm-card__note">اعتبار مصرف‌شده و کاربران تازه</span>
					</header>
					<div class="avadm-chart" role="img" aria-label="نمودار میله‌ای مصرف اعتبار و ثبت‌نام در ۱۴ روز گذشته">
						<?php foreach ( $series as $row ) : ?>
							<div class="avadm-chart__col">
								<div class="avadm-chart__bars">
									<span class="avadm-chart__bar" style="height:<?php echo esc_attr( (string) round( ( $row['credits'] / $series_max ) * 100 ) ); ?>%"></span>
									<span class="avadm-chart__bar avadm-chart__bar--alt" style="height:<?php echo esc_attr( (string) round( ( $row['users'] / $series_max ) * 100 ) ); ?>%"></span>
								</div>
								<span class="avadm-chart__label"><?php echo esc_html( $row['label'] ); ?></span>
							</div>
						<?php endforeach; ?>
					</div>
					<div class="avadm-legend">
						<span><i style="background:var(--avadm-brand)"></i>اعتبار مصرف‌شده</span>
						<span><i style="background:var(--avadm-brand-3)"></i>کاربر تازه</span>
					</div>
				</section>

				<section class="avadm-card">
					<header class="avadm-card__head">
						<h2 class="avadm-card__title">سلامت افزونه</h2>
						<a class="avadm-card__note" href="<?php echo esc_url( Niva_Admin_Shell::url( 'health' ) ); ?>">جزئیات کامل</a>
					</header>
					<ul class="avadm-kv" style="grid-template-columns:1fr">
						<li style="display:flex;gap:8px;align-items:center">
							<span class="avadm-dot <?php echo version_compare( PHP_VERSION, '7.4', '>=' ) ? '' : 'avadm-dot--danger'; ?>"></span>
							PHP <?php echo esc_html( PHP_VERSION ); ?>
						</li>
						<li style="display:flex;gap:8px;align-items:center">
							<span class="avadm-dot <?php echo version_compare( get_bloginfo( 'version' ), '6.4', '>=' ) ? '' : 'avadm-dot--warn'; ?>"></span>
							وردپرس <?php echo esc_html( get_bloginfo( 'version' ) ); ?>
						</li>
						<li style="display:flex;gap:8px;align-items:center">
							<span class="avadm-dot <?php echo dr_niva()->ai->configured_vision() ? '' : 'avadm-dot--warn'; ?>"></span>
							کلید هوش مصنوعی: <?php echo dr_niva()->ai->configured_vision() ? 'تنظیم شده' : 'تنظیم نشده'; ?>
						</li>
						<li style="display:flex;gap:8px;align-items:center">
							<span class="avadm-dot <?php echo class_exists( 'WooCommerce' ) ? '' : 'avadm-dot--warn'; ?>"></span>
							ووکامرس: <?php echo class_exists( 'WooCommerce' ) ? 'فعال' : 'غیرفعال'; ?>
						</li>
						<li style="display:flex;gap:8px;align-items:center">
							<span class="avadm-dot <?php echo $missing_tables ? 'avadm-dot--danger' : ''; ?>"></span>
							جداول دیتابیس: <?php echo $missing_tables ? esc_html( number_format_i18n( count( $missing_tables ) ) ) . ' جدول ساخته نشده' : 'همه ساخته شده‌اند'; ?>
							<code>v<?php echo esc_html( $db_version ); ?></code>
						</li>
						<li style="display:flex;gap:8px;align-items:center">
							<span class="avadm-dot <?php echo $cron_ok ? '' : 'avadm-dot--warn'; ?>"></span>
							زمان‌بند نگهداری روزانه: <?php echo $cron_ok ? 'فعال' : 'زمان‌بندی نشده'; ?>
						</li>
						<li style="display:flex;gap:8px;align-items:center">
							<span class="avadm-dot <?php echo $menu_ready ? '' : 'avadm-dot--warn'; ?>"></span>
							منوی اپ: <?php echo $menu_ready ? 'متصل' : 'متصل نشده'; ?>
							<a href="<?php echo esc_url( admin_url( 'nav-menus.php' ) ); ?>">فهرست‌ها</a>
						</li>
					</ul>
				</section>
			</div>

			<div class="avadm-toolbar">
				<span class="avadm-pill">میان‌برهای کار سریع</span>
				<a class="button" href="<?php echo esc_url( Niva_Admin_Shell::url( 'plans' ) ); ?>">ساخت و ویرایش پلن</a>
				<a class="button" href="<?php echo esc_url( Niva_Admin_Shell::url( 'plans', 'credits' ) ); ?>">افزودن بستهٔ اعتبار</a>
				<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-messages' ) ); ?>">ساخت پیام روزانه</a>
				<a class="button" href="<?php echo esc_url( Niva_Admin_Shell::url( 'users' ) ); ?>">مدیریت کاربران</a>
				<span class="avadm-toolbar__spacer"></span>
				<a class="button button-primary" href="#niva-review-queue">بازبینی گزارش‌شده‌ها (<?php echo esc_html( number_format_i18n( count( (array) $reviews ) ) ); ?>)</a>
			</div>

			<div class="avadm-grid avadm-grid--2">
				<section class="avadm-card">
					<header class="avadm-card__head">
						<h2 class="avadm-card__title">آخرین فعالیت‌ها</h2>
						<span class="avadm-card__note">۱۰ رویداد اخیر مصرف</span>
					</header>
					<div class="avadm-tablewrap">
						<table class="widefat striped avadm-table">
							<thead><tr><th>زمان</th><th>کاربر</th><th>نوع</th><th>اعتبار</th></tr></thead>
							<tbody>
							<?php if ( $recent_audit ) : ?>
								<?php foreach ( $recent_audit as $row ) : ?>
									<tr>
										<td><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ); ?></td>
										<td><?php echo esc_html( $this->user_label( (int) $row['target_user_id'] ) ); ?></td>
										<td><code><?php echo esc_html( (string) $row['action'] ); ?></code></td>
										<td><?php echo esc_html( (string) $row['ref'] ); ?></td>
									</tr>
								<?php endforeach; ?>
							<?php else : ?>
								<tr><td colspan="4" class="avadm-empty">هنوز رویدادی در لاگ مدیریت ثبت نشده است. اولین بازدید از پروفایل یک کاربر این‌جا ثبت می‌شود.</td></tr>
							<?php endif; ?>
							</tbody>
						</table>
					</div>
				</section>

				<section class="avadm-card">
					<header class="avadm-card__head">
						<h2 class="avadm-card__title">وضعیت بخش‌های تازه</h2>
					</header>
					<ul class="avadm-kv">
						<dt>گفتگو با کاربران</dt>
						<dd><?php echo esc_html( number_format_i18n( $pending_community ) ); ?> گفتگو در انتظار بازبینی — <a href="<?php echo esc_url( Niva_Admin_Shell::url( 'community' ) ); ?>">مدیریت</a></dd>
						<dt>کد همراهی فعال</dt>
						<dd><?php echo esc_html( number_format_i18n( $active_companions ) ); ?> کد — <a href="<?php echo esc_url( Niva_Admin_Shell::url( 'companion' ) ); ?>">مدیریت</a></dd>
						<dt>یادآورهای فعال</dt>
						<dd><?php echo esc_html( number_format_i18n( $active_reminders ) ); ?></dd>
						<dt>اعلان‌های ثبت‌شده</dt>
						<dd><?php echo esc_html( number_format_i18n( $notifications ) ); ?></dd>
						<dt>اعتبار شارژشده (کل)</dt>
						<dd><?php echo esc_html( number_format_i18n( $granted ) ); ?></dd>
						<dt>ماندهٔ کیف پول کاربران</dt>
						<dd><?php echo esc_html( number_format_i18n( $balance_total ) ); ?> <span class="description">(درآمد نیست)</span></dd>
					</ul>
				</section>
			</div>

			<h2>مصرف بر پایه‌ی نوع</h2>
			<table class="widefat striped" style="max-width:640px">
				<thead><tr><th>نوع</th><th>تعداد</th><th>اعتبار</th></tr></thead>
				<tbody>
				<?php if ( $by_kind ) : ?>
					<?php foreach ( $by_kind as $row ) : ?>
						<tr>
							<td><?php echo esc_html( (string) $row['kind'] ); ?></td>
							<td><?php echo esc_html( (string) $row['calls'] ); ?></td>
							<td><?php echo esc_html( (string) $row['credits'] ); ?></td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr><td colspan="3">هنوز مصرفی ثبت نشده است.</td></tr>
				<?php endif; ?>
				</tbody>
			</table>

			<h2 id="niva-review-queue">صف بازبینی پزشک</h2>
			<p>پاسخ‌هایی که فیلتر ایمنی آن‌ها را پرچم زده است، این‌جا جمع می‌شوند تا بازبین پزشکی بررسی کند.</p>
			<table class="widefat striped">
				<thead><tr><th>زمان</th><th>دلیل</th><th>کاربر</th><th>پاسخ</th><th>وضعیت</th></tr></thead>
				<tbody>
				<?php if ( $reviews ) : ?>
					<?php foreach ( $reviews as $row ) : ?>
						<?php $payload = json_decode( (string) $row['payload'], true ); ?>
						<tr>
							<td><?php echo esc_html( Niva_Chrome::format_datetime( (string) $row['created_at'] ) ); ?></td>
							<td><code><?php echo esc_html( (string) $row['reason'] ); ?></code></td>
							<td><?php echo esc_html( (string) $row['user_id'] ); ?></td>
							<td><?php echo esc_html( mb_substr( (string) ( $payload['reply'] ?? '' ), 0, 180 ) ); ?></td>
							<td>
								<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
									<input type="hidden" name="action" value="dr_niva_review" />
									<input type="hidden" name="id" value="<?php echo esc_attr( (string) $row['id'] ); ?>" />
									<?php wp_nonce_field( 'dr_niva_review' ); ?>
									<button class="button button-small" type="submit">بررسی شد</button>
								</form>
							</td>
						</tr>
					<?php endforeach; ?>
				<?php else : ?>
					<tr><td colspan="5">موردی در صف نیست.</td></tr>
				<?php endif; ?>
				</tbody>
			</table>
		<?php
		Niva_Admin_Shell::close();
	}

	/**
	 * Users with any real activity in the last 30 days.
	 *
	 * Union of "used the product" (usage rows) and "was seen recently"
	 * (wallets whose quota day is recent) — no synthetic activity counter.
	 */
	private function active_users_30d() : int {
		global $wpdb;
		$usage_table  = Niva_DB::table( 'usage' );
		$wallet_table = Niva_DB::table( 'wallets' );
		$since        = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) . ' -30 days' ) );
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT user_id) FROM (
					SELECT user_id FROM {$usage_table} WHERE created_at >= %s
					UNION
					SELECT user_id FROM {$wallet_table} WHERE updated_at >= %s
				) AS niva_active",
				$since,
				$since
			)
		);
	}

	/** Human label for a user id, used by the dashboard and the audit log. */
	private function user_label( int $user_id ) : string {
		if ( $user_id <= 0 ) {
			return '—';
		}
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return '#' . $user_id;
		}
		$name = trim( (string) $user->first_name . ' ' . (string) $user->last_name );
		if ( '' === $name ) {
			$name = (string) $user->display_name;
		}
		return $name;
	}

	/* ----------------------------------------------------------------- saving */

	/**
	 * Builds (or repairs) the «منوی اصلی دکتر نیوا» header menu.
	 *
	 * WordPress's importer skips nav menu items when the menu term is missing,
	 * so the menu is created from PHP on request instead of relying on the WXR.
	 */
	public function build_menu() : void {
		$this->guard();
		check_admin_referer( 'dr_niva_build_menu' );

		$report = Niva_Menu::ensure();
		wp_safe_redirect(
			add_query_arg(
				array( 'page' => 'dr-niva-tools', 'menu_report' => rawurlencode( Niva_Menu::summary( $report ) ) ),
				admin_url( 'admin.php' )
			)
		);
		exit;
	}

	/**
	 * Saves the per-module allowed plans from «ابزارها و دسترسی».
	 *
	 * The multi-select is written back as the same space-tolerant line format the
	 * site already stores, so older installs and the plain-text field keep
	 * reading the exact same data.
	 */
	public function save_gates() : void {
		$this->guard();
		check_admin_referer( 'dr_niva_save_gates' );

		$allowed = isset( $_POST['allowed'] ) ? (array) wp_unslash( $_POST['allowed'] ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$plans   = array_keys( Niva_Plans::labels() );
		$map     = Niva_Modules::map();

		$lines = array();
		foreach ( $allowed as $module_id => $plan_list ) {
			$module_id = sanitize_key( (string) $module_id );
			if ( ! isset( $map[ $module_id ] ) ) {
				continue;
			}
			$clean = array_values( array_intersect( array_map( 'sanitize_key', (array) $plan_list ), $plans ) );
			// An empty selection means "no lock": keeping the module out of the
			// list is how the runtime already interprets an absent rule.
			if ( ! $clean ) {
				continue;
			}
			$lines[] = $module_id . ' = ' . implode( ',', $clean );
		}

		$this->settings->update( array( 'feature_plan_gates' => implode( "\n", $lines ) ) );
		wp_safe_redirect( add_query_arg( array( 'page' => 'dr-niva-access', 'saved' => 1 ), admin_url( 'admin.php' ) ) );
		exit;
	}

	public function save_settings() : void {
		$this->guard();
		check_admin_referer( 'dr_niva_save_settings' );
		$posted = isset( $_POST['dr_niva'] ) ? (array) wp_unslash( $_POST['dr_niva'] ) : array(); // phpcs:ignore
		$tab    = isset( $_POST['tab'] ) ? sanitize_key( wp_unslash( $_POST['tab'] ) ) : 'general'; // phpcs:ignore

		// Checkboxes only exist in the payload when checked: fill the rest of the tab with 0.
		$groups = Niva_Settings::groups();
		if ( isset( $groups[ $tab ] ) ) {
			foreach ( $groups[ $tab ]['fields'] as $key => $field ) {
				if ( 'toggle' === $field['type'] && ! isset( $posted[ $key ] ) ) {
					$posted[ $key ] = 0;
				}
				if ( 'secret' === $field['type'] && ( ! isset( $posted[ $key ] ) || ! is_scalar( $posted[ $key ] ) || '' === trim( (string) $posted[ $key ] ) ) ) {
					unset( $posted[ $key ] );
				}
			}
		}

		$this->settings->update( $posted );
		$area = Niva_Admin_Shell::area_for_group( (string) $tab );
		wp_safe_redirect( add_query_arg( 'saved', '1', Niva_Admin_Shell::url( $area, '' ) ) . '#niva-group-' . $tab );
		exit;
	}

	/** Runs a small server-side GapGPT request without displaying or storing the API key. */
	public function test_ai() : void {
		$this->guard();
		check_admin_referer( 'dr_niva_test_ai' );

		$mode    = isset( $_POST['mode'] ) ? sanitize_key( wp_unslash( $_POST['mode'] ) ) : ''; // phpcs:ignore
		$started = microtime( true );
		$result  = null;

		if ( 'chat' === $mode ) {
			$result = dr_niva()->ai->chat(
				array( array( 'role' => 'user', 'content' => 'فقط بنویس: اتصال موفق است.' ) ),
				array(
					'provider'    => 'gapgpt',
					'model'       => trim( (string) $this->settings->get( 'ai_model_chat', '' ) ) ?: 'gpt-6-luna',
					'max_tokens'  => 24,
					'temperature' => 0,
				)
			);
		} elseif ( 'vision' === $mode ) {
			$file = $_FILES['test_image'] ?? null; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			if ( ! is_array( $file ) || ! isset( $file['tmp_name'], $file['error'], $file['size'], $file['name'] ) || ! is_string( $file['tmp_name'] ) || ! is_string( $file['name'] ) || ! is_scalar( $file['error'] ) || ! is_numeric( $file['size'] ) || (int) $file['size'] < 1 || UPLOAD_ERR_OK !== (int) $file['error'] || ! is_uploaded_file( $file['tmp_name'] ) ) {
				$result = new WP_Error( 'niva_ai_test_image', 'برای آزمون تصویر، یک تصویر آزمایش معتبر انتخاب کن.' );
			} elseif ( (int) $file['size'] > 5 * MB_IN_BYTES ) {
				$result = new WP_Error( 'niva_ai_test_image_size', 'حجم تصویر آزمون باید حداکثر ۵ مگابایت باشد.' );
			} else {
				$filetype = wp_check_filetype_and_ext( $file['tmp_name'], sanitize_file_name( $file['name'] ) );
				$image    = function_exists( 'getimagesize' ) ? getimagesize( $file['tmp_name'] ) : false;
				$mime     = isset( $filetype['type'] ) ? (string) $filetype['type'] : '';
				if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) || ! is_array( $image ) || ( $image['mime'] ?? '' ) !== $mime ) {
					$result = new WP_Error( 'niva_ai_test_image_type', 'فقط تصویر معتبر JPG، PNG یا WebP برای آزمون پذیرفته می‌شود.' );
				} else {
					$contents = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
					$result   = false === $contents
						? new WP_Error( 'niva_ai_test_image_read', 'خواندن تصویر آزمون ممکن نشد.' )
						: dr_niva()->ai->read_document(
							'data:' . $mime . ';base64,' . base64_encode( $contents ),
							'این فقط آزمون اتصال و توانایی دریافت تصویر است. تصویر را بررسی نکن و هیچ دادهٔ آن را استخراج نکن. فقط JSON معتبر {"ok":true,"readable":true} برگردان.'
						);
					unset( $contents );
				}
			}
		} else {
			$result = new WP_Error( 'niva_ai_test_mode', 'نوع آزمون معتبر نیست.' );
		}

		$elapsed = max( 0, (int) round( ( microtime( true ) - $started ) * 1000 ) );
		if ( is_wp_error( $result ) ) {
			$message = $result->get_error_message();
			$key     = (string) $this->settings->get( 'ai_key_gapgpt', '' );
			if ( '' !== $key ) {
				$message = str_replace( $key, '[کلید پنهان شد]', $message );
			}
			$report = array(
				'success' => false,
				'message' => sanitize_textarea_field( wp_trim_words( wp_strip_all_tags( $message ), 40, '…' ) ),
				'elapsed' => $elapsed,
			);
		} else {
			if ( 'vision' === $mode && ( empty( $result['data']['ok'] ) || empty( $result['data']['readable'] ) ) ) {
				$report = array(
					'success' => false,
					'message' => 'API پاسخ داد اما آزمون دریافت تصویر را تأیید نکرد؛ مدل انتخابی یا پشتیبانی تصویر را بررسی کن.',
					'elapsed' => $elapsed,
				);
			} else {
				$model  = (string) ( $result['model'] ?? ( trim( (string) $this->settings->get( 'ai_model_chat', '' ) ) ?: 'gpt-6-luna' ) );
				$report = array(
					'success' => true,
					'model'   => sanitize_text_field( $model ),
					'elapsed' => $elapsed,
				);
			}
		}

		set_transient( 'dr_niva_ai_test_' . get_current_user_id(), $report, 2 * MINUTE_IN_SECONDS );
		wp_safe_redirect( Niva_Admin_Shell::url( Niva_Admin_Shell::area_for_group( 'ai' ), '' ) . '&ai_test=1#niva-group-ai' );
		exit;
	}

	private function ai_test_panel() : void {
		if ( isset( $_GET['ai_test'] ) && get_transient( 'dr_niva_ai_test_' . get_current_user_id() ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$report = get_transient( 'dr_niva_ai_test_' . get_current_user_id() );
			delete_transient( 'dr_niva_ai_test_' . get_current_user_id() );
			if ( ! empty( $report['success'] ) ) {
				printf(
					'<div class="notice notice-success inline"><p>آزمون موفق بود. مدل: <code>%1$s</code> · زمان پاسخ: %2$s میلی‌ثانیه</p></div>',
					esc_html( (string) ( $report['model'] ?? '' ) ),
					esc_html( (string) ( $report['elapsed'] ?? 0 ) )
				);
			} else {
				printf(
					'<div class="notice notice-error inline"><p>آزمون ناموفق بود: %1$s · زمان: %2$s میلی‌ثانیه</p></div>',
					esc_html( (string) ( $report['message'] ?? 'پاسخ معتبر دریافت نشد.' ) ),
					esc_html( (string) ( $report['elapsed'] ?? 0 ) )
				);
			}
		}
		?>
		<div class="niva-fields">
			<div class="niva-field">
				<div class="niva-field__label">
					<strong>آزمون اتصال و مدل</strong>
					<span class="niva-field__hint">ابتدا کلید API و شناسهٔ مدل را ذخیره کن. آزمون چت به GapGPT درخواست متنی کوتاه می‌فرستد؛ برای آزمون تصویر، تصویر آزمایشی بدون اطلاعات شخصی انتخاب کن. تصویر برای آزمون به GapGPT فرستاده می‌شود و دادهٔ آزمایش ذخیره نمی‌شود.</span>
				</div>
				<div class="niva-field__control">
					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" enctype="multipart/form-data">
						<input type="hidden" name="action" value="dr_niva_test_ai" />
						<?php wp_nonce_field( 'dr_niva_test_ai' ); ?>
						<input type="file" name="test_image" accept="image/jpeg,image/png,image/webp" />
						<p>
							<button type="submit" class="button" name="mode" value="chat">آزمون چت متنی</button>
							<button type="submit" class="button" name="mode" value="vision">آزمون تحلیل تصویر</button>
						</p>
					</form>
				</div>
			</div>
		</div>
		<?php
	}

	public function save_layout() : void {
		$this->guard();
		check_admin_referer( 'dr_niva_save_layout' );

		$rows = isset( $_POST['rows'] ) ? (array) wp_unslash( $_POST['rows'] ) : array(); // phpcs:ignore
		$move = isset( $_POST['move'] ) ? sanitize_text_field( wp_unslash( $_POST['move'] ) ) : ''; // phpcs:ignore

		if ( $move && false !== strpos( $move, ':' ) ) {
			list( $id, $direction ) = explode( ':', $move, 2 );
			$current                = $this->layout->all();
			$ids                    = wp_list_pluck( $current, 'id' );
			$position               = array_search( $id, $ids, true );
			if ( false !== $position ) {
				$target = 'up' === $direction ? $position - 1 : $position + 1;
				if ( $target >= 0 && $target < count( $current ) ) {
					$temp                  = $current[ $position ];
					$current[ $position ]  = $current[ $target ];
					$current[ $target ]    = $temp;
				}
				$rows = $current;
			}
		}

		$this->layout->update( $rows );
		wp_safe_redirect( add_query_arg( 'saved', '1', Niva_Admin_Shell::url( Niva_Admin_Shell::area_for_group( 'layout' ), '' ) ) . '#niva-group-layout' );
		exit;
	}

	public function handle_review() : void {
		$this->guard();
		check_admin_referer( 'dr_niva_review' );
		global $wpdb;
		$id = isset( $_POST['id'] ) ? absint( wp_unslash( $_POST['id'] ) ) : 0; // phpcs:ignore
		if ( $id ) {
			$wpdb->update( Niva_DB::table( 'reviews' ), array( 'status' => 'reviewed' ), array( 'id' => $id ), array( '%s' ), array( '%d' ) );
		}
		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva&reviewed=1' ) );
		exit;
	}

	private function guard() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
	}

	private function notice() : void {
		if ( isset( $_GET['saved'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>ذخیره شد.</p></div>';
		}
		if ( isset( $_GET['reviewed'] ) ) { // phpcs:ignore
			echo '<div class="notice notice-success is-dismissible"><p>مورد از صف بازبینی خارج شد.</p></div>';
		}
	}

	/* ------------------------------------------------------- plan editor */

	/** Save the plan table (prices, discounts, limits and switches). */
	public function save_plans() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( 'برای این کار دسترسی نداری.' );
		}
		check_admin_referer( 'dr_niva_save_plans' );

		$posted   = isset( $_POST['plans'] ) ? (array) wp_unslash( $_POST['plans'] ) : array();
		$features = array_merge( Niva_Plans::feature_fields(), Niva_Plans::switch_fields() );
		$clean    = array();

		foreach ( array_keys( Niva_Plans::default_limits() ) as $plan ) {
			if ( ! isset( $posted[ $plan ] ) || ! is_array( $posted[ $plan ] ) ) {
				continue;
			}
			$row = array(
				'price'    => max( 0, (int) ( $posted[ $plan ]['price'] ?? 0 ) ),
				'discount' => max( 0, min( 90, (int) ( $posted[ $plan ]['discount'] ?? 0 ) ) ),
			);
			foreach ( $features as $feature => $label ) {
				$row[ $feature ] = empty( $posted[ $plan ][ $feature ] ) ? 0 : max( 0, (int) $posted[ $plan ][ $feature ] );
			}
			$clean[ $plan ] = $row;
		}

		Niva_Plans::save_plan_config( $clean );
		wp_safe_redirect( add_query_arg( 'plans_saved', '1', Niva_Admin_Shell::url( Niva_Admin_Shell::area_for_group( 'plans' ), '' ) ) . '#niva-group-plans' );
		exit;
	}

	/**
	 * The plan table: one column per plan, one row per feature. No code, no
	 * syntax to remember — the owner types numbers and ticks switches.
	 */
	public function plan_editor() : void {
		$plans    = Niva_Plans::plan_config();
		$labels   = Niva_Plans::labels();
		$features = Niva_Plans::feature_fields();
		$switches = Niva_Plans::switch_fields();
		?>
		<?php if ( isset( $_GET['plans_saved'] ) ) : ?>
			<div class="notice notice-success is-dismissible"><p>پلن‌ها ذخیره شد.</p></div>
		<?php endif; ?>

		<section class="niva-group" id="niva-group-plans" data-niva-group>
			<header class="niva-group__head">
				<h2>پلن‌ها، قیمت‌ها و امکانات</h2>
				<span class="niva-group__count">هر ستون یک پلن</span>
			</header>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dr_niva_save_plans" />
				<?php wp_nonce_field( 'dr_niva_save_plans' ); ?>

				<div class="niva-plan-editor">
					<p class="niva-field__hint">برای هر پلن، قیمت و تخفیف ماهیانه را مشخص کن. محدودیت‌ها هم در همین کارت قابل ویرایش‌اند؛ عدد ۰ یعنی بدون سقف.</p>
					<div class="niva-plan-cards">
						<?php foreach ( $plans as $key => $row ) : ?>
							<details class="niva-plan-card">
								<summary>
									<strong><?php echo esc_html( $labels[ $key ] ?? $key ); ?></strong>
									<span><?php echo esc_html( number_format_i18n( (int) $row['price'] ) ); ?> تومان در ماه</span>
								</summary>
								<div class="niva-plan-card__body">
									<label class="niva-plan-field">
										<span>قیمت ماهیانه (تومان)</span>
										<input type="number" min="0" step="1000" name="plans[<?php echo esc_attr( $key ); ?>][price]" value="<?php echo esc_attr( $row['price'] ); ?>" />
									</label>
									<label class="niva-plan-field">
										<span>تخفیف (درصد)</span>
										<input type="number" min="0" max="90" name="plans[<?php echo esc_attr( $key ); ?>][discount]" value="<?php echo esc_attr( $row['discount'] ); ?>" />
									</label>
									<h3>سقف استفاده و امکانات</h3>
									<?php foreach ( $features as $feature => $label ) : ?>
										<label class="niva-plan-field">
											<span><?php echo esc_html( $label ); ?> <small>۰ = بدون سقف</small></span>
											<input type="number" min="0" name="plans[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( $feature ); ?>]" value="<?php echo esc_attr( $row[ $feature ] ); ?>" />
										</label>
									<?php endforeach; ?>
									<?php foreach ( $switches as $feature => $label ) : ?>
										<label class="niva-plan-toggle">
											<input type="checkbox" name="plans[<?php echo esc_attr( $key ); ?>][<?php echo esc_attr( $feature ); ?>]" value="1" <?php checked( ! empty( $row[ $feature ] ) ); ?> />
											<span><?php echo esc_html( $label ); ?></span>
										</label>
									<?php endforeach; ?>
								</div>
							</details>
						<?php endforeach; ?>
					</div>
					<footer class="niva-group__foot">
						<button type="submit" class="button button-primary">ذخیرهٔ پلن‌ها</button>
					</footer>
				</div>
			</form>
		</section>
		<?php
	}

	/* ---------------------------------------------------- area page callbacks */

	public function page_brand() : void {
		$this->area_page( 'brand', 'ظاهر و برند', 'نام سرویس، شعار، رنگ‌های برند، هدر و نوار پایین، چیدمان و نشانی صفحه‌ها. هر مقدار این‌جا روی همهٔ صفحه‌های سرویس اثر می‌گذارد.' );
	}

	public function page_notify() : void {
		$this->area_page( 'notify', 'اطلاع‌رسانی', 'اعلان داخلی، پوش مرورگر، پوش اپلیکیشن و قواعد یادآور. کلیدهای محرمانه فقط به‌صورت «تنظیم‌شده / تنظیم‌نشده» نمایش داده می‌شوند و هرگز در HTML چاپ نمی‌شوند.' );
	}

	public function page_ai() : void {
		$this->area_page( 'ai', 'هوش مصنوعی', 'کلید اتصال، انتخاب مدل، لحن پاسخ، قواعد ایمنی پزشکی و رفتار تحلیل آزمایش. آزمون زندهٔ اتصال بالای همین صفحه است.' );
	}

	public function page_plans() : void {
		$this->guard();
		Niva_Admin_Shell::open(
			'plans',
			'پلن‌ها و اعتبار',
			array(
				'subtitle' => 'قیمت، دوره‌ها، سهمیه‌ها و بسته‌های اعتبار',
				'actions'  => '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=dr-niva-partners' ) ) . '">همکاران و پورسانت</a>',
			)
		);
		$this->notice();
		try {
			$this->plan_editor();
		} catch ( \Throwable $niva_error ) {
			echo '<div class="avadm-card"><p>ویرایشگر پلن بارگذاری نشد: ' . esc_html( $niva_error->getMessage() ) . '</p></div>';
		}
		$this->group_cards( Niva_Admin_Shell::group_owner()['plans'] );
		Niva_Admin_Shell::close();
	}

	public function page_payments() : void {
		$this->guard();
		Niva_Admin_Shell::open( 'payments', 'پرداخت‌ها', array( 'subtitle' => 'ووکامرس، فروشگاه‌های اپلیکیشن و سابقهٔ خرید' ) );
		$this->notice();
		$this->store_purchases_table();
		$this->group_cards( array( 'store' ) );
		Niva_Admin_Shell::close();
	}

	public function page_access() : void {
		$this->guard();
		Niva_Admin_Shell::open(
			'access',
			'ابزارها و دسترسی',
			array(
				'subtitle' => 'قفل پلنی هر ابزار',
				'actions'  => '<a class="button" href="' . esc_url( Niva_Admin_Shell::url( Niva_Admin_Shell::area_for_group( 'layout' ) ) ) . '">چیدمان و ماژول‌ها</a>'
					. '<a class="button" href="' . esc_url( Niva_Admin_Shell::url( Niva_Admin_Shell::area_for_group( 'widgets' ) ) ) . '">ویجت‌های المنتور</a>',
			)
		);
		$this->notice();
		$this->module_access_table();
		$this->lock_click_report();
		$this->group_cards( array( 'feature_access' ) );
		Niva_Admin_Shell::close();
	}

	public function page_messages() : void {
		$this->guard();
		$admin = new Niva_Messages_Admin();
		$admin->page();
	}

	public function page_health() : void {
		$this->guard();
		$health = new Niva_Health();
		$health->page();
	}

	public function page_community() : void {
		$this->guard();
		Niva_Admin_Shell::open( 'community', 'گفتگوهای کاربران', array( 'subtitle' => 'انجمن پرسش و پاسخ' ) );
		$this->notice();

		Niva_Community_Admin::instance()->render();
		$this->group_cards( array( 'community' ) );
		Niva_Admin_Shell::close();
	}

	public function page_companion() : void {
		$this->guard();
		Niva_Admin_Shell::open( 'companion', 'کدهای همراهی', array( 'subtitle' => 'دسترسی همراه بدون ساخت حساب' ) );
		$this->notice();

		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . Niva_DB::table( 'companion_codes' ) . ' ORDER BY id DESC LIMIT 50', ARRAY_A ); // phpcs:ignore
		$active  = (int) $wpdb->get_var( "SELECT COUNT(*) FROM " . Niva_DB::table( 'companion_codes' ) . " WHERE status = 'active'" ); // phpcs:ignore
		$owners  = (int) $wpdb->get_var( "SELECT COUNT(DISTINCT owner_id) FROM " . Niva_DB::table( 'companion_codes' ) . " WHERE status = 'active'" ); // phpcs:ignore
		$total   = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'companion_codes' ) ); // phpcs:ignore
		$withwallet = (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'wallets' ) ); // phpcs:ignore
		?>
		<div class="avadm-grid avadm-grid--kpi">
			<?php
			Niva_Admin_Shell::stat( 'کدهای همراهی فعال', number_format_i18n( $active ), 'در دسترس همراهان' );
			Niva_Admin_Shell::stat( 'کاربران دارای همراه', number_format_i18n( $owners ), $withwallet ? number_format_i18n( (int) round( ( $owners / $withwallet ) * 100 ) ) . '٪ کاربران فعال' : '—' );
			Niva_Admin_Shell::stat( 'کل کدهای ساخته‌شده', number_format_i18n( $total ), 'شامل ابطال‌شده و منقضی' );
			?>
		</div>
		<?php
		if ( ! $rows ) {
			Niva_Admin_Shell::empty_state( 'هنوز کد همراهی‌ای ساخته نشده است', 'کاربران از مسیر «پروفایل من → همراهی» می‌توانند کد بسازند. کدها با دامنهٔ دسترسی محدود، تاریخ انقضا و لاگ بازدید این‌جا فهرست می‌شوند.' );
		} else {
			?>
			<div class="avadm-tablewrap">
				<table class="widefat striped avadm-table">
					<thead><tr><th>کد</th><th>صاحب کد</th><th>همراه</th><th>موبایل</th><th>دامنهٔ دسترسی</th><th>وضعیت</th><th>بازدید</th><th>آخرین بازدید</th><th>انقضا</th><th>اقدام</th></tr></thead>
					<tbody>
					<?php foreach ( $rows as $row ) : ?>
						<tr>
							<td><code><?php echo esc_html( (string) $row['code'] ); ?></code></td>
							<td><?php echo esc_html( $this->user_label( (int) $row['owner_id'] ) ); ?></td>
							<td><?php echo esc_html( (string) $row['companion_name'] ); ?></td>
							<td dir="ltr"><?php echo esc_html( (string) $row['companion_phone'] ); ?></td>
							<td><?php echo esc_html( (string) $row['scopes'] ); ?></td>
							<td><span class="avadm-pill <?php echo 'active' === $row['status'] ? 'avadm-pill--ok' : 'avadm-pill--muted'; ?>"><?php echo esc_html( (string) $row['status'] ); ?></span></td>
							<td><?php echo esc_html( number_format_i18n( (int) $row['views'] ) ); ?></td>
							<td><?php echo esc_html( $row['last_view'] ? Niva_Chrome::format_datetime_gmt( (string) $row['last_view'] ) : '—' ); ?></td>
							<td><?php echo esc_html( $row['expires_at'] ? Niva_Chrome::format_datetime_gmt( (string) $row['expires_at'] ) : 'بدون انقضا' ); ?></td>
							<td>
								<?php if ( 'active' === $row['status'] ) : ?>
									<a class="button button-small" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'action' => 'dr_niva_companion_admin', 'do' => 'revoke', 'id' => (int) $row['id'] ), admin_url( 'admin-post.php' ) ), 'dr_niva_companion_admin' ) ); ?>" data-avadm-confirm="این کد همراهی ابطال شود؟ دسترسی همراه فوراً قطع می‌شود.">ابطال</a>
								<?php else : ?>
									<span class="description">—</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
			<?php
		}
		$this->group_cards( array( 'companion' ) );
		Niva_Admin_Shell::close();
	}

	public function page_users() : void {
		$this->guard();
		Niva_Admin_Shell::open( 'users', 'کاربران', array( 'subtitle' => 'مرکز دادهٔ کاربران' ) );
		$this->notice();
		Niva_Users_Admin::instance( $this->settings, $this->wallet )->render();
		$this->group_cards( Niva_Admin_Shell::group_owner()['users'] );
		Niva_Admin_Shell::close();
	}

	public function page_tools() : void {
		$this->guard();
		Niva_Admin_Shell::open(
			'tools',
			'ابزارهای تشخیصی',
			array(
				'subtitle' => 'وضعیت اجزا و لاگ‌ها',
				'actions'  => '<a class="button" href="' . esc_url( admin_url( 'admin.php?page=dr-niva-data&entity=users' ) ) . '">کاوشگر جدول‌ها</a>',
			)
		);
		$this->notice();

		$menu_report = isset( $_GET['menu_report'] ) ? sanitize_text_field( rawurldecode( wp_unslash( $_GET['menu_report'] ) ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( '' !== $menu_report ) {
			echo '<div class="avadm-card"><p style="margin:0"><strong>نتیجهٔ ساخت منو:</strong> ' . esc_html( $menu_report ) . '</p></div>';
		}
		?>
		<section class="avadm-card">
			<header class="avadm-card__head">
				<h2 class="avadm-card__title">منوی هدر دکتر نیوا</h2>
				<span class="avadm-card__note">۵ آیتم اصلی + زیرمنوها، با آیکون</span>
			</header>
			<p class="description">
				درون‌ریزکنندهٔ وردپرس آیتم‌های منوی WXR را در بعضی سایت‌ها «نامک نامعتبر» می‌بیند و بی‌صدا رد می‌کند.
				این دکمه منو را مستقیم می‌سازد (یا اگر ناقص باشد کامل می‌کند) و چیزی را که خودت دستی اضافه کرده‌ای حذف نمی‌کند.
			</p>
			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dr_niva_build_menu" />
				<?php wp_nonce_field( 'dr_niva_build_menu' ); ?>
				<button type="submit" class="button button-primary">ساخت / بازسازی منو</button>
			</form>
		</section>
		<?php
		$this->diagnostics();
		$this->audit_table();
		Niva_Admin_Shell::close();
	}

	/* -------------------------------------------------------------- fragments */

	/**
	 * «ابزارها و دسترسی» — every module with its allowed plans (multi-select),
	 * lock state, how many users can actually use it, and how often its lock was
	 * clicked in the last 14 days.
	 *
	 * Saved back into the same `feature_plan_gates` line format the site already
	 * uses ("module = plan,plan"), so old values stay valid and both the legacy
	 * text field and this screen keep working on the same data.
	 */
	private function module_access_table() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$map     = Niva_Modules::map();
		$plans   = Niva_Plans::labels();
		// Same reader the runtime uses, fed with the raw setting (both formats).
		$rules   = Niva_Plans::feature_gate_rules( (string) $this->settings->get( 'feature_plan_gates', '' ) );
		$search  = isset( $_GET['ms'] ) ? sanitize_text_field( wp_unslash( $_GET['ms'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$group   = isset( $_GET['mg'] ) ? sanitize_text_field( wp_unslash( $_GET['mg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$groups  = array_values( array_unique( wp_list_pluck( $map, 'group' ) ) );
		sort( $groups );

		global $wpdb;
		$usage = Niva_DB::table( 'usage' );
		$since = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) . ' -14 days' ) );
		$clicks = array();
		foreach ( (array) $wpdb->get_results( $wpdb->prepare( "SELECT ref, COUNT(*) hits FROM {$usage} WHERE kind = 'gate_blocked' AND created_at >= %s GROUP BY ref", $since ), ARRAY_A ) as $row ) { // phpcs:ignore WordPress.DB
			$clicks[ (string) $row['ref'] ] = (int) $row['hits'];
		}

		// How many people each plan currently covers (live membership rows).
		$counts = array();
		foreach ( (array) $wpdb->get_results( 'SELECT plan, COUNT(*) total FROM ' . Niva_DB::table( 'memberships' ) . " WHERE status = 'active' GROUP BY plan", ARRAY_A ) as $row ) { // phpcs:ignore WordPress.DB
			$counts[ (string) $row['plan'] ] = (int) $row['total'];
		}
		?>
		<section class="avadm-card">
			<header class="avadm-card__head">
				<h2 class="avadm-card__title">ابزارها و دسترسی</h2>
				<span class="avadm-card__note">هر تغییر با «ذخیرهٔ دسترسی‌ها» ثبت می‌شود</span>
			</header>

			<form method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>" class="avadm-toolbar">
				<input type="hidden" name="page" value="dr-niva-access" />
				<label class="screen-reader-text" for="niva-ms">جست‌وجوی ماژول</label>
				<input id="niva-ms" type="search" name="ms" value="<?php echo esc_attr( $search ); ?>" placeholder="نام ماژول…" />
				<label class="screen-reader-text" for="niva-mg">گروه</label>
				<select id="niva-mg" name="mg">
					<option value="">همهٔ گروه‌ها</option>
					<?php foreach ( $groups as $group_name ) : ?>
						<option value="<?php echo esc_attr( (string) $group_name ); ?>" <?php selected( $group, (string) $group_name ); ?>><?php echo esc_html( (string) $group_name ); ?></option>
					<?php endforeach; ?>
				</select>
				<button type="submit" class="button">فیلتر</button>
			</form>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>">
				<input type="hidden" name="action" value="dr_niva_save_gates" />
				<?php wp_nonce_field( 'dr_niva_save_gates' ); ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead>
							<tr>
								<th>ابزار</th>
								<th>گروه</th>
								<th>پلن‌های مجاز (چندانتخابی)</th>
								<th>وضعیت قفل</th>
								<th>کاربران دارای دسترسی</th>
								<th>کلیک قفل (۱۴ روز)</th>
							</tr>
						</thead>
						<tbody>
						<?php
						$shown = 0;
						foreach ( $map as $id => $module ) {
							if ( '' !== $search && false === mb_stripos( (string) $module['label'], $search ) && false === mb_stripos( (string) $id, $search ) ) {
								continue;
							}
							if ( '' !== $group && (string) $module['group'] !== $group ) {
								continue;
							}
							$shown++;
							$allowed = isset( $rules[ $id ] ) ? (array) $rules[ $id ] : array();
							$users   = 0;
							foreach ( $allowed as $plan_key ) {
								$users += (int) ( $counts[ $plan_key ] ?? 0 );
							}
							?>
							<tr>
								<td>
									<span class="avadm__ic" aria-hidden="true"><?php echo Niva_Icons::svg( (string) ( $module['icon'] ?? 'layers' ), 16 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
									<strong><?php echo esc_html( (string) $module['label'] ); ?></strong>
									<div class="description"><code><?php echo esc_html( (string) $id ); ?></code></div>
								</td>
								<td><?php echo esc_html( (string) $module['group'] ); ?></td>
								<td>
									<?php foreach ( $plans as $plan_key => $plan_label ) : ?>
										<label style="display:inline-flex;gap:4px;align-items:center;margin-inline-end:8px">
											<input type="checkbox" name="allowed[<?php echo esc_attr( (string) $id ); ?>][]" value="<?php echo esc_attr( (string) $plan_key ); ?>" <?php checked( in_array( (string) $plan_key, $allowed, true ) ); ?> />
											<span><?php echo esc_html( (string) $plan_label ); ?></span>
										</label>
									<?php endforeach; ?>
								</td>
								<td>
									<?php if ( ! $allowed ) : ?>
										<span class="avadm-pill avadm-pill--muted">بدون قفل</span>
									<?php else : ?>
										<span class="avadm-pill">قفل‌شده برای بقیه</span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( number_format_i18n( $users ) ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (int) ( $clicks[ $id ] ?? 0 ) ) ); ?></td>
							</tr>
						<?php } ?>
						<?php if ( ! $shown ) : ?>
							<tr><td colspan="6" class="avadm-empty">با این فیلتر ماژولی پیدا نشد.</td></tr>
						<?php endif; ?>
						</tbody>
					</table>
				</div>
				<p><button type="submit" class="button button-primary">ذخیرهٔ دسترسی‌ها</button></p>
			</form>
		</section>
		<?php
	}

	/** Real store receipts only — nothing is shown when the table is empty. */
	private function store_purchases_table() : void {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . Niva_DB::table( 'store_purchases' ) . ' ORDER BY id DESC LIMIT 50', ARRAY_A ); // phpcs:ignore
		?>
		<section class="avadm-card">
			<header class="avadm-card__head">
				<h2 class="avadm-card__title">خریدهای فروشگاهی</h2>
				<span class="avadm-card__note">کافه‌بازار و مایکت · ۵۰ مورد آخر</span>
			</header>
			<?php if ( ! $rows ) : ?>
				<?php Niva_Admin_Shell::empty_state( 'خریدی ثبت نشده است', 'با اولین تأیید رسید فروشگاه، خریدها این‌جا با وضعیت اعطا/ابطال فهرست می‌شوند.' ); ?>
			<?php else : ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>فروشگاه</th><th>کاربر</th><th>SKU</th><th>نوع</th><th>مقدار</th><th>مبلغ</th><th>وضعیت</th><th>تاریخ</th></tr></thead>
						<tbody>
						<?php foreach ( $rows as $row ) : ?>
							<tr>
								<td><?php echo esc_html( (string) $row['store'] ); ?></td>
								<td><?php echo esc_html( $this->user_label( (int) $row['user_id'] ) ); ?></td>
								<td><code><?php echo esc_html( (string) $row['sku'] ); ?></code></td>
								<td><?php echo esc_html( (string) $row['grant_type'] ); ?></td>
								<td><?php echo esc_html( (string) $row['grant_value'] ); ?></td>
								<td><?php echo esc_html( number_format_i18n( (float) $row['amount'] ) ); ?></td>
								<td><span class="avadm-pill <?php echo 'granted' === $row['status'] ? 'avadm-pill--ok' : 'avadm-pill--danger'; ?>"><?php echo esc_html( (string) $row['status'] ); ?></span></td>
								<td><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	/**
	 * Locked-tool clicks in the last 14 days.
	 *
	 * Reads the real «gate_blocked» usage rows; when there are none it says so
	 * instead of inventing demand figures.
	 */
	private function lock_click_report() : void {
		global $wpdb;
		$usage = Niva_DB::table( 'usage' );
		$since = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) . ' -14 days' ) );
		$rows  = $wpdb->get_results( $wpdb->prepare( "SELECT ref, COUNT(*) hits FROM {$usage} WHERE kind = 'gate_blocked' AND created_at >= %s GROUP BY ref ORDER BY hits DESC LIMIT 20", $since ), ARRAY_A ); // phpcs:ignore WordPress.DB
		?>
		<section class="avadm-card">
			<header class="avadm-card__head">
				<h2 class="avadm-card__title">کلیک روی قفل‌ها (۱۴ روز)</h2>
				<span class="avadm-card__note">کدام ابزار بیشترین تقاضای ارتقا را دارد</span>
			</header>
			<?php if ( ! $rows ) : ?>
				<?php Niva_Admin_Shell::empty_state( 'هنوز کلیک قفل‌شده‌ای ثبت نشده است', 'وقتی کاربری روی ابزار قفل‌شده کلیک کند و پیام ارتقا را ببیند، رویداد این‌جا ثبت می‌شود.' ); ?>
			<?php else : ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>ابزار</th><th>تعداد کلیک</th></tr></thead>
						<tbody>
						<?php foreach ( $rows as $row ) : ?>
							<tr><td><code><?php echo esc_html( (string) $row['ref'] ); ?></code></td><td><?php echo esc_html( number_format_i18n( (int) $row['hits'] ) ); ?></td></tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}

	/** Versions, table health and scheduled events — all observed, not assumed. */
	private function diagnostics() : void {
		$missing = Niva_DB::missing_tables();
		$cron    = array();
		foreach ( (array) _get_cron_array() as $timestamp => $hooks ) {
			foreach ( (array) $hooks as $hook => $events ) {
				if ( 0 === strpos( $hook, 'dr_niva' ) ) {
					$cron[ $hook ] = (int) $timestamp;
				}
			}
		}
		?>
		<div class="avadm-grid avadm-grid--2">
			<section class="avadm-card">
				<header class="avadm-card__head"><h2 class="avadm-card__title">محیط اجرا</h2></header>
				<ul class="avadm-kv">
					<dt>نسخهٔ افزونه</dt><dd><?php echo esc_html( DR_NIVA_VERSION ); ?></dd>
					<dt>نسخهٔ دیتابیس افزونه</dt><dd><?php echo esc_html( (string) get_option( 'dr_niva_db_version', '0' ) ); ?> <span class="description">(انتظار: <?php echo esc_html( Niva_DB::VERSION ); ?>)</span></dd>
					<dt>PHP</dt><dd><?php echo esc_html( PHP_VERSION ); ?></dd>
					<dt>وردپرس</dt><dd><?php echo esc_html( get_bloginfo( 'version' ) ); ?></dd>
					<dt>ووکامرس</dt><dd><?php echo class_exists( 'WooCommerce' ) ? esc_html( WC()->version ?? 'فعال' ) : 'غیرفعال'; ?></dd>
					<dt>المنتور</dt><dd><?php echo Niva_Elementor::is_active() ? 'فعال' : 'غیرفعال'; ?></dd>
					<dt>افزونهٔ فعال</dt><dd><?php echo $this->settings->is_on( 'enabled' ) ? 'بله' : 'خیر (در تنظیمات خاموش است)'; ?></dd>
				</ul>
			</section>

			<section class="avadm-card">
				<header class="avadm-card__head"><h2 class="avadm-card__title">جداول دیتابیس</h2></header>
				<?php if ( $missing ) : ?>
					<p><span class="avadm-pill avadm-pill--danger"><?php echo esc_html( number_format_i18n( count( $missing ) ) ); ?> جدول ساخته نشده</span></p>
					<ul class="avadm-kv"><dt>غایب</dt><dd><code><?php echo esc_html( implode( ', ', $missing ) ); ?></code></dd></ul>
					<p class="description">یک بازدید دیگر از پیشخوان، ساخت خودکار را دوباره تلاش می‌کند.</p>
				<?php else : ?>
					<p><span class="avadm-pill avadm-pill--ok">همهٔ <?php echo esc_html( number_format_i18n( count( Niva_DB::tables() ) ) ); ?> جدول ساخته شده‌اند</span></p>
				<?php endif; ?>
				<h3 style="margin:14px 0 6px">رویدادهای زمان‌بند</h3>
				<?php if ( $cron ) : ?>
					<ul class="avadm-kv">
						<?php foreach ( $cron as $hook => $stamp ) : ?>
							<dt><code><?php echo esc_html( $hook ); ?></code></dt>
							<dd><?php echo esc_html( Niva_Chrome::format_datetime_gmt( gmdate( 'Y-m-d H:i:s', $stamp ) ) ); ?></dd>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p class="description">هیچ رویداد زمان‌بندی‌شده‌ای برای افزونه ثبت نشده است.</p>
				<?php endif; ?>
			</section>
		</div>
		<?php
	}

	/** The admin audit log: who opened whose record and when. */
	private function audit_table() : void {
		global $wpdb;
		$rows = $wpdb->get_results( 'SELECT * FROM ' . Niva_DB::table( 'audit_log' ) . ' ORDER BY id DESC LIMIT 50', ARRAY_A ); // phpcs:ignore
		?>
		<section class="avadm-card">
			<header class="avadm-card__head">
				<h2 class="avadm-card__title">لاگ مدیریت</h2>
				<span class="avadm-card__note">۵۰ رویداد آخر · برای حریم خصوصی دادهٔ سلامت</span>
			</header>
			<?php if ( ! $rows ) : ?>
				<?php Niva_Admin_Shell::empty_state( 'لاگی ثبت نشده است', 'هر بار که مدیری پروندهٔ یک کاربر را باز کند یا عملیات گروهی اجرا شود، یک رویداد این‌جا ثبت می‌شود.' ); ?>
			<?php else : ?>
				<div class="avadm-tablewrap">
					<table class="widefat striped avadm-table">
						<thead><tr><th>زمان</th><th>مدیر</th><th>کاربر هدف</th><th>عملیات</th><th>مرجع</th></tr></thead>
						<tbody>
						<?php foreach ( $rows as $row ) : ?>
							<tr>
								<td><?php echo esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ); ?></td>
								<td><?php echo esc_html( $this->user_label( (int) $row['admin_id'] ) ); ?></td>
								<td><?php echo esc_html( $this->user_label( (int) $row['target_user_id'] ) ); ?></td>
								<td><code><?php echo esc_html( (string) $row['action'] ); ?></code></td>
								<td><?php echo esc_html( (string) $row['ref'] ); ?></td>
							</tr>
						<?php endforeach; ?>
						</tbody>
					</table>
				</div>
			<?php endif; ?>
		</section>
		<?php
	}
}
