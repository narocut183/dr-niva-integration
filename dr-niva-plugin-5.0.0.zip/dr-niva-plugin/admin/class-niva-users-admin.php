<?php
/**
 * User data centre (2.0.0).
 *
 * One screen where an administrator can find a person, see everything the
 * product knows about them across six tabs, act on them in bulk, and export
 * the list. Every figure comes from a real table or meta row; nothing is
 * sampled, estimated or hard-coded.
 *
 * Privacy: opening a person's record writes a row to niva_audit_log, because
 * this screen exposes health data.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Users_Admin {

	/** @var Niva_Settings */
	private $settings;

	/** @var Niva_Wallet */
	private $wallet;

	/** How many rows the inactive / active filters will look at. */
	private const SCAN_CAP = 5000;

	private static $instance = null;

	/** One shared instance (boot + screen must not register the hooks twice). */
	public static function instance( Niva_Settings $settings, Niva_Wallet $wallet ) : self {
		if ( null === self::$instance ) {
			self::$instance = new self( $settings, $wallet );
		}
		return self::$instance;
	}

	public function __construct( Niva_Settings $settings, Niva_Wallet $wallet ) {
		$this->settings = $settings;
		$this->wallet   = $wallet;

		add_action( 'admin_post_dr_niva_users_bulk', array( $this, 'handle_bulk' ) );
		add_action( 'admin_post_dr_niva_users_csv', array( $this, 'handle_csv' ) );
		add_action( 'admin_post_dr_niva_users_export', array( $this, 'handle_export' ) );
		add_action( 'admin_post_dr_niva_users_revoke_companions', array( $this, 'handle_revoke_companions' ) );
		add_action( 'admin_post_dr_niva_users_delete_health', array( $this, 'handle_delete_health' ) );
	}

	private function plans() : Niva_Plans {
		return dr_niva()->plans instanceof Niva_Plans ? dr_niva()->plans : new Niva_Plans();
	}

	private function profile( int $user_id ) : array {
		return dr_niva()->profile instanceof Niva_Profile ? dr_niva()->profile->get( $user_id ) : array();
	}

	/* ------------------------------------------------------------------ screen */

	public function render() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$user_id = isset( $_GET['user'] ) ? absint( wp_unslash( $_GET['user'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( $user_id ) {
			$this->detail( $user_id );
			return;
		}

		$args   = $this->read_args();
		$result = $this->query_users( $args );
		$this->toolbar( $args, $result['total'] );
		$this->table( $result['ids'], $args, $result['total'] );
	}

	/** Query arguments coming from the toolbar (all read-only, all sanitised). */
	private function read_args() : array {
		// phpcs:disable WordPress.Security.NonceVerification.Recommended -- read-only list filters.
		return array(
			's'        => isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '',
			'plan'     => isset( $_GET['plan'] ) ? sanitize_key( wp_unslash( $_GET['plan'] ) ) : '',
			'profile'  => isset( $_GET['profile'] ) ? sanitize_key( wp_unslash( $_GET['profile'] ) ) : '',
			'pregnant' => isset( $_GET['pregnant'] ) ? sanitize_key( wp_unslash( $_GET['pregnant'] ) ) : '',
			'baby'     => isset( $_GET['baby'] ) ? sanitize_key( wp_unslash( $_GET['baby'] ) ) : '',
			'inactive' => isset( $_GET['inactive'] ) ? absint( wp_unslash( $_GET['inactive'] ) ) : 0,
			'from'     => isset( $_GET['from'] ) ? sanitize_text_field( wp_unslash( $_GET['from'] ) ) : '',
			'to'       => isset( $_GET['to'] ) ? sanitize_text_field( wp_unslash( $_GET['to'] ) ) : '',
			'orderby'  => isset( $_GET['orderby'] ) ? sanitize_key( wp_unslash( $_GET['orderby'] ) ) : 'registered',
			'order'    => isset( $_GET['order'] ) && 'asc' === strtolower( (string) wp_unslash( $_GET['order'] ) ) ? 'asc' : 'desc',
			'paged'    => isset( $_GET['paged'] ) ? max( 1, absint( wp_unslash( $_GET['paged'] ) ) ) : 1,
			'per_page' => isset( $_GET['per_page'] ) ? min( 200, max( 10, absint( wp_unslash( $_GET['per_page'] ) ) ) ) : 25,
		);
		// phpcs:enable
	}

	/**
	 * Runs the user query, returning ids + total.
	 *
	 * Sortable keys are limited to ones WordPress can order by natively
	 * (registered, display_name, email, ID) plus the denormalised plan meta,
	 * so pagination stays correct instead of sorting only the visible page.
	 */
	private function query_users( array $args ) : array {
		$meta_query = array( 'relation' => 'AND' );

		if ( '1' === $args['pregnant'] ) {
			$meta_query[] = array( 'key' => 'niva_pregnant', 'value' => '1' );
		} elseif ( '0' === $args['pregnant'] ) {
			$meta_query[] = array( 'key' => 'niva_pregnant', 'value' => '0' );
		}
		if ( '1' === $args['baby'] ) {
			$meta_query[] = array( 'key' => 'niva_has_baby', 'value' => '1' );
		} elseif ( '0' === $args['baby'] ) {
			$meta_query[] = array( 'key' => 'niva_has_baby', 'value' => '0' );
		}
		if ( 'complete' === $args['profile'] ) {
			$meta_query[] = array( 'key' => 'niva_profile_completed', 'value' => '1' );
		} elseif ( 'incomplete' === $args['profile'] ) {
			$meta_query[] = array( 'key' => 'niva_profile_completed', 'value' => '0' );
		}
		if ( '' !== $args['plan'] ) {
			$meta_query[] = array( 'key' => 'niva_plan', 'value' => $args['plan'] );
		}

		$query = array(
			'fields'      => 'ID',
			'number'      => $args['per_page'],
			'offset'      => ( $args['paged'] - 1 ) * $args['per_page'],
			'count_total' => true,
			'order'       => strtoupper( $args['order'] ),
		);

		if ( count( $meta_query ) > 1 ) {
			$query['meta_query'] = $meta_query; // phpcs:ignore WordPress.DB.SlowDBQuery
		}
		if ( '' !== $args['s'] ) {
			$query['search']         = '*' . $args['s'] . '*';
			$query['search_columns'] = array( 'user_login', 'user_email', 'user_nicename', 'display_name' );
		}

		$order_map = array(
			'registered' => 'registered',
			'name'       => 'display_name',
			'email'      => 'email',
			'id'         => 'ID',
			'plan'       => 'meta_value',
		);
		$query['orderby'] = $order_map[ $args['orderby'] ] ?? 'registered';
		if ( 'plan' === $args['orderby'] ) {
			$query['meta_key'] = 'niva_plan'; // phpcs:ignore WordPress.DB.SlowDBQuery
		}

		// Join-date window (site time).
		if ( '' !== $args['from'] ) {
			$query['date_query'][] = array( 'after' => $args['from'] . ' 00:00:00', 'inclusive' => true );
		}
		if ( '' !== $args['to'] ) {
			$query['date_query'][] = array( 'before' => $args['to'] . ' 23:59:59', 'inclusive' => true );
		}

		// Inactivity is derived from real usage rows, never from a synthetic counter.
		if ( $args['inactive'] > 0 ) {
			$active = $this->active_ids( $args['inactive'] );
			if ( $active ) {
				$query['exclude'] = $active;
			}
		}

		$search = new WP_User_Query( $query );
		return array(
			'ids'   => array_map( 'intval', (array) $search->get_results() ),
			'total' => (int) $search->get_total(),
		);
	}

	/** Ids seen in the last N days, from usage rows and wallet touches. */
	private function active_ids( int $days ) : array {
		global $wpdb;
		$since = gmdate( 'Y-m-d H:i:s', strtotime( current_time( 'mysql' ) . ' -' . max( 1, $days ) . ' days' ) );
		$ids   = $wpdb->get_col( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				'SELECT user_id FROM ( SELECT user_id FROM ' . Niva_DB::table( 'usage' ) . ' WHERE created_at >= %s UNION SELECT user_id FROM ' . Niva_DB::table( 'wallets' ) . ' WHERE updated_at >= %s ) AS niva_active LIMIT %d',
				$since,
				$since,
				self::SCAN_CAP
			)
		);
		return array_map( 'intval', (array) $ids );
	}

	/* ----------------------------------------------------------------- toolbar */

	private function toolbar( array $args, int $total ) : void {
		$labels = Niva_Plans::labels();
		?>
		<form class="avadm-toolbar" method="get" action="<?php echo esc_url( admin_url( 'admin.php' ) ); ?>">
			<input type="hidden" name="page" value="dr-niva-users" />

			<label class="screen-reader-text" for="niva-u-s">جست‌وجوی کاربر</label>
			<input id="niva-u-s" type="search" name="s" value="<?php echo esc_attr( $args['s'] ); ?>" placeholder="نام، ایمیل یا نام کاربری…" />

			<label class="screen-reader-text" for="niva-u-plan">پلن</label>
			<select id="niva-u-plan" name="plan">
				<option value="">همهٔ پلن‌ها</option>
				<?php foreach ( $labels as $key => $label ) : ?>
					<option value="<?php echo esc_attr( $key ); ?>" <?php selected( $args['plan'], $key ); ?>><?php echo esc_html( $label ); ?></option>
				<?php endforeach; ?>
			</select>

			<label class="screen-reader-text" for="niva-u-profile">وضعیت پروفایل</label>
			<select id="niva-u-profile" name="profile">
				<option value="">پروفایل: همه</option>
				<option value="complete" <?php selected( $args['profile'], 'complete' ); ?>>کامل</option>
				<option value="incomplete" <?php selected( $args['profile'], 'incomplete' ); ?>>ناقص</option>
			</select>

			<label class="screen-reader-text" for="niva-u-pregnant">بارداری</label>
			<select id="niva-u-pregnant" name="pregnant">
				<option value="">بارداری: همه</option>
				<option value="1" <?php selected( $args['pregnant'], '1' ); ?>>باردار</option>
				<option value="0" <?php selected( $args['pregnant'], '0' ); ?>>غیرباردار</option>
			</select>

			<label class="screen-reader-text" for="niva-u-baby">نوزاد</label>
			<select id="niva-u-baby" name="baby">
				<option value="">نوزاد: همه</option>
				<option value="1" <?php selected( $args['baby'], '1' ); ?>>دارد</option>
				<option value="0" <?php selected( $args['baby'], '0' ); ?>>ندارد</option>
			</select>

			<label class="screen-reader-text" for="niva-u-inactive">غیرفعال بیش از</label>
			<select id="niva-u-inactive" name="inactive">
				<option value="0">فعالیت: همه</option>
				<?php foreach ( array( 7, 14, 30, 60, 90 ) as $days ) : ?>
					<option value="<?php echo esc_attr( (string) $days ); ?>" <?php selected( $args['inactive'], $days ); ?>>غیرفعال بیش از <?php echo esc_html( Niva_Chrome::digits( (string) $days ) ); ?> روز</option>
				<?php endforeach; ?>
			</select>

			<label class="screen-reader-text" for="niva-u-per">تعداد در صفحه</label>
			<select id="niva-u-per" name="per_page">
				<?php foreach ( array( 25, 50, 100 ) as $size ) : ?>
					<option value="<?php echo esc_attr( (string) $size ); ?>" <?php selected( $args['per_page'], $size ); ?>><?php echo esc_html( Niva_Chrome::digits( (string) $size ) ); ?> ردیف</option>
				<?php endforeach; ?>
			</select>

			<button type="submit" class="button">اعمال</button>
			<a class="button" href="<?php echo esc_url( admin_url( 'admin.php?page=dr-niva-users' ) ); ?>">پاک‌کردن</a>
			<span class="avadm-toolbar__spacer"></span>
			<span class="avadm-pill"><?php echo esc_html( number_format_i18n( $total ) ); ?> کاربر</span>
			<a class="button button-primary" href="<?php echo esc_url( $this->csv_url( $args ) ); ?>">خروجی CSV</a>
		</form>
		<?php
	}

	/** Builds the CSV download URL for the current filters. */
	private function csv_url( array $args ) : string {
		$url = add_query_arg(
			array_merge( $args, array( 'action' => 'dr_niva_users_csv' ) ),
			admin_url( 'admin-post.php' )
		);
		return wp_nonce_url( $url, 'dr_niva_users_csv' );
	}

	/* ------------------------------------------------------------------- table */

	private function table( array $ids, array $args, int $total ) : void {
		if ( ! $ids ) {
			Niva_Admin_Shell::empty_state( 'کاربری با این فیلترها پیدا نشد', 'عبارت جست‌وجو یا فیلترها را ساده‌تر کن.' );
			return;
		}
		$plans = Niva_Plans::labels();
		?>
		<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" id="niva-users-bulk">
			<input type="hidden" name="action" value="dr_niva_users_bulk" />
			<?php wp_nonce_field( 'dr_niva_users_bulk' ); ?>

			<div class="avadm-toolbar">
				<span class="avadm-pill">عملیات گروهی روی <b data-avadm-bulk-count>0</b> کاربر</span>
				<span class="avadm-toolbar__spacer"></span>
				<select name="bulk_action">
					<option value="">انتخاب کن…</option>
					<option value="label">افزودن برچسب</option>
					<option value="notify">ارسال اعلان داخلی</option>
					<option value="plan">صدور دستی اشتراک</option>
					<option value="credits">افزودن اعتبار</option>
				</select>
				<input type="text" name="label" placeholder="برچسب" dir="auto" />
				<select name="bulk_plan">
					<?php foreach ( $plans as $key => $label ) : ?>
						<option value="<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
				<input type="number" name="bulk_credits" min="1" step="1" placeholder="اعتبار" class="small-text" />
				<input type="text" name="bulk_message" placeholder="متن اعلان" dir="auto" class="regular-text" />
				<button type="submit" class="button" data-avadm-bulk data-avadm-bulk-confirm="این عملیات روی {n} کاربر اجرا شود؟">اجرای عملیات</button>
			</div>

			<div class="avadm-tablewrap" data-avadm-bulk-list>
				<table class="widefat striped avadm-table">
					<thead>
						<tr>
							<td><input type="checkbox" data-avadm-checkall="#niva-users-bulk" aria-label="انتخاب همه" /></td>
							<th><a href="<?php echo esc_url( $this->sort_url( $args, 'name' ) ); ?>">نام و نام خانوادگی</a></th>
							<th>موبایل</th>
							<th><a href="<?php echo esc_url( $this->sort_url( $args, 'email' ) ); ?>">ایمیل</a></th>
							<th><a href="<?php echo esc_url( $this->sort_url( $args, 'plan' ) ); ?>">پلن و انقضا</a></th>
							<th>اعتبار کیف پول</th>
							<th>مصرف سهمیهٔ امروز</th>
							<th>وضعیت پروفایل</th>
							<th><a href="<?php echo esc_url( $this->sort_url( $args, 'registered' ) ); ?>">عضویت</a></th>
							<th>گفتگو</th>
							<th>یادآور</th>
							<th>همراهی</th>
							<th>عملیات</th>
						</tr>
					</thead>
					<tbody>
					<?php foreach ( $ids as $id ) : ?>
						<?php $row = $this->row( $id, $plans ); ?>
						<tr>
							<td><input type="checkbox" name="ids[]" value="<?php echo esc_attr( (string) $id ); ?>" aria-label="انتخاب کاربر <?php echo esc_attr( $row['name'] ); ?>" /></td>
							<td>
								<strong><?php echo esc_html( $row['name'] ); ?></strong>
								<?php if ( $row['labels'] ) : ?>
									<div><?php foreach ( $row['labels'] as $label ) : ?><span class="avadm-pill avadm-pill--muted"><?php echo esc_html( $label ); ?></span> <?php endforeach; ?></div>
								<?php endif; ?>
							</td>
							<td dir="ltr"><?php echo esc_html( $row['phone'] ); ?></td>
							<td dir="ltr"><a href="mailto:<?php echo esc_attr( $row['email'] ); ?>"><?php echo esc_html( $row['email'] ); ?></a></td>
							<td>
								<span class="avadm-pill <?php echo $row['plan_active'] ? 'avadm-pill--ok' : 'avadm-pill--muted'; ?>"><?php echo esc_html( $row['plan_label'] ); ?></span>
								<?php if ( $row['plan_expires'] ) : ?><div class="description">تا <?php echo esc_html( $row['plan_expires'] ); ?></div><?php endif; ?>
							</td>
							<td><?php echo esc_html( number_format_i18n( $row['balance'] ) ); ?></td>
							<td><?php echo esc_html( $row['quota'] ); ?></td>
							<td>
								<?php if ( $row['profile_complete'] ) : ?>
									<span class="avadm-pill avadm-pill--ok">۱۰۰٪</span>
								<?php else : ?>
									<span class="avadm-pill avadm-pill--warn"><?php echo esc_html( Niva_Chrome::digits( (string) $row['profile_percent'] ) ); ?>٪</span>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( $row['registered'] ); ?><div class="description"><?php echo esc_html( $row['last_active'] ); ?></div></td>
							<td><?php echo esc_html( number_format_i18n( $row['chats'] ) ); ?></td>
							<td><?php echo esc_html( number_format_i18n( $row['reminders'] ) ); ?></td>
							<td>
								<?php if ( $row['companions'] ) : ?>
									<span class="avadm-pill avadm-pill--ok"><?php echo esc_html( Niva_Chrome::digits( (string) $row['companions'] ) ); ?> فعال</span>
								<?php else : ?>
									<span class="avadm-pill avadm-pill--muted">ندارد</span>
								<?php endif; ?>
							</td>
							<td><a class="button button-small" href="<?php echo esc_url( $this->detail_url( $id ) ); ?>">پرونده</a></td>
						</tr>
					<?php endforeach; ?>
					</tbody>
				</table>
			</div>
		</form>
		<?php
		$this->pagination( $args, $total );
	}

	private function row( int $id, array $plans ) : array {
		$user    = get_userdata( $id );
		$profile = $this->profile( $id );
		$plan    = $this->plans()->plan_of( $id );
		$wallet  = $this->wallet->summary( $id );

		global $wpdb;
		$chats     = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'chats' ) . ' WHERE user_id = %d', $id ) ); // phpcs:ignore WordPress.DB
		$reminders = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'reminders' ) . ' WHERE user_id = %d AND done = 0', $id ) ); // phpcs:ignore WordPress.DB
		$companion = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'companion_codes' ) . " WHERE owner_id = %d AND status = 'active'", $id ) ); // phpcs:ignore WordPress.DB
		$last      = $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(created_at) FROM ' . Niva_DB::table( 'usage' ) . ' WHERE user_id = %d', $id ) ); // phpcs:ignore WordPress.DB

		$name = trim( (string) ( $profile['full_name'] ?? '' ) );
		if ( '' === $name && $user ) {
			$name = (string) $user->display_name;
		}
		$completion = isset( $profile['completion'] ) && is_array( $profile['completion'] ) ? $profile['completion'] : array( 'percent' => 0, 'complete' => false );

		return array(
			'name'             => $name,
			'email'            => $user ? (string) $user->user_email : '',
			'phone'            => $this->phone( $id ),
			'labels'           => array_slice( (array) get_user_meta( $id, 'niva_label', true ), 0, 4 ),
			'plan_label'       => (string) $plan['label'],
			'plan_active'      => ! empty( $plan['active'] ),
			'plan_expires'     => ! empty( $plan['expires'] ) ? Niva_Chrome::format_datetime_gmt( (string) $plan['expires'] ) : '',
			'balance'          => (int) $wallet['balance'],
			'quota'            => Niva_Chrome::digits( (string) $wallet['quota_used'] ) . ' از ' . Niva_Chrome::digits( (string) $wallet['quota_limit'] ),
			'profile_complete' => (bool) ( $completion['complete'] ?? false ),
			'profile_percent'  => (int) ( $completion['percent'] ?? 0 ),
			'registered'       => $user ? Niva_Chrome::format_datetime_gmt( (string) $user->user_registered ) : '—',
			'last_active'      => $last ? 'آخرین فعالیت: ' . Niva_Chrome::format_datetime_gmt( (string) $last ) : 'بدون فعالیت',
			'chats'            => $chats,
			'reminders'        => $reminders,
			'companions'       => $companion,
		);
	}

	/** The phone number, from whichever real source the site has. */
	private function phone( int $user_id ) : string {
		foreach ( array( 'billing_phone', 'niva_phone', 'phone' ) as $key ) {
			$value = (string) get_user_meta( $user_id, $key, true );
			if ( '' !== trim( $value ) ) {
				return $value;
			}
		}
		return '—';
	}

	private function sort_url( array $args, string $key ) : string {
		$order = ( $args['orderby'] === $key && 'asc' === $args['order'] ) ? 'desc' : 'asc';
		return add_query_arg( array_merge( $args, array( 'orderby' => $key, 'order' => $order, 'page' => 'dr-niva-users' ) ), admin_url( 'admin.php' ) );
	}

	private function detail_url( int $user_id ) : string {
		return add_query_arg( array( 'page' => 'dr-niva-users', 'user' => $user_id ), admin_url( 'admin.php' ) );
	}

	private function pagination( array $args, int $total ) : void {
		$pages = (int) ceil( $total / max( 1, $args['per_page'] ) );
		if ( $pages < 2 ) {
			return;
		}
		$links = paginate_links(
			array(
				'base'      => add_query_arg( array_merge( $args, array( 'page' => 'dr-niva-users', 'paged' => '%#%' ) ), admin_url( 'admin.php' ) ),
				'format'    => '',
				'current'   => $args['paged'],
				'total'     => $pages,
				'type'      => 'array',
				'prev_text' => 'قبلی',
				'next_text' => 'بعدی',
			)
		);
		if ( ! $links ) {
			return;
		}
		echo '<div class="avadm-toolbar"><nav class="avadm-seg" aria-label="صفحه‌بندی">';
		foreach ( $links as $link ) {
			echo wp_kses_post( $link );
		}
		echo '</nav></div>';
	}

	/* ------------------------------------------------------------------ detail */

	/** The six-tab record. Every open is written to the audit log. */
	private function detail( int $user_id ) : void {
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			Niva_Admin_Shell::empty_state( 'این کاربر پیدا نشد', 'ممکن است حساب حذف شده باشد.' );
			return;
		}

		$this->log_view( $user_id, 'user_profile_view' );

		$done     = isset( $_GET['done'] ) ? sanitize_key( wp_unslash( $_GET['done'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$messages = array(
			'export'  => 'خروجی کامل داده ساخته و دانلود شد.',
			'revoked' => 'همهٔ کدهای همراهی فعال این کاربر قطع شد.',
			'health'  => 'دادهٔ سلامت این کاربر حذف شد.',
		);
		if ( isset( $messages[ $done ] ) ) {
			echo '<div class="avadm-card"><p style="margin:0">' . esc_html( $messages[ $done ] ) . '</p></div>';
		}

		$profile = $this->profile( $user_id );
		$plan    = $this->plans()->plan_of( $user_id );
		$wallet  = $this->wallet->summary( $user_id );
		$back    = admin_url( 'admin.php?page=dr-niva-users' );

		$jalali = static function ( $gmt ) {
			return $gmt ? Niva_Chrome::format_datetime_gmt( (string) $gmt ) : '—';
		};
		?>
		<div class="avadm-toolbar">
			<a class="button" href="<?php echo esc_url( $back ); ?>">← بازگشت به فهرست</a>
			<span class="avadm-pill">شناسه: <?php echo esc_html( Niva_Chrome::digits( (string) $user_id ) ); ?></span>
			<span class="avadm-toolbar__spacer"></span>
			<a class="button" href="<?php echo esc_url( get_edit_user_link( $user_id ) ); ?>">ویرایش در وردپرس</a>
		</div>

		<div class="avadm-card">
			<div style="display:flex;gap:14px;align-items:center">
				<?php $avatar = (string) ( $profile['avatar_url'] ?? '' ); ?>
				<?php if ( '' !== $avatar ) : ?>
					<img src="<?php echo esc_url( $avatar ); ?>" alt="" width="64" height="64" style="border-radius:16px;object-fit:cover" />
				<?php else : ?>
					<span class="avadm__brand-mark" style="width:64px;height:64px;font-size:22px" aria-hidden="true"><?php echo esc_html( mb_substr( (string) ( $profile['full_name'] ?? $user->display_name ), 0, 1 ) ); ?></span>
				<?php endif; ?>
				<div>
					<h2 class="avadm-card__title"><?php echo esc_html( (string) ( $profile['full_name'] ? $profile['full_name'] : $user->display_name ) ); ?></h2>
					<div class="description">
						<span class="avadm-pill <?php echo $plan['active'] ? 'avadm-pill--ok' : 'avadm-pill--muted'; ?>"><?php echo esc_html( (string) $plan['label'] ); ?></span>
						<span class="avadm-pill">اعتبار: <?php echo esc_html( number_format_i18n( (int) $wallet['balance'] ) ); ?></span>
					</div>
				</div>
			</div>
		</div>

		<div class="avadm-tabs" role="tablist">
			<?php
			$tabs = array(
				'identity'  => 'هویت',
				'health'    => 'سلامت و پروفایل',
				'financial' => 'مالی',
				'activity'  => 'فعالیت',
				'companion' => 'همراهی',
				'privacy'   => 'حریم خصوصی و عملیات',
			);
			$first = true;
			foreach ( $tabs as $key => $label ) :
				?>
				<button type="button" role="tab" aria-selected="<?php echo $first ? 'true' : 'false'; ?>" aria-controls="niva-tab-<?php echo esc_attr( $key ); ?>"><?php echo esc_html( $label ); ?></button>
				<?php
				$first = false;
			endforeach;
			?>
		</div>

		<section class="avadm-tabpanel" id="niva-tab-identity" role="tabpanel">
			<div class="avadm-card">
				<dl class="avadm-kv">
					<dt>نام</dt><dd><?php echo esc_html( (string) ( $profile['first_name'] ?? '' ) ); ?></dd>
					<dt>نام خانوادگی</dt><dd><?php echo esc_html( (string) ( $profile['last_name'] ?? '' ) ); ?></dd>
					<dt>موبایل</dt><dd dir="ltr"><?php echo esc_html( $this->phone( $user_id ) ); ?></dd>
					<dt>ایمیل</dt><dd dir="ltr"><?php echo esc_html( (string) $user->user_email ); ?></dd>
					<dt>جنسیت</dt><dd><?php echo esc_html( $this->sex_label( (string) ( $profile['sex'] ?? '' ) ) ); ?></dd>
					<dt>تاریخ تولد</dt><dd><?php echo esc_html( $this->birth_label( $profile ) ); ?></dd>
					<dt>سن</dt><dd><?php echo esc_html( '' !== (string) ( $profile['age'] ?? '' ) ? Niva_Chrome::digits( (string) $profile['age'] ) . ' سال' : '—' ); ?></dd>
					<dt>تاریخ عضویت</dt><dd><?php echo esc_html( $jalali( $user->user_registered ) ); ?></dd>
					<dt>آخرین ورود</dt><dd><?php echo esc_html( $this->last_login( $user_id ) ); ?></dd>
				</dl>
			</div>
		</section>

		<section class="avadm-tabpanel" id="niva-tab-health" role="tabpanel" hidden>
			<div class="avadm-card">
				<dl class="avadm-kv">
					<dt>قد / وزن</dt><dd><?php echo esc_html( trim( (string) ( $profile['height'] ?? '' ) . ' / ' . (string) ( $profile['weight'] ?? '' ), ' /' ) ?: '—' ); ?></dd>
					<dt>وضعیت بارداری</dt><dd><?php echo esc_html( $this->pregnancy_label( $profile ) ); ?></dd>
					<dt>طول سیکل / مدت پریود</dt><dd><?php echo esc_html( $this->cycle_label( $profile ) ); ?></dd>
					<dt>آخرین پریود</dt><dd><?php echo esc_html( $jalali( $profile['lmp'] ?? '' ) ); ?></dd>
					<dt>نوزاد</dt><dd><?php echo esc_html( $this->baby_label( $profile ) ); ?></dd>
					<dt>یادآور فعال</dt><dd><?php echo esc_html( number_format_i18n( (int) ( $this->row( $user_id, Niva_Plans::labels() )['reminders'] ) ) ); ?></dd>
				</dl>
			</div>
		</section>

		<section class="avadm-tabpanel" id="niva-tab-financial" role="tabpanel" hidden>
			<div class="avadm-card">
				<dl class="avadm-kv">
					<dt>پلن</dt><dd><?php echo esc_html( (string) $plan['label'] ); ?> <?php echo $plan['inherited'] ? '<span class="description">(ارثی از خانواده)</span>' : ''; ?></dd>
					<dt>انقضا</dt><dd><?php echo esc_html( $jalali( $plan['expires'] ?? '' ) ); ?></dd>
					<dt>اعتبار کیف پول</dt><dd><?php echo esc_html( number_format_i18n( (int) $wallet['balance'] ) ); ?></dd>
					<dt>مصرف امروز</dt><dd><?php echo esc_html( Niva_Chrome::digits( (string) $wallet['quota_used'] ) . ' از ' . Niva_Chrome::digits( (string) $wallet['quota_limit'] ) ); ?></dd>
					<dt>مجموع مصرف (اعتبار)</dt><dd><?php echo esc_html( number_format_i18n( (int) $wallet['spent_total'] ) ); ?></dd>
				</dl>
				<?php $this->ledger_table( $user_id ); ?>
			</div>
		</section>

		<section class="avadm-tabpanel" id="niva-tab-activity" role="tabpanel" hidden>
			<div class="avadm-card">
				<?php $this->usage_table( $user_id ); ?>
			</div>
		</section>

		<section class="avadm-tabpanel" id="niva-tab-companion" role="tabpanel" hidden>
			<div class="avadm-card">
				<?php $this->companion_table( $user_id ); ?>
			</div>
		</section>

		<section class="avadm-tabpanel" id="niva-tab-privacy" role="tabpanel" hidden>
			<div class="avadm-card">
				<p>این عملیات روی دادهٔ سلامت اثر می‌گذارد و همهٔ آن‌ها در لاگ مدیریت ثبت می‌شوند.</p>
				<div class="avadm-toolbar">
					<a class="button" href="<?php echo esc_url( $this->user_action_url( 'dr_niva_users_export', $user_id ) ); ?>">خروجی کامل داده (JSON)</a>
					<a class="button" data-avadm-confirm="همهٔ کدهای همراهی این کاربر قطع شود؟" href="<?php echo esc_url( $this->user_action_url( 'dr_niva_users_revoke_companions', $user_id ) ); ?>">قطع دسترسی همراه</a>
					<a class="button" data-avadm-confirm="دادهٔ سلامت این کاربر حذف شود؟ این کار بازگشت‌پذیر نیست." href="<?php echo esc_url( $this->user_action_url( 'dr_niva_users_delete_health', $user_id ) ); ?>">حذف دادهٔ سلامت</a>
				</div>
				<?php $this->audit_table( $user_id ); ?>
			</div>
		</section>
		<?php
	}

	private function sex_label( string $sex ) : string {
		$map = array( 'female' => 'خانم', 'male' => 'آقا' );
		return $map[ $sex ] ?? '—';
	}

	private function birth_label( array $profile ) : string {
		if ( ! empty( $profile['birth_date'] ) && preg_match( '/^\d{4}-\d{2}-\d{2}$/', (string) $profile['birth_date'] ) ) {
			$jalali = Niva_Chrome::jalali( strtotime( (string) $profile['birth_date'] . ' 12:00:00' ) );
			return Niva_Chrome::digits( sprintf( '%04d/%02d/%02d', $jalali[0], $jalali[1], $jalali[2] ) );
		}
		if ( ! empty( $profile['birth_year'] ) ) {
			return Niva_Chrome::digits( (string) $profile['birth_year'] );
		}
		return '—';
	}

	private function pregnancy_label( array $profile ) : string {
		if ( empty( $profile['pregnant'] ) ) {
			return 'باردار نیست';
		}
		if ( ! empty( $profile['due_date'] ) ) {
			$weeks = (int) floor( max( 0, strtotime( (string) $profile['due_date'] ) - time() ) / WEEK_IN_SECONDS );
			return 'باردار · حدود ' . Niva_Chrome::digits( (string) max( 0, 40 - $weeks ) ) . ' هفته · زایمان ' . Niva_Chrome::format_datetime_gmt( (string) $profile['due_date'] );
		}
		return 'باردار';
	}

	private function cycle_label( array $profile ) : string {
		$length = (int) ( $profile['cycle_length'] ?? 0 );
		$period = (int) ( $profile['period_length'] ?? 0 );
		if ( ! $length && ! $period ) {
			return 'ثبت نشده';
		}
		return Niva_Chrome::digits( (string) $length ) . ' روز / ' . Niva_Chrome::digits( (string) $period ) . ' روز';
	}

	private function baby_label( array $profile ) : string {
		if ( empty( $profile['baby_birth'] ) && empty( $profile['baby_name'] ) ) {
			return 'ثبت نشده';
		}
		$age = '';
		if ( ! empty( $profile['baby_birth'] ) ) {
			$months = max( 0, (int) floor( ( time() - strtotime( (string) $profile['baby_birth'] ) ) / MONTH_IN_SECONDS ) );
			$age    = ' · ' . Niva_Chrome::digits( (string) $months ) . ' ماه';
		}
		return trim( (string) ( $profile['baby_name'] ?? '' ) ) . $age;
	}

	private function last_login( int $user_id ) : string {
		$stamp = get_user_meta( $user_id, 'niva_last_login', true );
		if ( ! $stamp ) {
			global $wpdb;
			$stamp = $wpdb->get_var( $wpdb->prepare( 'SELECT MAX(created_at) FROM ' . Niva_DB::table( 'usage' ) . ' WHERE user_id = %d', $user_id ) ); // phpcs:ignore WordPress.DB
		}
		return $stamp ? Niva_Chrome::format_datetime_gmt( (string) $stamp ) : '—';
	}

	private function ledger_table( int $user_id ) : void {
		$rows = $this->wallet->ledger( $user_id, 15, 0 );
		if ( ! $rows ) {
			echo '<p class="description">تراکنشی ثبت نشده است.</p>';
			return;
		}
		echo '<div class="avadm-tablewrap"><table class="widefat striped avadm-table"><thead><tr><th>زمان</th><th>تغییر</th><th>دلیل</th><th>مانده</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			printf(
				'<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
				esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ),
				esc_html( Niva_Chrome::digits( ( (int) $row['delta'] > 0 ? '+' : '−' ) . abs( (int) $row['delta'] ) ) ),
				esc_html( (string) $row['reason'] ),
				esc_html( number_format_i18n( (int) $row['balance_after'] ) )
			);
		}
		echo '</tbody></table></div>';
	}

	private function usage_table( int $user_id ) : void {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT kind, provider, model, cost, charged_from, created_at FROM ' . Niva_DB::table( 'usage' ) . ' WHERE user_id = %d ORDER BY id DESC LIMIT 15', $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $rows ) {
			echo '<p class="description">هنوز مصرفی برای این کاربر ثبت نشده است.</p>';
			return;
		}
		echo '<div class="avadm-tablewrap"><table class="widefat striped avadm-table"><thead><tr><th>زمان</th><th>نوع</th><th>مدل</th><th>اعتبار</th><th>منبع</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			printf(
				'<tr><td>%s</td><td><code>%s</code></td><td>%s</td><td>%s</td><td>%s</td></tr>',
				esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ),
				esc_html( (string) $row['kind'] ),
				esc_html( (string) $row['model'] ),
				esc_html( number_format_i18n( (int) $row['cost'] ) ),
				esc_html( (string) $row['charged_from'] )
			);
		}
		echo '</tbody></table></div>';
	}

	private function companion_table( int $user_id ) : void {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'companion_codes' ) . ' WHERE owner_id = %d ORDER BY id DESC', $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $rows ) {
			echo '<p class="description">این کاربر کد همراهی نساخته است.</p>';
			return;
		}
		echo '<div class="avadm-tablewrap"><table class="widefat striped avadm-table"><thead><tr><th>کد</th><th>همراه</th><th>دامنه</th><th>وضعیت</th><th>بازدید</th><th>آخرین بازدید</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			printf(
				'<tr><td><code>%s</code></td><td>%s</td><td>%s</td><td>%s</td><td>%s</td><td>%s</td></tr>',
				esc_html( (string) $row['code'] ),
				esc_html( (string) $row['companion_name'] ),
				esc_html( (string) $row['scopes'] ),
				esc_html( (string) $row['status'] ),
				esc_html( number_format_i18n( (int) $row['views'] ) ),
				esc_html( $row['last_view'] ? Niva_Chrome::format_datetime_gmt( (string) $row['last_view'] ) : '—' )
			);
		}
		echo '</tbody></table></div>';
	}

	private function audit_table( int $user_id ) : void {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'audit_log' ) . ' WHERE target_user_id = %d ORDER BY id DESC LIMIT 20', $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $rows ) {
			echo '<p class="description">رویدادی برای این کاربر ثبت نشده است.</p>';
			return;
		}
		echo '<div class="avadm-tablewrap"><table class="widefat striped avadm-table"><thead><tr><th>زمان</th><th>مدیر</th><th>عملیات</th></tr></thead><tbody>';
		foreach ( $rows as $row ) {
			printf(
				'<tr><td>%s</td><td>%s</td><td><code>%s</code></td></tr>',
				esc_html( Niva_Chrome::format_datetime_gmt( (string) $row['created_at'] ) ),
				esc_html( $this->admin_label( (int) $row['admin_id'] ) ),
				esc_html( (string) $row['action'] )
			);
		}
		echo '</tbody></table></div>';
	}

	private function admin_label( int $admin_id ) : string {
		$admin = get_userdata( $admin_id );
		return $admin ? (string) $admin->display_name : '#' . $admin_id;
	}

	/** A nonce-protected admin-post URL that targets one user. */
	private function user_action_url( string $action, int $user_id ) : string {
		return wp_nonce_url(
			add_query_arg(
				array( 'action' => $action, 'user' => $user_id ),
				admin_url( 'admin-post.php' )
			),
			$action . '_' . $user_id
		);
	}

	private function back_to_user( int $user_id, string $flag ) : void {
		wp_safe_redirect( add_query_arg( array( 'page' => 'dr-niva-users', 'user' => $user_id, 'done' => $flag ), admin_url( 'admin.php' ) ) );
		exit;
	}

	/* ------------------------------------------------------------------ actions */

	/** Records that an administrator opened a health record. */
	private function log_view( int $target, string $action, string $ref = '' ) : void {
		global $wpdb;
		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'audit_log' ),
			array(
				'admin_id'       => (int) get_current_user_id(),
				'target_user_id' => $target,
				'action'         => $action,
				'ref'            => $ref,
				'meta'           => wp_json_encode( array( 'ip' => isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '' ) ),
				'created_at'     => current_time( 'mysql', true ),
			)
		);
	}

	/** Bulk operations: label, notify, grant plan, add credits. */
	public function handle_bulk() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		check_admin_referer( 'dr_niva_users_bulk' );

		$ids    = isset( $_POST['ids'] ) ? array_map( 'absint', (array) wp_unslash( $_POST['ids'] ) ) : array(); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
		$action = isset( $_POST['bulk_action'] ) ? sanitize_key( wp_unslash( $_POST['bulk_action'] ) ) : '';
		$ids    = array_values( array_filter( $ids ) );

		if ( ! $ids || ! $action ) {
			wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-users&bulk=empty' ) );
			exit;
		}

		$done = 0;
		foreach ( $ids as $id ) {
			switch ( $action ) {
				case 'label':
					$label = isset( $_POST['label'] ) ? sanitize_text_field( wp_unslash( $_POST['label'] ) ) : '';
					if ( '' !== $label ) {
						$labels = array_slice( array_unique( array_merge( (array) get_user_meta( $id, 'niva_label', true ), array( $label ) ) ), 0, 10 );
						update_user_meta( $id, 'niva_label', $labels );
						$done++;
					}
					break;

				case 'notify':
					$message = isset( $_POST['bulk_message'] ) ? sanitize_text_field( wp_unslash( $_POST['bulk_message'] ) ) : '';
					if ( '' !== $message && class_exists( 'Niva_Notifications' ) ) {
						Niva_Notifications::notify( $id, 'پیام از تیم دکتر نیوا', $message, home_url( '/' ) );
						$done++;
					}
					break;

				case 'plan':
					$plan = isset( $_POST['bulk_plan'] ) ? sanitize_key( wp_unslash( $_POST['bulk_plan'] ) ) : '';
					if ( '' !== $plan ) {
						$this->plans()->assign( $id, $plan, 'manual', 30, 'admin_bulk:' . get_current_user_id() );
						$done++;
					}
					break;

				case 'credits':
					$amount = isset( $_POST['bulk_credits'] ) ? absint( wp_unslash( $_POST['bulk_credits'] ) ) : 0;
					if ( $amount > 0 ) {
						$this->wallet->grant( $id, $amount, 'admin_bulk', 'admin:' . get_current_user_id() );
						$done++;
					}
					break;
			}
		}

		$this->log_view( 0, 'bulk_' . $action, 'count:' . $done );
		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-users&bulk=done&count=' . $done ) );
		exit;
	}

	/** CSV export of the filtered list, UTF-8 BOM so Excel shows Persian right. */
	public function handle_csv() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		check_admin_referer( 'dr_niva_users_csv' );

		$args = $this->read_args();
		unset( $args['paged'] );
		$args['per_page'] = 200;

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=dr-niva-users-' . gmdate( 'Ymd-Hi' ) . '.csv' );

		$out = fopen( 'php://output', 'w' ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		fwrite( $out, "\xEF\xBB\xBF" ); // UTF-8 BOM
		fputcsv( $out, array( 'شناسه', 'نام', 'موبایل', 'ایمیل', 'پلن', 'انقضا', 'اعتبار', 'وضعیت پروفایل', 'عضویت', 'آخرین فعالیت', 'گفتگو', 'یادآور', 'همراهی' ) );

		$labels = Niva_Plans::labels();
		$page   = 1;
		do {
			$args['paged'] = $page;
			$result        = $this->query_users( $args );
			foreach ( $result['ids'] as $id ) {
				$row = $this->row( $id, $labels );
				fputcsv(
					$out,
					array(
						$id,
						$row['name'],
						$row['phone'],
						$row['email'],
						$row['plan_label'],
						$row['plan_expires'],
						$row['balance'],
						$row['profile_complete'] ? '100%' : $row['profile_percent'] . '%',
						$row['registered'],
						$row['last_active'],
						$row['chats'],
						$row['reminders'],
						$row['companions'],
					)
				);
			}
			$page++;
		} while ( count( $result['ids'] ) === $args['per_page'] && $page <= 200 );

		fclose( $out ); // phpcs:ignore WordPress.WP.AlternativeFunctions
		exit;
	}

	/* ------------------------------------------------------- privacy / GDPR */

	/** Full JSON export of one account, for a data-subject request. */
	public function handle_export() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		$user_id = isset( $_GET['user'] ) ? absint( wp_unslash( $_GET['user'] ) ) : 0;
		check_admin_referer( 'dr_niva_users_export_' . $user_id );

		global $wpdb;
		$user = get_userdata( $user_id );
		if ( ! $user ) {
			wp_die( esc_html__( 'کاربر پیدا نشد.', 'dr-niva' ) );
		}

		$payload = array(
			'exported_at' => current_time( 'mysql', true ),
			'account'     => array(
				'id'         => $user_id,
				'login'      => $user->user_login,
				'email'      => $user->user_email,
				'registered' => $user->user_registered,
				'display'    => $user->display_name,
			),
			'profile'     => get_user_meta( $user_id, 'niva_profile', true ),
			'wallet'      => $this->wallet->summary( $user_id ),
			'ledger'      => $this->wallet->ledger( $user_id, 500, 0 ),
			'plan'        => $this->plans()->plan_of( $user_id ),
			'usage'       => $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'usage' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'chats'       => $wpdb->get_results( $wpdb->prepare( 'SELECT id, topic, status, created_at FROM ' . Niva_DB::table( 'chats' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'reminders'   => $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'reminders' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'companions'  => $wpdb->get_results( $wpdb->prepare( 'SELECT code, companion_name, scopes, status, expires_at FROM ' . Niva_DB::table( 'companion_codes' ) . ' WHERE owner_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
		);

		$this->log_view( $user_id, 'user_data_export' );

		nocache_headers();
		header( 'Content-Type: application/json; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=dr-niva-user-' . $user_id . '-' . gmdate( 'Ymd-Hi' ) . '.json' );
		echo wp_json_encode( $payload, JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT );
		exit;
	}

	/** Immediately cuts every active companion code of one account. */
	public function handle_revoke_companions() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		$user_id = isset( $_GET['user'] ) ? absint( wp_unslash( $_GET['user'] ) ) : 0;
		check_admin_referer( 'dr_niva_users_revoke_companions_' . $user_id );

		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'companion_codes' ),
			array( 'status' => 'revoked', 'revoked_at' => current_time( 'mysql', true ) ),
			array( 'owner_id' => $user_id, 'status' => 'active' )
		);

		$this->log_view( $user_id, 'companion_revoked_all' );
		$this->back_to_user( $user_id, 'revoked' );
	}

	/**
	 * Deletes the health payload of one account.
	 *
	 * The account itself, the wallet and the ledger stay (financial and
	 * security records); only health/clinical rows and profile health fields go.
	 */
	public function handle_delete_health() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		$user_id = isset( $_GET['user'] ) ? absint( wp_unslash( $_GET['user'] ) ) : 0;
		check_admin_referer( 'dr_niva_users_delete_health_' . $user_id );

		global $wpdb;

		$stored = get_user_meta( $user_id, 'niva_profile', true );
		if ( is_array( $stored ) ) {
			$health_keys = array( 'pregnant', 'lmp', 'cycle_length', 'period_length', 'due_date', 'baby_name', 'baby_birth', 'height', 'weight', 'mood_scores', 'focus_area', 'avatar_id' );
			$defaults    = ( new Niva_Profile() )->defaults();
			foreach ( $health_keys as $key ) {
				$stored[ $key ] = $defaults[ $key ] ?? '';
			}
			update_user_meta( $user_id, 'niva_profile', $stored );
		}

		$chat_ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . Niva_DB::table( 'chats' ) . ' WHERE user_id = %d', $user_id ) ); // phpcs:ignore WordPress.DB
		foreach ( (array) $chat_ids as $chat_id ) {
			$wpdb->delete( Niva_DB::table( 'chat_messages' ), array( 'chat_id' => (int) $chat_id ) ); // phpcs:ignore WordPress.DB
		}

		foreach ( array( 'chats', 'documents', 'growth', 'reminders', 'daily_logs' ) as $table ) {
			$wpdb->delete( Niva_DB::table( $table ), array( 'user_id' => $user_id ) ); // phpcs:ignore WordPress.DB
		}

		// Derived flags used by the list filters.
		update_user_meta( $user_id, 'niva_pregnant', 0 );
		update_user_meta( $user_id, 'niva_has_baby', 0 );

		$this->log_view( $user_id, 'health_data_deleted' );
		$this->back_to_user( $user_id, 'health' );
	}
}
