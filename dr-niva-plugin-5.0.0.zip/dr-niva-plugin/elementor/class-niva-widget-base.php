<?php
/**
 * Base class for every Dr. Niva widget.
 *
 * It gives all 55 widgets the same professional Elementor control set:
 *   Content tab  → module options (title, hide tokens)
 *   Style tab    → layout & alignment, typography, colors/surfaces, card style
 *   Advanced tab → Elementor's built-in margin/padding, responsive visibility, z-index…
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

abstract class Niva_Elementor_Widget extends \Elementor\Widget_Base {

	/** Module id from includes/niva-modules-map.php. */
	protected $module_id = '';

	public function get_name() : string {
		return 'niva_' . $this->module_id;
	}

	public function get_title() : string {
		return Niva_Modules::label( $this->module_id );
	}

	public function get_icon() : string {
		return Niva_Modules::icon( $this->module_id );
	}

	public function get_categories() : array {
		return array( 'dr-niva' );
	}

	public function get_keywords() : array {
		return array( 'دکتر نیوا', 'سلامت', 'هوش مصنوعی', Niva_Modules::group( $this->module_id ) );
	}

	/** Assets load only on pages that really contain one of our widgets. */
	public function get_style_depends() : array {
		return array( 'dr-niva-base', 'dr-niva-components', 'dr-niva-pages' );
	}

	public function get_script_depends() : array {
		return array( 'dr-niva-icons', 'dr-niva-app', 'dr-niva-bridge' );
	}

	/* =====================================================================
	   Content tab
	   ===================================================================== */

	protected function register_controls() : void {
		$this->register_content_controls();
		$this->register_link_controls();
		$this->register_lock_controls();
		$this->register_layout_controls();
		$this->register_color_controls();
		$this->register_text_controls();
		$this->register_card_controls();
	}

	/**
	 * Per-element link editing.
	 *
	 * Every module that contains a link gets one URL control per link, right in
	 * the Elementor panel. Leaving a field empty keeps the global target, so a
	 * half-finished page never loses its navigation.
	 */
	protected function register_link_controls() : void {
		$links = Niva_Modules::links( $this->module_id );
		if ( ! $links ) {
			return;
		}

		$this->start_controls_section(
			'niva_links',
			array(
				'label' => 'لینک‌های این بخش',
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'niva_links_notice',
			array(
				'type'            => \Elementor\Controls_Manager::RAW_HTML,
				'raw'             => 'هر لینک را همین‌جا (داخل خود المان) عوض کن. خالی بگذاری، همان نشانی پیش‌فرضِ سایت استفاده می‌شود.',
				'content_classes' => 'elementor-descriptor',
			)
		);

		foreach ( $links as $key => $label ) {
			$resolved = Niva_Modules::url( $key );

			$this->add_control(
				'niva_link_' . $key,
				array(
					'label'         => $label,
					'type'          => \Elementor\Controls_Manager::URL,
					'placeholder'   => $resolved ? $resolved : '/',
					'description'   => $resolved ? 'پیش‌فرض: ' . $resolved : '',
					'show_external' => false,
					'dynamic'       => array( 'active' => true ),
				)
			);
		}

		$this->end_controls_section();
	}

	protected function register_content_controls() : void {
		$this->start_controls_section(
			'niva_settings',
			array(
				'label' => 'تنظیمات بخش',
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'show_title',
			array(
				'label'        => 'نمایش عنوان بالای بخش',
				'type'         => \Elementor\Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
				'description'  => 'اگر خودِ بخش عنوان دارد، با گزینه‌ی «پنهان‌کردن بخش‌های داخلی» آن را خاموش کن و از این عنوان استفاده کن.',
			)
		);

		$this->add_control(
			'title',
			array(
				'label'     => 'متن عنوان',
				'type'      => \Elementor\Controls_Manager::TEXT,
				'default'   => Niva_Modules::label( $this->module_id ),
				'condition' => array( 'show_title' => 'yes' ),
			)
		);

		$this->add_control(
			'title_tag',
			array(
				'label'     => 'تگ عنوان',
				'type'      => \Elementor\Controls_Manager::SELECT,
				'default'   => 'h2',
				'options'   => array( 'h1' => 'H1', 'h2' => 'H2', 'h3' => 'H3', 'h4' => 'H4', 'span' => 'span' ),
				'condition' => array( 'show_title' => 'yes' ),
			)
		);

		$tokens = array();
		foreach ( Niva_Modules::tokens() as $token => $label ) {
			$tokens[] = $token . ' = ' . $label;
		}

		$this->add_control(
			'hide',
			array(
				'label'       => 'پنهان‌کردن بخش‌های داخلی',
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 3,
				'placeholder' => 'heading chart print',
				'description' => 'نام‌ها را با فاصله بنویس: ' . implode( '، ', $tokens ),
			)
		);

		$this->add_control(
			'link',
			array(
				'label'         => 'لینک (اختیاری)',
				'type'          => \Elementor\Controls_Manager::URL,
				'placeholder'   => '/plans/',
				'description'   => 'اگر پر شود، کل بخش قابل کلیک می‌شود.',
				'show_external' => true,
			)
		);

		$this->end_controls_section();
	}

	/* =====================================================================
	   Plan lock — per element, always enforced server side
	   ===================================================================== */

	protected function register_lock_controls() : void {
		$this->start_controls_section(
			'niva_lock_section',
			array(
				'label' => 'قفل پلن',
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'niva_lock_mode',
			array(
				'label'       => 'رفتار برای کاربر بدون دسترسی',
				'type'        => \Elementor\Controls_Manager::SELECT,
				'default'     => 'fade',
				'options'     => array(
					'fade' => 'کارت کمرنگ با پیام ارتقا (پیشنهادی)',
					'hide' => 'کاملاً پنهان شود',
				),
				'description' => 'قفل واقعی همیشه سرورساید بررسی می‌شود؛ این گزینه فقط ظاهر را عوض می‌کند.',
			)
		);

		$this->add_control(
			'niva_lock_text',
			array(
				'label'       => 'متن جایگزین کارت قفل‌شده',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => 'این بخش نیازمند ارتقا به پلاس است',
				'description' => 'خالی بماند، متن پیش‌فرض بر اساس پلن لازم ساخته می‌شود.',
			)
		);

		$this->add_control(
			'niva_upgrade_label',
			array(
				'label'   => 'متن دکمهٔ ارتقا',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'ارتقا بده',
			)
		);

		$this->add_control(
			'niva_upgrade_url',
			array(
				'label'       => 'لینک ارتقا',
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => '/plans/',
				'description' => 'خالی بماند، به صفحهٔ پلن‌ها می‌رود.',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'niva_lock_style',
			array(
				'label' => 'قفل پلن (ظاهر)',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'niva_lock_opacity',
			array(
				'label'      => 'شفافیت کارت قفل‌شده',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( '%' ),
				'range'      => array( '%' => array( 'min' => 20, 'max' => 100 ) ),
				'default'    => array( 'unit' => '%', 'size' => 55 ),
				'selectors'  => array(
					'{{WRAPPER}} .niva-feature-locked--faded' => 'opacity: {{SIZE}}%;',
				),
			)
		);

		$this->add_control(
			'niva_lock_badge_color',
			array(
				'label'     => 'رنگ برچسب پلن لازم',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-lock-badge' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'niva_lock_icon_color',
			array(
				'label'     => 'رنگ آیکون قفل',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-feature-locked .card__icon' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'niva_lock_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ کارت قفل‌شده',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-feature-locked--faded' => 'border-color: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();
	}

	/* =====================================================================
	   Style tab — layout
	   ===================================================================== */

	protected function register_layout_controls() : void {
		$this->start_controls_section(
			'niva_style_layout',
			array(
				'label' => 'چیدمان و تراز',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'niva_text_align',
			array(
				'label'     => 'تراز متن',
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'right'  => array( 'title' => 'راست', 'icon' => 'eicon-text-align-right' ),
					'center' => array( 'title' => 'وسط', 'icon' => 'eicon-text-align-center' ),
					'left'   => array( 'title' => 'چپ', 'icon' => 'eicon-text-align-left' ),
				),
				'default'   => 'right',
				'selectors' => array( '{{WRAPPER}} .niva-module' => 'text-align: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_direction',
			array(
				'label'     => 'جهت چیدمان داخلی',
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'column' => array( 'title' => 'عمودی', 'icon' => 'eicon-editor-list-ul' ),
					'row'    => array( 'title' => 'افقی', 'icon' => 'eicon-editor-list-ol' ),
				),
				'default'   => 'column',
				'selectors' => array( '{{WRAPPER}} .niva-module' => 'flex-direction: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_gap',
			array(
				'label'      => 'فاصله‌ی بین بخش‌های داخلی',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'em' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 80, 'step' => 2 ) ),
				'selectors'  => array( '{{WRAPPER}} .niva-module' => 'gap: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_max_width',
			array(
				'label'      => 'حداکثر عرض',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array( 'px' => array( 'min' => 240, 'max' => 1400 ), '%' => array( 'min' => 20, 'max' => 100 ) ),
				'selectors'  => array( '{{WRAPPER}} .niva-module' => 'max-width: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_self_align',
			array(
				'label'     => 'جای بخش در ستون',
				'type'      => \Elementor\Controls_Manager::CHOOSE,
				'options'   => array(
					'flex-start' => array( 'title' => 'ابتدا', 'icon' => 'eicon-justify-start-h' ),
					'center'     => array( 'title' => 'وسط', 'icon' => 'eicon-justify-center-h' ),
					'flex-end'   => array( 'title' => 'انتها', 'icon' => 'eicon-justify-end-h' ),
				),
				'selectors' => array( '{{WRAPPER}} .niva-module' => 'margin-inline: auto; align-self: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_padding',
			array(
				'label'      => 'فاصله‌ی داخلی',
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array( '{{WRAPPER}} .niva-module' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_margin',
			array(
				'label'      => 'فاصله‌ی بیرونی',
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array( '{{WRAPPER}} .niva-module' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->end_controls_section();
	}

	/* =====================================================================
	   Style tab — colors / surfaces (design tokens per widget)
	   ===================================================================== */

	protected function register_color_controls() : void {
		$this->start_controls_section(
			'niva_style_colors',
			array(
				'label' => 'رنگ‌ها و سطح',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'niva_brand',
			array(
				'label'       => 'رنگ اصلی بخش',
				'type'        => \Elementor\Controls_Manager::COLOR,
				'description' => 'دکمه‌ها، لینک‌ها، آیکون‌ها و نوارهای تأکید این بخش.',
				'selectors'   => array( '{{WRAPPER}} .niva-module' => '--brand: {{VALUE}}; --color-primary: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'niva_brand_soft',
			array(
				'label'     => 'رنگ ملایم بخش',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-module' => '--brand-soft: {{VALUE}}; --color-primary-soft: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'niva_ink',
			array(
				'label'     => 'رنگ متن',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-module' => '--ink: {{VALUE}}; --color-ink: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'niva_muted',
			array(
				'label'     => 'رنگ متن کم‌رنگ',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-module' => '--ink-muted: {{VALUE}}; --color-ink-muted: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'niva_surface',
			array(
				'label'     => 'رنگ کارت‌ها',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-module' => '--card: {{VALUE}}; --color-surface: {{VALUE}};' ),
			)
		);

		$this->add_control(
			'niva_line_color',
			array(
				'label'     => 'رنگ خطوط و حاشیه‌ی بخش',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-module' => '--border: {{VALUE}}; --color-border: {{VALUE}};' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'avag_background',
				'label'    => 'پس‌زمینه‌ی بخش',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .niva-module',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'avag_border',
				'label'    => 'حاشیه‌ی بخش',
				'selector' => '{{WRAPPER}} .niva-module',
			)
		);

		$this->add_responsive_control(
			'niva_radius',
			array(
				'label'      => 'گردی گوشه',
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%' ),
				'selectors'  => array( '{{WRAPPER}} .niva-module' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}}; overflow: hidden;' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'avag_shadow',
				'label'    => 'سایه‌ی بخش',
				'selector' => '{{WRAPPER}} .niva-module',
			)
		);

		$this->end_controls_section();
	}

	/* =====================================================================
	   Style tab — typography
	   ===================================================================== */

	protected function register_text_controls() : void {
		$this->start_controls_section(
			'niva_style_text',
			array(
				'label' => 'تایپوگرافی',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'avag_body_typography',
				'label'    => 'متن بخش',
				'selector' => '{{WRAPPER}} .niva-module, {{WRAPPER}} .niva-module p, {{WRAPPER}} .niva-module li, {{WRAPPER}} .niva-module span, {{WRAPPER}} .niva-module label',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Typography::get_type(),
			array(
				'name'     => 'avag_heading_typography',
				'label'    => 'عنوان‌ها',
				'selector' => '{{WRAPPER}} .niva-module h1, {{WRAPPER}} .niva-module h2, {{WRAPPER}} .niva-module h3, {{WRAPPER}} .niva-module .card__title, {{WRAPPER}} .niva-module__title',
			)
		);

		$this->add_control(
			'niva_heading_color',
			array(
				'label'     => 'رنگ عنوان‌ها',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-module h1, {{WRAPPER}} .niva-module h2, {{WRAPPER}} .niva-module h3, {{WRAPPER}} .niva-module .card__title, {{WRAPPER}} .niva-module__title' => 'color: {{VALUE}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_line_height',
			array(
				'label'      => 'ارتفاع خط',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'em', 'px' ),
				'range'      => array( 'em' => array( 'min' => 1, 'max' => 3, 'step' => 0.05 ) ),
				'selectors'  => array( '{{WRAPPER}} .niva-module' => 'line-height: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->end_controls_section();
	}

	/* =====================================================================
	   Style tab — the cards inside a module
	   ===================================================================== */

	protected function register_card_controls() : void {
		$this->start_controls_section(
			'niva_style_cards',
			array(
				'label' => 'کارت‌های داخل بخش',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Background::get_type(),
			array(
				'name'     => 'avag_card_background',
				'label'    => 'پس‌زمینه‌ی کارت',
				'types'    => array( 'classic', 'gradient' ),
				'selector' => '{{WRAPPER}} .niva-module .card',
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			array(
				'name'     => 'avag_card_border',
				'label'    => 'حاشیه‌ی کارت',
				'selector' => '{{WRAPPER}} .niva-module .card',
			)
		);

		$this->add_responsive_control(
			'niva_card_radius',
			array(
				'label'      => 'گردی گوشه‌ی کارت',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array( 'px' => array( 'min' => 0, 'max' => 40 ) ),
				'selectors'  => array( '{{WRAPPER}} .niva-module .card' => 'border-radius: {{SIZE}}{{UNIT}};' ),
			)
		);

		$this->add_responsive_control(
			'niva_card_padding',
			array(
				'label'      => 'فاصله‌ی داخلی کارت',
				'type'       => \Elementor\Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em' ),
				'selectors'  => array( '{{WRAPPER}} .niva-module .card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};' ),
			)
		);

		$this->add_group_control(
			\Elementor\Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'avag_card_shadow',
				'label'    => 'سایه‌ی کارت',
				'selector' => '{{WRAPPER}} .niva-module .card',
			)
		);

		$this->end_controls_section();
	}

	/* =====================================================================
	   Render
	   ===================================================================== */

	protected function render() : void {
		$settings = $this->get_settings_for_display();

		// Links edited inside this element (empty ones fall back to the registry).
		$links = array();
		foreach ( array_keys( Niva_Modules::links( $this->module_id ) ) as $key ) {
			$field = 'niva_link_' . $key;
			if ( ! empty( $settings[ $field ]['url'] ) ) {
				$links[ $key ] = (string) $settings[ $field ]['url'];
			}
		}

		$html = Niva_Modules::render(
			$this->module_id,
			array(
				'hide'       => isset( $settings['hide'] ) ? $settings['hide'] : '',
				'title'      => isset( $settings['title'] ) ? $settings['title'] : '',
				'show_title' => isset( $settings['show_title'] ) && 'yes' === $settings['show_title'],
				'title_tag'  => isset( $settings['title_tag'] ) ? $settings['title_tag'] : 'h2',
				'links'      => $links,
				// Per-element lock presentation. The access decision itself is
				// still taken inside Niva_Modules::render(), server side.
				'lock_mode'     => isset( $settings['niva_lock_mode'] ) ? (string) $settings['niva_lock_mode'] : '',
				'lock_text'     => isset( $settings['niva_lock_text'] ) ? (string) $settings['niva_lock_text'] : '',
				'upgrade_label' => isset( $settings['niva_upgrade_label'] ) ? (string) $settings['niva_upgrade_label'] : '',
				'upgrade_url'   => ! empty( $settings['niva_upgrade_url']['url'] ) ? (string) $settings['niva_upgrade_url']['url'] : '',
			)
		);

		if ( $html && ! empty( $settings['link']['url'] ) ) {
			$target = ! empty( $settings['link']['is_external'] ) ? ' target="_blank"' : '';
			$nofollow = ! empty( $settings['link']['nofollow'] ) ? ' rel="nofollow"' : '';
			printf(
				'<a class="niva-module-link" href="%s"%s%s>%s</a>',
				esc_url( $settings['link']['url'] ),
				$target, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				$nofollow, // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				$html // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			);
			return;
		}

		echo $html; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}
}
