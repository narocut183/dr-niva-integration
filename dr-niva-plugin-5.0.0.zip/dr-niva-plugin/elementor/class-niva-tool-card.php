<?php
/**
 * Configurable link card for adding tools without editing plugin code.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

if ( ! class_exists( '\Elementor\Widget_Base' ) ) {
	return;
}

class Niva_Widget_Tool_Card extends \Elementor\Widget_Base {

	public function get_name() : string {
		return 'niva_tool_card';
	}

	public function get_title() : string {
		return 'کارت ابزار دکتر نیوا';
	}

	public function get_icon() : string {
		return 'eicon-apps';
	}

	public function get_categories() : array {
		return array( 'dr-niva' );
	}

	protected function register_controls() : void {
		$this->start_controls_section(
			'content',
			array(
				'label' => 'محتوای کارت',
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);
		$this->add_control(
			'title',
			array(
				'label'       => 'عنوان ابزار',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'default'     => 'ابزار جدید',
				'label_block' => true,
			)
		);
		$this->add_control(
			'description',
			array(
				'label'       => 'توضیح کوتاه',
				'type'        => \Elementor\Controls_Manager::TEXTAREA,
				'rows'        => 2,
				'default'     => '',
				'label_block' => true,
			)
		);
		$this->add_control(
			'icon',
			array(
				'label'   => 'آیکون',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'heart',
				'options' => array(
					'activity'      => 'سلامت',
					'apple'         => 'تغذیه',
					'baby'          => 'کودک',
					'book-open'     => 'راهنما',
					'calendar-days' => 'تقویم',
					'heart'         => 'قلب',
					'layers'        => 'ابزارها',
					'message-circle'=> 'مشاوره',
					'sparkles'      => 'هوشمند',
					'stethoscope'   => 'پزشکی',
				),
			)
		);
		$this->add_control(
			'link',
			array(
				'label'         => 'پیوند ابزار',
				'type'          => \Elementor\Controls_Manager::URL,
				'placeholder'   => '/dr-niva/new-tool/',
				'show_external' => true,
				'default'       => array( 'url' => '' ),
			)
		);
		$this->end_controls_section();

		/*
		 * Plan lock. A tool card is free-form, so the admin names the module it
		 * should be gated by; the actual decision is still Niva_Plans::
		 * feature_access() on the server, never this widget.
		 */
		$this->start_controls_section(
			'niva_lock_section',
			array(
				'label' => 'قفل پلن',
				'tab'   => \Elementor\Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'niva_lock_module',
			array(
				'label'       => 'شناسهٔ ماژولی که این کارت به آن قفل می‌شود',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => 'advisor_chat',
				'description' => 'خالی بماند، کارت هیچ‌وقت قفل نمی‌شود. نمونه: advisor_chat، lab_upload، baby_chart',
			)
		);

		$this->add_control(
			'niva_lock_mode',
			array(
				'label'   => 'رفتار برای کاربر بدون دسترسی',
				'type'    => \Elementor\Controls_Manager::SELECT,
				'default' => 'fade',
				'options' => array(
					'fade' => 'کارت کمرنگ با پیام ارتقا',
					'hide' => 'کاملاً پنهان شود',
				),
			)
		);

		$this->add_control(
			'niva_lock_text',
			array(
				'label'       => 'متن جایگزین کارت قفل‌شده',
				'type'        => \Elementor\Controls_Manager::TEXT,
				'placeholder' => 'این بخش نیازمند ارتقا به پلاس است',
			)
		);

		$this->add_control(
			'niva_upgrade_label',
			array(
				'label'   => 'متن دکمهٔ ارتقا',
				'type'    => \Elementor\Controls_Manager::TEXT,
				'default' => 'ارتقا بده',
			)
		);

		$this->add_control(
			'niva_upgrade_url',
			array(
				'label'       => 'لینک ارتقا',
				'type'        => \Elementor\Controls_Manager::URL,
				'placeholder' => '/plans/',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'niva_lock_style',
			array(
				'label' => 'قفل پلن (ظاهر)',
				'tab'   => \Elementor\Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'niva_lock_opacity',
			array(
				'label'      => 'شفافیت کارت قفل‌شده',
				'type'       => \Elementor\Controls_Manager::SLIDER,
				'size_units' => array( '%' ),
				'range'      => array( '%' => array( 'min' => 20, 'max' => 100 ) ),
				'default'    => array( 'unit' => '%', 'size' => 55 ),
				'selectors'  => array( '{{WRAPPER}} .niva-tool-card--locked' => 'opacity: {{SIZE}}%;' ),
			)
		);

		$this->add_control(
			'niva_lock_badge_color',
			array(
				'label'     => 'رنگ برچسب پلن لازم',
				'type'      => \Elementor\Controls_Manager::COLOR,
				'selectors' => array( '{{WRAPPER}} .niva-lock-badge' => 'color: {{VALUE}};' ),
			)
		);

		$this->end_controls_section();
	}

	protected function render() : void {
		$settings    = $this->get_settings_for_display();
		$title       = sanitize_text_field( (string) ( $settings['title'] ?? '' ) );
		$description = sanitize_text_field( (string) ( $settings['description'] ?? '' ) );
		$icon        = sanitize_key( (string) ( $settings['icon'] ?? 'heart' ) );
		$link        = isset( $settings['link']['url'] ) ? esc_url( $settings['link']['url'] ) : '';
		$tag         = $link ? 'a' : 'div';
		$attributes  = $link ? ' href="' . $link . '"' : '';
		if ( $link && ! empty( $settings['link']['is_external'] ) ) {
			$attributes .= ' target="_blank" rel="noopener noreferrer"';
		}

		/*
		 * Server-side gate. When this card names a module the current user cannot
		 * use, the shared locked rendering (faded card + upgrade sheet) replaces
		 * it — so the lock behaves exactly like it does in a module widget.
		 */
		$lock_module = sanitize_key( (string) ( $settings['niva_lock_module'] ?? '' ) );
		if ( '' !== $lock_module && is_user_logged_in() && dr_niva()->plans ) {
			$access = dr_niva()->plans->feature_access( (int) get_current_user_id(), $lock_module );
			if ( is_wp_error( $access ) ) {
				echo Niva_Modules::locked_markup( // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
					$lock_module,
					$access,
					array(
						'lock_mode'     => (string) ( $settings['niva_lock_mode'] ?? '' ),
						'lock_text'     => (string) ( $settings['niva_lock_text'] ?? '' ),
						'upgrade_label' => (string) ( $settings['niva_upgrade_label'] ?? '' ),
						'upgrade_url'   => ! empty( $settings['niva_upgrade_url']['url'] ) ? (string) $settings['niva_upgrade_url']['url'] : '',
						'title'         => $title,
					)
				);
				return;
			}
		}
		?>
		<<?php echo esc_html( $tag ); ?> class="niva-tool-card"<?php echo $attributes; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>>
			<span class="niva-tool-card__icon" aria-hidden="true"><?php echo Niva_Icons::svg( $icon, 24 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<span class="niva-tool-card__content">
				<strong class="niva-tool-card__title"><?php echo esc_html( $title ); ?></strong>
				<?php if ( '' !== $description ) : ?>
					<span class="niva-tool-card__description"><?php echo esc_html( $description ); ?></span>
				<?php endif; ?>
			</span>
			<?php if ( $link ) : ?>
				<span class="niva-tool-card__arrow" aria-hidden="true"><?php echo Niva_Icons::svg( 'arrow-left', 18 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
			<?php endif; ?>
		</<?php echo esc_html( $tag ); ?>>
		<?php
	}
}
