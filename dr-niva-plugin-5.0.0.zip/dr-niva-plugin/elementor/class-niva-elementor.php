<?php
/**
 * Elementor integration.
 *
 * Every section of the product becomes a real Elementor widget: the site owner
 * drags it into any section/column, reorders it, duplicates it, or deletes it —
 * no HTML editing, no shortcode copying.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Elementor {

	public function __construct() {
		add_action( 'elementor/elements/categories_registered', array( $this, 'category' ) );
		add_action( 'elementor/widgets/register', array( $this, 'register_widgets' ) );
		// Elementor < 3.5
		add_action( 'elementor/widgets/widgets_registered', array( $this, 'register_widgets_legacy' ) );
	}

	public static function is_active() : bool {
		return did_action( 'elementor/loaded' ) || class_exists( '\Elementor\Plugin' );
	}

	/** The "دکتر نیوا" panel group. */
	public function category( $manager ) : void {
		if ( ! method_exists( $manager, 'add_category' ) ) {
			return;
		}
		$manager->add_category(
			'dr-niva',
			array(
				'title' => 'دکتر نیوا',
				'icon'  => 'eicon-heart',
			)
		);
	}

	/** Loads and registers one widget class per module. */
	public function register_widgets( $manager ) : void {
		$this->load_classes();
		foreach ( array_keys( Niva_Modules::map() ) as $module_id ) {
			$class = self::class_name( $module_id );
			if ( class_exists( $class ) ) {
				$manager->register( new $class() );
			}
		}
		if ( class_exists( 'Niva_Widget_Tool_Card' ) ) {
			$manager->register( new Niva_Widget_Tool_Card() );
		}
	}

	/** Back-compat path for older Elementor. */
	public function register_widgets_legacy() : void {
		if ( did_action( 'elementor/widgets/register' ) ) {
			return;
		}
		$this->load_classes();
		foreach ( array_keys( Niva_Modules::map() ) as $module_id ) {
			$class = self::class_name( $module_id );
			if ( class_exists( $class ) && function_exists( 'register_widget_type' ) ) {
				register_widget_type( new $class() ); // phpcs:ignore WordPress.NamingConventions.ValidFunctionName
			}
		}
		if ( class_exists( 'Niva_Widget_Tool_Card' ) && function_exists( 'register_widget_type' ) ) {
			register_widget_type( new Niva_Widget_Tool_Card() ); // phpcs:ignore WordPress.NamingConventions.ValidFunctionName
		}
	}

	private function load_classes() : void {
		require_once DR_NIVA_PATH . 'elementor/class-niva-widget-base.php';
		require_once DR_NIVA_PATH . 'elementor/class-niva-tool-card.php';
		require_once DR_NIVA_PATH . 'elementor/widgets.php';
	}

	/** 'cycle_calendar' → 'Niva_Widget_Cycle_Calendar' */
	public static function class_name( string $module_id ) : string {
		$parts = preg_split( '/[-_]/', $module_id );
		return 'Niva_Widget_' . implode( '_', array_map( 'ucfirst', (array) $parts ) );
	}
}
