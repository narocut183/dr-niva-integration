<?php
/**
 * Generated widget classes — one Elementor widget per module.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

/** about_contact */
class Niva_Widget_About_Contact extends Niva_Elementor_Widget {
	protected $module_id = 'about_contact';
}

/** about_mission */
class Niva_Widget_About_Mission extends Niva_Elementor_Widget {
	protected $module_id = 'about_mission';
}

/** about_privacy */
class Niva_Widget_About_Privacy extends Niva_Elementor_Widget {
	protected $module_id = 'about_privacy';
}

/** about_review */
class Niva_Widget_About_Review extends Niva_Elementor_Widget {
	protected $module_id = 'about_review';
}

/** advisor_chat */
class Niva_Widget_Advisor_Chat extends Niva_Elementor_Widget {
	protected $module_id = 'advisor_chat';
}

/** advisor_safety */
class Niva_Widget_Advisor_Safety extends Niva_Elementor_Widget {
	protected $module_id = 'advisor_safety';
}

/** advisor_topics */
class Niva_Widget_Advisor_Topics extends Niva_Elementor_Widget {
	protected $module_id = 'advisor_topics';
}

/** baby_baby-history */
class Niva_Widget_Baby_Baby_History extends Niva_Elementor_Widget {
	protected $module_id = 'baby_baby-history';
}

/** baby_baby-measure */
class Niva_Widget_Baby_Baby_Measure extends Niva_Elementor_Widget {
	protected $module_id = 'baby_baby-measure';
}

/** baby_baby-profile */
class Niva_Widget_Baby_Baby_Profile extends Niva_Elementor_Widget {
	protected $module_id = 'baby_baby-profile';
}

/** baby_baby-reference */
class Niva_Widget_Baby_Baby_Reference extends Niva_Elementor_Widget {
	protected $module_id = 'baby_baby-reference';
}

/** baby_baby-verdict */
class Niva_Widget_Baby_Baby_Verdict extends Niva_Elementor_Widget {
	protected $module_id = 'baby_baby-verdict';
}

/** baby_chart */
class Niva_Widget_Baby_Chart extends Niva_Elementor_Widget {
	protected $module_id = 'baby_chart';
}

/** baby_checklist */
class Niva_Widget_Baby_Checklist extends Niva_Elementor_Widget {
	protected $module_id = 'baby_checklist';
}

/** baby_print */
class Niva_Widget_Baby_Print extends Niva_Elementor_Widget {
	protected $module_id = 'baby_print';
}

/** cycle_calendar */
class Niva_Widget_Cycle_Calendar extends Niva_Elementor_Widget {
	protected $module_id = 'cycle_calendar';
}

/** cycle_checklist */
class Niva_Widget_Cycle_Checklist extends Niva_Elementor_Widget {
	protected $module_id = 'cycle_checklist';
}

/** cycle_print */
class Niva_Widget_Cycle_Print extends Niva_Elementor_Widget {
	protected $module_id = 'cycle_print';
}

/** cycle_today */
class Niva_Widget_Cycle_Today extends Niva_Elementor_Widget {
	protected $module_id = 'cycle_today';
}

/** faq */
class Niva_Widget_Faq extends Niva_Elementor_Widget {
	protected $module_id = 'faq';
}

/** home_head */
class Niva_Widget_Home_Head extends Niva_Elementor_Widget {
	protected $module_id = 'home_head';
}

/** home_message */
class Niva_Widget_Home_Message extends Niva_Elementor_Widget {
	protected $module_id = 'home_message';
}

/** home_status */
class Niva_Widget_Home_Status extends Niva_Elementor_Widget {
	protected $module_id = 'home_status';
}

/** home_tasks */
class Niva_Widget_Home_Tasks extends Niva_Elementor_Widget {
	protected $module_id = 'home_tasks';
}

/** lab_chart */
class Niva_Widget_Lab_Chart extends Niva_Elementor_Widget {
	protected $module_id = 'lab_chart';
}

/** lab_docs */
class Niva_Widget_Lab_Docs extends Niva_Elementor_Widget {
	protected $module_id = 'lab_docs';
}

/** lab_print */
class Niva_Widget_Lab_Print extends Niva_Elementor_Widget {
	protected $module_id = 'lab_print';
}

/** lab_progress */
class Niva_Widget_Lab_Progress extends Niva_Elementor_Widget {
	protected $module_id = 'lab_progress';
}

/** lab_skeleton */
class Niva_Widget_Lab_Skeleton extends Niva_Elementor_Widget {
	protected $module_id = 'lab_skeleton';
}

/** lab_upload */
class Niva_Widget_Lab_Upload extends Niva_Elementor_Widget {
	protected $module_id = 'lab_upload';
}

/** lab_values */
class Niva_Widget_Lab_Values extends Niva_Elementor_Widget {
	protected $module_id = 'lab_values';
}

/** mind_assessment */
class Niva_Widget_Mind_Assessment extends Niva_Elementor_Widget {
	protected $module_id = 'mind_assessment';
}

/** mind_breathing */
class Niva_Widget_Mind_Breathing extends Niva_Elementor_Widget {
	protected $module_id = 'mind_breathing';
}

/** mind_chat */
class Niva_Widget_Mind_Chat extends Niva_Elementor_Widget {
	protected $module_id = 'mind_chat';
}

/** mind_crisis */
class Niva_Widget_Mind_Crisis extends Niva_Elementor_Widget {
	protected $module_id = 'mind_crisis';
}

/** mind_mood */
class Niva_Widget_Mind_Mood extends Niva_Elementor_Widget {
	protected $module_id = 'mind_mood';
}

/** mind_thought-record */
class Niva_Widget_Mind_Thought_Record extends Niva_Elementor_Widget {
	protected $module_id = 'mind_thought-record';
}

/** pregnancy_bag */
class Niva_Widget_Pregnancy_Bag extends Niva_Elementor_Widget {
	protected $module_id = 'pregnancy_bag';
}

/** pregnancy_checklist */
class Niva_Widget_Pregnancy_Checklist extends Niva_Elementor_Widget {
	protected $module_id = 'pregnancy_checklist';
}

/** pregnancy_counter */
class Niva_Widget_Pregnancy_Counter extends Niva_Elementor_Widget {
	protected $module_id = 'pregnancy_counter';
}

/** pregnancy_print */
class Niva_Widget_Pregnancy_Print extends Niva_Elementor_Widget {
	protected $module_id = 'pregnancy_print';
}

/** pregnancy_timeline */
class Niva_Widget_Pregnancy_Timeline extends Niva_Elementor_Widget {
	protected $module_id = 'pregnancy_timeline';
}

/** pregnancy_week */
class Niva_Widget_Pregnancy_Week extends Niva_Elementor_Widget {
	protected $module_id = 'pregnancy_week';
}

/** reminders_notification */
class Niva_Widget_Reminders_Notification extends Niva_Elementor_Widget {
	protected $module_id = 'reminders_notification';
}

/** reminders_reminder-form */
class Niva_Widget_Reminders_Reminder_Form extends Niva_Elementor_Widget {
	protected $module_id = 'reminders_reminder-form';
}

/** reminders_reminder-list */
class Niva_Widget_Reminders_Reminder_List extends Niva_Elementor_Widget {
	protected $module_id = 'reminders_reminder-list';
}

/** tools_advisor */
class Niva_Widget_Tools_Advisor extends Niva_Elementor_Widget {
	protected $module_id = 'tools_advisor';
}

/** tools_child */
class Niva_Widget_Tools_Child extends Niva_Elementor_Widget {
	protected $module_id = 'tools_child';
}

/** tools_health */
class Niva_Widget_Tools_Health extends Niva_Elementor_Widget {
	protected $module_id = 'tools_health';
}

/** tools_mind */
class Niva_Widget_Tools_Mind extends Niva_Elementor_Widget {
	protected $module_id = 'tools_mind';
}

/** tools_note */
class Niva_Widget_Tools_Note extends Niva_Elementor_Widget {
	protected $module_id = 'tools_note';
}

/** tools_women */
class Niva_Widget_Tools_Women extends Niva_Elementor_Widget {
	protected $module_id = 'tools_women';
}

/** credits_bar */
class Niva_Widget_Credits_Bar extends Niva_Elementor_Widget {
	protected $module_id = 'credits_bar';
}

/** wallet */
class Niva_Widget_Wallet extends Niva_Elementor_Widget {
	protected $module_id = 'wallet';
}

/** packages */
class Niva_Widget_Packages extends Niva_Elementor_Widget {
	protected $module_id = 'packages';
}

/** app_header */
class Niva_Widget_App_Header extends Niva_Elementor_Widget {
	protected $module_id = 'app_header';
}

/** app_footer */
class Niva_Widget_App_Footer extends Niva_Elementor_Widget {
	protected $module_id = 'app_footer';
}

/** home_plan */
class Niva_Widget_Home_Plan extends Niva_Elementor_Widget {
	protected $module_id = 'home_plan';
}

/** family_panel */
class Niva_Widget_Family_Panel extends Niva_Elementor_Widget {
	protected $module_id = 'family_panel';
}

/** partners_join */
class Niva_Widget_Partners_Join extends Niva_Elementor_Widget {
	protected $module_id = 'partners_join';
}

/** partner_dashboard */
class Niva_Widget_Partner_Dashboard extends Niva_Elementor_Widget {
	protected $module_id = 'partner_dashboard';
}

/** partners_plan */
class Niva_Widget_Partners_Plan extends Niva_Elementor_Widget {
	protected $module_id = 'partners_plan';
}

/** messages_archive */
class Niva_Widget_Messages_Archive extends Niva_Elementor_Widget {
	protected $module_id = 'messages_archive';
}

/** user_settings */
class Niva_Widget_User_Settings extends Niva_Elementor_Widget {
	protected $module_id = 'user_settings';
}

/** notifications_inbox */
class Niva_Widget_Notifications_Inbox extends Niva_Elementor_Widget {
	protected $module_id = 'notifications_inbox';
}

/** health_score */
class Niva_Widget_Health_Score extends Niva_Elementor_Widget {
	protected $module_id = 'health_score';
}

/** weekly_activity */
class Niva_Widget_Weekly_Activity extends Niva_Elementor_Widget {
	protected $module_id = 'weekly_activity';
}

/** quick_actions */
class Niva_Widget_Quick_Actions extends Niva_Elementor_Widget {
	protected $module_id = 'quick_actions';
}

/** insights_feed */
class Niva_Widget_Insights_Feed extends Niva_Elementor_Widget {
	protected $module_id = 'insights_feed';
}

/** today_plan */
class Niva_Widget_Today_Plan extends Niva_Elementor_Widget {
	protected $module_id = 'today_plan';
}

/** exercises */
class Niva_Widget_Exercises extends Niva_Elementor_Widget {
	protected $module_id = 'exercises';
}

/** medication_grid */
class Niva_Widget_Medication_Grid extends Niva_Elementor_Widget {
	protected $module_id = 'medication_grid';
}

/** profile_hub */
class Niva_Widget_Profile_Hub extends Niva_Elementor_Widget {
	protected $module_id = 'profile_hub';
}

/** ثبت نتیجهٔ آزمایش */
class Niva_Widget_Lab_Entry extends Niva_Elementor_Widget {
	protected $module_id = 'lab_entry';
}

/** پلن‌ها و اشتراک */
class Niva_Widget_Plans_Table extends Niva_Elementor_Widget {
	protected $module_id = 'plans_table';
}
