<?php
/**
 * Uninstall routine: honours the "keep data" switch.
 *
 * @package DrAva
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

$dr_niva_settings = get_option( 'dr_niva_settings', array() );
$dr_niva_keep     = is_array( $dr_niva_settings ) && ! empty( $dr_niva_settings['keep_data_on_uninstall'] );

delete_option( 'dr_niva_settings' );
delete_option( 'dr_niva_layout' );
delete_option( 'dr_niva_db_version' );
wp_clear_scheduled_hook( 'dr_niva_daily_maintenance' );
wp_clear_scheduled_hook( 'dr_niva_every_minute' );
wp_clear_scheduled_hook( 'dr_niva_daily' );

if ( ! $dr_niva_keep ) {
	/*
	 * 2.0.1 — drop every table the plugin created, not a hand-written subset.
	 *
	 * The old list named six tables, so uninstalling left the chats, growth,
	 * membership, partner, store-purchase and the new community/companion
	 * tables behind. Niva_DB::tables() is the single source of truth.
	 */
	$dr_niva_db_file = __DIR__ . '/includes/class-niva-db.php';
	if ( file_exists( $dr_niva_db_file ) ) {
		require_once $dr_niva_db_file;
	}
	if ( class_exists( 'Niva_DB' ) ) {
		Niva_DB::drop_all();
	} else {
		global $wpdb;
		foreach ( array( 'wallets', 'ledger', 'usage', 'documents', 'reviews', 'reminders', 'notifications', 'push_subs', 'chats', 'chat_messages', 'growth', 'daily_logs', 'memberships', 'family_members', 'partners', 'partner_referrals', 'payouts', 'push_devices', 'messages', 'community_categories', 'community_threads', 'community_comments', 'community_reactions', 'community_reports', 'companion_codes', 'companion_views', 'store_purchases', 'audit_log' ) as $dr_niva_table ) {
			$dr_niva_name = $wpdb->prefix . 'niva_' . $dr_niva_table;
			$wpdb->query( "DROP TABLE IF EXISTS {$dr_niva_name}" ); // phpcs:ignore
		}
	}
	delete_transient( 'dr_niva_page_key_map' );
	delete_transient( 'dr_niva_app_shell_page' );
}
