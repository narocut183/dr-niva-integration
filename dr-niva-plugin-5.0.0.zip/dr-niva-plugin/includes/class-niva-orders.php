<?php
/**
 * WooCommerce bridge: credit packages as products, wallet screen, reversals.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Orders {

	/** @var Niva_Wallet */
	private $wallet;

	/** @var Niva_Settings */
	private $settings;

	public function __construct( Niva_Wallet $wallet, Niva_Settings $settings ) {
		$this->wallet   = $wallet;
		$this->settings = $settings;

		// Product data: a package marker + how many credits it carries.
		add_action( 'woocommerce_product_options_general_product_data', array( $this, 'product_fields' ) );
		add_action( 'woocommerce_product_options_general_product_data', array( $this, 'plan_fields' ) );
		add_action( 'woocommerce_process_product_meta', array( $this, 'save_product_fields' ) );

		// Credit on the configured order status.
		$status = (string) $this->settings->get( 'credit_on_status' );
		add_action( 'woocommerce_order_status_' . $status, array( $this, 'on_order_paid' ) );

		// Reverse on refund or cancellation.
		add_action( 'woocommerce_order_status_refunded', array( $this, 'on_order_reversed' ) );
		add_action( 'woocommerce_order_status_cancelled', array( $this, 'on_order_reversed' ) );
		add_action( 'template_redirect', array( $this, 'handle_direct_checkout' ), 1 );

		// Wallet tab inside "حساب من".
		add_filter( 'woocommerce_account_menu_items', array( $this, 'account_menu' ), 20 );
		add_action( 'init', array( $this, 'wallet_endpoint' ) );
		add_action( 'woocommerce_account_niva-wallet_endpoint', array( $this, 'wallet_endpoint_content' ) );

		// Shortcodes usable anywhere.
		add_shortcode( 'dr_niva_wallet', array( $this, 'shortcode_wallet' ) );
		add_shortcode( 'dr_niva_packages', array( $this, 'shortcode_packages' ) );
	}

	/** Checkbox + credits field on the product edit screen. */
	public function product_fields() : void {
		echo '<div class="options_group">';
		woocommerce_wp_checkbox(
			array(
				'id'          => '_niva_is_credit_package',
				'label'       => 'بسته‌ی اعتبار دکتر نیوا',
				'description' => 'با تکمیل سفارش، اعتبار به کیف پول خریدار اضافه می‌شود.',
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_niva_credits',
				'label'       => 'تعداد اعتبار',
				'type'        => 'number',
				'desc_tip'    => true,
				'description' => 'مثلاً ۱۰۰، ۵۰۰ یا ۱۲۰۰ اعتبار.',
			)
		);
		echo '</div>';
	}

	/** Subscription products: a plan instead of (or beside) a credit package. */
	public function plan_fields() : void {
		woocommerce_wp_checkbox(
			array(
				'id'          => '_niva_is_plan',
				'label'       => 'اشتراک دکتر نیوا',
				'description' => 'این محصول یک اشتراک را فعال می‌کند.',
			)
		);
		woocommerce_wp_select(
			array(
				'id'      => '_niva_plan',
				'label'   => 'کدام پلن فعال شود',
				'options' => array( 'plus' => 'پلاس', 'family' => 'خانوادگی', 'partner' => 'همکاری' ),
			)
		);
		woocommerce_wp_text_input(
			array(
				'id'          => '_niva_plan_days',
				'label'       => 'مدت اشتراک (روز)',
				'type'        => 'number',
				'value'       => '30',
				'description' => 'عدد ۰ یعنی بدون محدودیت زمانی.',
			)
		);
	}

	public function save_product_fields( int $post_id ) : void {
		update_post_meta( $post_id, '_niva_is_plan', isset( $_POST['_niva_is_plan'] ) ? 'yes' : 'no' );
		if ( isset( $_POST['_niva_plan'] ) ) {
			update_post_meta( $post_id, '_niva_plan', sanitize_key( wp_unslash( $_POST['_niva_plan'] ) ) );
		}
		if ( isset( $_POST['_niva_plan_days'] ) ) {
			update_post_meta( $post_id, '_niva_plan_days', absint( $_POST['_niva_plan_days'] ) );
		}

		$is_package = isset( $_POST['_niva_is_credit_package'] ) ? 'yes' : 'no'; // phpcs:ignore
		$credits    = isset( $_POST['_niva_credits'] ) ? absint( wp_unslash( $_POST['_niva_credits'] ) ) : 0; // phpcs:ignore

		update_post_meta( $post_id, '_niva_is_credit_package', $is_package );
		update_post_meta( $post_id, '_niva_credits', $credits );

		if ( 'yes' === $is_package ) {
			// Digital good: no shipping, no stock pressure.
			update_post_meta( $post_id, '_virtual', 'yes' );
		}
	}

	/** Adds credits once per order. */
	public function on_order_paid( int $order_id ) : void {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		if ( $order ) {
			foreach ( $order->get_items() as $item ) {
				$product_id = (int) $item->get_product_id();
				$key        = (string) get_post_meta( $product_id, '_niva_plan', true );
				if ( 'yes' !== get_post_meta( $product_id, '_niva_is_plan', true ) || ! $key ) {
					continue;
				}
				if ( get_post_meta( $order_id, '_niva_plan_granted_' . $product_id, true ) ) {
					continue;
				}
				$user_id = (int) $order->get_user_id();
				if ( ! $user_id ) {
					continue;
				}
				dr_niva()->plans->assign( $user_id, $key, 'woocommerce', (int) get_post_meta( $product_id, '_niva_plan_days', true ), 'order:' . $order_id );
				update_post_meta( $order_id, '_niva_plan_granted_' . $product_id, 1 );
			}
		}

		$order = $this->order( $order_id );
		if ( ! $order || ! $order->get_user_id() ) {
			return;
		}
		if ( get_post_meta( $order_id, '_niva_credits_granted', true ) ) {
			return; // already applied
		}

		$credits = 0;
		foreach ( $order->get_items() as $item ) {
			$product_id = $item->get_product_id();
			$per_item   = (int) get_post_meta( $product_id, '_niva_credits', true );
			if ( $per_item > 0 ) {
				$credits += $per_item * max( 1, (int) $item->get_quantity() );
			}
		}
		if ( $credits <= 0 ) {
			return;
		}

		$user_id = (int) $order->get_user_id();
		$this->wallet->grant( $user_id, $credits, 'purchase', 'order:' . $order_id, array( 'order' => $order_id ) );
		update_post_meta( $order_id, '_niva_credits_granted', $credits );

		if ( $this->settings->is_on( 'email_on_credit' ) ) {
			$summary = $this->wallet->summary( $user_id );
			$subject = sprintf( 'اعتبار شما شارژ شد (%s)', (string) $this->settings->get( 'brand_name' ) );
			$body    = sprintf(
				"سلام،\n\nسفارش شما تکمیل شد.\nاعتبار افزوده‌شده: %d\nموجودی فعلی: %d\n\n%s",
				$credits,
				(int) $summary['balance'],
				home_url( '/my-account/niva-wallet/' )
			);
			wp_mail( $order->get_billing_email(), $subject, $body );
		}

		do_action( 'dr_niva_credits_purchased', $user_id, $credits, $order_id );
	}

	/** Takes credits back when the order is refunded or cancelled. */
	public function on_order_reversed( int $order_id ) : void {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		if ( $order ) {
			foreach ( $order->get_items() as $item ) {
				$product_id = (int) $item->get_product_id();
				if ( 'yes' === get_post_meta( $product_id, '_niva_is_plan', true ) && get_post_meta( $order_id, '_niva_plan_granted_' . $product_id, true ) ) {
					dr_niva()->plans->revoke( (int) $order->get_user_id(), 'refund' );
					delete_post_meta( $order_id, '_niva_plan_granted_' . $product_id );
				}
			}
		}

		if ( ! $this->settings->is_on( 'refund_reverses' ) ) {
			return;
		}
		$order = $this->order( $order_id );
		$granted = (int) get_post_meta( $order_id, '_niva_credits_granted', true );
		if ( ! $order || ! $order->get_user_id() || $granted <= 0 || get_post_meta( $order_id, '_niva_credits_reversed', true ) ) {
			return;
		}
		global $wpdb;
		$table = Niva_DB::table( 'wallets' );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET balance = GREATEST(0, balance - %d), updated_at = %s WHERE user_id = %d", // phpcs:ignore
				$granted,
				current_time( 'mysql' ),
				(int) $order->get_user_id()
			)
		);
		update_post_meta( $order_id, '_niva_credits_reversed', 1 );
		$balance = (int) $wpdb->get_var( $wpdb->prepare( "SELECT balance FROM {$table} WHERE user_id = %d", (int) $order->get_user_id() ) ); // phpcs:ignore
		$wpdb->insert(
			Niva_DB::table( 'ledger' ),
			array(
				'user_id'       => (int) $order->get_user_id(),
				'delta'         => -$granted,
				'reason'        => 'clawback',
				'ref'           => 'order:' . $order_id,
				'balance_after' => $balance,
				'created_at'    => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s' )
		);
	}

	/** Wallet endpoint inside My Account. */
	public function wallet_endpoint() : void {
		add_rewrite_endpoint( 'niva-wallet', EP_ROOT | EP_PAGES );
	}

	public function account_menu( array $items ) : array {
		if ( ! $this->settings->is_on( 'wallet_in_my_account' ) ) {
			return $items;
		}
		$new = array();
		foreach ( $items as $key => $label ) {
			$new[ $key ] = $label;
			if ( 'dashboard' === $key ) {
				$new['niva-wallet'] = 'اعتبار من';
			}
		}
		if ( ! isset( $new['niva-wallet'] ) ) {
			$new['niva-wallet'] = 'اعتبار من';
		}
		return $new;
	}

	public function wallet_endpoint_content() : void {
		echo $this->wallet_markup(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
	}

	public function shortcode_wallet() : string {
		if ( ! is_user_logged_in() ) {
			return '<p>برای دیدن اعتبار خود وارد شوید.</p>';
		}
		return $this->wallet_markup();
	}

	/* ------------------------------------------------- direct plan checkout */

	/** The WooCommerce product that sells this plan (0 when the owner has none). */
	public static function product_for_plan( string $plan ) : int {
		if ( ! function_exists( 'get_posts' ) || ! function_exists( 'wc_get_product' ) || ! class_exists( 'WC_Product_Simple' ) ) {
			return 0;
		}
		$catalog = Niva_Plans::catalog();
		if ( empty( $catalog[ $plan ]['monthly'] ) ) {
			return 0;
		}
		$ids = get_posts(
			array(
				'post_type'      => 'product',
				'post_status'    => 'publish',
				'posts_per_page' => 1,
				'fields'         => 'ids',
				'meta_query'     => array(
					'relation' => 'AND',
					array(
						'key'   => '_niva_is_plan',
						'value' => 'yes',
					),
					array(
						'key'   => '_niva_plan',
						'value' => $plan,
					),
				),
			)
		);
		if ( $ids ) {
			$product_id = (int) $ids[0];
			self::sync_plan_product( $product_id, $plan, $catalog[ $plan ] );
			return $product_id;
		}

		$product = new WC_Product_Simple();
		$product->set_name( 'اشتراک ماهیانه دکتر نیوا — ' . $catalog[ $plan ]['label'] );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'hidden' );
		$product->set_virtual( true );
		$product->set_sold_individually( true );
		$product->set_regular_price( (string) $catalog[ $plan ]['price'] );
		$product->set_sale_price( $catalog[ $plan ]['discount'] > 0 ? (string) $catalog[ $plan ]['payable'] : '' );
		$product->set_price( (string) $catalog[ $plan ]['payable'] );
		$product_id = (int) $product->save();
		if ( $product_id ) {
			self::sync_plan_product( $product_id, $plan, $catalog[ $plan ] );
			update_post_meta( $product_id, '_niva_auto_managed', 'yes' );
		}
		return $product_id;
	}

	private static function sync_plan_product( int $product_id, string $plan, array $details ) : void {
		$product = wc_get_product( $product_id );
		if ( ! $product ) {
			return;
		}
		$product->set_virtual( true );
		$product->set_sold_individually( true );
		$product->set_regular_price( (string) $details['price'] );
		$product->set_sale_price( $details['discount'] > 0 ? (string) $details['payable'] : '' );
		$product->set_price( (string) $details['payable'] );
		$product->save();
		update_post_meta( $product_id, '_niva_is_plan', 'yes' );
		update_post_meta( $product_id, '_niva_plan', $plan );
		update_post_meta( $product_id, '_niva_plan_days', 30 );
	}

	/**
	 * Straight to the site's payment page with this plan in the basket — no cart
	 * detour, no intermediate step. Payment then activates the plan automatically.
	 */
	public static function checkout_url_for_plan( string $plan ) : string {
		$product = self::product_for_plan( $plan );
		if ( ! $product ) {
			return '';
		}
		return self::direct_checkout_url( $product );
	}

	private static function direct_checkout_url( int $product_id ) : string {
		if ( ! function_exists( 'wc_get_checkout_url' ) ) {
			return '';
		}
		return add_query_arg(
			array(
				'niva_purchase' => $product_id,
				'_wpnonce'     => wp_create_nonce( 'dr_niva_purchase_' . $product_id ),
			),
			wc_get_checkout_url()
		);
	}

	/** Replaces the cart with only the selected plan/package before checkout. */
	public function handle_direct_checkout() : void {
		if ( ! isset( $_GET['niva_purchase'], $_GET['_wpnonce'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$product_id = absint( wp_unslash( $_GET['niva_purchase'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$nonce      = sanitize_text_field( wp_unslash( $_GET['_wpnonce'] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! $product_id || ! wp_verify_nonce( $nonce, 'dr_niva_purchase_' . $product_id ) ) {
			wp_die( esc_html__( 'پیوند خرید معتبر نیست؛ صفحهٔ پلن‌ها را دوباره باز کن.', 'dr-niva' ), '', array( 'response' => 403 ) );
		}
		if ( ! is_user_logged_in() || ! function_exists( 'WC' ) || ! WC()->cart ) {
			wp_die( esc_html__( 'برای خرید باید وارد حساب شوی و ووکامرس فعال باشد.', 'dr-niva' ), '', array( 'response' => 403 ) );
		}
		$is_plan = 'yes' === get_post_meta( $product_id, '_niva_is_plan', true );
		$is_credit = 'yes' === get_post_meta( $product_id, '_niva_is_credit_package', true );
		if ( ! $is_plan && ! $is_credit ) {
			wp_die( esc_html__( 'این محصول خرید مستقیم دکتر نیوا نیست.', 'dr-niva' ), '', array( 'response' => 404 ) );
		}

		WC()->cart->empty_cart( true );
		if ( ! WC()->cart->add_to_cart( $product_id, 1 ) ) {
			wc_add_notice( 'این محصول در حال حاضر قابل خرید نیست؛ تنظیمات محصول و درگاه را بررسی کن.', 'error' );
		}
		wp_safe_redirect( wc_get_checkout_url() );
		exit;
	}

	/** Packages with add-to-cart links for matching WooCommerce products. */
	public function shortcode_packages() : string {
		$packages = $this->settings->packages();
		if ( ! $packages ) {
			return '';
		}
		if ( ! function_exists( 'wc_get_cart_url' ) ) {
			return '<p class="niva-package__note">برای خرید اعتبار، ووکامرس باید فعال باشد.</p>';
		}
		$out = '<div class="niva-packages">';
		foreach ( $packages as $package ) {
			$product_id = $this->find_product_for_credits( (int) $package['credits'] );
			$price      = number_format( (int) $package['price'] );
			$out       .= '<div class="niva-package">';
			$out       .= '<strong>' . esc_html( (string) $package['credits'] ) . ' اعتبار</strong>';
			$out       .= '<span>' . esc_html( $price ) . ' تومان</span>';
			if ( $product_id ) {
				$out .= '<a class="button" href="' . esc_url( self::direct_checkout_url( $product_id ) ) . '">خرید و پرداخت</a>';
			} else {
				$out .= '<span class="niva-package__note">برای این بسته محصولی در ووکامرس ساخته نشده است.</span>';
			}
			$out .= '</div>';
		}
		$out .= '</div>';
		return $out;
	}

	/** The wallet panel: balance, usage, history, packages. */
	public function wallet_markup() : string {
		$user_id = get_current_user_id();
		$summary = $this->wallet->summary( $user_id );
		$ledger_page  = max( 1, absint( $_GET['wallet_page'] ?? 1 ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		$ledger_count = $this->wallet->ledger_count( $user_id );
		$ledger_pages = max( 1, (int) ceil( $ledger_count / 10 ) );
		$ledger_page  = min( $ledger_page, $ledger_pages );
		$ledger       = $this->wallet->ledger( $user_id, 10, ( $ledger_page - 1 ) * 10 );
		$usage   = $this->wallet->usage_report( $user_id, 30 );
		$wallet_url = Niva_Modules::url( 'wallet' );

		ob_start();
		?>
		<div class="niva-wallet">
			<h2>اعتبار من</h2>
			<div class="niva-wallet__grid">
				<div class="niva-wallet__card">
					<span class="niva-wallet__label">موجودی</span>
					<strong class="niva-wallet__value"><?php echo esc_html( (string) $summary['balance'] ); ?></strong>
				</div>
				<div class="niva-wallet__card">
					<span class="niva-wallet__label">مصرف کل</span>
					<strong class="niva-wallet__value"><?php echo esc_html( (string) $summary['spent_total'] ); ?></strong>
				</div>
				<div class="niva-wallet__card">
					<span class="niva-wallet__label">سهمیه‌ی رایگان امروز</span>
					<strong class="niva-wallet__value"><?php echo esc_html( (string) $summary['quota_left'] ); ?></strong>
					<span class="niva-wallet__hint">از <?php echo esc_html( (string) $summary['quota_limit'] ); ?> پیام</span>
				</div>
			</div>

			<?php if ( ! empty( $summary['low'] ) ) : ?>
				<p class="niva-wallet__alert"><?php echo esc_html( (string) $this->settings->get( 'exhausted_message' ) ); ?></p>
			<?php endif; ?>

			<h3>خرید اعتبار</h3>
			<?php echo $this->shortcode_packages(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?>

			<?php if ( $usage ) : ?>
				<h3>مصرف ۳۰ روز گذشته</h3>
				<ul class="niva-wallet__usage">
					<?php foreach ( $usage as $row ) : ?>
						<li>
							<?php echo esc_html( $this->kind_label( (string) $row['kind'] ) ); ?>:
							<?php echo esc_html( (string) $row['calls'] ); ?> بار،
							<?php echo esc_html( (string) (int) $row['credits'] ); ?> اعتبار
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>

			<?php if ( $ledger ) : ?>
				<h3>تراکنش‌های اخیر</h3>
				<ul class="niva-wallet__ledger">
					<?php foreach ( $ledger as $row ) : ?>
						<li>
							<span class="niva-wallet__delta <?php echo (int) $row['delta'] >= 0 ? 'is-plus' : 'is-minus'; ?>">
								<?php echo esc_html( ( (int) $row['delta'] >= 0 ? '+' : '' ) . (int) $row['delta'] ); ?>
							</span>
							<span class="niva-wallet__reason"><?php echo esc_html( $this->reason_label( (string) $row['reason'] ) ); ?></span>
							<span class="niva-wallet__date"><?php echo esc_html( (string) $row['created_at_label'] ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
				<?php if ( $ledger_pages > 1 ) : ?>
					<nav class="niva-wallet__pagination" aria-label="صفحه‌های تراکنش">
						<?php if ( $ledger_page > 1 ) : ?>
							<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( add_query_arg( 'wallet_page', $ledger_page - 1, $wallet_url ) ); ?>">تراکنش‌های جدیدتر</a>
						<?php endif; ?>
						<span class="caption">صفحهٔ <?php echo esc_html( (string) $ledger_page ); ?> از <?php echo esc_html( (string) $ledger_pages ); ?></span>
						<?php if ( $ledger_page < $ledger_pages ) : ?>
							<a class="btn btn--secondary btn--sm" href="<?php echo esc_url( add_query_arg( 'wallet_page', $ledger_page + 1, $wallet_url ) ); ?>">تراکنش‌های قدیمی‌تر</a>
						<?php endif; ?>
					</nav>
				<?php endif; ?>
			<?php endif; ?>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	private function kind_label( string $kind ) : string {
		$map = array(
			'chat'    => 'گفت‌وگو با مشاور',
			'lab'     => 'تحلیل آزمایش',
			'image'   => 'تحلیل تصویر',
			'summary' => 'خلاصه‌سازی',
			'pdf'     => 'خروجی PDF',
		);
		return $map[ $kind ] ?? $kind;
	}

	private function reason_label( string $reason ) : string {
		if ( 0 === strpos( $reason, 'spend:' ) ) {
			return 'مصرف: ' . $this->kind_label( substr( $reason, 6 ) );
		}
		$map = array(
			'purchase' => 'خرید بسته‌ی اعتبار',
			'signup'   => 'هدیه‌ی ثبت‌نام',
			'referral' => 'هدیه‌ی معرفی دوستان',
			'refund'   => 'بازگشت اعتبار',
			'clawback' => 'کسر به دلیل بازپرداخت سفارش',
		);
		if ( 0 === strpos( $reason, 'store:' ) ) {
			return 'خرید از ' . ( 'store:bazaar' === $reason ? 'کافه‌بازار' : 'مایکت' );
		}
		return $map[ $reason ] ?? $reason;
	}

	private function find_product_for_credits( int $credits ) : int {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return 0;
		}
		$found = wc_get_products(
			array(
				'limit'      => 1,
				'return'     => 'ids',
				'meta_key'   => '_niva_credits', // phpcs:ignore
				'meta_value' => $credits, // phpcs:ignore
			)
		);
		if ( $found ) {
			$product_id = (int) $found[0];
			if ( 'yes' === get_post_meta( $product_id, '_niva_auto_managed', true ) ) {
				$package = $this->credit_package( $credits );
				if ( $package && function_exists( 'wc_get_product' ) ) {
					$product = wc_get_product( $product_id );
					if ( $product ) {
						$product->set_regular_price( (string) $package['price'] );
						$product->set_price( (string) $package['price'] );
						$product->save();
					}
				}
			}
			return $product_id;
		}

		$package = $this->credit_package( $credits );
		if ( ! $package || ! class_exists( 'WC_Product_Simple' ) ) {
			return 0;
		}
		$product = new WC_Product_Simple();
		$product->set_name( 'اعتبار دکتر نیوا — ' . number_format_i18n( $credits ) );
		$product->set_status( 'publish' );
		$product->set_catalog_visibility( 'hidden' );
		$product->set_virtual( true );
		$product->set_sold_individually( true );
		$product->set_regular_price( (string) $package['price'] );
		$product->set_price( (string) $package['price'] );
		$product_id = (int) $product->save();
		if ( $product_id ) {
			update_post_meta( $product_id, '_niva_is_credit_package', 'yes' );
			update_post_meta( $product_id, '_niva_credits', $credits );
			update_post_meta( $product_id, '_niva_auto_managed', 'yes' );
		}
		return $product_id;
	}

	private function credit_package( int $credits ) : ?array {
		foreach ( $this->settings->packages() as $package ) {
			if ( (int) $package['credits'] === $credits && (int) $package['price'] > 0 ) {
				return $package;
			}
		}
		return null;
	}

	private function order( int $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return null;
		}
		return wc_get_order( $order_id );
	}
}
