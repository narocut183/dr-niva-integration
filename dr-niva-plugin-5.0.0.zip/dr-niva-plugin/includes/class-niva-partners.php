<?php
/**
 * Partner programme: applications, referral codes, commission and payouts.
 *
 * A partner is any clinic, doctor, midwife, nutritionist, pharmacy or content
 * creator who brings users in. They get a code, a share link, a dashboard and a
 * commission ledger the back office pays out.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Partners {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
		add_action( 'init', array( $this, 'capture_ref' ) );
		add_action( 'user_register', array( $this, 'attribute_signup' ), 20 );
		add_action( 'woocommerce_order_status_completed', array( $this, 'record_commission' ), 20 );
		add_action( 'admin_post_dr_niva_partner_action', array( $this, 'handle_admin_action' ) );
		add_action( 'admin_post_dr_niva_partner_plan', array( $this, 'handle_plan_action' ) );

		/*
		 * The partner plan is a switch, not a purchase: any user who asks for it
		 * can have it turned on (or off) from the back office, and a partner who
		 * is still a plain subscriber gets it the moment they ask.
		 */
		add_action( 'dr_niva_partner_plan_requested', array( $this, 'notify_plan_request' ), 10, 3 );
	}

	/** Back-office: turn the partner plan on/off for one user. */
	public function handle_plan_action() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_partner_plan' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}

		$action  = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';
		$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : 0;
		$raw     = isset( $_POST['user'] ) ? trim( sanitize_text_field( wp_unslash( $_POST['user'] ) ) ) : '';
		$plan    = isset( $_POST['plan'] ) ? sanitize_key( wp_unslash( $_POST['plan'] ) ) : (string) dr_niva()->settings->get( 'partner_plan', 'partner' );
		$days    = isset( $_POST['days'] ) ? absint( $_POST['days'] ) : (int) dr_niva()->settings->get( 'partner_plan_days' );
		$redirect = admin_url( 'admin.php?page=dr-niva-partners&plan_done=' . $action );

		if ( ! $user_id && $raw ) {
			$user_id = $this->resolve_user( $raw );
		}
		if ( ! $user_id ) {
			wp_safe_redirect( add_query_arg( 'plan_error', 'user', $redirect ) );
			exit;
		}

		if ( 'revoke' === $action ) {
			dr_niva()->plans->revoke( $user_id, 'partner_plan' );
			Niva_Notifications::notify( $user_id, 'پلن همکاران غیرفعال شد', 'دسترسی همکاری برای حساب تو موقتاً غیرفعال شد. برای اطلاعات بیشتر با پشتیبانی تماس بگیر.', home_url( '/' ) );
			wp_safe_redirect( $redirect );
			exit;
		}

		$plans = Niva_Plans::assignable();
		if ( ! isset( $plans[ $plan ] ) ) {
			$plan = 'partner';
		}
		dr_niva()->plans->grant( $user_id, $plan, $days, 'partner_manual', 'admin:' . get_current_user_id() );
		wp_safe_redirect( $redirect );
		exit;
	}

	/** Accepts a user id, a login or an email address. */
	public function resolve_user( string $needle ) : int {
		if ( ctype_digit( $needle ) ) {
			return get_userdata( (int) $needle ) ? (int) $needle : 0;
		}
		if ( is_email( $needle ) ) {
			$user = get_user_by( 'email', $needle );
			return $user ? (int) $user->ID : 0;
		}
		$user = get_user_by( 'login', $needle );
		return $user ? (int) $user->ID : 0;
	}

	/** Tells the admins that somebody asked for the partner plan. */
	public function notify_plan_request( int $user_id, string $plan, string $name = '' ) : void {
		$admins = get_users( array( 'role' => 'administrator', 'fields' => array( 'ID' ), 'number' => 10 ) );
		foreach ( $admins as $admin ) {
			Niva_Notifications::notify(
				(int) $admin->ID,
				'درخواست پلن همکاران',
				$name . ' درخواست فعال‌سازی «' . dr_niva()->plans->label( $plan ) . '» را ثبت کرد.',
				admin_url( 'admin.php?page=dr-niva-partners' ),
				array( 'channels' => array( 'inapp' ) )
			);
		}
	}

	/** Stores ?ref=CODE in a cookie so a later registration can be attributed. */
	public function capture_ref() : void {
		if ( is_admin() || ! isset( $_GET['ref'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			return;
		}
		$code = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) wp_unslash( $_GET['ref'] ) ) ); // phpcs:ignore WordPress.Security.NonceVerification.Recommended
		if ( ! $code || ! $this->by_code( $code ) ) {
			return;
		}
		setcookie( 'niva_ref', $code, time() + ( 30 * DAY_IN_SECONDS ), COOKIEPATH ? COOKIEPATH : '/', COOKIE_DOMAIN );
		global $wpdb;
		$wpdb->query( $wpdb->prepare( 'UPDATE ' . Niva_DB::table( 'partners' ) . ' SET clicks = clicks + 1 WHERE code = %s', $code ) ); // phpcs:ignore WordPress.DB
	}

	public function by_code( string $code ) : ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'partners' ) . ' WHERE code = %s', strtoupper( $code ) ), ARRAY_A ); // phpcs:ignore WordPress.DB
		return $row ? $row : null;
	}

	public function by_user( int $user_id ) : ?array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'partners' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		return $row ? $row : null;
	}

	/* ---------------------------------------------------------- registration */

	public function apply( array $data ) {
		global $wpdb;

		$name  = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		$type  = sanitize_key( (string) ( $data['type'] ?? 'clinic' ) );
		$phone = sanitize_text_field( (string) ( $data['phone'] ?? '' ) );
		$email = sanitize_email( (string) ( $data['email'] ?? '' ) );
		$city  = sanitize_text_field( (string) ( $data['city'] ?? '' ) );
		$note  = sanitize_textarea_field( (string) ( $data['note'] ?? '' ) );

		if ( ! $name || ( ! $phone && ! $email ) ) {
			return new WP_Error( 'niva_partner_invalid', 'نام و یک راه ارتباطی (تلفن یا ایمیل) لازم است.', array( 'status' => 400 ) );
		}
		if ( ! $email ) {
			$email = '';
		}

		$user_id = get_current_user_id();
		if ( $user_id && $this->by_user( $user_id ) ) {
			return new WP_Error( 'niva_partner_exists', 'قبلاً درخواست همکاری ثبت کرده‌ای.', array( 'status' => 409 ) );
		}

		$code = $this->unique_code( $name );
		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'partners' ),
			array(
				'user_id'    => $user_id,
				'name'       => $name,
				'type'       => $type,
				'phone'      => $phone,
				'email'      => $email,
				'city'       => $city,
				'note'       => $note,
				'code'       => $code,
				'status'     => 'pending',
				'commission' => (float) dr_niva()->settings->get( 'partner_commission' ),
				'created_at' => current_time( 'mysql' ),
			)
		);

		do_action( 'dr_niva_partner_applied', (int) $wpdb->insert_id, $name );

		// The request doubles as a request for the partner plan.
		if ( $user_id ) {
			do_action( 'dr_niva_partner_plan_requested', (int) $user_id, (string) dr_niva()->settings->get( 'partner_plan', 'partner' ), $name );
		}

		$admins = get_users( array( 'role' => 'administrator', 'fields' => array( 'ID' ), 'number' => 10 ) );
		foreach ( $admins as $admin ) {
			Niva_Notifications::notify(
				(int) $admin->ID,
				'درخواست همکاری جدید',
				$name . ' (' . $type . ') درخواست همکاری ثبت کرد.',
				admin_url( 'admin.php?page=dr-niva-partners' ),
				array( 'channels' => array( 'inapp' ) )
			);
		}

		return array( 'ok' => true, 'code' => $code );
	}

	private function unique_code( string $name ) : string {
		$base = strtoupper( substr( preg_replace( '/[^A-Za-z]/', '', $name ), 0, 4 ) );
		if ( strlen( $base ) < 3 ) {
			$base = 'NIVA';
		}
		do {
			$code = $base . wp_rand( 100, 999 );
		} while ( $this->by_code( $code ) );
		return $code;
	}

	public function set_status( int $partner_id, string $status, ?float $commission = null ) : void {
		global $wpdb;
		$data = array( 'status' => sanitize_key( $status ) );
		if ( null !== $commission ) {
			$data['commission'] = $commission;
		}
		if ( 'approved' === $status ) {
			$data['approved_at'] = current_time( 'mysql' );
		}
		$wpdb->update( Niva_DB::table( 'partners' ), $data, array( 'id' => $partner_id ) ); // phpcs:ignore WordPress.DB

		$partner = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'partners' ) . ' WHERE id = %d', $partner_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $partner ) {
			return;
		}

		// approved partners can be given the partner plan for free (option)
		if ( 'approved' === $status && $partner['user_id'] && dr_niva()->settings->is_on( 'partner_gets_plan' ) ) {
			dr_niva()->plans->assign( (int) $partner['user_id'], (string) dr_niva()->settings->get( 'partner_plan' ), 'partner', 0, 'partner:' . $partner_id );
		}

		if ( $partner['user_id'] ) {
			Niva_Notifications::notify(
				(int) $partner['user_id'],
				'approved' === $status ? 'درخواست همکاری تأیید شد' : 'وضعیت درخواست همکاری تغییر کرد',
				'approved' === $status
					? 'کد معرف تو فعال شد و از پنل همکاران قابل مشاهده است.'
					: 'وضعیت درخواستت به «' . $status . '» تغییر کرد.',
				home_url( '/' )
			);
		}
	}

	/* -------------------------------------------------------------- analytics */

	public function referrals( int $partner_id, int $limit = 50 ) : array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'partner_referrals' ) . ' WHERE partner_id = %d ORDER BY id DESC LIMIT %d', $partner_id, $limit ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		return $rows ? $rows : array();
	}

	public function stats( int $partner_id ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'partner_referrals' );

		$signups    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE partner_id = %d", $partner_id ) ); // phpcs:ignore WordPress.DB
		$sales      = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(amount),0) FROM {$table} WHERE partner_id = %d", $partner_id ) ); // phpcs:ignore WordPress.DB
		$commission = (float) $wpdb->get_var( $wpdb->prepare( "SELECT COALESCE(SUM(commission),0) FROM {$table} WHERE partner_id = %d", $partner_id ) ); // phpcs:ignore WordPress.DB
		$paid       = (float) $wpdb->get_var( $wpdb->prepare( 'SELECT COALESCE(SUM(amount),0) FROM ' . Niva_DB::table( 'payouts' ) . " WHERE partner_id = %d AND status = 'paid'", $partner_id ) ); // phpcs:ignore WordPress.DB
		$partner    = $wpdb->get_row( $wpdb->prepare( 'SELECT clicks FROM ' . Niva_DB::table( 'partners' ) . ' WHERE id = %d', $partner_id ), ARRAY_A ); // phpcs:ignore WordPress.DB

		return array(
			'clicks'     => $partner ? (int) $partner['clicks'] : 0,
			'signups'    => $signups,
			'sales'      => $sales,
			'commission' => $commission,
			'paid'       => $paid,
			'unpaid'     => max( 0, $commission - $paid ),
		);
	}

	/** A new user registered: link them to the partner whose cookie is present. */
	public function attribute_signup( int $user_id ) : void {
		$code = isset( $_COOKIE['niva_ref'] ) ? strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', (string) $_COOKIE['niva_ref'] ) ) : '';
		if ( ! $code ) {
			return;
		}
		$partner = $this->by_code( $code );
		if ( ! $partner || 'approved' !== $partner['status'] ) {
			return;
		}
		global $wpdb;
		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'partner_referrals' ),
			array(
				'partner_id' => (int) $partner['id'],
				'user_id'    => $user_id,
				'order_id'   => 0,
				'amount'     => 0,
				'commission' => 0,
				'status'     => 'signup',
				'created_at' => current_time( 'mysql' ),
			)
		);
		update_user_meta( $user_id, 'niva_ref_partner', (int) $partner['id'] );
	}

	/** Commission whenever a referred user completes an order. */
	public function record_commission( $order_id ) : void {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}
		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return;
		}
		$user_id  = (int) $order->get_user_id();
		$partner_id = (int) get_user_meta( $user_id, 'niva_ref_partner', true );
		if ( ! $partner_id ) {
			return;
		}
		$partner = $this->by_user( $user_id ) ? null : $this->by_code( (string) get_user_meta( $user_id, 'niva_ref_code', true ) );
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'partners' ) . ' WHERE id = %d', $partner_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $row ) {
			return;
		}

		$already = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'partner_referrals' ) . ' WHERE partner_id = %d AND order_id = %d', $partner_id, $order_id ) ); // phpcs:ignore WordPress.DB
		if ( $already ) {
			return;
		}

		$amount     = (float) $order->get_total();
		$commission = round( $amount * ( (float) $row['commission'] / 100 ), 2 );

		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'partner_referrals' ),
			array(
				'partner_id' => $partner_id,
				'user_id'    => $user_id,
				'order_id'   => (int) $order_id,
				'amount'     => $amount,
				'commission' => $commission,
				'status'     => 'earned',
				'created_at' => current_time( 'mysql' ),
			)
		);

		if ( $row['user_id'] ) {
			Niva_Notifications::notify(
				(int) $row['user_id'],
				'پورسانت جدید ثبت شد',
				'یک سفارش با کد تو ثبت شد و ' . number_format_i18n( $commission ) . ' پورسانت گرفتی.',
				home_url( '/' )
			);
		}
	}

	/* ------------------------------------------------------------------- REST */

	public function routes() : void {
		register_rest_route(
			Niva_Rest::NS,
			'/partners/apply',
			array(
				'methods'             => 'POST',
				'permission_callback' => '__return_true',
				'callback'            => function ( WP_REST_Request $request ) {
					$limit = (int) get_transient( 'niva_partner_rl_' . md5( (string) $request->get_param( 'phone' ) . $request->get_param( 'email' ) ) );
					if ( $limit > 2 ) {
						return new WP_Error( 'niva_partner_rate', 'درخواست تکراری؛ بعداً تلاش کن.', array( 'status' => 429 ) );
					}
					set_transient( 'niva_partner_rl_' . md5( (string) $request->get_param( 'phone' ) . $request->get_param( 'email' ) ), $limit + 1, DAY_IN_SECONDS );
					return $this->apply( (array) $request->get_params() );
				},
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/partners/me',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => function () {
					$partner = $this->by_user( get_current_user_id() );
					if ( ! $partner ) {
						return array( 'partner' => null );
					}
					return array(
						'partner' => $partner,
						'stats'   => $this->stats( (int) $partner['id'] ),
						'link'    => home_url( '/?ref=' . $partner['code'] ),
					);
				},
			)
		);
	}

	/* ------------------------------------------------------------------ admin */

	public function handle_admin_action() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_partner_action' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		$partner_id = isset( $_POST['partner_id'] ) ? absint( $_POST['partner_id'] ) : 0;
		$action     = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';

		switch ( $action ) {
			case 'approve':
				$this->set_status( $partner_id, 'approved', isset( $_POST['commission'] ) ? (float) $_POST['commission'] : null );
				break;
			case 'decline':
				$this->set_status( $partner_id, 'declined' );
				break;
			case 'suspend':
				$this->set_status( $partner_id, 'suspended' );
				break;
			case 'commission':
				$this->set_status( $partner_id, 'approved', isset( $_POST['commission'] ) ? (float) $_POST['commission'] : null );
				break;
			case 'payout':
				global $wpdb;
				$amount = isset( $_POST['amount'] ) ? (float) $_POST['amount'] : 0;
				if ( $amount > 0 ) {
					$wpdb->insert( // phpcs:ignore WordPress.DB
						Niva_DB::table( 'payouts' ),
						array(
							'partner_id' => $partner_id,
							'amount'     => $amount,
							'status'     => 'paid',
							'note'       => isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : '',
							'created_at' => current_time( 'mysql' ),
						)
					);
					$row = $wpdb->get_row( $wpdb->prepare( 'SELECT user_id FROM ' . Niva_DB::table( 'partners' ) . ' WHERE id = %d', $partner_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
					if ( $row && $row['user_id'] ) {
						Niva_Notifications::notify( (int) $row['user_id'], 'تسویه‌ی پورسانت انجام شد', number_format_i18n( $amount ) . ' به‌عنوان پورسانت پرداخت شد.', home_url( '/' ) );
					}
				}
				break;
		}

		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-partners&done=1' ) );
		exit;
	}
}
