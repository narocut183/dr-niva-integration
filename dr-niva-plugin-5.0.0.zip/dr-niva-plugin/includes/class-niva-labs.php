<?php
/**
 * The user's own lab results.
 *
 * Stored as user meta (no schema migration needed, survives updates): a list of
 * { date, marker, value } entries, newest first. Every screen that shows a lab
 * number reads from here — the plugin never invents a value.
 *
 * Reference ranges are standard adult ranges, shown as guidance only; they are
 * not a diagnosis and the screen says so.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Labs {

	const META = 'dr_niva_labs';
	const MAX  = 300;

	/** marker => [ label, unit, low, high ] */
	public static function markers() : array {
		return array(
			'hgb'  => array( 'هموگلوبین', 'g/dL', 12, 16 ),
			'fer'  => array( 'فریتین', 'ng/mL', 30, 200 ),
			'vitd' => array( 'ویتامین D', 'ng/mL', 30, 100 ),
			'fbs'  => array( 'قند ناشتا', 'mg/dL', 70, 100 ),
			'hba1c' => array( 'HbA1c', '٪', 4, 5.7 ),
			'tsh'  => array( 'TSH', 'mIU/L', 0.4, 4 ),
			'chol' => array( 'کلسترول تام', 'mg/dL', 0, 200 ),
			'ldl'  => array( 'LDL', 'mg/dL', 0, 130 ),
			'tg'   => array( 'تری‌گلیسیرید', 'mg/dL', 0, 150 ),
			'cr'   => array( 'کراتینین', 'mg/dL', 0.6, 1.2 ),
			'wbc'  => array( 'گلبول سفید', '10³/µL', 4, 10 ),
			'plt'  => array( 'پلاکت', '10³/µL', 150, 450 ),
			'ca'   => array( 'کلسیم', 'mg/dL', 8.5, 10.5 ),
			'fe'   => array( 'آهن', 'µg/dL', 60, 170 ),
			'rbc'  => array( 'گلبول قرمز', '10⁶/µL', 4, 6 ),
			'hct'  => array( 'هماتوکریت', '%', 36, 50 ),
			'mcv'  => array( 'حجم متوسط گلبول قرمز', 'fL', 80, 100 ),
			'mch'  => array( 'هموگلوبین متوسط گلبول قرمز', 'pg', 27, 33 ),
			'mchc' => array( 'غلظت متوسط هموگلوبین', 'g/dL', 32, 36 ),
			'rdw'  => array( 'پهنای توزیع گلبول قرمز', '%', 11.5, 14.5 ),
			'neu'  => array( 'نوتروفیل', '%', 40, 75 ),
			'lym'  => array( 'لنفوسیت', '%', 20, 45 ),
			'mono' => array( 'مونوسیت', '%', 2, 10 ),
			'eos'  => array( 'ائوزینوفیل', '%', 0, 6 ),
			'baso' => array( 'بازوفیل', '%', 0, 2 ),
			'bun'  => array( 'اوره خون (BUN)', 'mg/dL', 7, 20 ),
			'egfr' => array( 'برآورد عملکرد کلیه (eGFR)', 'mL/min', 60, 130 ),
			'ast'  => array( 'AST', 'U/L', 0, 40 ),
			'alt'  => array( 'ALT', 'U/L', 0, 41 ),
			'alp'  => array( 'آلکالین فسفاتاز', 'U/L', 44, 147 ),
			'bili' => array( 'بیلی‌روبین تام', 'mg/dL', 0.1, 1.2 ),
			'na'   => array( 'سدیم', 'mmol/L', 135, 145 ),
			'k'    => array( 'پتاسیم', 'mmol/L', 3.5, 5.1 ),
			't3'   => array( 'T3', 'ng/dL', 80, 200 ),
			't4'   => array( 'T4', 'µg/dL', 5, 12 ),
			'uric' => array( 'اسیداوریک', 'mg/dL', 2.4, 7 ),
			'crp'  => array( 'CRP', 'mg/L', 0, 10 ),
			'esr'  => array( 'ESR', 'mm/h', 0, 20 ),
		);
	}

	public static function label( string $marker ) : string {
		$all = self::markers();
		return isset( $all[ $marker ] ) ? $all[ $marker ][0] : $marker;
	}

	public static function unit( string $marker ) : string {
		$all = self::markers();
		return isset( $all[ $marker ] ) ? $all[ $marker ][1] : '';
	}

	/** 'low' | 'ok' | 'high' — or '' when the marker is unknown. */
	public static function status( string $marker, $value, $reference_low = null, $reference_high = null ) : string {
		$all = self::markers();
		$has_report_range = is_numeric( $reference_low ) && is_numeric( $reference_high ) && (float) $reference_high >= (float) $reference_low;
		if ( ! isset( $all[ $marker ] ) && ! $has_report_range ) {
			return '';
		}
		$value = (float) $value;
		$low   = $has_report_range ? (float) $reference_low : (float) $all[ $marker ][2];
		$high  = $has_report_range ? (float) $reference_high : (float) $all[ $marker ][3];
		if ( $value < $low ) {
			return 'low';
		}
		if ( $value > $high ) {
			return 'high';
		}
		return 'ok';
	}

	public static function status_label( string $status ) : string {
		return array(
			'low'  => 'کمتر از محدوده',
			'ok'   => 'در محدوده',
			'high' => 'بیشتر از محدوده',
		)[ $status ] ?? '';
	}

	public static function explanation( string $marker, $value, $reference_low = null, $reference_high = null ) : string {
		$has_report_range = is_numeric( $reference_low ) && is_numeric( $reference_high ) && (float) $reference_high >= (float) $reference_low;
		$status = self::status( $marker, $value, $reference_low, $reference_high );
		$source = $has_report_range ? 'بازهٔ درج‌شده روی برگه' : 'محدودهٔ مرجع عمومی';
		if ( 'ok' === $status ) {
			return 'این مقدار در ' . $source . ' قرار دارد.';
		}
		if ( 'low' === $status ) {
			return 'این مقدار پایین‌تر از ' . $source . ' است؛ علت را نمی‌توان فقط از این عدد مشخص کرد.';
		}
		if ( 'high' === $status ) {
			return 'این مقدار بالاتر از ' . $source . ' است؛ علت را نمی‌توان فقط از این عدد مشخص کرد.';
		}
		return 'برای این مورد محدودهٔ مرجع در دسترس نیست.';
	}

	/** Every entry, newest first. */
	public static function all( int $user_id = 0 ) : array {
		$user_id = $user_id ? $user_id : (int) get_current_user_id();
		if ( ! $user_id ) {
			return array();
		}
		$raw = get_user_meta( $user_id, self::META, true );
		if ( ! is_array( $raw ) ) {
			return array();
		}
		$out = array();
		foreach ( $raw as $entry ) {
			if ( ! is_array( $entry ) || ! isset( $entry['marker'], $entry['value'] ) ) {
				continue;
			}
			$out[] = array(
				'date'   => (string) ( $entry['date'] ?? '' ),
				'marker' => (string) $entry['marker'],
				'value'  => (float) $entry['value'],
				'name'   => sanitize_text_field( (string) ( $entry['name'] ?? '' ) ),
				'unit'   => sanitize_text_field( (string) ( $entry['unit'] ?? '' ) ),
				'reference_low'  => isset( $entry['reference_low'] ) && is_numeric( $entry['reference_low'] ) ? (float) $entry['reference_low'] : null,
				'reference_high' => isset( $entry['reference_high'] ) && is_numeric( $entry['reference_high'] ) ? (float) $entry['reference_high'] : null,
			);
		}
		return $out;
	}

	/** marker => the most recent entry for that marker. */
	public static function latest( int $user_id = 0 ) : array {
		$out = array();
		foreach ( self::all( $user_id ) as $entry ) {
			if ( ! isset( $out[ $entry['marker'] ] ) ) {
				$out[ $entry['marker'] ] = $entry;
			}
		}
		return $out;
	}

	/** The real trend for one marker, oldest first (max 12 points). */
	public static function series( int $user_id, string $marker, int $limit = 12 ) : array {
		return array_map(
			static function ( $entry ) {
				return $entry['value'];
			},
			self::series_entries( $user_id, $marker, $limit )
		);
	}

	public static function series_entries( int $user_id, string $marker, int $limit = 12 ) : array {
		$entries = array();
		foreach ( self::all( $user_id ) as $entry ) {
			if ( $entry['marker'] === $marker ) {
				$entries[] = $entry;
			}
		}
		return array_slice( array_reverse( $entries ), -max( 1, $limit ) );
	}

	/** Markers that actually have data, in the order of first appearance. */
	public static function used( int $user_id = 0 ) : array {
		$used = array();
		foreach ( self::latest( $user_id ) as $marker => $entry ) {
			$used[] = $marker;
		}
		return $used;
	}

	public static function add( int $user_id, string $marker, $value, string $date = '', bool $default_to_today = true, array $reference = array(), string $name = '', string $unit = '' ) : bool {
		if ( ! $user_id || ! isset( self::markers()[ $marker ] ) ) {
			return false;
		}
		$meta = self::markers()[ $marker ];
		return self::store( $user_id, $marker, $value, $date, $default_to_today, $reference, $name ?: $meta[0], $unit ?: $meta[1] );
	}

	public static function add_custom( int $user_id, string $name, $value, string $unit, string $date = '', array $reference = array() ) : bool {
		$name = sanitize_text_field( $name );
		$name_length = function_exists( 'mb_strlen' ) ? mb_strlen( $name, 'UTF-8' ) : strlen( $name );
		if ( ! $user_id || '' === $name || $name_length > 120 ) {
			return false;
		}
		$marker = 'custom-' . substr( hash( 'sha256', function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name ) ), 0, 16 );
		return self::store( $user_id, $marker, $value, $date, false, $reference, $name, sanitize_text_field( $unit ) );
	}

	private static function store( int $user_id, string $marker, $value, string $date, bool $default_to_today, array $reference, string $name, string $unit ) : bool {
		$value = (float) $value;
		if ( $value <= 0 || $value > 100000 ) {
			return false;
		}
		$timestamp = '' !== $date ? strtotime( $date ) : false;
		$date      = false !== $timestamp
			? wp_date( 'Y-m-d', $timestamp )
			: ( $default_to_today ? current_time( 'Y-m-d' ) : '' );
		$entry = array( 'date' => $date, 'marker' => $marker, 'value' => $value, 'name' => $name, 'unit' => $unit );
		if ( is_numeric( $reference['low'] ?? null ) && is_numeric( $reference['high'] ?? null ) && (float) $reference['high'] >= (float) $reference['low'] ) {
			$entry['reference_low']  = (float) $reference['low'];
			$entry['reference_high'] = (float) $reference['high'];
		}

		$list = self::all( $user_id );
		array_unshift( $list, $entry );
		$list = array_slice( $list, 0, self::MAX );

		update_user_meta( $user_id, self::META, $list );
		return true;
	}

	public static function forget( int $user_id, int $index ) : bool {
		$list = self::all( $user_id );
		if ( ! isset( $list[ $index ] ) ) {
			return false;
		}
		unset( $list[ $index ] );
		update_user_meta( $user_id, self::META, array_values( $list ) );
		return true;
	}
}
