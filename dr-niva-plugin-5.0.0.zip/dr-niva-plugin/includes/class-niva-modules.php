<?php
/**
 * Module renderer.
 *
 * Every section of the product is a partial in public/partials plus an entry in
 * the generated map. Elementor widgets and the [dr_niva_module] shortcode both
 * call render(), so markup has one source of truth.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Modules {

	/** Tokens the editor may pass through the "hide" field. */
	public static function tokens() : array {
		return array(
			'heading'   => 'عنوان و سربرگ بخش',
			'chart'     => 'نمودارها',
			'upload'    => 'باکس آپلود فایل',
			'docs'      => 'فهرست اسناد',
			'print'     => 'دکمه و برگه‌ی چاپ',
			'chat'      => 'پنجره‌ی گفت‌وگو',
			'legend'    => 'راهنمای رنگ‌ها',
			'symptoms'  => 'ثبت علائم',
			'counter'   => 'شمارنده‌ها',
			'checklist' => 'چک‌لیست',
		);
	}

	/** @var array<string,array>|null */
	private static $map = null;

	/** id => module definition */
	public static function map() : array {
		if ( null === self::$map ) {
			$file = DR_NIVA_PATH . 'includes/niva-modules-map.php';
			self::$map = file_exists( $file ) ? (array) include $file : array();
		}
		return self::$map;
	}

	public static function exists( string $id ) : bool {
		$map = self::map();
		return isset( $map[ $id ] );
	}

	public static function label( string $id ) : string {
		$map = self::map();
		return isset( $map[ $id ] ) ? (string) $map[ $id ]['label'] : $id;
	}

	public static function group( string $id ) : string {
		$map = self::map();
		return isset( $map[ $id ] ) ? (string) $map[ $id ]['group'] : 'عمومی';
	}

	public static function icon( string $id ) : string {
		$map = self::map();
		return isset( $map[ $id ] ) ? (string) $map[ $id ]['icon'] : 'eicon-apps';
	}

	/** Modules that need a logged-in user. */
	public static function requires_login( string $id ) : bool {
		/*
		 * companion_view is deliberately public: a companion has no account and
		 * authenticates with the signed link + their own one-time code, so the
		 * login gate must not block them (Niva_Companion re-checks everything).
		 */
		$public = array( 'home_head', 'home_tasks', 'home_plan', 'quick_actions', 'exercises', 'partners_join', 'partners_plan', 'faq', 'packages', 'credits_bar', 'app_header', 'app_footer', 'about_mission', 'about_review', 'about_privacy', 'about_contact', 'tools_women', 'tools_health', 'tools_child', 'tools_advisor', 'tools_mind', 'tools_note', 'plans', 'companion_view' );
		return ! in_array( $id, $public, true );
	}

	/** Normalises the hide list to known tokens only. */
	public static function sanitize_hide( $value ) : string {
		$tokens = array_keys( self::tokens() );
		$given  = is_array( $value ) ? $value : preg_split( '/[\s,]+/', (string) $value );
		$out    = array();
		foreach ( (array) $given as $token ) {
			$token = sanitize_key( $token );
			if ( in_array( $token, $tokens, true ) ) {
				$out[] = $token;
			}
		}
		return implode( ' ', array_unique( $out ) );
	}


	/**
	 * Some screens belong to one profile only: a man has no use for the period
	 * calendar, and the product has screens that only make sense for a woman.
	 * Declaring the audience here lets render() skip a mismatch without a single
	 * template knowing anything about the user's profile.
	 *
	 * @return string '' (everyone) | 'female' | 'male'
	 */
	public static function audience( string $id ) : string {
		if ( 0 === strpos( $id, 'cycle_' ) || 0 === strpos( $id, 'pregnancy_' ) || 'tools_women' === $id ) {
			return 'female';
		}
		if ( 0 === strpos( $id, 'men_' ) || 'tools_men' === $id ) {
			return 'male';
		}
		return '';
	}

	/** True when the profile already states a different sex. */
	private static function audience_mismatch( string $id ) : bool {
		$wanted = self::audience( $id );
		if ( '' === $wanted || ! is_user_logged_in() || ! function_exists( 'dr_niva' ) ) {
			return false;
		}
		$plugin = dr_niva();
		if ( ! $plugin || ! $plugin->profile ) {
			return false;
		}
		$sex = strtolower( (string) ( $plugin->profile->get()['sex'] ?? '' ) );
		if ( '' === $sex || 'other' === $sex ) {
			return false; // unknown -> show everything
		}
		return $sex !== $wanted;
	}

	/**
	 * Link keys each module offers, so the editor can retarget them from inside
	 * the Elementor element instead of the plugin settings screen.
	 *
	 * @return array<string,array<string,string>> module id => [ link key => label ]
	 */
	public static function link_map() : array {
		return array(
			'home_head'      => array( 'plans' => 'دکمه‌ی پروفایل / اشتراک' ),
			'home_message'   => array( 'messages' => 'پیام‌های من' ),
			'home_status'    => array( 'cycle' => 'چرخه‌ی بانوان', 'pregnancy' => 'مسیر بارداری', 'baby' => 'رشد نوزاد' ),
			'home_tasks'     => array( 'advisor' => 'مشاور هوشمند', 'lab' => 'تحلیل آزمایش', 'cycle' => 'چرخه‌ی بانوان', 'pregnancy' => 'مسیر بارداری', 'baby' => 'رشد نوزاد', 'mind' => 'حال روان' ),
			'home_plan'      => array( 'plans' => 'اشتراک و اعتبار' ),
			'tools_health'   => array( 'lab' => 'تحلیل آزمایش', 'mind' => 'حال روان', 'baby' => 'رشد نوزاد' ),
			'tools_mind'     => array( 'mind' => 'حال روان' ),
			'tools_advisor'  => array( 'advisor' => 'مشاور هوشمند', 'reminders' => 'یادآورها' ),
			'tools_women'    => array( 'cycle' => 'چرخه‌ی بانوان', 'pregnancy' => 'مسیر بارداری' ),
			'tools_child'    => array( 'baby' => 'رشد نوزاد' ),
			'tools_note'     => array( 'advisor' => 'مشاور هوشمند', 'reminders' => 'یادآورها' ),
			'about_contact'  => array( 'plans' => 'اشتراک و اعتبار' ),
			'about_mission'  => array( 'tools' => 'فهرست ابزارها' ),
			'advisor_chat'   => array( 'mind' => 'حال روان' ),
			'lab_print'      => array( 'reminders' => 'ثبت یادآور' ),
			'faq'            => array( 'tools' => 'فهرست ابزارها', 'reminders' => 'یادآورها' ),
			'partners_join'  => array( 'plans' => 'اشتراک و اعتبار', 'profile' => 'تنظیمات من' ),
			'partners_plan'  => array( 'plans' => 'اشتراک و اعتبار', 'profile' => 'تنظیمات من' ),
			'partner_dashboard' => array( 'plans' => 'اشتراک و اعتبار' ),
			'family_panel'   => array( 'plans' => 'اشتراک و اعتبار' ),
			'user_settings'  => array( 'plans' => 'اشتراک و اعتبار', 'wallet' => 'کیف پول' ),
			'quick_actions'  => array( 'advisor' => 'مشاور هوشمند', 'lab' => 'تحلیل آزمایش', 'cycle' => 'چرخه‌ی بانوان', 'baby' => 'رشد نوزاد', 'mind' => 'حال روان', 'reminders' => 'یادآورها' ),
			'insights_feed'  => array( 'advisor' => 'مشاور هوشمند', 'lab' => 'تحلیل آزمایش', 'tools' => 'فهرست ابزارها', 'reminders' => 'یادآورها', 'plans' => 'اشتراک و اعتبار' ),
			'today_plan'     => array( 'reminders' => 'یادآورها' ),
			'lab_entry'      => array( 'lab' => 'بخش آزمایش' ),
			'exercises'      => array( 'reminders' => 'یادآور تمرین' ),
			'profile_hub'    => array( 'profile' => 'تنظیمات حساب', 'wallet' => 'کیف پول', 'plans' => 'اشتراک من', 'reminders' => 'یادآورها', 'tools' => 'همه‌ی ابزارها', 'partners' => 'همکاری با ما' ),
		);
	}

	/** Link keys (and their editor-facing labels) for one module. */
	public static function links( string $id ) : array {
		$map = self::link_map();
		return isset( $map[ $id ] ) ? $map[ $id ] : array();
	}

	/**
	 * Resolves one link for a module: element override first, then the global
	 * link registry. Partials call this instead of touching the registry, which
	 * is what makes per-widget link editing possible.
	 */
	public static function url( string $key, array $args = array(), string $fallback = '' ) : string {
		if ( ! empty( $args['links'][ $key ] ) ) {
			$override = (string) $args['links'][ $key ];
			if ( 0 === strpos( $override, 'http' ) ) {
				return Niva_Links::normalize_legacy_router_url( $override );
			}
			if ( 0 === strpos( $override, '#' ) || 0 === strpos( $override, '?' ) ) {
				return home_url( '/' ) . $override;
			}
			return Niva_Links::normalize_legacy_router_url( home_url( '/' . ltrim( $override, '/' ) ) );
		}

		/*
		 * The registry always exists in a healthy install, but the header and
		 * every button route through here — so a missing registry must degrade to
		 * the home URL instead of taking the whole page down.
		 */
		$plugin = function_exists( 'dr_niva' ) ? dr_niva() : null;
		if ( $plugin && ! empty( $plugin->links ) ) {
			return $plugin->links->url( $key );
		}

		return '' !== $fallback ? $fallback : home_url( '/' );
	}

	/**
	 * Renders one module.
	 *
	 * @param string $id   Module id from the map.
	 * @param array  $args ['hide' => string, 'title' => string, 'show_title' => bool,
	 *                      'links' => array<string,string>]
	 */
	public static function render( string $id, array $args = array() ) : string {
		if ( ! self::exists( $id ) ) {
			return '';
		}

		if ( self::audience_mismatch( $id ) ) {
			// Never render a blank page for the wrong profile: say why, and how to fix it.
			$wants = self::audience( $id );
			return '<div class="niva-module" data-module="' . esc_attr( $id ) . '"><section class="card">' .
				Niva_Chrome::blank(
					'این بخش برای پروفایل تو فعال نیست',
					( 'female' === $wants
						? 'بخش‌های چرخه و بارداری برای پروفایل بانوان نمایش داده می‌شوند. '
						: 'این بخش برای پروفایل آقایان نمایش داده می‌شود. ' )
					. 'برای فعال‌کردن، پروفایلت را کامل کن. علت دقیق را در «چرا این بخش‌ها را نمی‌بینم؟» ببین.',
					'تنظیمات حساب من',
					'profile',
					array()
				) .
				'</section></div>';
		}

		$args = wp_parse_args(
			$args,
			array(
				'hide'       => '',
				'title'      => '',
				'show_title' => false,
				'title_tag'  => 'h2',
				'links'      => array(),
			)
		);
		$args['hide']  = self::sanitize_hide( $args['hide'] );
		$args['links'] = is_array( $args['links'] ) ? $args['links'] : array();

		// Guests see a clear call to action instead of a broken screen.
		if ( self::requires_login( $id ) && ! is_user_logged_in() ) {
			return self::login_notice();
		}

		if ( is_user_logged_in() && dr_niva()->plans ) {
			$access = dr_niva()->plans->feature_access( get_current_user_id(), $id );
			if ( is_wp_error( $access ) ) {
				return self::locked_markup( $id, $access, $args );
			}
		}

		// Data driven modules (no static partial).
		switch ( $id ) {
			case 'credits_bar':
				return dr_niva()->frontend ? dr_niva()->frontend->credits_bar_html() : '';
			case 'wallet':
				return dr_niva()->orders ? dr_niva()->orders->wallet_markup() : '';
			case 'packages':
				return dr_niva()->orders ? dr_niva()->orders->shortcode_packages() : '';
		}

		$partial = DR_NIVA_PATH . 'public/partials/' . $id . '.php';
		if ( ! file_exists( $partial ) ) {
			return '';
		}

		ob_start();
		if ( $args['show_title'] && '' !== trim( (string) $args['title'] ) ) {
			$tag = in_array( $args['title_tag'], array( 'h1', 'h2', 'h3', 'h4', 'span' ), true ) ? $args['title_tag'] : 'h2';
			echo '<' . esc_html( $tag ) . ' class="niva-module__title">' . esc_html( $args['title'] ) . '</' . esc_html( $tag ) . '>';
		}
		include $partial;
		return (string) ob_get_clean();
	}

	/**
	 * The locked state of a module (2.0.0).
	 *
	 * Per the brief the card is *faded, not dead*: it stays visible so the user
	 * can see what they are missing, but the click is intercepted and opens a
	 * small sheet explaining the upgrade instead of navigating. Elementor can
	 * override the wording, the required plan and hide/fade behaviour per widget;
	 * the access decision itself is always taken here, server side.
	 *
	 * @param array $args Widget/shortcode arguments (optional lock overrides).
	 */
	public static function locked_markup( string $id, WP_Error $access, array $args = array() ) : string {
		$error_data = (array) $access->get_error_data();
		$upgrade    = isset( $error_data['upgrade'] ) ? (string) $error_data['upgrade'] : self::url( 'plans' );
		$required   = isset( $error_data['plan'] ) ? (string) $error_data['plan'] : '';

		$mode        = isset( $args['lock_mode'] ) && in_array( $args['lock_mode'], array( 'fade', 'hide' ), true ) ? (string) $args['lock_mode'] : 'fade';
		$custom_text = isset( $args['lock_text'] ) ? trim( (string) $args['lock_text'] ) : '';
		$custom_url  = isset( $args['upgrade_url'] ) ? trim( (string) $args['upgrade_url'] ) : '';
		$button_text = isset( $args['upgrade_label'] ) && '' !== trim( (string) $args['upgrade_label'] ) ? (string) $args['upgrade_label'] : 'ارتقا بده';
		if ( '' !== $custom_url ) {
			$upgrade = $custom_url;
		}

		$plan_label = $required && dr_niva()->plans ? dr_niva()->plans->label( $required ) : '';
		$message    = '' !== $custom_text ? $custom_text : 'این بخش نیازمند ارتقا به ' . ( $plan_label ? $plan_label : 'پلن بالاتر' ) . ' است.';
		$show_faded = 'hide' !== $mode;

		/*
		 * The click signal is recorded by the script when the user actually
		 * opens the sheet (POST /gate) — not on render, so the admin report
		 * measures intent rather than impressions.
		 */
		if ( ! $show_faded ) {
			return '';
		}

		// The gate script only loads on pages that actually show a locked tool.
		wp_enqueue_script( 'dr-niva-gate', DR_NIVA_URL . 'public/assets/js/gate.js', array(), DR_NIVA_VERSION, true );

		$sheet_id = 'niva-gate-' . sanitize_html_class( $id ) . '-' . wp_rand( 1000, 9999 );
		ob_start();
		?>
		<div class="niva-module niva-module--locked niva-gate" data-module="<?php echo esc_attr( $id ); ?>"
			data-niva-gate data-niva-gate-sheet="<?php echo esc_attr( $sheet_id ); ?>"
			data-niva-gate-module="<?php echo esc_attr( $id ); ?>"
			data-niva-gate-log="<?php echo esc_attr( rest_url( Niva_Rest::NS . '/gate' ) ); ?>"
			data-niva-gate-nonce="<?php echo esc_attr( wp_create_nonce( 'wp_rest' ) ); ?>">
			<section class="card niva-feature-locked niva-feature-locked--faded">
				<span class="card__icon" aria-hidden="true"><?php echo Niva_Icons::svg( 'lock', 20 ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></span>
				<span class="niva-lock-badge">نیازمند <?php echo esc_html( $plan_label ? $plan_label : 'ارتقا' ); ?></span>
				<h2 class="card__title"><?php echo esc_html( isset( $args['title'] ) && '' !== trim( (string) $args['title'] ) ? (string) $args['title'] : self::map()[ $id ]['label'] ?? 'این بخش' ); ?></h2>
				<p class="muted"><?php echo esc_html( $message ); ?></p>
				<button type="button" class="btn btn--primary" data-niva-gate-open="<?php echo esc_attr( $sheet_id ); ?>">
					<?php echo esc_html( $button_text ); ?>
				</button>
				<span class="niva-lock-fallback">
					<a href="<?php echo esc_url( $upgrade ); ?>">دیدن پلن‌ها</a>
				</span>
			</section>

			<div class="sheet niva-gate__sheet" id="<?php echo esc_attr( $sheet_id ); ?>" hidden>
				<button type="button" class="sheet__scrim" data-niva-gate-close aria-label="بستن"></button>
				<section class="sheet__panel" role="dialog" aria-modal="true" aria-labelledby="<?php echo esc_attr( $sheet_id ); ?>-title" tabindex="-1">
					<div class="sheet__head">
						<h2 class="sheet__title" id="<?php echo esc_attr( $sheet_id ); ?>-title">این بخش نیازمند ارتقا به <?php echo esc_html( $plan_label ? $plan_label : 'پلن بالاتر' ); ?> است</h2>
						<button type="button" class="sheet__close" data-niva-gate-close aria-label="بستن">&#215;</button>
					</div>
					<p class="muted"><?php echo esc_html( $message ); ?></p>
					<ul class="niva-gate__benefits">
						<li>دسترسی کامل به همین ابزار و بخش‌های مرتبط</li>
						<li>سهمیهٔ بیشتر برای گفتگو، آزمایش و تحلیل تصویر</li>
						<li>حفظ همهٔ داده‌های فعلی؛ فقط محدودیت‌ها کم می‌شود</li>
					</ul>
					<div class="niva-gate__actions">
						<a class="btn btn--primary" href="<?php echo esc_url( $upgrade ); ?>"><?php echo esc_html( $button_text ); ?></a>
						<button type="button" class="btn btn--ghost" data-niva-gate-close>بعداً</button>
					</div>
				</section>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * Records one locked-tool click so the admin can see real upgrade demand.
	 *
	 * Written to the same usage table the rest of the product uses, with the
	 * cost pinned to zero — this is a signal, never a charge.
	 */
	public static function log_gate_click( string $module_id, string $required_plan = '' ) : void {
		$user_id = (int) get_current_user_id();
		if ( ! $user_id || ! dr_niva()->wallet ) {
			return;
		}
		// One row per module per hour per user: enough signal, no flood.
		$key = 'niva_gate_' . $user_id . '_' . md5( $module_id );
		if ( get_transient( $key ) ) {
			return;
		}
		set_transient( $key, 1, HOUR_IN_SECONDS );

		dr_niva()->wallet->log_usage(
			$user_id,
			'gate_blocked',
			0,
			'gate',
			$module_id,
			array( 'required_plan' => $required_plan )
		);
	}

	/** Shown to guests for modules that need an account. */
	public static function login_notice() : string {
		ob_start();
		?>
		<div class="niva-module niva-module--locked">
			<div class="card" style="text-align: center">
				<h2>برای استفاده از این بخش وارد شو</h2>
				<p class="muted">با یک شماره موبایل ثبت‌نام می‌کنی و سهمیه‌ی رایگان روزانه‌ات فعال می‌شود.</p>
				<a class="btn btn--primary" href="<?php echo esc_url( wp_login_url( get_permalink() ? get_permalink() : home_url( '/' ) ) ); ?>">ورود / ثبت‌نام</a>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}


	/**
	 * A module that throws must never leave the page blank and silent.
	 *
	 * Visitors see nothing; an administrator sees exactly which module failed and
	 * on which line, so a problem is one screenshot away from being fixed instead
	 * of being invisible.
	 */
	private static function failure_note( string $id, \Throwable $e ) : string {
		if ( ! current_user_can( 'manage_options' ) ) {
			return '';
		}

		return sprintf(
			'<div class="card niva-module-error" style="border:2px solid #c0453d;background:#fff5f4"><strong>بخش «%s» رندر نشد</strong><br><code dir="ltr">%s: %s</code><br><span class="caption">%s:%d</span></div>',
			esc_html( $id ),
			esc_html( get_class( $e ) ),
			esc_html( $e->getMessage() ),
			esc_html( basename( $e->getFile() ) ),
			(int) $e->getLine()
		);
	}

	/** [dr_niva_module id="cycle_calendar" hide="chart"] */
	public static function shortcode( $atts = array() ) : string {
		$niva_level = ob_get_level();
		$atts = shortcode_atts(
			array( 'id' => '', 'hide' => '', 'title' => '', 'show_title' => '', 'title_tag' => 'h2' ),
			$atts,
			'dr_niva_module'
		);
		$id = sanitize_key( $atts['id'] );
		if ( ! $id ) {
			return '';
		}
		try {
			$frontend = dr_niva()->frontend;
			if ( $frontend ) {
				$frontend->enqueue();
			}

			return self::render(
				$id,
				array(
					'hide'       => $atts['hide'],
					'title'      => sanitize_text_field( $atts['title'] ),
					'show_title' => in_array( (string) $atts['show_title'], array( '1', 'yes', 'true' ), true ),
					'title_tag'  => sanitize_key( (string) ( $atts['title_tag'] ?? 'h2' ) ),
				)
			);
		} catch ( \Throwable $e ) {
			// Unwind only the buffers opened since we were called, so a failing
			// module can never eat WordPress's own output buffer.
			while ( ob_get_level() > $niva_level ) {
				ob_end_clean();
			}
			return self::failure_note( $id, $e );
		}
	}

	public static function init() : void {
		add_shortcode( 'dr_niva_module', array( __CLASS__, 'shortcode' ) );
	}
}

Niva_Modules::init();
