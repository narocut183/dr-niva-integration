<?php
/**
 * Credits, daily quota and the ledger.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Wallet {

	private function table( string $name ) : string {
		return Niva_DB::table( $name );
	}

	/** Returns the wallet row for a user, creating it when needed. */
	public function ensure( int $user_id ) : array {
		global $wpdb;
		$table = $this->table( 'wallets' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d", $user_id ), ARRAY_A ); // phpcs:ignore
		if ( $row ) {
			return $row;
		}
		$wpdb->insert(
			$table,
			array(
				'user_id'    => $user_id,
				'balance'    => 0,
				'spent_total' => 0,
				'quota_date' => gmdate( 'Y-m-d' ),
				'quota_used' => 0,
				'updated_at' => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%d', '%s', '%d', '%s' )
		);

		$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d", $user_id ), ARRAY_A ); // phpcs:ignore

		/*
		 * The method promises an array. When the table is missing or the insert
		 * was refused, get_row() returns null and PHP throws a TypeError that
		 * takes the whole page down — this ran from enqueue(), so a single
		 * missing wallet row wiped out the entire app page. Return a zeroed
		 * record instead and let the rest of the page render.
		 */
		if ( ! is_array( $row ) ) {
			return array(
				'user_id'     => $user_id,
				'balance'     => 0,
				'spent_total' => 0,
				'quota_date'  => gmdate( 'Y-m-d' ),
				'quota_used'  => 0,
				'updated_at'  => current_time( 'mysql' ),
			);
		}

		return $row;
	}

	/** Rolls the free daily quota forward when the date changed. */
	private function roll_quota( array $row ) : array {
		$today = current_time( 'Y-m-d' );
		if ( $row['quota_date'] === $today ) {
			return $row;
		}
		global $wpdb;
		$table = $this->table( 'wallets' );
		$wpdb->update(
			$table,
			array( 'quota_date' => $today, 'quota_used' => 0, 'updated_at' => current_time( 'mysql' ) ),
			array( 'user_id' => (int) $row['user_id'] ),
			array( '%s', '%d', '%s' ),
			array( '%d' )
		);
		$row['quota_date'] = $today;
		$row['quota_used'] = 0;
		return $row;
	}

	/** Everything the UI needs in one payload. */
	/** Removes credits, never going below zero (refunds, manual corrections). */
	public function deduct( int $user_id, int $amount, string $reason = 'adjust', string $ref = '' ) : array {
		global $wpdb;
		$this->ensure( $user_id );
		$amount = abs( $amount );
		$table  = $this->table( 'wallets' );

		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET balance = GREATEST( 0, balance - %d ), updated_at = %s WHERE user_id = %d", // phpcs:ignore
				$amount,
				current_time( 'mysql' ),
				$user_id
			)
		);
		$balance = (int) $wpdb->get_var( $wpdb->prepare( "SELECT balance FROM {$table} WHERE user_id = %d", $user_id ) ); // phpcs:ignore
		$this->log_ledger( $user_id, -$amount, $reason, $ref, $balance );
		do_action( 'dr_niva_credits_deducted', $user_id, $amount, $reason, $ref );
		return $this->summary( $user_id );
	}

	public function summary( int $user_id ) : array {
		$settings = dr_niva()->settings;
		$row      = $this->roll_quota( $this->ensure( $user_id ) );
		$limit    = (int) $settings->get( 'free_daily_quota' );
		$used     = (int) $row['quota_used'];

		/*
		 * 2.0.0 — the plan allowance is the middle layer of the spend order, so it
		 * is reported next to the free quota: the user always sees which bucket
		 * the next action will spend.
		 */
		$subscription    = $this->subscription();
		$plan_quota      = $subscription ? $subscription->plan_quota( $user_id, 'chat' ) : array();
		$expiry_notice   = $subscription ? $subscription->expiry_notice( $user_id ) : array();
		$plan_left       = (int) ( $plan_quota['left'] ?? 0 );
		$free_exhausted  = $limit > 0 && $used >= $limit;

		return array(
			'enabled'      => $settings->is_on( 'credits_enabled' ),
			'balance'      => (int) $row['balance'],
			'spent_total'  => (int) $row['spent_total'],
			'quota_limit'  => $limit,
			'quota_used'   => $used,
			'quota_left'   => max( 0, $limit - $used ),
			'low'          => (int) $row['balance'] <= (int) $settings->get( 'low_balance_threshold' ),
			'packages'     => $settings->packages(),
			'plan'            => (string) ( $plan_quota['plan'] ?? 'free' ),
			'plan_limit'      => (int) ( $plan_quota['limit'] ?? 0 ),
			'plan_used'       => (int) ( $plan_quota['used'] ?? 0 ),
			'plan_left'       => $plan_left,
			'plan_window'     => (string) ( $plan_quota['window'] ?? '' ),
			'announce_wallet' => $settings->is_on( 'quota_notify_on_empty' ) && $free_exhausted && 0 === $plan_left && (int) $row['balance'] > 0,
			'exhausted'       => $free_exhausted && 0 === $plan_left && (int) $row['balance'] < 1,
			'expiry_notice'   => is_array( $expiry_notice ) ? $expiry_notice : array(),
		);
	}

	/** Subscription helper (optional, so the wallet never hard-depends on it). */
	private function subscription() : ?Niva_Subscription {
		$plugin = function_exists( 'dr_niva' ) ? dr_niva() : null;
		return ( $plugin && isset( $plugin->subscription ) && $plugin->subscription instanceof Niva_Subscription ) ? $plugin->subscription : null;
	}

	/** Which plan counter an action consumes (chat / lab / image). */
	private function counter_for_kind( string $kind ) : string {
		if ( 0 === strpos( $kind, 'image' ) ) {
			return 'image';
		}
		if ( 0 === strpos( $kind, 'lab' ) ) {
			return 'lab';
		}
		return 'chat';
	}

	/** Adds credits (purchase, gift, referral, refund). */
	public function grant( int $user_id, int $amount, string $reason, string $ref = '', array $meta = array() ) : array {
		global $wpdb;
		if ( $amount <= 0 ) {
			return $this->summary( $user_id );
		}
		$this->ensure( $user_id );
		$table = $this->table( 'wallets' );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET balance = balance + %d, updated_at = %s WHERE user_id = %d", // phpcs:ignore
				$amount,
				current_time( 'mysql' ),
				$user_id
			)
		);
		$balance = (int) $wpdb->get_var( $wpdb->prepare( "SELECT balance FROM {$table} WHERE user_id = %d", $user_id ) ); // phpcs:ignore
		$this->log_ledger( $user_id, $amount, $reason, $ref, $balance, $meta );
		do_action( 'dr_niva_credits_granted', $user_id, $amount, $reason, $ref );
		return $this->summary( $user_id );
	}

	/**
	 * Charges one action: free quota first, then the paid balance.
	 *
	 * @return array|WP_Error
	 */
	public function spend( int $user_id, int $cost, string $kind, string $ref = '', array $meta = array() ) {
		global $wpdb;
		$settings = dr_niva()->settings;

		if ( ! $settings->is_on( 'credits_enabled' ) ) {
			return array( 'charged_from' => 'free_mode', 'cost' => 0, 'usage_id' => 0, 'summary' => $this->summary( $user_id ) );
		}

		$row   = $this->roll_quota( $this->ensure( $user_id ) );
		$limit = (int) $settings->get( 'free_daily_quota' );
		$used  = (int) $row['quota_used'];

		// 1) free daily allowance
		if ( empty( $meta['force_balance'] ) && $limit > 0 && $used < $limit ) {
			$wpdb->update(
				$this->table( 'wallets' ),
				array( 'quota_used' => $used + 1, 'updated_at' => current_time( 'mysql' ) ),
				array( 'user_id' => $user_id ),
				array( '%d', '%s' ),
				array( '%d' )
			);
			$usage_id = $this->log_usage( $user_id, $kind, 0, 'quota', $ref, $meta );
			return array( 'charged_from' => 'quota', 'cost' => 0, 'usage_id' => $usage_id, 'summary' => $this->summary( $user_id ) );
		}

		/*
		 * 2) the plan's own allowance. It sits between the free quota and the
		 * wallet, and it is consumed atomically (see Niva_Subscription) so two
		 * parallel requests can never overspend the monthly allowance.
		 */
		$subscription = $this->subscription();
		if ( empty( $meta['force_balance'] ) && $subscription
			&& $subscription->consume_plan_quota( $user_id, $this->counter_for_kind( $kind ) ) ) {
			$usage_id = $this->log_usage( $user_id, $kind, 0, 'plan', $ref, $meta );
			return array( 'charged_from' => 'plan', 'cost' => 0, 'usage_id' => $usage_id, 'summary' => $this->summary( $user_id ) );
		}

		// 3) paid balance — conditional update keeps it race-safe
		$charged = $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$this->table('wallets')} SET balance = balance - %d, spent_total = spent_total + %d, updated_at = %s
				 WHERE user_id = %d AND balance >= %d", // phpcs:ignore
				$cost,
				$cost,
				current_time( 'mysql' ),
				$user_id,
				$cost
			)
		);

		if ( 1 !== $charged ) {
			return new WP_Error(
				'niva_insufficient_credits',
				(string) $settings->get( 'exhausted_message' ),
				array(
					'status'   => 402,
					'balance'  => (int) $row['balance'],
					'required' => $cost,
					'packages' => $settings->packages(),
					'credits_url' => ( new Niva_Links() )->url( 'wallet' ),
					'upgrade_url' => ( new Niva_Links() )->url( 'plans' ),
				)
			);
		}

		$usage_id = $this->log_usage( $user_id, $kind, $cost, 'balance', $ref, $meta );
		$balance = (int) $wpdb->get_var( $wpdb->prepare( "SELECT balance FROM {$this->table('wallets')} WHERE user_id = %d", $user_id ) ); // phpcs:ignore
		if ( $cost > 0 ) {
			$this->log_ledger( $user_id, -$cost, 'spend:' . $kind, $ref, $balance, $meta );
		}
		return array( 'charged_from' => 'balance', 'cost' => $cost, 'usage_id' => $usage_id, 'summary' => $this->summary( $user_id ) );
	}

	/** Gives a charge back when the AI call failed. */
	public function refund_usage( int $usage_id ) : bool {
		global $wpdb;
		$table = $this->table( 'usage' );
		$usage = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $usage_id ), ARRAY_A ); // phpcs:ignore
		if ( ! $usage ) {
			return false;
		}
		if ( 'balance' === $usage['charged_from'] && (int) $usage['cost'] > 0 ) {
			$this->grant( (int) $usage['user_id'], (int) $usage['cost'], 'refund', 'usage:' . $usage_id );
		} elseif ( 'plan' === $usage['charged_from'] ) {
			// Give the plan unit back to the same bucket it came from.
			$subscription = $this->subscription();
			if ( $subscription ) {
				$subscription->refund_plan_quota( (int) $usage['user_id'], $this->counter_for_kind( (string) $usage['kind'] ) );
			}
		} elseif ( 'quota' === $usage['charged_from'] ) {
			$wallet = $this->ensure( (int) $usage['user_id'] );
			$wpdb->update(
				$this->table( 'wallets' ),
				array( 'quota_used' => max( 0, (int) $wallet['quota_used'] - 1 ), 'updated_at' => current_time( 'mysql' ) ),
				array( 'user_id' => (int) $usage['user_id'] ),
				array( '%d', '%s' ),
				array( '%d' )
			);
		}
		$wpdb->update( $table, array( 'charged_from' => 'refunded' ), array( 'id' => $usage_id ), array( '%s' ), array( '%d' ) );
		return true;
	}

	public function log_usage( int $user_id, string $kind, int $cost, string $from, string $ref = '', array $meta = array() ) : int {
		global $wpdb;
		$wpdb->insert(
			$this->table( 'usage' ),
			array(
				'user_id'      => $user_id,
				'kind'         => $kind,
				'provider'     => isset( $meta['provider'] ) ? (string) $meta['provider'] : null,
				'model'        => isset( $meta['model'] ) ? (string) $meta['model'] : null,
				'cost'         => $cost,
				'charged_from' => $from,
				'tokens_in'    => isset( $meta['tokens_in'] ) ? (int) $meta['tokens_in'] : 0,
				'tokens_out'   => isset( $meta['tokens_out'] ) ? (int) $meta['tokens_out'] : 0,
				'ref'          => $ref,
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%d', '%s', '%d', '%d', '%s', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	/** Stores the provider's reported token usage for cost auditing. */
	public function record_usage_tokens( int $usage_id, array $result ) : void {
		if ( $usage_id <= 0 ) {
			return;
		}
		global $wpdb;
		$wpdb->update(
			$this->table( 'usage' ),
			array(
				'provider'   => sanitize_key( (string) ( $result['provider'] ?? '' ) ),
				'model'      => sanitize_text_field( (string) ( $result['model'] ?? '' ) ),
				'tokens_in'  => max( 0, (int) ( $result['tokens_in'] ?? 0 ) ),
				'tokens_out' => max( 0, (int) ( $result['tokens_out'] ?? 0 ) ),
			),
			array( 'id' => $usage_id ),
			array( '%s', '%s', '%d', '%d' ),
			array( '%d' )
		);
	}

	/** Finalizes a previously reserved plan-quota record after successful work. */
	public function complete_plan_usage( int $usage_id ) : bool {
		global $wpdb;
		$table = $this->table( 'usage' );
		$changed = $wpdb->update(
			$table,
			array( 'charged_from' => 'plan' ),
			array( 'id' => $usage_id, 'charged_from' => 'plan_reserved' ),
			array( '%s' ),
			array( '%d', '%s' )
		);
		return 1 === $changed;
	}

	/** Releases an unused reservation or charges a small remaining difference. */
	public function reconcile_usage( int $usage_id, int $actual_cost ) : bool {
		global $wpdb;
		$table = $this->table( 'usage' );
		$usage = $wpdb->get_row( $wpdb->prepare( "SELECT user_id, cost, charged_from, ref FROM {$table} WHERE id = %d", $usage_id ), ARRAY_A ); // phpcs:ignore
		if ( ! $usage || 'balance' !== $usage['charged_from'] ) {
			return (bool) $usage;
		}

		$actual_cost = max( 0, $actual_cost );
		$difference  = $actual_cost - (int) $usage['cost'];
		$wallet_table = $this->table( 'wallets' );
		if ( $difference > 0 ) {
			$charged = $wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wallet_table} SET balance = balance - %d, spent_total = spent_total + %d, updated_at = %s WHERE user_id = %d AND balance >= %d", // phpcs:ignore
					$difference,
					$difference,
					current_time( 'mysql' ),
					(int) $usage['user_id'],
					$difference
				)
			);
			if ( 1 !== $charged ) {
				return false;
			}
		} elseif ( $difference < 0 ) {
			$refund = abs( $difference );
			$wpdb->query(
				$wpdb->prepare(
					"UPDATE {$wallet_table} SET balance = balance + %d, spent_total = GREATEST( 0, spent_total - %d ), updated_at = %s WHERE user_id = %d", // phpcs:ignore
					$refund,
					$refund,
					current_time( 'mysql' ),
					(int) $usage['user_id']
				)
			);
		}

		$wpdb->update( $table, array( 'cost' => $actual_cost ), array( 'id' => $usage_id ), array( '%d' ), array( '%d' ) );
		if ( 0 !== $difference ) {
			$balance = (int) $wpdb->get_var( $wpdb->prepare( "SELECT balance FROM {$wallet_table} WHERE user_id = %d", (int) $usage['user_id'] ) ); // phpcs:ignore
			$this->log_ledger( (int) $usage['user_id'], -$difference, 'usage-adjust', (string) $usage['ref'], $balance );
		}
		return true;
	}

	private function log_ledger( int $user_id, int $delta, string $reason, string $ref, int $balance_after, array $meta = array() ) : void {
		if ( 0 === $delta ) {
			return;
		}
		global $wpdb;
		$wpdb->insert(
			$this->table( 'ledger' ),
			array(
				'user_id'       => $user_id,
				'delta'         => $delta,
				'reason'        => $reason,
				'ref'           => $ref,
				'balance_after' => $balance_after,
				'meta'          => $meta ? wp_json_encode( $meta ) : null,
				'created_at'    => current_time( 'mysql' ),
			),
			array( '%d', '%d', '%s', '%s', '%d', '%s', '%s' )
		);
	}

	/** Recent ledger movements for the wallet screen. */
	public function ledger( int $user_id, int $limit = 10, int $offset = 0 ) : array {
		global $wpdb;
		$table = $this->table( 'ledger' );
		$rows  = $wpdb->get_results(
			$wpdb->prepare( "SELECT delta, reason, balance_after, created_at FROM {$table} WHERE user_id = %d AND delta <> 0 ORDER BY id DESC LIMIT %d OFFSET %d", $user_id, max( 1, $limit ), max( 0, $offset ) ), // phpcs:ignore
			ARRAY_A
		);
		if ( ! is_array( $rows ) ) {
			return array();
		}
		foreach ( $rows as &$row ) {
			$row['created_at_label'] = Niva_Chrome::format_datetime( (string) $row['created_at'] );
		}
		unset( $row );
		return $rows;
	}

	public function ledger_count( int $user_id ) : int {
		global $wpdb;
		$table = $this->table( 'ledger' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND delta <> 0", $user_id ) ); // phpcs:ignore
	}

	/** Usage grouped by kind for the "چند تا مصرف کردی" panel. */
	public function usage_report( int $user_id, int $days = 30 ) : array {
		global $wpdb;
		$table = $this->table( 'usage' );
		$rows  = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT kind, COUNT(*) AS calls, SUM(cost) AS credits FROM {$table}
				 WHERE user_id = %d AND created_at >= DATE_SUB(NOW(), INTERVAL %d DAY)
				 GROUP BY kind ORDER BY calls DESC", // phpcs:ignore
				$user_id,
				$days
			),
			ARRAY_A
		);
		return is_array( $rows ) ? $rows : array();
	}
}
