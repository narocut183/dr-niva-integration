<?php
/**
 * Generated module map — every section of the product as one Elementor widget.
 *
 * Built from the partials in public/partials; regenerate instead of editing by hand.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

return array(
	'about_contact' => array(
		'label' => 'چطور با ما در ارتباط باشی',
		'group' => 'درباره ما',
		'icon'  => 'eicon-info-circle',
	),
	'about_mission' => array(
		'label' => 'داده‌ی سلامت را از سردرگمی به تصمیم تبدیل می',
		'group' => 'درباره ما',
		'icon'  => 'eicon-info-circle',
	),
	'about_privacy' => array(
		'label' => 'حریم خصوصی داده سلامت',
		'group' => 'درباره ما',
		'icon'  => 'eicon-info-circle',
	),
	'about_review' => array(
		'label' => 'محتوای این سایت چطور تأیید می‌شود',
		'group' => 'درباره ما',
		'icon'  => 'eicon-info-circle',
	),
	'advisor_chat' => array(
		'label' => 'موضوع',
		'group' => 'مشاور هوشمند',
		'icon'  => 'eicon-comments',
	),
	'advisor_safety' => array(
		'label' => 'قبل از شروع بدان',
		'group' => 'مشاور هوشمند',
		'icon'  => 'eicon-comments',
	),
	'advisor_topics' => array(
		'label' => 'موضوع گفت‌وگو',
		'group' => 'مشاور هوشمند',
		'icon'  => 'eicon-comments',
	),
	'baby_baby-history' => array(
		'label' => 'سابقه‌ی اندازه‌ها',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'baby_baby-measure' => array(
		'label' => 'ثبت اندازه‌های امروز',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'baby_baby-profile' => array(
		'label' => 'مشخصات نوزاد',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'baby_baby-reference' => array(
		'label' => 'مقایسه با جدول مرجع رشد',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'baby_baby-verdict' => array(
		'label' => 'نتیجه‌ی بررسی رشد',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'baby_chart' => array(
		'label' => 'روند وزن نوزاد',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'baby_checklist' => array(
		'label' => 'چک‌لیست این ماه',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'baby_print' => array(
		'label' => 'علائمی که نباید صبر کرد',
		'group' => 'نوزاد و کودک',
		'icon'  => 'eicon-image-box',
	),
	'cycle_calendar' => array(
		'label' => 'تقویم مهر',
		'group' => 'چرخه بانوان',
		'icon'  => 'eicon-calendar',
	),
	'cycle_checklist' => array(
		'label' => 'امروز چه حسی داری؟ (اختیاری)',
		'group' => 'چرخه بانوان',
		'icon'  => 'eicon-calendar',
	),
	'cycle_print' => array(
		'label' => 'بردن به متخصص زنان',
		'group' => 'چرخه بانوان',
		'icon'  => 'eicon-calendar',
	),
	'cycle_today' => array(
		'label' => 'امروز، ۱۵ مهر',
		'group' => 'چرخه بانوان',
		'icon'  => 'eicon-calendar',
	),
	'faq' => array(
		'label' => 'سؤال‌های کوتاه',
		'group' => 'عمومی',
		'icon'  => 'eicon-apps',
	),
	'home_head' => array(
		'label' => 'home_head',
		'group' => 'صفحه اصلی',
		'icon'  => 'eicon-home',
	),
	'home_message' => array(
		'label' => 'home_message',
		'group' => 'صفحه اصلی',
		'icon'  => 'eicon-home',
	),
	'home_status' => array(
		'label' => 'وضعیت امروزت',
		'group' => 'صفحه اصلی',
		'icon'  => 'eicon-home',
	),
	'home_tasks' => array(
		'label' => 'الان چه کاری داری؟',
		'group' => 'صفحه اصلی',
		'icon'  => 'eicon-home',
	),
	'lab_entry' => array(
		'label' => 'ثبت نتیجهٔ آزمایش',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-form-horizontal',
	),
	'lab_chart' => array(
		'label' => 'روند هموگلوبین تو',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-document-file',
	),
	'lab_docs' => array(
		'label' => 'فهرست اسناد من',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-document-file',
	),
	'lab_print' => array(
		'label' => 'خلاصه‌ی نتیجه',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-document-file',
	),
	'lab_progress' => array(
		'label' => 'حالت «در حال ارسال»',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-document-file',
	),
	'lab_skeleton' => array(
		'label' => 'حالت «در حال تحلیل»',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-document-file',
	),
	'lab_upload' => array(
		'label' => 'فایل را بفرست',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-document-file',
	),
	'lab_values' => array(
		'label' => 'مقدارها یکی‌یکی',
		'group' => 'تحلیل آزمایش',
		'icon'  => 'eicon-document-file',
	),
	'mind_assessment' => array(
		'label' => 'پرسشنامه‌ی حال',
		'group' => 'حال روان',
		'icon'  => 'eicon-smile',
	),
	'mind_breathing' => array(
		'label' => 'یک تمرین سه‌دقیقه‌ای',
		'group' => 'حال روان',
		'icon'  => 'eicon-smile',
	),
	'mind_chat' => array(
		'label' => 'می‌خواهی حرف بزنی؟',
		'group' => 'حال روان',
		'icon'  => 'eicon-smile',
	),
	'mind_crisis' => array(
		'label' => 'کمک فوری، همیشه در دسترس',
		'group' => 'حال روان',
		'icon'  => 'eicon-smile',
	),
	'mind_mood' => array(
		'label' => 'الان حالت چطوره؟',
		'group' => 'حال روان',
		'icon'  => 'eicon-smile',
	),
	'mind_thought-record' => array(
		'label' => 'دفترچه‌ی افکار',
		'group' => 'حال روان',
		'icon'  => 'eicon-smile',
	),
	'pregnancy_bag' => array(
		'label' => 'لیست بیمارستان',
		'group' => 'بارداری',
		'icon'  => 'eicon-heart-o',
	),
	'pregnancy_checklist' => array(
		'label' => 'کارهای همین هفته',
		'group' => 'بارداری',
		'icon'  => 'eicon-heart-o',
	),
	'pregnancy_counter' => array(
		'label' => 'وزن و حرکت جنین',
		'group' => 'بارداری',
		'icon'  => 'eicon-heart-o',
	),
	'pregnancy_print' => array(
		'label' => 'این علائم را جدی بگیر',
		'group' => 'بارداری',
		'icon'  => 'eicon-heart-o',
	),
	'pregnancy_timeline' => array(
		'label' => 'هفته‌های نزدیک',
		'group' => 'بارداری',
		'icon'  => 'eicon-heart-o',
	),
	'pregnancy_week' => array(
		'label' => 'این هفته چه مهم است',
		'group' => 'بارداری',
		'icon'  => 'eicon-heart-o',
	),
	'reminders_notification' => array(
		'label' => 'اجازه‌ی اعلان',
		'group' => 'یادآور و اعلان',
		'icon'  => 'eicon-alarm',
	),
	'reminders_reminder-form' => array(
		'label' => 'یادآور تازه',
		'group' => 'یادآور و اعلان',
		'icon'  => 'eicon-alarm',
	),
	'reminders_reminder-list' => array(
		'label' => 'یادآورهای من',
		'group' => 'یادآور و اعلان',
		'icon'  => 'eicon-alarm',
	),
	'tools_advisor' => array(
		'label' => 'مشاور هوشمند و یادآور',
		'group' => 'ناوبری',
		'icon'  => 'eicon-apps',
	),
	'tools_child' => array(
		'label' => 'نوزاد و کودک',
		'group' => 'ناوبری',
		'icon'  => 'eicon-apps',
	),
	'tools_health' => array(
		'label' => 'سلامت و آزمایش',
		'group' => 'ناوبری',
		'icon'  => 'eicon-apps',
	),
	'tools_mind' => array(
		'label' => 'حال روان',
		'group' => 'ناوبری',
		'icon'  => 'eicon-apps',
	),
	'tools_note' => array(
		'label' => 'یادداشت پایین فهرست',
		'group' => 'ناوبری',
		'icon'  => 'eicon-apps',
	),
	'tools_women' => array(
		'label' => 'بانوان و بارداری',
		'group' => 'ناوبری',
		'icon'  => 'eicon-apps',
	),
	'credits_bar' => array(
		'label' => 'نوار اعتبار کاربر',
		'group' => 'اعتبار',
		'icon'  => 'eicon-number-field',
	),
	'wallet' => array(
		'label' => 'کیف پول و تراکنش‌ها',
		'group' => 'اعتبار',
		'icon'  => 'eicon-wallet',
	),
	'packages' => array(
		'label' => 'بسته‌های خرید اعتبار',
		'group' => 'اعتبار',
		'icon'  => 'eicon-price-list',
	),
	'app_header' => array(
		'label' => 'هدر اپ (لوگو، منو، حساب)',
		'group' => 'برند و چیدمان',
		'icon'  => 'eicon-header',
	),
	'app_footer' => array(
		'label' => 'فوتر اپ و نوار پایین',
		'group' => 'برند و چیدمان',
		'icon'  => 'eicon-footer',
	),
	'plans_table' => array(
		'label' => 'پلن‌ها و اشتراک (قابل تنظیم)',
		'group' => 'اشتراک و اعتبار',
		'icon'  => 'eicon-price-table',
	),
	'home_plan' => array(
		'label' => 'وضعیت اشتراک من',
		'group' => 'اشتراک و اعتبار',
		'icon'  => 'eicon-price-list',
	),
	'family_panel' => array(
		'label' => 'اشتراک خانوادگی (اعضا و کد دعوت)',
		'group' => 'اشتراک و اعتبار',
		'icon'  => 'eicon-person',
	),
	'partners_join' => array(
		'label' => 'همکاری با ما (فرم ثبت‌نام)',
		'group' => 'همکاران',
		'icon'  => 'eicon-person',
	),
	'partner_dashboard' => array(
		'label' => 'پنل همکاران',
		'group' => 'همکاران',
		'icon'  => 'eicon-chart',
	),
	'partners_plan' => array(
		'label' => 'پلن همکاران (ویژگی‌ها و درخواست فعال‌سازی)',
		'group' => 'همکاران',
		'icon'  => 'eicon-price-list',
	),
	'messages_archive' => array(
		'label' => 'آرشیو پیام‌ها (متن کامل)',
		'group' => 'پیام‌ها',
		'icon'  => 'eicon-document-file',
	),
	'user_settings' => array(
		'label' => 'تنظیمات کاربر',
		'group' => 'حساب کاربری',
		'icon'  => 'eicon-settings',
	),
	'health_score' => array(
		'label' => 'امتیاز سلامت (حلقه و ریزامتیازها)',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-counter',
	),
	'weekly_activity' => array(
		'label' => 'فعالیت هفت روز گذشته (نمودار ستونی)',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-bar-chart',
	),
	'quick_actions' => array(
		'label' => 'دسترسی سریع (شبکه‌ی کارت‌ها)',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-apps',
	),
	'insights_feed' => array(
		'label' => 'پیشنهادهای هوشمند',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-alert',
	),
	'today_plan' => array(
		'label' => 'برنامه‌ی امروز (یادآورها)',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-checkbox',
	),
	'exercises' => array(
		'label' => 'تمرین‌های خانگی (کتابخانه‌ی حرکت)',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-move',
	),
	'medication_grid' => array(
		'label' => 'تابلوی هفته (نمودار شبکه‌ای)',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-grid',
	),
	'profile_hub' => array(
		'label' => 'حساب کاربری (کارت پروفایل و فهرست)',
		'group' => 'پیشخوان هوشمند',
		'icon'  => 'eicon-user-circle-o',
	),
	'notifications_inbox' => array(
		'label' => 'صندوق اعلان‌ها',
		'group' => 'حساب کاربری',
		'icon'  => 'eicon-alert',
	),
	/* ---- 2.0.0 ---- */
	'onboarding_wizard' => array(
		'label' => 'ویزارد تکمیل پروفایل',
		'group' => 'حساب کاربری',
		'icon'  => 'eicon-form-horizontal',
	),
	'profile_completion' => array(
		'label' => 'کارت تکمیل پروفایل',
		'group' => 'حساب کاربری',
		'icon'  => 'eicon-alert',
	),
	'profile_visibility' => array(
		'label' => 'چرا این بخش‌ها را نمی‌بینم؟',
		'group' => 'حساب کاربری',
		'icon'  => 'eicon-eye',
	),
	'community_home' => array(
		'label' => 'گفتگو با کاربران (صفحهٔ اصلی انجمن)',
		'group' => 'انجمن و گفتگو',
		'icon'  => 'eicon-comments',
	),
	'community_thread' => array(
		'label' => 'گفتگو با کاربران (صفحهٔ یک پرسش)',
		'group' => 'انجمن و گفتگو',
		'icon'  => 'eicon-commenting-o',
	),
	'community_new' => array(
		'label' => 'گفتگو با کاربران (ثبت پرسش تازه)',
		'group' => 'انجمن و گفتگو',
		'icon'  => 'eicon-plus-circle-o',
	),
	'community_categories' => array(
		'label' => 'گفتگو با کاربران (دسته‌بندی‌ها)',
		'group' => 'انجمن و گفتگو',
		'icon'  => 'eicon-apps',
	),
	'community_my_activity' => array(
		'label' => 'گفتگو با کاربران (فعالیت من)',
		'group' => 'انجمن و گفتگو',
		'icon'  => 'eicon-bullet-list',
	),
	'companion_create' => array(
		'label' => 'کد همراهی (ساخت و مدیریت)',
		'group' => 'همراهی',
		'icon'  => 'eicon-heart-o',
	),
	'companion_view' => array(
		'label' => 'کد همراهی (صفحهٔ خواندنی همراه)',
		'group' => 'همراهی',
		'icon'  => 'eicon-preview-medium',
	),
);
