<?php
/**
 * Reminders storage (the notification itself fires in the browser while the
 * app is open; a future phase adds web push).
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Reminders {

	public function table() : string {
		return Niva_DB::table( 'reminders' );
	}

	public function add( int $user_id, string $title, string $time, string $repeat ) : int {
		global $wpdb;
		if ( ! preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time ) || '' === trim( $title ) ) {
			return 0;
		}
		$limit = (int) dr_niva()->settings->get( 'reminders_limit' );
		if ( $limit > 0 && $this->count( $user_id ) >= $limit ) {
			return 0;
		}
		$wpdb->insert(
			$this->table(),
			array(
				'user_id'      => $user_id,
				'title'        => sanitize_text_field( $title ),
				'time_at'      => $time,
				'repeat_rule'  => in_array( $repeat, array( 'daily', 'once', 'weekly' ), true ) ? $repeat : 'daily',
				'done'         => 0,
				'created_at'   => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%d', '%s' )
		);
		return (int) $wpdb->insert_id;
	}

	public function all( int $user_id ) : array {
		global $wpdb;
		$rows = $wpdb->get_results(
			$wpdb->prepare( "SELECT id, title, time_at, repeat_rule, done, created_at FROM {$this->table()} WHERE user_id = %d ORDER BY time_at ASC", $user_id ), // phpcs:ignore
			ARRAY_A
		);
		return is_array( $rows ) ? $rows : array();
	}

	public function count( int $user_id ) : int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table()} WHERE user_id = %d", $user_id ) ); // phpcs:ignore
	}

	public function toggle( int $user_id, int $id ) : bool {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( "SELECT done FROM {$this->table()} WHERE id = %d AND user_id = %d", $id, $user_id ), ARRAY_A ); // phpcs:ignore
		if ( ! $row ) {
			return false;
		}
		$wpdb->update( $this->table(), array( 'done' => empty( $row['done'] ) ? 1 : 0 ), array( 'id' => $id ), array( '%d' ), array( '%d' ) );
		return true;
	}

	public function update( int $user_id, int $id, string $title, string $time, string $repeat ) : bool {
		global $wpdb;
		if ( ! $id || '' === trim( $title ) || ! preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time ) ) {
			return false;
		}
		$result = $wpdb->update(
			$this->table(),
			array(
				'title'       => sanitize_text_field( $title ),
				'time_at'     => $time,
				'repeat_rule' => in_array( $repeat, array( 'daily', 'once', 'weekly' ), true ) ? $repeat : 'daily',
			),
			array(
				'id'      => $id,
				'user_id' => $user_id,
			),
			array( '%s', '%s', '%s' ),
			array( '%d', '%d' )
		);
		$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$this->table()} WHERE id = %d AND user_id = %d", $id, $user_id ) ); // phpcs:ignore WordPress.DB
		return false !== $result && 1 === $exists;
	}

	public function remove( int $user_id, int $id ) : bool {
		global $wpdb;
		return (bool) $wpdb->delete( $this->table(), array( 'id' => $id, 'user_id' => $user_id ), array( '%d', '%d' ) );
	}

	/** Reminders that are due right now (used if a server-side channel is added). */
	public function due( int $user_id ) : array {
		global $wpdb;
		$now = current_time( 'H:i' );
		$today = current_time( 'Y-m-d' );
		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT id, title FROM {$this->table()} WHERE user_id = %d AND done = 0 AND time_at = %s AND (fired_on IS NULL OR fired_on <> %s)", // phpcs:ignore
				$user_id,
				$now,
				$today
			),
			ARRAY_A
		);
		return is_array( $rows ) ? $rows : array();
	}
}
