<?php
/**
 * Server side icon renderer.
 *
 * Icons are printed as inline SVG on the server, so a widget never shows a
 * broken box when Javascript is slow or blocked, and nothing is fetched from
 * an external host.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Icons {

	/** @var array<string,string>|null */
	private static $map = null;

	public static function map() : array {
		if ( null === self::$map ) {
			$file      = DR_NIVA_PATH . 'includes/niva-icons-map.php';
			self::$map = file_exists( $file ) ? (array) include $file : array();
		}
		return self::$map;
	}

	/** Inline SVG for one icon name. */
	public static function svg( string $name, int $size = 20, string $class = '' ) : string {
		$map = self::map();
		if ( ! isset( $map[ $name ] ) ) {
			return '';
		}
		return sprintf(
			'<svg class="niva-icon %s" width="%d" height="%d" style="width:%dpx;height:%dpx" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.75" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true" focusable="false">%s</svg>',
			esc_attr( $class ),
			$size,
			$size,
			$size,
			$size,
			$map[ $name ] // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped -- trusted local markup
		);
	}

	/**
	 * Replaces every <span data-icon="name" data-size="n"></span> placeholder in a
	 * chunk of markup with the real inline SVG. Used for content that is stored in
	 * the database and for templates that were authored as static HTML.
	 */
	public static function hydrate( string $html ) : string {
		return (string) preg_replace_callback(
			'#<span\s+data-icon="([a-z0-9\-]+)"(?:\s+data-size="(\d+)")?\s*></span>#i',
			static function ( $matches ) {
				return self::svg( $matches[1], isset( $matches[2] ) ? (int) $matches[2] : 20 );
			},
			$html
		);
	}
}
