<?php
/**
 * Every internal link in one place, so nothing points at a missing .html file.
 *
 * Each key resolves in this order:
 *   1. an explicit URL from the settings
 *   2. a WordPress page whose slug matches the key (or the translated labels)
 *   3. the app router at the WordPress home path: /key/
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Links {

	/** key => [label, slug candidates, view name] */
	public static function registry() : array {
		return array(
			'home'         => array( 'خانه', array( 'home', 'dr-niva', 'دکتر-نیوا' ), 'home' ),
			'advisor'      => array( 'مشاور هوشمند', array( 'advisor', 'moshaver', 'مشاور' ), 'advisor' ),
			'lab'          => array( 'تحلیل آزمایش', array( 'lab', 'analyze', 'azmayesh', 'آزمایش' ), 'analyze' ),
			'cycle'        => array( 'چرخه بانوان', array( 'cycle', 'period', 'چرخه' ), 'cycle' ),
			'pregnancy'    => array( 'مسیر بارداری', array( 'pregnancy', 'bardari', 'بارداری' ), 'pregnancy' ),
			'baby'         => array( 'رشد نوزاد', array( 'baby', 'nozad', 'نوزاد' ), 'baby' ),
			'mind'         => array( 'حال روان', array( 'mind', 'ravan', 'روان' ), 'mind' ),
			'reminders'    => array( 'یادآورها', array( 'reminders', 'alarms', 'yaddavar', 'یادآور' ), 'alarms' ),
			'plans'        => array( 'اشتراک و اعتبار', array( 'plans', 'subscription', 'اشتراک' ), 'plans' ),
			'wallet'       => array( 'کیف پول', array( 'wallet', 'kifpool', 'کیف-پول' ), 'wallet' ),
			'tools'        => array( 'ابزارها', array( 'tools', 'abzarha', 'ابزارها' ), 'tools' ),
			'family'       => array( 'اشتراک خانوادگی', array( 'family', 'khanevade', 'خانوادگی' ), 'family' ),
			'partners'     => array( 'همکاری با ما', array( 'partners', 'hamkari', 'همکاری' ), 'partners' ),
			'messages'     => array( 'پیام‌ها', array( 'messages', 'payamha', 'پیام-ها' ), 'tools' ),
			'profile'      => array( 'تنظیمات من', array( 'profile', 'settings', 'تنظیمات' ), 'profile' ),
			'about'        => array( 'درباره ما', array( 'about', 'darbare', 'درباره' ), 'about' ),
			// 2.0.0 destinations — each falls back to «تنظیمات من» until a page exists.
			'notifications' => array( 'اعلان‌ها', array( 'notifications', 'alerts', 'اعلان-ها' ), 'profile' ),
			'companion'    => array( 'همراهی', array( 'companion', 'hamrahi', 'همراهی' ), 'profile' ),
			'visibility'   => array( 'چرا این بخش‌ها را نمی‌بینم', array( 'visibility', 'why-not-visible', 'چرا-نمی-بینم' ), 'profile' ),
			// 2.0.1 — the new destinations must resolve to their own pages, not home.
			'community'    => array( 'گفتگو با کاربران', array( 'community', 'گفتگو', 'انجمن' ), 'community' ),
			'community_thread' => array( 'گفتگو', array( 'community-thread' ), 'community_thread' ),
			'community_new' => array( 'پرسش تازه', array( 'community-new' ), 'community_new' ),
			'companion_create' => array( 'کد همراهی', array( 'companion', 'همراهی' ), 'companion_create' ),
			'companion_view' => array( 'نمای همراه', array( 'companion-view' ), 'companion_view' ),
			'onboarding'   => array( 'تکمیل پروفایل', array( 'profile-completion', 'onboarding', 'تکمیل-پروفایل' ), 'onboarding' ),
		);
	}

	/**
	 * Module ids that mean the same destination as a registry key.
	 *
	 * The community, companion and wizard modules live on pages whose
	 * `_dr_niva_page_key` differs from the module id (`community_home` lives on
	 * the page keyed `community`), so a link built from the module id used to
	 * fall through to the home page.
	 *
	 * @return array<string,string>
	 */
	public static function aliases() : array {
		return array(
			'community_home'   => 'community',
			'community_new'    => 'community_new',
			'community_thread' => 'community_thread',
			'companion_create' => 'companion_create',
			'companion_view'   => 'companion_view',
			'onboarding_wizard' => 'onboarding',
			'profile_completion' => 'onboarding',
		);
	}

	/**
	 * Permalink of the page that owns a page key, rebuilt when pages change.
	 *
	 * @return array<string,string> page key => permalink
	 */
	public static function page_map() : array {
		$map = get_transient( 'dr_niva_page_key_map' );
		if ( is_array( $map ) ) {
			return $map;
		}
		$map   = array();
		$pages = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => 'publish',
				'posts_per_page'   => 200,
				'suppress_filters' => true,
				'fields'           => 'ids',
				'meta_key'         => '_dr_niva_page_key', // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		foreach ( $pages as $page_id ) {
			$key = (string) get_post_meta( (int) $page_id, '_dr_niva_page_key', true );
			if ( '' !== $key && ! isset( $map[ $key ] ) ) {
				$map[ $key ] = (string) get_permalink( (int) $page_id );
			}
		}
		set_transient( 'dr_niva_page_key_map', $map, DAY_IN_SECONDS );
		return $map;
	}

	/** Drops the cached page map after a page is saved or deleted. */
	public static function flush_page_map() : void {
		delete_transient( 'dr_niva_page_key_map' );
	}

	/** Resolves a page key (or module alias) straight to its page permalink. */
	public static function page_url_for_key( string $key ) : string {
		$key = sanitize_key( $key );
		if ( '' === $key ) {
			return '';
		}
		$aliases = self::aliases();
		if ( isset( $aliases[ $key ] ) ) {
			$key = $aliases[ $key ];
		}
		$map = self::page_map();
		return isset( $map[ $key ] ) ? (string) $map[ $key ] : '';
	}

	/** All links, resolved. */
	public function all() : array {
		$out = array();
		foreach ( array_keys( self::registry() ) as $key ) {
			$out[ $key ] = $this->url( $key );
		}
		return $out;
	}

	public function url( string $key ) : string {
		$registry = self::registry();
		if ( ! isset( $registry[ $key ] ) ) {
			// Module ids (community_home, companion_view, onboarding_wizard, …)
			// resolve through the page that carries their page key. Falling back
			// to home_url() here is what sent «پرسش تازه» to the home page.
			$mapped = self::page_url_for_key( $key );
			return '' !== $mapped ? $mapped : home_url( '/' );
		}

		// The account destination is always the app profile, never a store endpoint.
		if ( 'profile' === $key ) {
			$page = get_page_by_path( 'profile' );
			if ( $page instanceof WP_Post ) {
				return (string) get_permalink( $page );
			}
			return self::router_url( 'profile' );
		}

		// 1) explicit setting
		$override = (string) dr_niva()->settings->get( 'link_' . $key );
		if ( '' !== $override ) {
			$url = Niva_Compat::starts_with( $override, 'http' ) ? $override : home_url( '/' . ltrim( $override, '/' ) );
			return self::normalize_legacy_router_url( $url );
		}

		// 2) the page that carries this key in its elementor/page key meta
		$mapped = self::page_url_for_key( $key );
		if ( '' !== $mapped ) {
			return $mapped;
		}

		// 3) a page with the slug the site owner created
		foreach ( $registry[ $key ][1] as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page instanceof WP_Post ) {
				return (string) get_permalink( $page );
			}
		}

		// 3) the app router uses clean paths when the matching page is absent.
		if ( 'home' === $key ) {
			return home_url( '/' );
		}
		return self::router_url( $registry[ $key ][2] );
	}

	/** The canonical clean route, rooted at the configured WordPress home path. */
	public static function router_url( string $view ) : string {
		if ( 'home' === sanitize_key( $view ) ) {
			return home_url( '/' );
		}
		return home_url( '/' . rawurlencode( sanitize_key( $view ) ) . '/' );
	}

	/** Converts a same-site legacy /dr-niva/view/ link into the clean route. */
	public static function normalize_legacy_router_url( string $url ) : string {
		$parts = wp_parse_url( $url );
		if ( ! is_array( $parts ) || empty( $parts['path'] ) ) {
			return $url;
		}
		$home = wp_parse_url( home_url( '/' ) );
		if ( ! empty( $parts['host'] ) && ! empty( $home['host'] ) && strtolower( $parts['host'] ) !== strtolower( $home['host'] ) ) {
			return $url;
		}
		if ( ! preg_match( '#/dr-niva/([a-z0-9-]+)/?$#i', (string) $parts['path'], $match ) ) {
			return $url;
		}
		$route = sanitize_key( $match[1] );
		$known = array();
		foreach ( self::registry() as $entry ) {
			$known[] = $entry[2];
		}
		$known = array_merge( $known, array( 'home', 'profile', 'wallet', 'family', 'notifications' ) );
		if ( ! in_array( $route, array_unique( $known ), true ) ) {
			return $url;
		}
		$canonical = self::router_url( $route );
		if ( ! empty( $parts['query'] ) ) {
			$canonical .= '?' . $parts['query'];
		}
		if ( ! empty( $parts['fragment'] ) ) {
			$canonical .= '#' . $parts['fragment'];
		}
		return $canonical;
	}

	/** Adds one text field per link key to the settings screen. */
	public static function settings_fields() : array {
		$fields = array();
		foreach ( self::registry() as $key => $data ) {
			$fields[ 'link_' . $key ] = array(
				'type'  => 'text',
				'label' => 'لینک «' . $data[0] . '»',
				'default' => '',
				'hint'  => 'این مقدار پیش‌فرض کل سایت است. خالی بگذار تا خودکار پیدا شود (نشانی صفحه با نام ' . $data[1][0] . ' یا مسیر تمیز /' . $data[2] . '/). برای عوض‌کردن لینک فقط در یک بخش، از تنظیمات همان ویجت در المنتور > «لینک‌های این بخش» استفاده کن.',
			);
		}
		return $fields;
	}
}
