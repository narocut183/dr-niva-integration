<?php
/**
 * Community — «گفتگو با کاربران» (2.0.0).
 *
 * A moderated question-and-answer space: colour-coded categories, threads,
 * one level of comments, reactions and reports. This class is the single
 * source of truth for every rule (who may post, what gets hidden, what needs
 * review), and both the PHP partials and the REST layer go through it — so a
 * rule can never be bypassed by calling the API directly.
 *
 * Health-data safety: medical advice is not published without review, and
 * contact details are stripped from user text before it is stored.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Community {

	public const STATUS_PUBLISH = 'publish';
	public const STATUS_PENDING = 'pending';
	public const STATUS_HIDDEN  = 'hidden';
	public const STATUS_CLOSED  = 'closed';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
		add_action( 'init', array( $this, 'maybe_seed' ), 25 );
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
	}

	private function on() : bool {
		return dr_niva()->settings->is_on( 'community_enabled' );
	}

	/** New threads appear immediately, or wait for review. */
	private function auto_publish() : bool {
		return 'auto' === (string) dr_niva()->settings->get( 'community_mode', 'moderated' );
	}

	private function hide_contacts() : bool {
		return dr_niva()->settings->is_on( 'community_hide_contacts' );
	}

	/* ------------------------------------------------------------- categories */

	/** Seeds the default categories once, from the shipped JSON file. */
	public function maybe_seed() : void {
		if ( ! $this->on() ) {
			return;
		}
		if ( 'done' === get_option( 'dr_niva_community_seeded', '' ) ) {
			return;
		}

		global $wpdb;
		$table = Niva_DB::table( 'community_categories' );
		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ); // phpcs:ignore WordPress.DB
		if ( $count > 0 ) {
			update_option( 'dr_niva_community_seeded', 'done', false );
			return;
		}

		$file = DR_NIVA_PATH . 'data/community-categories.json';
		$raw  = is_readable( $file ) ? file_get_contents( $file ) : ''; // phpcs:ignore WordPress.WP.AlternativeFunctions
		$rows = $raw ? json_decode( $raw, true ) : array();
		if ( ! is_array( $rows ) ) {
			return;
		}

		$order = 0;
		foreach ( $rows as $row ) {
			$slug = sanitize_key( (string) ( $row['slug'] ?? '' ) );
			if ( '' === $slug ) {
				continue;
			}
			$order += 10;
			$wpdb->insert( // phpcs:ignore WordPress.DB
				$table,
				array(
					'slug'        => $slug,
					'title'       => sanitize_text_field( (string) ( $row['title'] ?? $slug ) ),
					'description' => sanitize_text_field( (string) ( $row['description'] ?? '' ) ),
					'icon'        => sanitize_key( (string) ( $row['icon'] ?? '' ) ),
					'color'       => sanitize_key( (string) ( $row['color'] ?? '' ) ),
					'sort_order'  => $order,
					'is_active'   => 1,
					'created_at'  => current_time( 'mysql', true ),
				)
			);
		}
		update_option( 'dr_niva_community_seeded', 'done', false );
	}

	/** All active categories, keyed by id. */
	public function categories( bool $active_only = true ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'community_categories' );
		$where = $active_only ? 'WHERE is_active = 1' : '';
		$rows  = $wpdb->get_results( "SELECT * FROM {$table} {$where} ORDER BY sort_order ASC, id ASC", ARRAY_A ); // phpcs:ignore WordPress.DB
		$out   = array();
		foreach ( (array) $rows as $row ) {
			$row['id'] = (int) $row['id'];
			$out[ $row['id'] ] = $row;
		}
		return $out;
	}

	public function category_by_slug( string $slug ) : array {
		foreach ( $this->categories() as $category ) {
			if ( $category['slug'] === $slug ) {
				return $category;
			}
		}
		return array();
	}

	/** Creates or updates a category (admin only; the caller checks caps). */
	public function save_category( array $data, int $id = 0 ) : int {
		global $wpdb;
		$table = Niva_DB::table( 'community_categories' );
		$row   = array(
			'slug'        => sanitize_key( (string) ( $data['slug'] ?? '' ) ),
			'title'       => sanitize_text_field( (string) ( $data['title'] ?? '' ) ),
			'description' => sanitize_text_field( (string) ( $data['description'] ?? '' ) ),
			'icon'        => sanitize_key( (string) ( $data['icon'] ?? 'message-circle' ) ),
			'color'       => sanitize_key( (string) ( $data['color'] ?? 'blue' ) ),
			'sort_order'  => (int) ( $data['sort_order'] ?? 0 ),
			'is_active'   => empty( $data['is_active'] ) ? 0 : 1,
		);
		if ( '' === $row['slug'] || '' === $row['title'] ) {
			return 0;
		}
		if ( $id > 0 ) {
			$wpdb->update( $table, $row, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB
			return $id;
		}
		$row['created_at'] = current_time( 'mysql', true );
		$wpdb->insert( $table, $row ); // phpcs:ignore WordPress.DB
		return (int) $wpdb->insert_id;
	}

	/* ---------------------------------------------------------- safety rules */

	/**
	 * Cleans user text before it is stored.
	 *
	 * When the site hides contact details, phone numbers, links, e-mail
	 * addresses and messenger handles are replaced with a neutral marker so the
	 * forum cannot be used to move a health conversation off-platform.
	 */
	public function clean_body( string $text ) : string {
		$text = wp_kses( $text, array( 'br' => array(), 'p' => array(), 'strong' => array(), 'em' => array(), 'ul' => array(), 'ol' => array(), 'li' => array() ) );
		$text = trim( $text );

		if ( $this->hide_contacts() ) {
			$patterns = array(
				'/(?:\+?98|0)?9\d{9}/u',                                   // mobile numbers
				'/\b\d{8,}\b/u',                                            // long digit runs (IDs, landlines)
				'/https?:\/\/[^\s]+/iu',                                    // links
				'/\b[\w.+-]+@[\w-]+\.[\w.]{2,}\b/iu',                       // e-mail
				'/(?:@|آیدی|ایدی|تلگرام|واتساپ|واتس‌اپ|اینستاگرام)[^\s]{2,}/iu', // handles
			);
			$text = (string) preg_replace( $patterns, '«اطلاعات تماس حذف شد»', $text );
		}

		// The medical safety list is shared with the advisor.
		if ( class_exists( 'Niva_Safety' ) && method_exists( 'Niva_Safety', 'scan' ) ) {
			$flagged = Niva_Safety::scan( $text );
			if ( is_array( $flagged ) && ! empty( $flagged['blocked'] ) ) {
				$text .= "\n\n" . '«این متن حاوی توصیهٔ دارویی است و پیش از نمایش بازبینی می‌شود.»';
			}
		}

		return $text;
	}

	/** True when the text looks like medical advice that needs a human check. */
	public function needs_review( string $text ) : bool {
		$text = mb_strtolower( $text );
		foreach ( array( 'میلی‌گرم', 'میلی گرم', 'mg', 'دوز', 'قرص بخور', 'تزریق کن', 'نسخه' ) as $needle ) {
			if ( false !== mb_strpos( $text, $needle ) ) {
				return true;
			}
		}
		return false;
	}

	/** Per-user daily limits, from the settings screen. */
	public function rate_limit_ok( int $user_id, string $type ) : bool {
		global $wpdb;
		$today = current_time( 'Y-m-d 00:00:00' );
		if ( 'thread' === $type ) {
			$limit = (int) dr_niva()->settings->get( 'community_threads_per_day', 3 );
			$table = Niva_DB::table( 'community_threads' );
		} else {
			$limit = (int) dr_niva()->settings->get( 'community_comments_per_day', 10 );
			$table = Niva_DB::table( 'community_comments' );
		}
		if ( $limit <= 0 ) {
			return true;
		}
		$count = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND created_at >= %s", $user_id, $today )
		);
		return $count < $limit;
	}

	public function is_muted( int $user_id ) : bool {
		return '1' === (string) get_user_meta( $user_id, 'niva_community_muted', true );
	}

	/** Which audience chip a thread belongs to, from the author's profile. */
	public function anchor_for( int $user_id ) : string {
		$profile = dr_niva()->profile->get( $user_id );
		if ( ! empty( $profile['pregnant'] ) ) {
			return 'pregnant';
		}
		if ( '' !== trim( (string) ( $profile['baby_birth'] ?? '' ) ) || '' !== trim( (string) ( $profile['baby_name'] ?? '' ) ) ) {
			return 'baby';
		}
		if ( 'female' === (string) ( $profile['sex'] ?? '' ) ) {
			return 'cycle';
		}
		return 'general';
	}

	/* -------------------------------------------------------------- threading */

	/**
	 * Thread list.
	 *
	 * @param array $args category_id, anchor, status, search, sort, paged, per_page, author.
	 * @return array{items:array,total:int,pages:int}
	 */
	public function threads( array $args = array() ) : array {
		global $wpdb;

		$table = Niva_DB::table( 'community_threads' );
		$cat   = Niva_DB::table( 'community_categories' );

		$args = wp_parse_args(
			$args,
			array( 'category_id' => 0, 'anchor' => '', 'status' => self::STATUS_PUBLISH, 'search' => '', 'sort' => 'newest', 'paged' => 1, 'per_page' => 10, 'author' => 0 )
		);

		$where  = array( '1=1' );
		$params = array();

		if ( $args['status'] ) {
			$where[]  = 't.status = %s';
			$params[] = $args['status'];
		}
		if ( $args['category_id'] > 0 ) {
			$where[]  = 't.category_id = %d';
			$params[] = (int) $args['category_id'];
		}
		if ( '' !== $args['anchor'] && 'all' !== $args['anchor'] ) {
			$where[]  = 't.anchor = %s';
			$params[] = $args['anchor'];
		}
		if ( $args['author'] > 0 ) {
			$where[]  = 't.user_id = %d';
			$params[] = (int) $args['author'];
		}
		if ( '' !== trim( (string) $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( trim( (string) $args['search'] ) ) . '%';
			$where[]  = '( t.title LIKE %s OR t.body LIKE %s )';
			$params[] = $like;
			$params[] = $like;
		}

		$order = 't.is_pinned DESC, t.last_activity_at DESC, t.id DESC';
		if ( 'answers' === $args['sort'] ) {
			$order = 't.is_pinned DESC, t.comment_count DESC, t.id DESC';
		} elseif ( 'popular' === $args['sort'] ) {
			$order = 't.is_pinned DESC, t.likes DESC, t.id DESC';
		} elseif ( 'unanswered' === $args['sort'] ) {
			$order = 't.is_pinned DESC, t.comment_count ASC, t.id DESC';
		}

		$per_page = max( 1, min( 50, (int) $args['per_page'] ) );
		$offset   = ( max( 1, (int) $args['paged'] ) - 1 ) * $per_page;
		$sql_where = implode( ' AND ', $where );

		$count_sql = "SELECT COUNT(*) FROM {$table} t WHERE {$sql_where}";
		$total     = (int) $wpdb->get_var( $params ? $wpdb->prepare( $count_sql, $params ) : $count_sql ); // phpcs:ignore WordPress.DB

		$sql           = "SELECT t.*, c.slug AS category_slug, c.title AS category_title, c.color AS category_color, c.icon AS category_icon
			FROM {$table} t LEFT JOIN {$cat} c ON c.id = t.category_id
			WHERE {$sql_where} ORDER BY {$order} LIMIT %d OFFSET %d";
		$list_params   = array_merge( $params, array( $per_page, $offset ) );
		$rows          = $wpdb->get_results( $wpdb->prepare( $sql, $list_params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		$items = array();
		foreach ( (array) $rows as $row ) {
			$items[] = $this->hydrate_thread( $row );
		}

		return array(
			'items' => $items,
			'total' => $total,
			'pages' => (int) ceil( $total / $per_page ),
		);
	}

	/** Adds author display data to a raw thread row (single query for all). */
	private function hydrate_thread( array $row ) : array {
		$profile = dr_niva()->profile->get( (int) $row['user_id'] );
		$name    = trim( (string) ( $profile['full_name'] ?? '' ) );
		if ( '' === $name ) {
			$user = get_userdata( (int) $row['user_id'] );
			$name = $user ? (string) $user->display_name : 'کاربر دکتر نیوا';
		}

		$row['id']            = (int) $row['id'];
		$row['user_id']       = (int) $row['user_id'];
		$row['likes']         = (int) $row['likes'];
		$row['comment_count'] = (int) $row['comment_count'];
		$row['views']         = (int) $row['views'];
		$row['is_pinned']     = (int) $row['is_pinned'];
		$row['is_featured']   = (int) $row['is_featured'];
		$row['excerpt']       = wp_trim_words( wp_strip_all_tags( (string) $row['body'] ), 22 );
		$row['author_name']   = $name;
		$row['author_avatar'] = (string) ( $profile['avatar_url'] ?? '' );
		$row['author_letter'] = function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 1 ) : substr( $name, 0, 1 );
		$row['answered']      = $row['comment_count'] > 0;
		$row['time_ago']      = $this->relative_time( (string) $row['created_at'] );
		// The links registry resolves page URLs only, so the thread id is added
		// as a query argument on top of the resolved page.
		$row['url']           = add_query_arg( 'thread', $row['id'], Niva_Modules::url( 'community_thread', array(), home_url( '/' ) ) );
		$row['mine']          = is_user_logged_in() && (int) get_current_user_id() === $row['user_id'];
		return $row;
	}

	/** Persian relative time ("۳ ساعت پیش"), from a GMT datetime string. */
	public function relative_time( string $gmt ) : string {
		$stamp = strtotime( $gmt . ' UTC' );
		if ( ! $stamp ) {
			return '';
		}
		$diff = time() - $stamp;
		if ( $diff < 60 ) {
			return 'همین حالا';
		}
		$map = array(
			60          => array( 60, 'دقیقه پیش' ),
			3600        => array( 3600, 'ساعت پیش' ),
			DAY_IN_SECONDS   => array( DAY_IN_SECONDS, 'روز پیش' ),
			WEEK_IN_SECONDS  => array( WEEK_IN_SECONDS, 'هفته پیش' ),
			MONTH_IN_SECONDS => array( MONTH_IN_SECONDS, 'ماه پیش' ),
		);
		foreach ( $map as $threshold => $pair ) {
			if ( $diff < $threshold * ( $threshold === 60 ? 60 : 30 ) ) {
				$value = max( 1, (int) floor( $diff / $pair[0] ) );
				return Niva_Chrome::digits( (string) $value ) . ' ' . $pair[1];
			}
		}
		$years = max( 1, (int) floor( $diff / ( 365 * DAY_IN_SECONDS ) ) );
		return Niva_Chrome::digits( (string) $years ) . ' سال پیش';
	}

	public function thread( int $thread_id ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'community_threads' );
		$cat   = Niva_DB::table( 'community_categories' );
		$row   = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT t.*, c.slug AS category_slug, c.title AS category_title, c.color AS category_color, c.icon AS category_icon FROM {$table} t LEFT JOIN {$cat} c ON c.id = t.category_id WHERE t.id = %d", $thread_id ),
			ARRAY_A
		);
		if ( ! $row ) {
			return array();
		}
		$this->bump_views( $thread_id );
		return $this->hydrate_thread( $row );
	}

	private function bump_views( int $thread_id ) : void {
		global $wpdb;
		$table  = Niva_DB::table( 'community_threads' );
		$cookie = 'niva_ct_' . $thread_id;
		if ( ! empty( $_COOKIE[ $cookie ] ) ) {
			return; // one view per browser per thread, so the number means something
		}

		/*
		 * 3.1.0 — the cookie above was never set, so every refresh increased the
		 * counter. A visitor+signed-in-user transient does the job without
		 * depending on cookies being writable after output has started.
		 */
		$guard = 'niva_view_' . $thread_id . '_' . md5( (string) ( $_SERVER['REMOTE_ADDR'] ?? '' ) . '|' . (string) get_current_user_id() );
		if ( get_transient( $guard ) ) {
			return;
		}
		set_transient( $guard, 1, 6 * HOUR_IN_SECONDS );
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET views = views + 1 WHERE id = %d", $thread_id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Creates a thread.
	 *
	 * @return int|WP_Error thread id, or an error the caller can show as-is.
	 */
	public function create_thread( int $user_id, array $data ) {
		if ( ! $this->on() ) {
			return new WP_Error( 'niva_community_off', 'بخش گفتگو با کاربران خاموش است.', array( 'status' => 403 ) );
		}
		if ( $this->is_muted( $user_id ) ) {
			return new WP_Error( 'niva_community_muted', 'امکان نوشتن برای این حساب موقتاً محدود شده است.', array( 'status' => 403 ) );
		}
		if ( ! $this->rate_limit_ok( $user_id, 'thread' ) ) {
			return new WP_Error( 'niva_community_limit', 'سقف گفتگوهای امروزت پر شده؛ فردا دوباره تلاش کن.', array( 'status' => 429 ) );
		}

		$title = sanitize_text_field( (string) ( $data['title'] ?? '' ) );
		$body  = $this->clean_body( (string) ( $data['body'] ?? '' ) );
		$cat   = (int) ( $data['category_id'] ?? 0 );

		if ( mb_strlen( $title ) < 6 ) {
			return new WP_Error( 'niva_community_title', 'عنوان را کمی کامل‌تر بنویس (حداقل ۶ نویسه).', array( 'status' => 400 ) );
		}
		if ( mb_strlen( wp_strip_all_tags( $body ) ) < 15 ) {
			return new WP_Error( 'niva_community_body', 'متن پرسش را کمی بیشتر توضیح بده.', array( 'status' => 400 ) );
		}
		if ( ! $cat ) {
			return new WP_Error( 'niva_community_category', 'دستهٔ پرسش را انتخاب کن.', array( 'status' => 400 ) );
		}

		$status = ( $this->auto_publish() && ! $this->needs_review( $body ) ) ? self::STATUS_PUBLISH : self::STATUS_PENDING;

		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'community_threads' ),
			array(
				'category_id'      => $cat,
				'user_id'          => $user_id,
				'title'            => $title,
				'body'             => $body,
				'image_id'         => isset( $data['image_id'] ) ? absint( $data['image_id'] ) : null,
				'status'           => $status,
				'is_pinned'        => 0,
				'is_featured'      => 0,
				'likes'            => 0,
				'comment_count'    => 0,
				'views'            => 0,
				'anchor'           => $this->anchor_for( $user_id ),
				'created_at'       => $now,
				'updated_at'       => $now,
				'last_activity_at' => $now,
			)
		);
		$thread_id = (int) $wpdb->insert_id;

		if ( self::STATUS_PENDING === $status ) {
			$this->notify_moderators( $thread_id );
		} else {
			do_action( 'dr_niva_community_thread_published', $thread_id, $user_id );
		}

		return $thread_id;
	}

	/* -------------------------------------------------------------- comments */

	public function comments( int $thread_id, string $order = 'newest' ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'community_comments' );
		$dir   = 'helpful' === $order ? 'likes DESC, id ASC' : 'id ASC';
		$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE thread_id = %d AND status = %s ORDER BY {$dir}", $thread_id, self::STATUS_PUBLISH ),
			ARRAY_A
		);

		$out = array();
		foreach ( (array) $rows as $row ) {
			$profile             = dr_niva()->profile->get( (int) $row['user_id'] );
			$name                = trim( (string) ( $profile['full_name'] ?? '' ) );
			if ( '' === $name ) {
				$user = get_userdata( (int) $row['user_id'] );
				$name = $user ? (string) $user->display_name : 'کاربر دکتر نیوا';
			}
			$row['id']            = (int) $row['id'];
			$row['user_id']       = (int) $row['user_id'];
			$row['likes']         = (int) $row['likes'];
			$row['author_name']   = $name;
			$row['author_avatar'] = (string) ( $profile['avatar_url'] ?? '' );
			$row['author_letter'] = function_exists( 'mb_substr' ) ? mb_substr( $name, 0, 1 ) : substr( $name, 0, 1 );
			$row['time_ago']      = $this->relative_time( (string) $row['created_at'] );
			$out[]                = $row;
		}
		return $out;
	}

	public function add_comment( int $user_id, int $thread_id, string $body, int $parent_id = 0 ) {
		global $wpdb;

		if ( ! $this->on() ) {
			return new WP_Error( 'niva_community_off', 'بخش گفتگو با کاربران خاموش است.', array( 'status' => 403 ) );
		}
		if ( $this->is_muted( $user_id ) ) {
			return new WP_Error( 'niva_community_muted', 'امکان نوشتن برای این حساب موقتاً محدود شده است.', array( 'status' => 403 ) );
		}
		if ( ! $this->rate_limit_ok( $user_id, 'comment' ) ) {
			return new WP_Error( 'niva_community_limit', 'سقف نظرهای امروزت پر شده؛ فردا دوباره تلاش کن.', array( 'status' => 429 ) );
		}

		$thread = $this->thread_raw( $thread_id );
		if ( ! $thread ) {
			return new WP_Error( 'niva_community_missing', 'این گفتگو پیدا نشد.', array( 'status' => 404 ) );
		}
		if ( self::STATUS_CLOSED === (string) $thread['status'] ) {
			return new WP_Error( 'niva_community_closed', 'این گفتگو بسته شده و نظر تازه نمی‌پذیرد.', array( 'status' => 403 ) );
		}

		$clean = $this->clean_body( $body );
		if ( mb_strlen( wp_strip_all_tags( $clean ) ) < 3 ) {
			return new WP_Error( 'niva_community_short', 'متن نظر خیلی کوتاه است.', array( 'status' => 400 ) );
		}

		$status = ( $this->auto_publish() && ! $this->needs_review( $clean ) ) ? self::STATUS_PUBLISH : self::STATUS_PENDING;

		// One level only: a reply to a reply attaches to the original comment.
		if ( $parent_id > 0 ) {
			$parent = $wpdb->get_row( $wpdb->prepare( 'SELECT id, parent_id, thread_id FROM ' . Niva_DB::table( 'community_comments' ) . ' WHERE id = %d', $parent_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
			if ( ! $parent || (int) $parent['thread_id'] !== $thread_id ) {
				$parent_id = 0;
			} elseif ( (int) $parent['parent_id'] > 0 ) {
				$parent_id = (int) $parent['parent_id'];
			}
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'community_comments' ),
			array(
				'thread_id'  => $thread_id,
				'user_id'    => $user_id,
				'parent_id'  => $parent_id,
				'body'       => $clean,
				'likes'      => 0,
				'status'     => $status,
				'created_at' => current_time( 'mysql', true ),
			)
		);
		$comment_id = (int) $wpdb->insert_id;

		if ( self::STATUS_PUBLISH === $status ) {
			$this->touch_thread( $thread_id, true );
			$this->notify_reply( (int) $thread['user_id'], $thread_id, $user_id );
		} else {
			$this->notify_moderators( $thread_id, 'comment', $comment_id );
		}

		return $comment_id;
	}

	private function thread_raw( int $thread_id ) : array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'community_threads' ) . ' WHERE id = %d', $thread_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		return $row ? $row : array();
	}

	private function touch_thread( int $thread_id, bool $count_comment = false ) : void {
		global $wpdb;
		$table = Niva_DB::table( 'community_threads' );
		$now   = current_time( 'mysql', true );
		if ( $count_comment ) {
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET comment_count = comment_count + 1, last_activity_at = %s WHERE id = %d", $now, $thread_id ) ); // phpcs:ignore WordPress.DB
		} else {
			$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET last_activity_at = %s WHERE id = %d", $now, $thread_id ) ); // phpcs:ignore WordPress.DB
		}
	}

	/* ------------------------------------------------------------- reactions */

	/** Adds or removes a reaction. Returns the fresh count. */
	public function react( int $user_id, string $object_type, int $object_id, string $type = 'like' ) : array {
		global $wpdb;
		$types = array( 'like', 'heart', 'helpful' );
		$type  = in_array( $type, $types, true ) ? $type : 'like';
		$table = Niva_DB::table( 'community_reactions' );

		$existing = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT id FROM {$table} WHERE object_type = %s AND object_id = %d AND user_id = %d AND type = %s", $object_type, $object_id, $user_id, $type )
		);

		$added = false;
		if ( $existing ) {
			$wpdb->delete( $table, array( 'id' => (int) $existing ) ); // phpcs:ignore WordPress.DB
		} else {
			$wpdb->insert( // phpcs:ignore WordPress.DB
				$table,
				array(
					'object_type' => $object_type,
					'object_id'   => $object_id,
					'user_id'     => $user_id,
					'type'        => $type,
					'created_at'  => current_time( 'mysql', true ),
				)
			);
			$added = true;
			if ( 'comment' !== $object_type ) {
				$this->notify_like( $object_type, $object_id, $user_id );
			}
		}

		return array( 'added' => $added, 'count' => $this->reaction_count( $object_type, $object_id ) );
	}

	private function reaction_count( string $object_type, int $object_id ) : int {
		global $wpdb;
		$table = Niva_DB::table( 'community_reactions' );
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE object_type = %s AND object_id = %d", $object_type, $object_id )
		);
	}

	/* --------------------------------------------------------------- reports */

	public function report( int $user_id, string $object_type, int $object_id, string $reason ) {
		global $wpdb;
		$table = Niva_DB::table( 'community_reports' );

		$dupe = $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT id FROM {$table} WHERE object_type = %s AND object_id = %d AND user_id = %d AND status = 'open'", $object_type, $object_id, $user_id )
		);
		if ( $dupe ) {
			return new WP_Error( 'niva_community_reported', 'قبلاً همین مورد را گزارش کرده‌ای؛ بررسی می‌کنیم.', array( 'status' => 409 ) );
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			$table,
			array(
				'object_type' => $object_type,
				'object_id'   => $object_id,
				'user_id'     => $user_id,
				'reason'      => sanitize_text_field( $reason ),
				'status'      => 'open',
				'created_at'  => current_time( 'mysql', true ),
			)
		);
		$this->notify_moderators( 0, $object_type, $object_id );
		return (int) $wpdb->insert_id;
	}

	/** Moderator actions: approve / hide / close / pin / feature / delete. */
	public function moderate( string $action, string $object_type, int $object_id, array $extra = array() ) : bool {
		global $wpdb;
		$table = 'thread' === $object_type ? Niva_DB::table( 'community_threads' ) : Niva_DB::table( 'community_comments' );
		$now   = current_time( 'mysql', true );

		switch ( $action ) {
			case 'approve':
				$wpdb->update( $table, array( 'status' => self::STATUS_PUBLISH ), array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				if ( 'thread' === $object_type ) {
					// The reply counter only counts approved comments, so a queue
					// release has to recount instead of trusting the stored value.
					$this->recount_comments( $object_id );
					$this->touch_thread( $object_id );
				}
				return true;

			case 'hide':
				$wpdb->update( $table, array( 'status' => self::STATUS_HIDDEN ), array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				if ( 'thread' === $object_type ) {
					$this->recount_comments( $object_id );
				}
				return true;

			case 'close':
				$wpdb->update( Niva_DB::table( 'community_threads' ), array( 'status' => self::STATUS_CLOSED ), array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				return true;

			case 'pin':
				$wpdb->update( Niva_DB::table( 'community_threads' ), array( 'is_pinned' => ! empty( $extra['value'] ) ? 1 : 0 ), array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				return true;

			case 'feature':
				$wpdb->update( Niva_DB::table( 'community_threads' ), array( 'is_featured' => ! empty( $extra['value'] ) ? 1 : 0 ), array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				return true;

			case 'delete':
				if ( 'thread' === $object_type ) {
					$wpdb->delete( Niva_DB::table( 'community_comments' ), array( 'thread_id' => $object_id ) ); // phpcs:ignore WordPress.DB
					$wpdb->delete( Niva_DB::table( 'community_threads' ), array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				} else {
					$wpdb->delete( $table, array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				}
				return true;

			case 'resolve_report':
				$wpdb->update( Niva_DB::table( 'community_reports' ), array( 'status' => 'closed' ), array( 'id' => $object_id ) ); // phpcs:ignore WordPress.DB
				return true;

			case 'mute':
				update_user_meta( (int) $object_id, 'niva_community_muted', ! empty( $extra['value'] ) ? '1' : '0' );
				unset( $now );
				return true;
		}
		return false;
	}

	private function recount_comments( int $thread_id ) : void {
		global $wpdb;
		$comments = Niva_DB::table( 'community_comments' );
		$threads  = Niva_DB::table( 'community_threads' );
		$count    = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$comments} WHERE thread_id = %d AND status = %s", $thread_id, self::STATUS_PUBLISH ) ); // phpcs:ignore WordPress.DB
		$wpdb->update( $threads, array( 'comment_count' => $count ), array( 'id' => $thread_id ) ); // phpcs:ignore WordPress.DB
	}

	/* --------------------------------------------------------- notifications */

	private function notify_reply( int $author_id, int $thread_id, int $from_id ) : void {
		if ( ! $author_id || $author_id === $from_id || ! class_exists( 'Niva_Notifications' ) ) {
			return;
		}
		Niva_Notifications::notify(
			$author_id,
			'پاسخ تازه برای پرسش تو',
			'کسی به گفتگوی تو پاسخ داد.',
			add_query_arg( 'thread', $thread_id, Niva_Modules::url( 'community_thread', array(), home_url( '/' ) ) )
		);
	}

	private function notify_like( string $object_type, int $object_id, int $from_id ) : void {
		global $wpdb;
		if ( 'thread' !== $object_type || ! class_exists( 'Niva_Notifications' ) ) {
			return;
		}
		$author = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT user_id FROM ' . Niva_DB::table( 'community_threads' ) . ' WHERE id = %d', $object_id ) ); // phpcs:ignore WordPress.DB
		if ( ! $author || $author === $from_id ) {
			return;
		}
		Niva_Notifications::notify(
			$author,
			'پرسشت پسندیده شد',
			'یک کاربر پرسش تو را مفید دانست.',
			Niva_Modules::url( 'community_thread', array( 'thread' => $object_id ), home_url( '/' ) )
		);
	}

	/** Tells the administrators something is waiting in the review queue. */
	public function notify_moderators( int $thread_id, string $object_type = 'thread', int $object_id = 0 ) : void {
		$ref = 'thread' === $object_type ? $thread_id : $object_id;
		do_action( 'dr_niva_community_needs_review', $object_type, $ref );
		if ( class_exists( 'Niva_Notifications' ) && $thread_id ) {
			$admins = get_users( array( 'capability' => 'manage_options', 'fields' => 'ID', 'number' => 5 ) );
			foreach ( (array) $admins as $admin_id ) {
				Niva_Notifications::notify(
					(int) $admin_id,
					'گفتگوی تازه در انتظار بازبینی',
					'یک پرسش یا نظر تازه در صف بازبینی است.',
					admin_url( 'admin.php?page=dr-niva-community' )
				);
			}
		}
	}

	/* ------------------------------------------------------------------- REST */

	public function routes() : void {
		$public = array( 'permission_callback' => '__return_true' );
		$member = array( 'permission_callback' => array( $this, 'is_logged_in' ) );

		register_rest_route( Niva_Rest::NS, '/community/threads', array( 'methods' => 'GET', 'callback' => array( $this, 'rest_threads' ) ) + $public );
		register_rest_route( Niva_Rest::NS, '/community/categories', array( 'methods' => 'GET', 'callback' => array( $this, 'rest_categories' ) ) + $public );
		register_rest_route( Niva_Rest::NS, '/community/thread', array( 'methods' => 'GET', 'callback' => array( $this, 'rest_thread' ) ) + $public );
		register_rest_route( Niva_Rest::NS, '/community/create', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_create' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/community/comment', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_comment' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/community/react', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_react' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/community/report', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_report' ) ) + $member );
	}

	public function is_logged_in() : bool {
		return is_user_logged_in();
	}

	public function rest_threads( WP_REST_Request $request ) {
		if ( ! $this->on() ) {
			return new WP_Error( 'niva_community_off', 'بخش گفتگو با کاربران خاموش است.', array( 'status' => 403 ) );
		}
		$category = (string) $request->get_param( 'category' );
		$cat      = '' !== $category ? $this->category_by_slug( sanitize_key( $category ) ) : array();

		$result = $this->threads(
			array(
				'category_id' => $cat ? (int) $cat['id'] : 0,
				'anchor'      => sanitize_key( (string) $request->get_param( 'anchor' ) ),
				'search'      => (string) $request->get_param( 's' ),
				'sort'        => sanitize_key( (string) $request->get_param( 'sort' ) ),
				'paged'       => max( 1, (int) $request->get_param( 'paged' ) ),
				'per_page'    => max( 1, min( 20, (int) ( $request->get_param( 'per_page' ) ?: 10 ) ) ),
			)
		);
		return new WP_REST_Response( $result, 200 );
	}

	public function rest_categories() {
		return new WP_REST_Response( array_values( $this->categories() ), 200 );
	}

	public function rest_thread( WP_REST_Request $request ) {
		$id     = (int) $request->get_param( 'id' );
		$thread = $this->thread( $id );
		if ( ! $thread ) {
			return new WP_Error( 'niva_community_missing', 'این گفتگو پیدا نشد.', array( 'status' => 404 ) );
		}
		if ( self::STATUS_PUBLISH !== $thread['status'] && ! current_user_can( 'manage_options' ) ) {
			return new WP_Error( 'niva_community_pending', 'این گفتگو در انتظار بازبینی است.', array( 'status' => 403 ) );
		}
		return new WP_REST_Response( array( 'thread' => $thread, 'comments' => $this->comments( $id ) ), 200 );
	}

	public function rest_create( WP_REST_Request $request ) {
		$result = $this->create_thread(
			(int) get_current_user_id(),
			array(
				'title'       => $request->get_param( 'title' ),
				'body'        => $request->get_param( 'body' ),
				'category_id' => (int) $request->get_param( 'category_id' ),
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		$thread = $this->thread( (int) $result );
		return new WP_REST_Response(
			array(
				'ok'      => true,
				'id'      => (int) $result,
				// 2.0.1 — the card is rendered in place, so the row travels back.
				'thread'  => $thread,
				'status'  => $thread['status'] ?? self::STATUS_PENDING,
				'message' => self::STATUS_PENDING === ( $thread['status'] ?? '' )
					? 'پرسشت ثبت شد و بعد از بازبینی نمایش داده می‌شود.'
					: 'پرسشت منتشر شد.',
			),
			200
		);
	}

	public function rest_comment( WP_REST_Request $request ) {
		$result = $this->add_comment(
			(int) get_current_user_id(),
			(int) $request->get_param( 'thread_id' ),
			(string) $request->get_param( 'body' ),
			(int) $request->get_param( 'parent_id' )
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}

		/*
		 * 2.0.1 — the comment is appended where it was written, so the response
		 * carries the row and whether it still waits for moderation.
		 */
		$user    = wp_get_current_user();
		$pending = ! $this->auto_publish() || $this->needs_review( (string) $request->get_param( 'body' ) );
		return new WP_REST_Response(
			array(
				'ok'      => true,
				'id'      => (int) $result,
				'pending' => $pending,
				'comment' => array(
					'id'          => (int) $result,
					'body'        => wp_strip_all_tags( (string) $request->get_param( 'body' ) ),
					'author_name' => $user && $user->display_name ? (string) $user->display_name : 'شما',
					'time_ago'    => 'همین حالا',
					'pending'     => $pending,
				),
			),
			200
		);
	}

	public function rest_react( WP_REST_Request $request ) {
		$type = in_array( (string) $request->get_param( 'object_type' ), array( 'thread', 'comment' ), true ) ? (string) $request->get_param( 'object_type' ) : 'thread';
		$out  = $this->react(
			(int) get_current_user_id(),
			$type,
			(int) $request->get_param( 'id' ),
			(string) ( $request->get_param( 'type' ) ?: 'like' )
		);
		return new WP_REST_Response( array( 'ok' => true ) + $out, 200 );
	}

	public function rest_report( WP_REST_Request $request ) {
		$type = in_array( (string) $request->get_param( 'object_type' ), array( 'thread', 'comment' ), true ) ? (string) $request->get_param( 'object_type' ) : 'thread';
		$out  = $this->report(
			(int) get_current_user_id(),
			$type,
			(int) $request->get_param( 'id' ),
			(string) $request->get_param( 'reason' )
		);
		if ( is_wp_error( $out ) ) {
			return $out;
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/* ----------------------------------------------------------------- assets */

	public function assets() : void {
		if ( ! $this->on() ) {
			return;
		}
		wp_register_style( 'dr-niva-community', DR_NIVA_URL . 'public/assets/css/community.css', array( 'dr-niva-base' ), DR_NIVA_VERSION );
		wp_register_script( 'dr-niva-community', DR_NIVA_URL . 'public/assets/js/community.js', array( 'dr-niva-router' ), DR_NIVA_VERSION, true );
	}

	/** Called by the partials so the CSS/JS only load on community screens. */
	public static function enqueue() : void {
		wp_enqueue_style( 'dr-niva-community' );
		wp_enqueue_script( 'dr-niva-community' );
	}
}
