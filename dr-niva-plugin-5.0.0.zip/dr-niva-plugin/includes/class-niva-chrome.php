<?php
/**
 * Site chrome helpers: logo, navigation and the account button.
 *
 * The header / dock / footer widgets are rendered by PHP (not by Javascript) so
 * the editor can style and position them like any other Elementor element.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Chrome {

	private static $header_rendered = false;

	public function __construct() {
		add_action( 'after_setup_theme', array( $this, 'register_menu' ) );
		add_action( 'init', array( $this, 'register_page_taxonomy' ) );
		add_action( 'import_end', array( $this, 'assign_imported_menu' ) );
		add_action( 'wp_loaded', array( $this, 'assign_menu_if_empty' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'enqueue_auto_header_assets' ), 20 );
		add_action( 'wp_body_open', array( $this, 'maybe_header' ), 5 );
		add_action( 'wp_footer', array( $this, 'maybe_footer' ), 20 );
		add_action( 'wp_nav_menu_item_custom_fields', array( $this, 'menu_item_icon_field' ), 10, 5 );
		add_action( 'wp_update_nav_menu_item', array( $this, 'save_menu_item_icon' ), 10, 3 );
		add_filter( 'walker_nav_menu_start_el', array( $this, 'render_menu_item_icon' ), 10, 4 );
	}

	/** A real WordPress menu location the editor can assign a menu to. */
	public function register_menu() : void {
		register_nav_menus(
			array(
				'dr_niva_app' => 'منوی اپ دکتر نیوا (هدر)',
			)
		);
	}

	/** Organised page groups included in the WXR import. */
	public function register_page_taxonomy() : void {
		register_taxonomy(
			'dr_niva_page_category',
			array( 'page' ),
			array(
				'labels'       => array(
					'name'          => 'دسته‌بندی برگه‌های دکتر نیوا',
					'singular_name' => 'دسته‌بندی برگه',
				),
				'hierarchical' => true,
				'show_ui'      => true,
				'show_in_rest' => true,
				'rewrite'      => false,
			)
		);
	}

	/** The WXR import creates the menu; connect it to the plugin's header. */
	public function assign_imported_menu() : void {
		$menu = get_term_by( 'slug', 'niva-main', 'nav_menu' );
		if ( ! $menu || is_wp_error( $menu ) ) {
			return;
		}
		$locations = (array) get_theme_mod( 'nav_menu_locations', array() );
		if ( isset( $locations['dr_niva_app'] ) && (int) $locations['dr_niva_app'] === (int) $menu->term_id ) {
			return;
		}
		$locations['dr_niva_app'] = (int) $menu->term_id;
		set_theme_mod( 'nav_menu_locations', $locations );
	}

	/** Repair an unassigned imported menu without replacing the site's choice. */
	public function assign_menu_if_empty() : void {
		$locations = (array) get_theme_mod( 'nav_menu_locations', array() );
		if ( ! empty( $locations['dr_niva_app'] ) ) {
			return;
		}
		$this->assign_imported_menu();
	}

	public function enqueue_auto_header_assets() : void {
		if ( is_admin() ) {
			return;
		}
		$is_app_page = self::is_app_page();
		if ( ! $is_app_page && ( ! self::auto_header_enabled() || self::is_elementor_page() ) ) {
			return;
		}
		try {
			self::enqueue_notification_assets();
		} catch ( \Throwable $error ) {
			error_log( sprintf( 'Dr. Niva header assets failed: %s in %s:%d', $error->getMessage(), $error->getFile(), $error->getLine() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
		}
	}

	public function menu_item_icon_field( int $item_id, $item, int $depth, $args, int $current_object_id ) : void {
	if ( ! current_user_can( 'edit_theme_options' ) ) {
			return;
	}
		$selected = (string) get_post_meta( $item_id, '_dr_niva_menu_icon', true );
		$icons    = array(
			''               => 'بدون آیکون',
			'home'           => 'خانه',
			'message-circle' => 'مشاور',
			'layers'         => 'ابزارها',
			'calendar-days'  => 'تقویم',
			'user'           => 'حساب کاربری',
			'heart'          => 'سلامت',
			'baby'           => 'کودک',
			'bell'           => 'اعلان',
			'credit-card'    => 'اعتبار',
			'stethoscope'    => 'پزشکی',
			'apple'          => 'تغذیه',
		);
		?>
		<p class="description description-wide">
			<label for="edit-menu-item-dr-niva-icon-<?php echo esc_attr( (string) $item_id ); ?>">آیکون دکتر نیوا (فقط در منوی اپ نمایش داده می‌شود)<br />
				<select id="edit-menu-item-dr-niva-icon-<?php echo esc_attr( (string) $item_id ); ?>" name="dr_niva_menu_icon[<?php echo esc_attr( (string) $item_id ); ?>]">
					<?php foreach ( $icons as $icon => $label ) : ?>
						<option value="<?php echo esc_attr( $icon ); ?>" <?php selected( $selected, $icon ); ?>><?php echo esc_html( $label ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
		</p>
		<?php
	}

	public function save_menu_item_icon( int $menu_id, int $menu_item_db_id, array $args ) : void {
		if ( ! current_user_can( 'edit_theme_options' ) || ! isset( $_POST['dr_niva_menu_icon'][ $menu_item_db_id ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Missing
			return;
		}
		$icon    = sanitize_key( wp_unslash( $_POST['dr_niva_menu_icon'][ $menu_item_db_id ] ) ); // phpcs:ignore WordPress.Security.NonceVerification.Missing
		$allowed = array( 'home', 'message-circle', 'layers', 'calendar-days', 'user', 'heart', 'baby', 'bell', 'credit-card', 'stethoscope', 'apple' );
		if ( '' === $icon ) {
			delete_post_meta( $menu_item_db_id, '_dr_niva_menu_icon' );
		} elseif ( in_array( $icon, $allowed, true ) ) {
			update_post_meta( $menu_item_db_id, '_dr_niva_menu_icon', $icon );
		}
	}

	public function render_menu_item_icon( string $item_output, $item, int $depth, $args ) : string {
		if ( ! is_object( $args ) || 'dr_niva_app' !== ( $args->theme_location ?? '' ) ) {
			return $item_output;
		}
		$icon = sanitize_key( (string) get_post_meta( (int) $item->ID, '_dr_niva_menu_icon', true ) );
		if ( '' === $icon || ! isset( Niva_Icons::map()[ $icon ] ) ) {
			return $item_output;
		}
		$markup = '<span class="niva-menu-icon" aria-hidden="true">' . Niva_Icons::svg( $icon, 18 ) . '</span>';
		return (string) preg_replace( '/(<a\b[^>]*>)/i', '$1' . $markup, $item_output, 1 );
	}

	public static function enqueue_notification_assets() : void {
		wp_enqueue_style( 'dr-niva-chrome', DR_NIVA_URL . 'public/assets/css/chrome.css', array(), DR_NIVA_VERSION );
		wp_enqueue_script( 'dr-niva-chrome', DR_NIVA_URL . 'public/assets/js/chrome.js', array(), DR_NIVA_VERSION, true );
		wp_localize_script(
			'dr-niva-chrome',
			'DR_NIVA_CHROME',
			array(
				'rest'      => esc_url_raw( untrailingslashit( rest_url( 'niva/v1' ) ) ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'loggedIn'  => get_current_user_id() > 0,
				'loginUrl'  => esc_url_raw( wp_login_url( get_permalink() ? get_permalink() : home_url( '/' ) ) ),
				'push'      => array(
					'endpoint'  => esc_url_raw( rest_url( Niva_Rest::NS . '/push/subscribe' ) ),
					'nonce'     => wp_create_nonce( 'wp_rest' ),
					'sw'        => home_url( '/dr-niva-sw.js' ),
					'publicKey' => (string) dr_niva()->settings->get( 'vapid_public' ),
					'enabled'   => dr_niva()->settings->is_on( 'push_enabled' ),
				),
			)
		);
	}

	/** True when the active theme already renders its own footer. */
	public static function theme_has_footer() : bool {
		if ( function_exists( 'wp_is_block_theme' ) && wp_is_block_theme() ) {
			$templates = get_block_templates( array( 'slug__in' => array( 'footer' ) ) );
			if ( ! empty( $templates ) ) {
				return true;
			}
		}

		$all = wp_get_sidebars_widgets();

		// 1) a footer area that actually holds widgets
		foreach ( array( 'footer-1', 'footer-2', 'footer-3', 'footer-4', 'footer-5', 'footer', 'footer-widgets', 'colophon' ) as $area ) {
			if ( ! empty( $all[ $area ] ) ) {
				return true;
			}
		}

		// 2) the theme declares a footer area at all (Astra, Blocksy, OceanWP, …):
		//    they render their own footer even when no widget was placed.
		$sidebars = isset( $GLOBALS['wp_registered_sidebars'] ) ? (array) $GLOBALS['wp_registered_sidebars'] : array();
		foreach ( $sidebars as $id => $sidebar ) {
			$haystack = strtolower( (string) $id . ' ' . ( isset( $sidebar['name'] ) ? (string) $sidebar['name'] : '' ) );
			if ( false !== strpos( $haystack, 'footer' ) || false !== strpos( $haystack, 'colophon' ) || false !== strpos( $haystack, 'پاورقی' ) ) {
				return true;
			}
		}

		return (bool) apply_filters( 'dr_niva_theme_has_footer', false );
	}

	/** Prints the app header on every non-Elementor page unless explicitly disabled. */
	public function maybe_header() : void {
		if ( is_admin() || ! self::auto_header_enabled() || self::is_app_page() || self::is_elementor_page() ) {
			return;
		}
		$header = self::render_auto_module( 'app_header' );
		if ( '' !== $header ) {
			self::$header_rendered = true;
			echo $header; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
		}
	}

	/**
	 * Prints the app footer + the bottom dock automatically.
	 * The plugin footer steps aside when the theme already has one.
	 */
	public function maybe_footer() : void {
		if ( is_admin() || self::is_app_page() ) {
			return;
		}
		$settings = dr_niva()->settings;

		if ( self::auto_header_enabled() && ! self::is_elementor_page() && ! self::$header_rendered ) {
			$header = self::render_auto_module( 'app_header' );
			if ( '' !== $header ) {
				self::$header_rendered = true;
				echo $header; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '<script>(function(){var h=document.currentScript&&document.currentScript.previousElementSibling;if(h&&document.body){document.body.insertBefore(h,document.body.firstChild);}})();</script>';
			}
		}

		if ( 'auto' === $settings->get( 'chrome_footer' ) ) {
			$blocked = self::theme_has_footer() && $settings->is_on( 'hide_plugin_footer_with_theme' );
			if ( ! $blocked ) {
				echo self::render_auto_module( 'app_footer' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
			}
		}

		if ( 'auto' === $settings->get( 'chrome_dock' ) ) {
			try {
				echo '<div class="niva-auto-dock">' . self::dock() . '</div>'; // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped
				echo '<style>@media (max-width: 860px){body{padding-block-end:96px}}</style>';
			} catch ( \Throwable $error ) {
				error_log( sprintf( 'Dr. Niva automatic dock failed: %s in %s:%d', $error->getMessage(), $error->getFile(), $error->getLine() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
		}
	}

	/** Keep an optional, site-wide chrome widget from taking down theme pages. */
	private static function render_auto_module( string $module ) : string {
		try {
			return Niva_Modules::render( $module );
		} catch ( \Throwable $error ) {
			error_log( sprintf( 'Dr. Niva automatic %s failed: %s in %s:%d', $module, $error->getMessage(), $error->getFile(), $error->getLine() ) ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			return '';
		}
	}

	/**
	 * App pages render their own header, footer and dock inside the app shell.
	 * Elementor stores shortcode widgets in post meta rather than post_content.
	 */
	private static function is_app_page() : bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post ) {
			return false;
		}
		if ( has_shortcode( $post->post_content, 'dr_niva_app' ) ) {
			return true;
		}
		$elementor_data = (string) get_post_meta( $post->ID, '_elementor_data', true );
		return false !== strpos( $elementor_data, '[dr_niva_app' );
	}

	private static function auto_header_enabled() : bool {
		return 'off' !== dr_niva()->settings->get( 'chrome_header', 'auto' );
	}

	/** Elementor-built pages manage their own header and are not auto-decorated. */
	private static function is_elementor_page() : bool {
		if ( ! is_singular() ) {
			return false;
		}
		$post = get_queried_object();
		if ( ! $post instanceof WP_Post ) {
			return false;
		}
		if ( 'builder' === get_post_meta( $post->ID, '_elementor_edit_mode', true ) ) {
			return true;
		}
		if ( '' !== (string) get_post_meta( $post->ID, '_elementor_data', true ) ) {
			return true;
		}
		return false !== strpos( (string) get_post_meta( $post->ID, '_wp_page_template', true ), 'elementor' );
	}

	/** Logo from settings, else the site logo, else the brand mark. */
	public static function logo() : string {
		$id  = (int) dr_niva()->settings->get( 'brand_logo_id' );
		$url = (string) dr_niva()->settings->get( 'brand_logo_url' );

		if ( $id ) {
			$img = wp_get_attachment_image( $id, 'medium', false, array( 'class' => 'niva-brand__img', 'alt' => self::name() ) );
			if ( $img ) {
				return $img;
			}
		}
		if ( $url ) {
			return '<img class="niva-brand__img" src="' . esc_url( $url ) . '" alt="' . esc_attr( self::name() ) . '" loading="lazy" />';
		}
		return '<span class="brand__mark" aria-hidden="true"><span data-icon="activity" data-size="20"></span></span>';
	}

	/**
	 * WordPress has a filter on number_format_i18n()'s result, so every number the
	 * whole site prints — plugin, theme and admin — can be shown in Persian
	 * numerals with one hook, instead of wrapping hundreds of call sites.
	 */
	public static function localize_number( $formatted ) {
		if ( ! function_exists( 'dr_niva' ) ) {
			return $formatted;
		}
		$plugin = dr_niva();
		if ( ! $plugin || ! $plugin->settings ) {
			return $formatted;
		}
		return 'latin' === $plugin->settings->get( 'numeral_style', 'fa' ) ? $formatted : self::digits( $formatted );
	}

	/* ----------------------------------------------------------------- brand */

	/** #0878e8 -> [8, 120, 232]; anything unparsable falls back to the default. */
	public static function hex_to_rgb( string $hex, array $fallback = array( 8, 120, 232 ) ) : array {
		$hex = ltrim( trim( $hex ), '#' );
		if ( 3 === strlen( $hex ) ) {
			$hex = $hex[0] . $hex[0] . $hex[1] . $hex[1] . $hex[2] . $hex[2];
		}
		if ( 6 !== strlen( $hex ) || ! preg_match( '/^[0-9a-f]{6}$/i', $hex ) ) {
			return $fallback;
		}
		return array(
			(int) hexdec( substr( $hex, 0, 2 ) ),
			(int) hexdec( substr( $hex, 2, 2 ) ),
			(int) hexdec( substr( $hex, 4, 2 ) ),
		);
	}

	/** Shades a colour towards black ($amount > 0) or white ($amount < 0). */
	public static function shade( string $hex, float $amount ) : string {
		list( $r, $g, $b ) = self::hex_to_rgb( $hex );
		$target = $amount >= 0 ? 0 : 255;
		$ratio  = min( 1, abs( $amount ) );

		$r = (int) round( $r + ( $target - $r ) * $ratio );
		$g = (int) round( $g + ( $target - $g ) * $ratio );
		$b = (int) round( $b + ( $target - $b ) * $ratio );

		return sprintf( '#%02x%02x%02x', $r, $g, $b );
	}

	/**
	 * The three brand colours from the settings, turned into the full token set
	 * the stylesheets read. Printing this inline is what makes «رنگ برند» in the
	 * back office actually visible on the site.
	 */
	public static function brand_css() : string {
		$settings = dr_niva()->settings;
		$brand    = (string) $settings->get( 'brand_color', '#0878E8' );
		$brand_2  = (string) $settings->get( 'brand_color_2', '#4FA8F5' );
		$brand_3  = (string) $settings->get( 'brand_color_3', '#DDF7EC' );

		list( $r, $g, $b ) = self::hex_to_rgb( $brand );

		$css = ':root{'
			. '--brand:' . $brand . ';'
			. '--brand-dark:' . self::shade( $brand, 0.18 ) . ';'
			. '--brand-deep:' . self::shade( $brand, 0.38 ) . ';'
			. '--brand-soft:' . self::shade( $brand, -0.86 ) . ';'
			. '--brand-tint:' . self::shade( $brand, -0.94 ) . ';'
			. '--brand-2:' . $brand_2 . ';'
			. '--brand-2-dark:' . self::shade( $brand_2, 0.18 ) . ';'
			. '--brand-2-soft:' . self::shade( $brand_2, -0.86 ) . ';'
			. '--brand-3:' . $brand_3 . ';'
			. '--brand-3-soft:' . self::shade( $brand_3, -0.82 ) . ';'
			. '--brand-grad:linear-gradient(135deg,' . $brand . ' 0%,' . self::shade( $brand, 0.16 ) . ' 55%,' . self::shade( $brand, 0.34 ) . ' 100%);'
			. '--brand-grad-soft:linear-gradient(135deg,' . self::shade( $brand, -0.94 ) . ' 0%,' . self::shade( $brand, -0.86 ) . ' 60%,' . self::shade( $brand_3, -0.72 ) . ' 100%);'
			. '--sh-brand:0 14px 30px -16px rgba(' . $r . ',' . $g . ',' . $b . ',0.45);'
			. '--ring:0 0 0 3px rgba(' . $r . ',' . $g . ',' . $b . ',0.16);'
			. '--color-primary:' . $brand . ';'
			. '--color-primary-strong:' . self::shade( $brand, 0.18 ) . ';'
			. '--color-primary-soft:' . self::shade( $brand, -0.86 ) . ';'
			. '--info:' . $brand . ';'
			. '--info-soft:' . self::shade( $brand, -0.86 ) . ';'
			. '--color-info:' . $brand . ';'
			. '--color-info-soft:' . self::shade( $brand, -0.86 ) . ';'
			. '--sky:' . $brand . ';'
			. '--sky-soft:' . self::shade( $brand, -0.86 ) . ';'
			. '}';

		return $css;
	}


	/**
	 * Brings the active theme's chrome (header, buttons, links, footer) onto the
	 * same three colours as the app sections.
	 *
	 * Deliberately conservative: colours and geometry only, no layout, no
	 * display:none — a theme that looks different is never broken by this.
	 */
	public static function theme_css() : string {
		$brand  = (string) dr_niva()->settings->get( 'brand_color', '#0878E8' );
		$dark   = self::shade( $brand, 0.18 );
		$deep   = self::shade( $brand, 0.42 );
		$soft   = self::shade( $brand, -0.88 );
		$ink    = '#17242f';
		$line   = self::shade( $brand, -0.86 );

		$buttons = '.elementor-button, .elementor-button-link, .ast-button, .ast-custom-button,'
			. '.wp-block-button__link, .elementor-widget-button .elementor-button,'
			. 'input[type="submit"], button[type="submit"], .ast-header-button .ast-custom-button';

				/*
		 * Elementor's global kit colours are the source of the theme's green
		 * (#32CF7A accent / #218D6E secondary). Pulling those two variables onto
		 * the brand is what finally makes buttons and menus match the app.
		 */
		$kit_css = '
:root,
body[class*="elementor-kit-"] {
	--e-global-color-primary: ' . $brand . ';
	--e-global-color-secondary: ' . $dark . ';
	--e-global-color-accent: ' . $brand . ';
}
';

		/*
		 * The theme prints its own page title, which collided with the logo mark;
		 * the app carries its own header, so this can be switched off in settings.
		 */
		$title_css = dr_niva()->settings->is_on( 'theme_hide_title' )
			? '
.entry-header,
.ast-single-entry-banner .entry-header,
.page .entry-header {
	display: none;
}
'
			: '';

return '
/* --- Dr. Niva: theme harmoniser --------------------------------------- */
/* Solid header background: stops page content (e.g. the page title) from
   bleeding through a transparent / sticky theme header. */
#masthead, .site-header, .ast-primary-header-bar, .ast-above-header-bar,
.elementor-location-header, header.site-header {
	background-color: #ffffff;
}
' . $buttons . ' {
	background-color: ' . $brand . ';
	background-image: linear-gradient(135deg, ' . $brand . ' 0%, ' . $dark . ' 100%);
	border-color: transparent;
	color: #ffffff;
	border-radius: 999px;
}
' . $buttons . ':hover { filter: brightness(1.06); color: #ffffff; }

/* Navigation */
.main-header-menu > li > a,
.ast-builder-menu .menu-item > a,
.elementor-nav-menu a { color: ' . $ink . '; }
.main-header-menu .current-menu-item > a,
.main-header-menu > li > a:hover,
.ast-builder-menu .current-menu-item > a,
.elementor-nav-menu a:hover,
.elementor-nav-menu .current-menu-item > a { color: ' . $brand . '; }

/* Body links that are not buttons */
.site-content a:not(.btn):not(.elementor-button):not(.ast-button):not(.wp-block-button__link) {
	color: ' . $dark . ';
}
.site-content a:not(.btn):not(.elementor-button):not(.ast-button):hover { color: ' . $brand . '; }

/* Page titles */
.entry-title, .page-title, .ast-archive-title, h1.entry-title, h2.entry-title {
	color: ' . $ink . ';
}

/* Footer */
#colophon, .site-footer, .ast-footer-copyright, .elementor-location-footer {
	background-color: ' . $deep . ';
	color: rgba(255, 255, 255, 0.86);
}
#colophon a, .site-footer a, .site-footer .widget a { color: #ffffff; }
#colophon a:hover, .site-footer a:hover { color: ' . $line . '; }
.site-footer .widget-title, .site-footer h2, .site-footer h3 { color: #ffffff; }

/* Selection + focus ring follow the brand */
::selection { background: ' . $brand . '; color: #fff; }
.site-content :focus-visible { outline: 2px solid ' . $brand . '; outline-offset: 2px; }

/* Soft brand tint for bordered callout blocks the theme prints */
.elementor-widget-text-editor blockquote,
.ast-block-templates blockquote { border-inline-start-color: ' . $brand . '; background: ' . $soft . '; }
' . $kit_css . $title_css;
	}

	/* ------------------------------------------------------------ onboarding */

	/** True when we still do not know the most basic thing about the user. */
	public static function needs_onboarding() : bool {
		if ( ! is_user_logged_in() || ! function_exists( 'dr_niva' ) ) {
			return false;
		}
		$plugin = dr_niva();
		if ( ! $plugin || ! $plugin->profile ) {
			return false;
		}

		/*
		 * 2.0.0 — the full-page wizard replaces this sheet. While it is enabled
		 * the legacy modal stays quiet and the «تکمیل پروفایل» card drives the
		 * same flow, so a user is never asked the same questions twice.
		 */
		if ( isset( $plugin->onboarding ) && $plugin->onboarding instanceof Niva_Onboarding
			&& dr_niva()->settings->is_on( 'onboarding_wizard_enabled' ) ) {
			return false;
		}

		if ( ! empty( $_COOKIE['dr_niva_onboard_later'] ) ) {
			return false; // the user asked us to wait
		}
		$profile = $plugin->profile->get();
		return empty( $profile['sex'] );
	}

	/**
	 * The step-by-step welcome sheet.
	 *
	 * A brand-new user should never meet a dashboard full of zeros and have to
	 * hunt for the settings screen: the sheet asks for one thing at a time, only
	 * shows the steps the profile actually supports, and skips the cycle step
	 * for anyone who is not a woman.
	 */
	public static function onboarding_modal() : string {
		/*
		 * Ask the profile object what it supports. Calling Niva_Profile::defaults()
		 * statically threw a TypeError inside wp_footer, which took the whole page
		 * down — an instance read is both correct and safe here.
		 */
		$keys = array();
		if ( function_exists( 'dr_niva' ) && dr_niva() && dr_niva()->profile ) {
			$keys = array_keys( (array) dr_niva()->profile->get() );
		}
		$has = static function ( $key ) use ( $keys ) {
			return in_array( $key, $keys, true );
		};

		$steps = array();
		if ( $has( 'sex' ) ) {
			$steps[] = 'sex';
		}
		if ( $has( 'height' ) || $has( 'weight' ) ) {
			$steps[] = 'body';
		}
		if ( $has( 'lmp' ) ) {
			$steps[] = 'cycle';
		}
		$steps[] = 'notify';

		ob_start();
		?>
		<div class="onboarding" data-onboarding hidden>
			<div class="onboarding__backdrop" data-ob-later></div>
			<div class="onboarding__sheet" role="dialog" aria-modal="true" aria-labelledby="ob-title">
				<div class="onboarding__top">
					<span class="onboarding__step" data-ob-step-label></span>
					<button type="button" class="onboarding__x" data-ob-later aria-label="بستن"><?php echo self::svg_x(); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?></button>
				</div>
				<div class="onboarding__bar"><i data-ob-progress></i></div>

				<h2 class="onboarding__title" id="ob-title">خوش آمدی</h2>
				<p class="onboarding__lead">چند سؤال کوتاه، تا دکتر نیوا دقیقاً همان چیزی را نشانت بدهد که به آن نیاز داری. هر وقت خواستی می‌توانی بعداً هم پاسخ بدهی.</p>

				<div class="onboarding__body">
					<?php if ( $has( 'sex' ) ) : ?>
					<section class="ob-step" data-step="sex" data-title="خودت را معرفی کن">
						<p class="ob-step__q">مخاطب ما خانم است یا آقا؟</p>
						<span class="caption">این را می‌پرسیم چون بعضی بخش‌ها فقط برای یکی از این دو لازم است.</span>
						<div class="ob-choices">
							<button type="button" class="ob-choice" data-ob-sex="female"><?php echo self::svg_icon( 'heart' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span>خانم</span></button>
							<button type="button" class="ob-choice" data-ob-sex="male"><?php echo self::svg_icon( 'user' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span>آقا</span></button>
							<button type="button" class="ob-choice" data-ob-sex="other"><?php echo self::svg_icon( 'shield-check' ); // phpcs:ignore WordPress.Security.EscapeOutput.OutputNotEscaped ?><span>ترجیح می‌دهم نگویم</span></button>
						</div>
					</section>
					<?php endif; ?>

					<?php if ( $has( 'height' ) || $has( 'weight' ) ) : ?>
					<section class="ob-step" data-step="body" data-title="مشخصات بدنی" hidden>
						<p class="ob-step__q">قد و وزن تقریبی‌ات را بنویس.</p>
						<div class="ob-grid">
							<?php if ( $has( 'birth_year' ) ) : ?>
							<label class="field"><span class="field__label">سال تولد (شمسی)</span><input class="field__input" type="number" min="1300" max="1410" dir="ltr" data-ob-key="birth_year" /></label>
							<?php endif; ?>
							<?php if ( $has( 'height' ) ) : ?>
							<label class="field"><span class="field__label">قد (سانتی‌متر)</span><input class="field__input" type="number" min="80" max="230" dir="ltr" data-ob-key="height" /></label>
							<?php endif; ?>
							<?php if ( $has( 'weight' ) ) : ?>
							<label class="field"><span class="field__label">وزن (کیلوگرم)</span><input class="field__input" type="number" min="20" max="300" dir="ltr" data-ob-key="weight" /></label>
							<?php endif; ?>
						</div>
					</section>
					<?php endif; ?>

					<?php if ( $has( 'lmp' ) ) : ?>
					<section class="ob-step" data-step="cycle" data-title="چرخه‌ی ماهانه" hidden data-ob-only="female">
						<p class="ob-step__q">اولین روز آخرین پریودت کِی بود؟</p>
						<label class="field"><span class="field__label">تاریخ شروع آخرین پریود</span><input class="field__input" type="date" dir="ltr" data-ob-key="lmp" /></label>
						<div class="ob-grid">
							<?php if ( $has( 'cycle_length' ) ) : ?>
							<label class="field"><span class="field__label">طول چرخه (روز)</span><input class="field__input" type="number" min="20" max="45" dir="ltr" value="28" data-ob-key="cycle_length" /></label>
							<?php endif; ?>
							<?php if ( $has( 'period_length' ) ) : ?>
							<label class="field"><span class="field__label">چند روز پریود می‌شوی؟</span><input class="field__input" type="number" min="2" max="10" dir="ltr" value="5" data-ob-key="period_length" /></label>
							<?php endif; ?>
						</div>
						<span class="caption">از این‌ها تقویم، روزهای باروری و پیش‌بینی دوره ساخته می‌شود.</span>
					</section>
					<?php endif; ?>

					<?php if ( $has( 'pregnant' ) ) : ?>
					<section class="ob-step" data-step="pregnancy" data-title="بارداری" hidden data-ob-only="female">
						<p class="ob-step__q">آیا باردار هستی؟</p>
						<span class="caption">اگر بله، هفتهٔ بارداری و روزهای مانده خودکار حساب می‌شود.</span>
						<div class="ob-choices">
							<button type="button" class="ob-choice" data-ob-pregnant="1"><?php echo self::svg_icon( 'heart' ); // phpcs:ignore ?> بله</button>
							<button type="button" class="ob-choice" data-ob-pregnant="0"><?php echo self::svg_icon( 'check' ); // phpcs:ignore ?> خیر</button>
						</div>
						<div class="ob-grid" data-ob-due hidden>
							<?php if ( $has( 'due_date' ) ) : ?>
							<label class="field"><span class="field__label">تاریخ تقریبی زایمان</span><input class="field__input" type="date" dir="ltr" data-ob-key="due_date" /></label>
							<?php endif; ?>
						</div>
					</section>
					<?php endif; ?>

					<section class="ob-step" data-step="notify" data-title="یادآورها" hidden>
						<p class="ob-step__q">یادت بیاورم؟</p>
						<span class="caption">اگر اجازه بدهی، دارو، ویتامین، قرار و تمرین‌ها را سر وقت یادآوری می‌کنیم.</span>
						<button type="button" class="btn btn--secondary" data-ob-notify>اجازهٔ اعلان</button>
						<span class="caption" data-ob-notify-state></span>
					</section>
				</div>

				<div class="onboarding__foot">
					<button type="button" class="btn btn--ghost btn--sm" data-ob-later>بعداً</button>
					<button type="button" class="btn btn--secondary btn--sm" data-ob-prev hidden>قبلی</button>
					<button type="button" class="btn btn--primary" data-ob-next>بعدی</button>
				</div>
			</div>
		</div>
		<?php
		return (string) ob_get_clean();
	}

	/** Small helper so the sheet does not repeat the icons markup. */
	public static function svg_icon( string $name, int $size = 22 ) : string {
		return Niva_Icons::svg( $name, $size );
	}

	/** The close cross. */
	public static function svg_x() : string {
		return Niva_Icons::svg( 'x', 18 );
	}

	/* --------------------------------------------------------- real charts */

	/**
	 * A small bar chart drawn in PHP from an array of real numbers.
	 *
	 * Used where a Javascript chart would otherwise need a hard-coded series —
	 * the height of each bar is the user's own value, never a sample.
	 *
	 * @param array $values  numbers, oldest first
	 * @param int   $max     the scale ceiling
	 * @param array $labels  optional labels in the same order
	 */
	public static function bars( array $values, int $max = 27, array $labels = array() ) : string {
		$values = array_map( 'floatval', $values );
		if ( ! $values ) {
			return '';
		}
		$top = max( 1, $max );
		$out = '<div class="bar-chart" role="img">';

		foreach ( $values as $index => $value ) {
			$height = max( 3, (int) round( ( $value / $top ) * 100 ) );
			$label  = $labels[ $index ] ?? '';
			$out   .= '<span class="bar-chart__col' . ( $index === count( $values ) - 1 ? ' bar-chart__col--today' : '' ) . '">';
			$out   .= '<b class="bar-chart__value">' . esc_html( self::digits( (int) round( $value ) ) ) . '</b>';
			$out   .= '<span class="bar-chart__track"><i class="bar-chart__bar" style="height:' . $height . '%"></i></span>';
			$out   .= '<span class="bar-chart__label">' . esc_html( (string) $label ) . '</span>';
			$out   .= '</span>';
		}

		return $out . '</div>';
	}

	/* ------------------------------------------------------------ empty state */

	/**
	 * The one way this product says "there is no data yet".
	 *
	 * Every screen that used to print a made-up number now prints this instead,
	 * so a brand-new account never sees someone else's haemoglobin or a fake
	 * pregnancy week. Real data in the profile simply takes over.
	 */
	public static function blank( string $title, string $text = '', string $cta = '', string $cta_key = '', array $args = array() ) : string {
		/*
		 * 5.0.0 — the shared empty state now follows the app design: a soft
		 * circular icon, a bold title, a quiet explanation and one clear
		 * primary action. Every screen that has "nothing here yet" renders
		 * through this one method, so all of them stay identical.
		 */
		$out = '<div class="empty-state niva-state">';
		$out .= '<span class="niva-state__icon" aria-hidden="true">' . self::svg_icon( 'info', 26 ) . '</span>';
		$out .= '<span class="empty-state__title niva-state__title">' . esc_html( $title ) . '</span>';
		if ( '' !== $text ) {
			$out .= '<span class="caption">' . esc_html( $text ) . '</span>';
		}
		if ( '' !== $cta && '' !== $cta_key ) {
			$out .= '<a class="btn btn--primary btn--sm" href="' . esc_url( Niva_Modules::url( $cta_key, $args ) ) . '">' . esc_html( $cta ) . '</a>';
		}
		$out .= '</div>';

		return $out;
	}

	/** A single profile flag, read safely. */
	public static function flag( string $key, $default = '' ) {
		if ( ! function_exists( 'dr_niva' ) || ! dr_niva() || ! dr_niva()->profile ) {
			return $default;
		}
		$profile = (array) dr_niva()->profile->get();
		return array_key_exists( $key, $profile ) ? $profile[ $key ] : $default;
	}

	/* ----------------------------------------------------------- cycle maths */

	/** How many days a Persian month has. */
	public static function days_in_month( int $year, int $month ) : int {
		if ( $month <= 6 ) {
			return 31;
		}
		if ( $month <= 11 ) {
			return 30;
		}
		$mod = $year % 33;
		return in_array( $mod, array( 1, 5, 9, 13, 17, 22, 26, 30 ), true ) ? 30 : 29;
	}

	/** "۱۵ مهر" for a timestamp. */
	public static function date_short( int $timestamp ) : string {
		list( , $month, $day ) = self::jalali( $timestamp );
		return self::digits( $day ) . ' ' . ( self::months()[ (int) $month ] ?? '' );
	}

	/** A site-local Shamsi date and time for activity records. */
	public static function format_datetime( string $datetime ) : string {
		$date = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $datetime, wp_timezone() );
		if ( ! $date ) {
			return '';
		}
		return self::date_short( $date->getTimestamp() ) . '، ' . self::digits( $date->format( 'H:i' ) );
	}

	/** Converts a UTC MySQL timestamp to the site's Shamsi date and local time. */
	public static function format_datetime_gmt( string $datetime ) : string {
		$date = \DateTimeImmutable::createFromFormat( 'Y-m-d H:i:s', $datetime, new \DateTimeZone( 'UTC' ) );
		if ( ! $date ) {
			return '';
		}
		$date = $date->setTimezone( wp_timezone() );
		return self::date_short( $date->getTimestamp() ) . '، ' . self::digits( $date->format( 'H:i' ) );
	}

	/** Converts a stored Gregorian date to a full Shamsi date label. */
	public static function format_date( string $date ) : string {
		$parsed = \DateTimeImmutable::createFromFormat( '!Y-m-d', $date, wp_timezone() );
		if ( ! $parsed || $parsed->format( 'Y-m-d' ) !== $date ) {
			return '';
		}
		list( $year, $month, $day ) = self::jalali( $parsed->getTimestamp() );
		if ( ! $year || ! $month || ! $day ) {
			return '';
		}
		return self::digits( sprintf( '%04d/%02d/%02d', $year, $month, $day ) );
	}

	/** [1,2,3,4,5] -> "۱ تا ۵ مهر" · [15] -> "۱۵ مهر" · [] -> "—" */
	public static function range_label( array $days ) : string {
		$days = array_values( array_unique( array_map( 'intval', $days ) ) );
		sort( $days );
		if ( ! $days ) {
			return '—';
		}
		list( , $j_month ) = self::jalali( time() );
		$month = self::months()[ (int) $j_month ] ?? '';
		if ( count( $days ) === 1 ) {
			return self::digits( $days[0] ) . ' ' . $month;
		}
		return self::digits( $days[0] ) . ' تا ' . self::digits( $days[ count( $days ) - 1 ] ) . ' ' . $month;
	}

	/**
	 * Every number the cycle screens show, derived from the user's own profile:
	 * last period + cycle length. Nothing here is sample data — when the profile
	 * has no `lmp` the screen falls back to an explicit "not set yet" state.
	 *
	 * @return array
	 */
	public static function cycle_state( int $user_id = 0 ) : array {
		// The companion view needs another person's cycle, so the state is
		// computed for an explicit user when one is given.
		$profile = ( function_exists( 'dr_niva' ) && dr_niva() && dr_niva()->profile ) ? dr_niva()->profile->get( $user_id ) : array();
		$lmp     = (string) ( $profile['lmp'] ?? '' );
		/*
		 * The user's own numbers when they set them. When they have not, the
		 * baseline below is only used to draw a prediction and is flagged with
		 * 'configured' => false, so the UI can say "not set yet" instead of
		 * presenting a made-up cycle length as if the user had chosen it.
		 */
		$user_len   = (int) ( $profile['cycle_length'] ?? 0 );
		$user_bleed = (int) ( $profile['period_length'] ?? 0 );
		$len        = $user_len >= 20 ? min( 45, $user_len ) : 28;
		$bleed      = $user_bleed >= 2 ? min( 10, $user_bleed ) : 5;

		$now = function_exists( 'current_time' ) ? current_time( 'timestamp' ) : time();
		// jalali() returns a numeric triple [year, month, day].
		list( $j_year, $j_month, $j_day ) = self::jalali( $now );

		$state = array(
			'has_data'      => false,
			'configured'    => $user_len >= 20,
			'cycle_day'     => 0,
			'cycle_length'  => $len,
			'period_length' => $bleed,
			'today'         => (int) $j_day,
			'days_in_month' => self::days_in_month( (int) $j_year, (int) $j_month ),
			'month_name'    => self::months()[ (int) $j_month ] ?? '',
			'year'          => (int) $j_year,
			'offset'        => 0,
			'period'        => array(),
			'predicted'     => array(),
			'fertile'       => array(),
			'ovulation'     => array(),
			'pms'           => array(),
			'next_in_days'  => 0,
			'next_date'     => '',
			'ranges'        => array(),
		);
		$state['offset'] = ( ( (int) self::weekday_index() - ( $state['today'] - 1 ) ) % 7 + 7 ) % 7;

		if ( '' === $lmp || false === strtotime( $lmp ) ) {
			return $state;
		}

		$state['has_data'] = true;
		$start            = strtotime( 'today', strtotime( $lmp ) );
		$today_ts         = strtotime( 'today', $now );
		$passed           = (int) floor( ( $today_ts - $start ) / DAY_IN_SECONDS );
		if ( $passed < 0 ) {
			$passed = 0;
		}
		$state['cycle_day'] = ( $passed % $len ) + 1;
		$ovu                = $len - 14;
		if ( $ovu < 1 ) {
			$ovu = (int) floor( $len / 2 );
		}

		for ( $d = 1; $d <= $state['days_in_month']; $d++ ) {
			$pos = ( ( $state['cycle_day'] + ( $d - $state['today'] ) - 1 ) % $len + $len ) % $len + 1;
			if ( $pos <= $bleed ) {
				if ( $d <= $state['today'] ) {
					$state['period'][] = $d;
				} else {
					$state['predicted'][] = $d;
				}
			}
			if ( $pos === $ovu ) {
				$state['ovulation'][] = $d;
			}
			if ( abs( $pos - $ovu ) <= 1 ) {
				$state['fertile'][] = $d;
			}
			if ( $pos > $len - 4 ) {
				$state['pms'][] = $d;
			}
		}

		$state['next_in_days'] = (int) ( ( $len - $state['cycle_day'] ) + 1 );
		$state['next_date']    = self::date_short( $today_ts + ( $state['next_in_days'] * DAY_IN_SECONDS ) );
		$state['ranges']       = array(
			'period'    => self::range_label( array_merge( $state['period'], $state['predicted'] ) ),
			'fertile'   => self::range_label( $state['fertile'] ),
			'ovulation' => self::range_label( $state['ovulation'] ),
			'pms'       => self::range_label( $state['pms'] ),
		);
		$state['len_label']     = self::digits( $len ) . ' روز';
		$state['cycle_day_fa']  = self::digits( $state['cycle_day'] );
		$state['next_in_fa']    = self::digits( $state['next_in_days'] );

		return $state;
	}

	/* ------------------------------------------------------------------ date */

	/** Persian month names, index 1..12. */
	public static function months() : array {
		return array(
			1  => 'فروردین',
			2  => 'اردیبهشت',
			3  => 'خرداد',
			4  => 'تیر',
			5  => 'مرداد',
			6  => 'شهریور',
			7  => 'مهر',
			8  => 'آبان',
			9  => 'آذر',
			10 => 'دی',
			11 => 'بهمن',
			12 => 'اسفند',
		);
	}

	/** Persian week, starting on Saturday (index 0). */
	public static function weekdays() : array {
		return array( 'شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه' );
	}

	/** Latin digits -> Persian digits, honouring the «نمایش اعداد» setting. */
	public static function digits( $value ) : string {
		$value = (string) $value;
		if ( dr_niva()->settings && 'latin' === dr_niva()->settings->get( 'numeral_style', 'fa' ) ) {
			return $value;
		}
		return str_replace( array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ), array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' ), $value );
	}

	/**
	 * Gregorian (in the site timezone) -> Jalali.
	 *
	 * The classic 12053/1461 day-count algorithm: no external library and no
	 * dependency on a PHP intl extension.
	 *
	 * @return array [year, month, day] or [0, 0, 0] on failure.
	 */
	public static function jalali( int $timestamp = 0 ) : array {
		/*
		 * Only a literal 0 means "now". Negative stamps (birth dates before
		 * 1970, which the onboarding wizard can absolutely produce) are real
		 * dates and must be converted, not silently replaced by today.
		 */
		$time = 0 !== $timestamp ? $timestamp : time();

		try {
			$zone = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
			$date = new DateTime( '@' . $time );
			$date->setTimezone( $zone );
			$gy   = (int) $date->format( 'Y' );
			$gm   = (int) $date->format( 'n' );
			$gd   = (int) $date->format( 'j' );
		} catch ( \Exception $error ) {
			return array( 0, 0, 0 );
		}

		$days_in_month = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );
		$gy2           = $gm > 2 ? $gy + 1 : $gy;

		$days = 355666 + ( 365 * $gy ) + (int) floor( ( $gy2 + 3 ) / 4 ) - (int) floor( ( $gy2 + 99 ) / 100 )
			+ (int) floor( ( $gy2 + 399 ) / 400 ) + $gd + $days_in_month[ $gm - 1 ];

		$jy    = -1595 + ( 33 * (int) floor( $days / 12053 ) );
		$days %= 12053;
		$jy   += 4 * (int) floor( $days / 1461 );
		$days %= 1461;

		if ( $days > 365 ) {
			$jy  += (int) floor( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}

		if ( $days < 186 ) {
			$jm = 1 + (int) floor( $days / 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + (int) floor( ( $days - 186 ) / 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}

		return array( $jy, $jm, $jd );
	}

	/**
	 * Jalali -> Gregorian, the inverse of jalali().
	 *
	 * Same day-count algorithm as jalaali-js, no intl dependency. Used by the
	 * onboarding wizard (birth date, LMP) and by the 2.0.0 profile migration.
	 *
	 * @return array [year, month, day] or [0, 0, 0] on failure.
	 */
	public static function jalali_to_gregorian( int $jy, int $jm, int $jd ) : array {
		if ( $jm < 1 || $jm > 12 || $jd < 1 || $jd > 31 || $jy < 1000 || $jy > 1600 ) {
			return array( 0, 0, 0 );
		}
		$jy += 1595;
		$days = -355668
			+ ( 365 * $jy )
			+ ( (int) floor( $jy / 33 ) * 8 )
			+ (int) floor( ( ( $jy % 33 ) + 3 ) / 4 )
			+ $jd
			+ ( $jm < 7 ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );

		$gy = 400 * (int) floor( $days / 146097 );
		$days %= 146097;

		if ( $days > 36524 ) {
			$gy  += 100 * (int) floor( --$days / 36524 );
			$days %= 36524;
			if ( $days >= 365 ) {
				$days++;
			}
		}

		$gy  += 4 * (int) floor( $days / 1461 );
		$days %= 1461;

		if ( $days > 365 ) {
			$gy  += (int) floor( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}

		$gd    = $days + 1;
		$leap  = ( 0 === $gy % 4 && 0 !== $gy % 100 ) || 0 === $gy % 400;
		$month = array( 0, 31, $leap ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31 );

		$gm = 1;
		while ( $gm <= 12 && $gd > $month[ $gm ] ) {
			$gd -= $month[ $gm ];
			$gm++;
		}

		return array( $gy, $gm, $gd );
	}

	/** 0-based Persian weekday of a timestamp (Saturday = 0). */
	public static function weekday_index( int $timestamp = 0 ) : int {
		$time = $timestamp > 0 ? $timestamp : time();
		try {
			$zone = function_exists( 'wp_timezone' ) ? wp_timezone() : new DateTimeZone( 'UTC' );
			$date = new DateTime( '@' . $time );
			$date->setTimezone( $zone );
			$w = (int) $date->format( 'w' ); // 0 = Sunday
		} catch ( \Exception $error ) {
			return 0;
		}
		return ( $w + 1 ) % 7;
	}

	/** How many days a Jalali month has. */
	public static function jalali_month_days( int $year, int $month ) : int {
		if ( $month <= 6 ) {
			return 31;
		}
		if ( $month <= 11 ) {
			return 30;
		}
		return self::jalali_is_leap( $year ) ? 30 : 29;
	}

	/** Leap-year test for the Jalali calendar. */
	public static function jalali_is_leap( int $year ) : bool {
		$year %= 33;
		return in_array( $year, array( 1, 5, 9, 13, 17, 22, 26, 30 ), true );
	}

	/** «سه‌شنبه ۱۵ مهر ۱۴۰۵» — the real date, never a hard-coded string. */
	public static function today_label( int $timestamp = 0 ) : string {
		$time = $timestamp > 0 ? $timestamp : time();
		list( $y, $m, $d ) = self::jalali( $time );
		if ( ! $y ) {
			return '';
		}
		$weekdays = self::weekdays();
		$months   = self::months();
		$index    = self::weekday_index( $time );
		$weekday  = isset( $weekdays[ $index ] ) ? $weekdays[ $index ] : '';

		return trim( $weekday . ' ' . self::digits( $d ) . ' ' . $months[ $m ] . ' ' . self::digits( $y ) );
	}

	/** «۱۵ مهر» — the short form used inside the cycle screens. */
	public static function today_short( int $timestamp = 0 ) : string {
		$time = $timestamp > 0 ? $timestamp : time();
		list( $y, $m, $d ) = self::jalali( $time );
		if ( ! $y ) {
			return '';
		}
		$months = self::months();
		return self::digits( $d ) . ' ' . $months[ $m ];
	}

	/** «مهر ۱۴۰۵» — the month a calendar should open on. */
	public static function month_label( int $timestamp = 0 ) : string {
		$time = $timestamp > 0 ? $timestamp : time();
		list( $y, $m ) = self::jalali( $time );
		if ( ! $y ) {
			return '';
		}
		$months = self::months();
		return $months[ $m ] . ' ' . self::digits( $y );
	}

	/** «سلام، نام کاربر» — never a hard-coded name. */
	public static function greeting() : string {
		if ( is_user_logged_in() ) {
			$user = wp_get_current_user();
			$name = $user->first_name ? $user->first_name : $user->display_name;
			return $name ? 'سلام، ' . $name . ' جان' : 'سلام';
		}
		return 'سلام';
	}

	public static function name() : string {
		$name = (string) dr_niva()->settings->get( 'brand_name' );
		return $name ? $name : get_bloginfo( 'name' );
	}

	public static function tagline() : string {
		$tagline = (string) dr_niva()->settings->get( 'brand_tagline' );
		return $tagline ? $tagline : 'کلینیک دیجیتال همراه شما';
	}

	/** The primary menu: the WordPress menu if assigned, otherwise the app screens. */
	public static function menu( string $class = 'nav' ) : string {
		if ( has_nav_menu( 'dr_niva_app' ) ) {
			return (string) wp_nav_menu(
				array(
					'theme_location' => 'dr_niva_app',
					'container'      => false,
					'menu_class'     => $class . '__list',
					'depth'          => 2,
					'echo'           => false,
					'fallback_cb'    => '',
				)
			);
		}

		$items = array(
			'home'    => array( 'خانه', Niva_Modules::url( 'home' ) ),
			'advisor' => array( 'مشاور', Niva_Modules::url( 'advisor' ) ),
			'tools'   => array( 'ابزارها', Niva_Modules::url( 'tools' ) ),
			'cycle'   => array( 'چرخه', Niva_Modules::url( 'cycle' ) ),
			'profile' => array( 'حساب من', Niva_Modules::url( 'profile' ) ),
		);

		$out = '<ul class="' . esc_attr( $class . '__list' ) . '">';
		foreach ( $items as $key => $item ) {
			$out .= '<li class="nav__link-wrap"><a class="nav__link" href="' . esc_url( $item[1] ) . '">' . esc_html( $item[0] ) . '</a></li>';
		}
		return $out . '</ul>';
	}

	/** Menu entries for the Javascript app header, preserving labels and icons. */
	/**
	 * The app's own menu when no WordPress menu is assigned to «dr_niva_app».
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function default_menu() : array {
		$tree = array(
			array( 'home', 'خانه', 'home', array() ),
			array( 'cycle', 'سیکل', 'calendar-days', array(
				array( 'cycle_calendar', 'تقویم چرخه', 'calendar' ),
				array( 'pregnancy', 'بارداری', 'baby' ),
				array( 'baby', 'کودک', 'baby' ),
			) ),
			array( 'tools', 'کلینیک', 'layers', array(
				array( 'analyze', 'آزمایش و تحلیل', 'flask-conical' ),
				array( 'reminders', 'یادآورها', 'alarm-clock' ),
				array( 'mind', 'ذهن و حال', 'sparkles' ),
				array( 'advisor', 'مشاوره', 'message-circle' ),
			) ),
			array( 'community', 'گفتگو', 'messages-square', array(
				array( 'community_new', 'پرسش تازه', 'plus-circle' ),
				array( 'companion_create', 'کد همراهی', 'user-plus' ),
			) ),
			array( 'profile', 'پروفایل من', 'user-circle', array(
				array( 'wallet', 'کیف پول', 'wallet' ),
				array( 'plans', 'پلن‌ها و اشتراک', 'credit-card' ),
				array( 'family', 'خانواده', 'users' ),
				array( 'notifications', 'اعلان‌ها', 'bell' ),
				array( 'about', 'دربارهٔ دکتر نیوا', 'info' ),
			) ),
		);

		$out = array();
		foreach ( $tree as $node ) {
			$kids = array();
			foreach ( $node[3] as $child ) {
				$kids[] = array(
					'label' => $child[1],
					'url'   => Niva_Links::url( $child[0] ),
					'icon'  => (string) $child[2],
					'key'   => (string) $child[0],
				);
			}
			$out[] = array(
				'label'    => $node[1],
				'url'      => Niva_Links::url( $node[0] ),
				'icon'     => (string) $node[2],
				'key'      => (string) $node[0],
				'children' => $kids,
			);
		}
		return $out;
	}

	public static function menu_data() : array {
		$location = (array) get_nav_menu_locations();
		$menu_id  = absint( $location['dr_niva_app'] ?? 0 );
		$items    = $menu_id ? wp_get_nav_menu_items( $menu_id ) : false;
		if ( ! $items || is_wp_error( $items ) ) {
			/*
			 * 3.1.0 — no menu assigned used to return an empty array, so the
			 * header and the drawer fell back to a flat list of five links and
			 * no sub-menu could ever appear. The app's own grouped menu is used
			 * instead, with the same shape as a WordPress menu.
			 */
			return self::default_menu();
		}
		$registry = Niva_Links::registry();
		$out      = array();

		/*
		 * 3.0.3 — child items used to be dropped (`continue`), so the header and
		 * the drawer had no sub-menu at all. They are grouped by parent now.
		 */
		$children = array();
		foreach ( $items as $child ) {
			if ( (int) $child->menu_item_parent > 0 ) {
				$children[ (int) $child->menu_item_parent ][] = $child;
			}
		}

		foreach ( $items as $item ) {
			if ( (int) $item->menu_item_parent > 0 ) {
				continue;
			}
			$url   = (string) $item->url;
			$path  = (string) wp_parse_url( $url, PHP_URL_PATH );
			$slug  = trim( (string) basename( untrailingslashit( $path ) ) );
			$key   = '';
			$route = array();
			if ( preg_match( '#/dr-niva/([a-z0-9-]+)/?$#i', $path, $route ) ) {
				foreach ( $registry as $candidate => $definition ) {
					if ( $definition[2] === sanitize_key( $route[1] ) ) {
						$key = $candidate;
						break;
					}
				}
			}
			if ( '' === $key ) {
				foreach ( $registry as $candidate => $definition ) {
					if ( in_array( $slug, $definition[1], true ) ) {
						$key = $candidate;
						break;
					}
				}
			}
			$kids = array();
			$child_items = isset( $children[ (int) $item->ID ] ) ? $children[ (int) $item->ID ] : array();
			foreach ( $child_items as $child ) {
				$child_url  = (string) $child->url;
				$child_path = (string) wp_parse_url( $child_url, PHP_URL_PATH );
				$child_slug = trim( (string) basename( untrailingslashit( $child_path ) ) );
				$child_key  = '';
				foreach ( $registry as $candidate => $definition ) {
					if ( in_array( $child_slug, $definition[1], true ) ) {
						$child_key = $candidate;
						break;
					}
				}
				$kids[] = array(
					'label' => wp_strip_all_tags( (string) $child->title ),
					'url'   => esc_url_raw( $child_url ),
					'icon'  => sanitize_key( (string) get_post_meta( (int) $child->ID, '_dr_niva_menu_icon', true ) ),
					'key'   => $child_key,
				);
			}
			$out[] = array(
				'label'    => wp_strip_all_tags( (string) $item->title ),
				'url'      => esc_url_raw( $url ),
				'icon'     => sanitize_key( (string) get_post_meta( (int) $item->ID, '_dr_niva_menu_icon', true ) ),
				'key'      => $key,
				'children' => $kids,
			);
		}
		return $out;
	}

	/**
	 * WooCommerce may not be installed at all — every store URL goes through here
	 * so a missing store can never break the page.
	 */
	public static function account_url( string $endpoint = 'niva-wallet' ) : string {
		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			return (string) wc_get_account_endpoint_url( $endpoint );
		}
		return ( new Niva_Links() )->url( 'plans' );
	}

	public static function store_url( string $page = 'shop' ) : string {
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			$url = (string) wc_get_page_permalink( $page );
			if ( $url ) {
				return $url;
			}
		}
		return ( new Niva_Links() )->url( 'plans' );
	}

	/** Login button, or the signed-in user with their balance. */
	public static function account() : string {
		if ( ! is_user_logged_in() ) {
			return '<a class="btn btn--primary btn--sm" href="' . esc_url( wp_login_url( get_permalink() ? get_permalink() : home_url( '/' ) ) ) . '">ورود / ثبت‌نام</a>';
		}

		$user    = wp_get_current_user();
		$balance = dr_niva()->wallet->summary( $user->ID );
		ob_start();
		?>
		<span class="niva-account">
			<span class="niva-account__name"><?php echo esc_html( $user->display_name ); ?></span>
			<span class="badge badge--green" title="اعتبار باقی‌مانده">
				<span data-icon="credit-card" data-size="14"></span>
				<bdi dir="ltr"><?php echo esc_html( number_format_i18n( $balance['balance'] ) ); ?></bdi>
			</span>
			<a class="niva-account__link" href="<?php echo esc_url( Niva_Modules::url( 'profile' ) ); ?>">حساب من</a>
			<a class="niva-account__link" href="<?php echo esc_url( wp_logout_url( home_url( '/' ) ) ); ?>">خروج</a>
		</span>
		<?php
		return (string) ob_get_clean();
	}

	/**
	 * 5.0.0 — the screen the current request is showing.
	 *
	 * The dock and header highlight need the *view* (home/cycle/…), not the page
	 * slug: an imported page may be called «پروندهٔ کودک» while its view is
	 * `baby`. This mirrors the alias table Niva_Frontend::shortcode_app() uses,
	 * so the tab that lights up is the tab that is actually open.
	 */
	public static function current_view() : string {
		$view = '';
		if ( isset( $_GET['niva_view'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$view = sanitize_key( wp_unslash( $_GET['niva_view'] ) ); // phpcs:ignore
		} elseif ( get_query_var( 'niva_view' ) ) {
			$view = sanitize_key( (string) get_query_var( 'niva_view' ) );
		}

		if ( '' === $view ) {
			$post = get_post();
			if ( $post instanceof WP_Post ) {
				$view = sanitize_key( strtolower( rawurldecode( (string) $post->post_name ) ) );
			}
		}

		$aliases = array(
			'index'     => 'home',
			'lab'       => 'analyze',
			'reminders' => 'alarms',
			'messages'  => 'tools',
			'account'   => 'profile',
		);
		$view = isset( $aliases[ $view ] ) ? $aliases[ $view ] : $view;
		return '' !== $view ? $view : 'home';
	}

	/** One grapheme, safe for Persian (multi-byte) names. */
	private static function first_char( string $value ) : string {
		$value = trim( $value );
		if ( '' === $value ) {
			return '';
		}
		return function_exists( 'mb_substr' ) ? (string) mb_substr( $value, 0, 1, 'UTF-8' ) : substr( $value, 0, 1 );
	}

	/** Two letters for the avatar bubble, taken from the user's real name. */
	public static function initials( string $name = '' ) : string {
		$name = trim( wp_strip_all_tags( $name ) );
		if ( '' === $name ) {
			return 'ن';
		}
		$parts = preg_split( '/\s+/u', $name );
		$parts = is_array( $parts ) ? array_values( array_filter( $parts ) ) : array();
		$first = isset( $parts[0] ) ? (string) $parts[0] : '';
		if ( count( $parts ) > 1 ) {
			$second = isset( $parts[1] ) ? (string) $parts[1] : '';
			return self::first_char( $first ) . self::first_char( $second );
		}
		return self::first_char( $first );
	}

	/** The user's given name, or '' for a guest. */
	public static function greeting_name() : string {
		if ( ! is_user_logged_in() ) {
			return '';
		}
		$user = wp_get_current_user();
		$name = $user->first_name ? $user->first_name : $user->display_name;
		return (string) $name;
	}

	/**
	 * The round avatar used by the app header and the profile hero.
	 *
	 * Falls back to the user's initials on a blue circle, so the header never
	 * shows an empty grey box for an account without a picture.
	 */
	public static function avatar( string $extra_class = '', int $size = 46 ) : string {
		$user_id = (int) get_current_user_id();
		$url     = '';
		$name    = '';
		if ( $user_id ) {
			$name = self::greeting_name();
			if ( function_exists( 'dr_niva' ) && dr_niva()->profile ) {
				try {
					$url = (string) dr_niva()->profile->avatar_url( $user_id );
				} catch ( \Throwable $e ) {
					$url = '';
				}
			}
		}
		$class  = 'nv-avatar' . ( '' !== $extra_class ? ' ' . $extra_class : '' );
		$size   = max( 28, min( 120, $size ) );
		$styles = 'width:' . $size . 'px;height:' . $size . 'px;font-size:' . round( $size * 0.36, 1 ) . 'px';
		if ( '' !== $url ) {
			return '<span class="' . esc_attr( $class ) . '" style="' . esc_attr( $styles ) . '"><img src="' . esc_url( $url ) . '" alt="' . esc_attr( $name ) . '" loading="lazy" /></span>';
		}
		return '<span class="' . esc_attr( $class ) . '" style="' . esc_attr( $styles ) . '" aria-hidden="true">' . esc_html( self::initials( $name ) ) . '</span>';
	}

	/**
	 * Bottom dock for phones — the five destinations of the app.
	 *
	 * @return array<int,array{label:string,url:string,icon:string,view:string}>
	 */
	public static function dock_tabs() : array {
		return array(
			array( 'label' => 'خانه', 'url' => Niva_Modules::url( 'home' ), 'icon' => 'home', 'view' => 'home' ),
			array( 'label' => 'مشاور', 'url' => Niva_Modules::url( 'advisor' ), 'icon' => 'message-circle', 'view' => 'advisor' ),
			array( 'label' => 'چرخه', 'url' => Niva_Modules::url( 'cycle' ), 'icon' => 'calendar-heart', 'view' => 'cycle' ),
			array( 'label' => 'آزمایش‌ها', 'url' => Niva_Modules::url( 'lab' ), 'icon' => 'file-text', 'view' => 'analyze' ),
			array( 'label' => 'پروفایل', 'url' => Niva_Modules::url( 'profile' ), 'icon' => 'user', 'view' => 'profile' ),
		);
	}

	/** Bottom dock for phones (part of the footer widget). */
	public static function dock() : string {
		$current = self::current_view();
		$tabs    = self::dock_tabs();

		ob_start();
		?>
		<nav class="mobile-bar niva-dock" aria-label="ناوبری پایین">
			<?php foreach ( $tabs as $tab ) : ?>
				<?php $is_active = ( $current === $tab['view'] ); ?>
				<a class="mobile-bar__tab niva-dock__tab<?php echo $is_active ? ' mobile-bar__tab--active niva-dock__tab--active' : ''; ?>"
					href="<?php echo esc_url( $tab['url'] ); ?>"
					<?php echo $is_active ? ' aria-current="page"' : ''; ?>>
					<span data-icon="<?php echo esc_attr( $tab['icon'] ); ?>" data-size="22"></span>
					<span><?php echo esc_html( $tab['label'] ); ?></span>
				</a>
			<?php endforeach; ?>
		</nav>
		<?php
		return (string) ob_get_clean();
	}
}
