<?php
/**
 * One-time migration from the old «دکتر آوا» keys to «دکتر نیوا».
 *
 * The rebrand renamed everything: the folder, the classes, the database tables,
 * the user/post meta keys and the option names. A site that already had data
 * would otherwise look empty after the update, so this class moves the old
 * names aside exactly once:
 *
 *   · tables      wp_ava_*   → wp_niva_*
 *   · user meta   ava_*      → niva_*
 *   · post meta   _dr_ava_*  → _dr_niva_*
 *   · options     dr_ava_*   → dr_niva_*
 *
 * It never deletes anything: if the new name already exists the row/table is
 * left untouched, and the old names simply stop being used.
 *
 * @package DrNiva
 */

defined( 'ABSPATH' ) || exit;

/**
 * Handles the ava → niva data move.
 */
class Niva_Migrate {

	/** Set once the move has run, so it never happens twice. */
	const FLAG = 'niva_rebrand_migrated_at';

	/** Result of the last run, for the admin notice. */
	const REPORT = 'niva_rebrand_migrated_report';

	public function __construct() {
		add_action( 'plugins_loaded', array( $this, 'maybe' ), 5 );
		add_action( 'admin_init', array( $this, 'maybe' ), 5 );
	}

	/**
	 * Runs the migration once, then records it.
	 */
	public function maybe() : void {
		if ( get_option( self::FLAG ) ) {
			return;
		}

		$report = $this->run();
		update_option( self::FLAG, time(), false );
		update_option( self::REPORT, $report, false );

		/*
		 * Cached lookups still hold the old names; clearing the niva_* transients
		 * is enough (there is no database-level cache in this version).
		 */
		global $wpdb;
		$wpdb->query( "DELETE FROM {$wpdb->options} WHERE option_name LIKE '\_transient\_niva\_%' OR option_name LIKE '\_transient\_timeout\_niva\_%'" ); // phpcs:ignore WordPress.DB
	}

	/**
	 * @return array<string,int|array<int,string>>
	 */
	private function run() : array {
		global $wpdb;

		$report = array( 'tables' => 0, 'usermeta' => 0, 'postmeta' => 0, 'options' => 0, 'content' => 0, 'meta_values' => 0, 'renamed' => array() );

		// 1) database tables.
		$old_tables = $wpdb->get_col( "SHOW TABLES LIKE '" . $wpdb->prefix . "ava\\_%'" ); // phpcs:ignore WordPress.DB
		foreach ( (array) $old_tables as $table ) {
			$new = $wpdb->prefix . 'niva_' . substr( (string) $table, strlen( $wpdb->prefix . 'ava_' ) );
			$has = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $new ) ); // phpcs:ignore WordPress.DB
			if ( $has ) {
				continue; // the new table is already in use — leave the old one alone
			}
			$wpdb->query( 'RENAME TABLE `' . esc_sql( (string) $table ) . '` TO `' . esc_sql( $new ) . '`' ); // phpcs:ignore WordPress.DB
			$report['tables']++;
			$report['renamed'][] = (string) $table . ' → ' . $new;
		}

		// 2) user meta: ava_* → niva_* (esc_like keeps `avatar_*` out of it).
		$like = $wpdb->esc_like( 'ava_' ) . '%';
		$rows = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->usermeta} SET meta_key = REPLACE( meta_key, %s, %s ) WHERE meta_key LIKE %s", 'ava_', 'niva_', $like ) ); // phpcs:ignore WordPress.DB
		$report['usermeta'] = (int) $rows;

		// 3) post meta: _dr_ava_* → _dr_niva_*.
		$like = $wpdb->esc_like( '_dr_ava_' ) . '%';
		$rows = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->postmeta} SET meta_key = REPLACE( meta_key, %s, %s ) WHERE meta_key LIKE %s", '_dr_ava_', '_dr_niva_', $like ) ); // phpcs:ignore WordPress.DB
		$report['postmeta'] = (int) $rows;

		/*
		 * 3b) page content: the imported pages carry shortcodes and Elementor data
		 * named `dr_ava_*`. Without this they would all render blank after the
		 * rebrand.
		 */
		$rows = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->posts} SET post_content = REPLACE( post_content, %s, %s ) WHERE post_content LIKE %s", 'dr_ava_', 'dr_niva_', '%' . $wpdb->esc_like( 'dr_ava_' ) . '%' ) ); // phpcs:ignore WordPress.DB
		$report['content'] = (int) $rows;

		$rows = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->postmeta} SET meta_value = REPLACE( meta_value, %s, %s ) WHERE meta_value LIKE %s", 'dr_ava_', 'dr_niva_', '%' . $wpdb->esc_like( 'dr_ava_' ) . '%' ) ); // phpcs:ignore WordPress.DB
		$report['meta_values'] = (int) $rows;

		// 4) options: dr_ava_* → dr_niva_*.
		$like = $wpdb->esc_like( 'dr_ava_' ) . '%';
		$rows = $wpdb->query( $wpdb->prepare( "UPDATE {$wpdb->options} SET option_name = REPLACE( option_name, %s, %s ) WHERE option_name LIKE %s", 'dr_ava_', 'dr_niva_', $like ) ); // phpcs:ignore WordPress.DB
		$report['options'] = (int) $rows;

		return $report;
	}

	/**
	 * A short line for the admin, shown once.
	 */
	public static function notice() : string {
		$report = get_option( self::REPORT );
		if ( ! is_array( $report ) ) {
			return '';
		}
		return sprintf(
			'نیوا: انتقال داده‌های نسخهٔ قبلی انجام شد — جدول‌ها: %d، داده‌های کاربر: %d، برگه‌ها: %d، تنظیمات: %d.',
			(int) $report['tables'],
			(int) $report['usermeta'],
			(int) $report['postmeta'],
			(int) $report['options']
		);
	}
}
