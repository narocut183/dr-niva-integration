<?php
/**
 * Companion access codes (2.0.0) — «کد همراهی».
 *
 * A user grants a partner, mother or doctor read-only access to a chosen slice
 * of their data. The companion never creates an account and never sees a
 * profile form: they open a signed link, confirm their own phone once, and only
 * the scopes the owner ticked are ever rendered.
 *
 * Security model
 *   - The link carries an HMAC over (code id, owner, expiry) keyed with the
 *     site's auth salt, so a code cannot be guessed or forged.
 *   - The companion's own phone must match the one the owner entered, and is
 *     confirmed with a one-time code before a session is issued.
 *   - The session is a signed cookie that expires with the code.
 *   - Revoking a code kills the link and the session immediately.
 *   - Every visit is written to niva_companion_views.
 *
 * This is intentionally separate from the partner/affiliate codes in
 * Niva_Partners: different table, different purpose, no shared helper.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Companion {

	public const COOKIE = 'niva_companion';
	public const REST   = 'niva/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'assets' ) );
		add_action( 'admin_post_dr_niva_companion_admin', array( $this, 'handle_admin_action' ) );
	}

	/** Admin-side revoke, from the companion list in the panel. */
	public function handle_admin_action() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی مجاز نیست.', 'dr-niva' ) );
		}
		check_admin_referer( 'dr_niva_companion_admin' );

		$do = isset( $_GET['do'] ) ? sanitize_key( wp_unslash( $_GET['do'] ) ) : '';
		$id = isset( $_GET['id'] ) ? absint( wp_unslash( $_GET['id'] ) ) : 0;

		if ( $id > 0 && 'revoke' === $do ) {
			$this->revoke( 0, $id, true );
			do_action( 'dr_niva_companion_admin_revoked', $id, (int) get_current_user_id() );
		}

		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-companion' ) );
		exit;
	}

	/** Every scope a code can carry, with the label shown to both sides. */
	public static function scopes() : array {
		return array(
			'cycle'     => 'چرخه و پریود',
			'pregnancy' => 'بارداری',
			'reminders' => 'یادآورها',
			'mood'      => 'خلاصهٔ حال روان',
			'labs'      => 'نتیجهٔ آزمایش‌ها',
		);
	}

	private function on() : bool {
		return dr_niva()->settings->is_on( 'companion_enabled' );
	}

	private function max_active() : int {
		return max( 1, (int) dr_niva()->settings->get( 'companion_max_active', 3 ) );
	}

	private function default_days() : int {
		return max( 1, (int) dr_niva()->settings->get( 'companion_default_days', 30 ) );
	}

	private function otp_required() : bool {
		return dr_niva()->settings->is_on( 'companion_otp_required' );
	}

	/* ------------------------------------------------------------------ codes */

	/** Unambiguous short code: AV-XXXX-XXXX (no 0/O/1/I look-alikes). */
	private function generate_code() : string {
		$alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
		$make     = static function () use ( $alphabet ) {
			$out = '';
			for ( $i = 0; $i < 4; $i++ ) {
				$out .= $alphabet[ wp_rand( 0, strlen( $alphabet ) - 1 ) ];
			}
			return $out;
		};
		return 'AV-' . $make() . '-' . $make();
	}

	private function unique_code() : string {
		global $wpdb;
		$table = Niva_DB::table( 'companion_codes' );
		for ( $try = 0; $try < 8; $try++ ) {
			$code = $this->generate_code();
			$exists = (int) $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE code = %s", $code ) ); // phpcs:ignore WordPress.DB
			if ( ! $exists ) {
				return $code;
			}
		}
		return 'AV-' . strtoupper( wp_generate_password( 4, false, false ) ) . '-' . strtoupper( wp_generate_password( 4, false, false ) );
	}

	/**
	 * Creates a companion code for an owner.
	 *
	 * @return array|WP_Error the new row (with link) or a reason it was refused.
	 */
	public function create( int $owner_id, array $data ) {
		if ( ! $this->on() ) {
			return new WP_Error( 'niva_companion_off', 'ساخت کد همراهی خاموش است.', array( 'status' => 403 ) );
		}
		if ( ! $this->allowed_by_owner( $owner_id ) ) {
			return new WP_Error( 'niva_companion_disabled', 'اشتراک‌گذاری با همراه در پروفایل تو غیرفعال است.', array( 'status' => 403 ) );
		}

		$name  = sanitize_text_field( (string) ( $data['name'] ?? '' ) );
		$phone = preg_replace( '/[^0-9+]/', '', (string) ( $data['phone'] ?? '' ) );
		if ( '' === $name ) {
			return new WP_Error( 'niva_companion_name', 'نام همراه را بنویس.', array( 'status' => 400 ) );
		}
		if ( strlen( $phone ) < 10 ) {
			return new WP_Error( 'niva_companion_phone', 'شمارهٔ موبایل همراه را کامل وارد کن.', array( 'status' => 400 ) );
		}

		$active = $this->active_count( $owner_id );
		if ( $active >= $this->max_active() ) {
			return new WP_Error( 'niva_companion_limit', 'حداکثر ' . $this->max_active() . ' همراه فعال می‌توانی داشته باشی. یکی را ابطال کن.', array( 'status' => 429 ) );
		}

		$days   = (int) ( $data['days'] ?? $this->default_days() );
		$scopes = array_values( array_intersect( array_map( 'sanitize_key', (array) ( $data['scopes'] ?? array() ) ), array_keys( self::scopes() ) ) );
		if ( ! $scopes ) {
			$default = (string) dr_niva()->settings->get( 'companion_default_scopes', 'cycle' );
			$scopes  = array_values( array_intersect( array_map( 'trim', explode( ',', $default ) ), array_keys( self::scopes() ) ) );
		}
		if ( ! $scopes ) {
			$scopes = array( 'cycle' );
		}

		global $wpdb;
		$now = current_time( 'mysql', true );
		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'companion_codes' ),
			array(
				'owner_id'         => $owner_id,
				'code'             => $this->unique_code(),
				'companion_name'   => $name,
				'companion_phone'  => $phone,
				'phone_verified'   => 0,
				'scopes'           => implode( ',', $scopes ),
				'status'           => 'active',
				'token_secret'     => wp_generate_password( 32, false, false ),
				'views'            => 0,
				'created_at'       => $now,
				'expires_at'       => $days > 0 ? gmdate( 'Y-m-d H:i:s', time() + $days * DAY_IN_SECONDS ) : null,
			)
		);
		$id = (int) $wpdb->insert_id;

		do_action( 'dr_niva_companion_created', $id, $owner_id );
		return $this->get( $id );
	}

	public function get( int $id ) : array {
		global $wpdb;
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'companion_codes' ) . ' WHERE id = %d', $id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $row ) {
			return array();
		}
		$row['id']          = (int) $row['id'];
		$row['owner_id']    = (int) $row['owner_id'];
		$row['views']       = (int) $row['views'];
		$row['scope_list']  = array_values( array_filter( array_map( 'trim', explode( ',', (string) $row['scopes'] ) ) ) );
		$row['expired']     = ! empty( $row['expires_at'] ) && strtotime( (string) $row['expires_at'] ) < time();
		$row['usable']      = 'active' === $row['status'] && ! $row['expired'];
		$row['link']        = $this->link( $row );
		return $row;
	}

	/** All codes of one owner, newest first. */
	public function list_for_owner( int $owner_id ) : array {
		global $wpdb;
		$ids = $wpdb->get_col( $wpdb->prepare( 'SELECT id FROM ' . Niva_DB::table( 'companion_codes' ) . ' WHERE owner_id = %d ORDER BY id DESC', $owner_id ) ); // phpcs:ignore WordPress.DB
		$out = array();
		foreach ( (array) $ids as $id ) {
			$row = $this->get( (int) $id );
			if ( $row ) {
				$row['companion_phone_masked'] = $this->mask( (string) $row['companion_phone'] );
				$out[]                         = $row;
			}
		}
		return $out;
	}

	/**
	 * One code row as markup — the list and the "created in place" response use
	 * the same renderer, so a new code can appear without reloading the screen.
	 */
	public function item_markup( array $row ) : string {
		$scopes  = self::scopes();
		$usable  = ! empty( $row['usable'] );
		$list    = isset( $row['scope_list'] ) && is_array( $row['scope_list'] ) ? $row['scope_list'] : array();
		$labels  = array();
		foreach ( $list as $scope_key ) {
			if ( isset( $scopes[ $scope_key ] ) ) {
				$labels[] = $scopes[ $scope_key ];
			}
		}
		$code  = (string) ( $row['code'] ?? '' );
		$phone = (string) ( $row['companion_phone_masked'] ?? $this->mask( (string) ( $row['companion_phone'] ?? '' ) ) );
		$link  = (string) ( $row['link'] ?? $this->link( $row ) );

		ob_start();
		?>
		<li class="companion-item<?php echo $usable ? '' : ' is-inactive'; ?>" data-niva-companion-row="<?php echo esc_attr( (string) ( $row['id'] ?? 0 ) ); ?>">
			<div class="companion-item__head">
				<strong><?php echo esc_html( (string) ( $row['companion_name'] ?? '' ) ); ?></strong>
				<code dir="ltr" class="companion-code"><?php echo esc_html( $code ); ?></code>
				<?php if ( ! $usable ) : ?>
					<span class="companion-badge"><?php echo ! empty( $row['expired'] ) ? 'منقضی' : 'ابطال‌شده'; ?></span>
				<?php else : ?>
					<span class="companion-badge companion-badge--ok">فعال</span>
				<?php endif; ?>
			</div>
			<div class="companion-item__meta">
				<span dir="ltr"><?php echo esc_html( $phone ); ?></span>
				<span>·</span>
				<span><?php echo esc_html( implode( '، ', $labels ) ); ?></span>
			</div>
			<div class="companion-item__meta">
				<span><?php echo esc_html( Niva_Chrome::digits( (string) ( $row['views'] ?? 0 ) ) ); ?> بازدید</span>
				<span>·</span>
				<span>آخرین بازدید: <?php echo esc_html( ! empty( $row['last_view'] ) ? Niva_Chrome::format_datetime_gmt( (string) $row['last_view'] ) : 'ندارد' ); ?></span>
				<span>·</span>
				<span>انقضا: <?php echo esc_html( ! empty( $row['expires_at'] ) ? Niva_Chrome::format_datetime_gmt( (string) $row['expires_at'] ) : 'بدون انقضا' ); ?></span>
			</div>
			<div class="companion-item__actions">
				<?php if ( $usable ) : ?>
					<button type="button" class="btn btn--ghost btn--sm" data-niva-companion-copy="<?php echo esc_attr( $link ); ?>">کپی لینک</button>
					<a class="btn btn--ghost btn--sm" target="_blank" rel="noopener" href="<?php echo esc_url( 'https://wa.me/?text=' . rawurlencode( 'کد همراهی دکتر نیوا: ' . $link ) ); ?>">اشتراک در واتس‌اپ</a>
					<a class="btn btn--ghost btn--sm" href="<?php echo esc_url( 'sms:?&body=' . rawurlencode( $link ) ); ?>">پیامک</a>
				<?php endif; ?>
				<button type="button" class="btn btn--ghost btn--sm" data-niva-companion-regen="<?php echo esc_attr( (string) ( $row['id'] ?? 0 ) ); ?>">کد تازه</button>
				<button type="button" class="btn btn--danger btn--sm" data-niva-companion-revoke="<?php echo esc_attr( (string) ( $row['id'] ?? 0 ) ); ?>">ابطال</button>
			</div>
		</li>
		<?php
		return (string) ob_get_clean();
	}

	/** Re-reads one row in the shape the list uses (masked phone, link, …). */
	private function row_for_response( int $code_id ) : array {
		$row = $this->get( $code_id );
		if ( ! $row ) {
			return array();
		}
		$row['companion_phone_masked'] = $this->mask( (string) $row['companion_phone'] );
		$row['link']                   = $this->link( $row );
		return $row;
	}

	private function active_count( int $owner_id ) : int {
		global $wpdb;
		$table = Niva_DB::table( 'companion_codes' );
		$now   = current_time( 'mysql', true );
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE owner_id = %d AND status = 'active' AND ( expires_at IS NULL OR expires_at > %s )", $owner_id, $now )
		);
	}

	/** Revocation is immediate: link and session both stop working. */
	public function revoke( int $owner_id, int $code_id, bool $as_admin = false ) : bool {
		$row = $this->get( $code_id );
		if ( ! $row ) {
			return false;
		}
		if ( ! $as_admin && $row['owner_id'] !== $owner_id ) {
			return false;
		}
		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'companion_codes' ),
			array( 'status' => 'revoked', 'revoked_at' => current_time( 'mysql', true ) ),
			array( 'id' => $code_id )
		);
		do_action( 'dr_niva_companion_revoked', $code_id, $row['owner_id'] );
		return true;
	}

	/** Issues a fresh code/secret for the same companion (invalidates the old link). */
	public function regenerate( int $owner_id, int $code_id ) {
		$row = $this->get( $code_id );
		if ( ! $row || $row['owner_id'] !== $owner_id ) {
			return new WP_Error( 'niva_companion_missing', 'این کد پیدا نشد.', array( 'status' => 404 ) );
		}
		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'companion_codes' ),
			array(
				'code'         => $this->unique_code(),
				'token_secret' => wp_generate_password( 32, false, false ),
				'phone_verified' => 0,
				'status'       => 'active',
				'revoked_at'   => null,
			),
			array( 'id' => $code_id )
		);
		return $this->get( $code_id );
	}

	public function update_scopes( int $owner_id, int $code_id, array $scopes ) : bool {
		$row = $this->get( $code_id );
		if ( ! $row || $row['owner_id'] !== $owner_id ) {
			return false;
		}
		$clean = array_values( array_intersect( array_map( 'sanitize_key', $scopes ), array_keys( self::scopes() ) ) );
		global $wpdb;
		$wpdb->update( Niva_DB::table( 'companion_codes' ), array( 'scopes' => implode( ',', $clean ) ), array( 'id' => $code_id ) ); // phpcs:ignore WordPress.DB
		return true;
	}

	/* ----------------------------------------------------------------- tokens */

	/** Signed link for a code: page URL + ?c=CODE&t=HMAC. */
	public function link( array $row ) : string {
		$base = Niva_Modules::url( 'companion_view', array(), home_url( '/?dr_niva_companion=1' ) );
		return add_query_arg(
			array(
				'c' => (string) $row['code'],
				't' => $this->token( $row ),
			),
			$base
		);
	}

	/** HMAC over the code identity and its expiry. */
	public function token( array $row ) : string {
		$payload = implode(
			'|',
			array(
				'avacompanion',
				(int) $row['id'],
				(string) $row['code'],
				(string) $row['token_secret'],
				(string) ( $row['expires_at'] ?? 'never' ),
			)
		);
		return hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
	}

	/** Finds a usable code row from a code + token pair, or an empty array. */
	public function verify_link( string $code, string $token ) : array {
		global $wpdb;
		$code = strtoupper( preg_replace( '/[^A-Za-z0-9-]/', '', $code ) );
		if ( '' === $code || '' === $token ) {
			return array();
		}
		$row = $wpdb->get_row( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'companion_codes' ) . ' WHERE code = %s', $code ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $row ) {
			return array();
		}
		$full = $this->get( (int) $row['id'] );
		if ( ! $full['usable'] ) {
			return array();
		}
		if ( ! hash_equals( $this->token( $full ), (string) $token ) ) {
			return array();
		}
		return $full;
	}

	/** Signed session cookie value for a verified companion. */
	private function session_value( array $row ) : string {
		$exp     = min(
			time() + 7 * DAY_IN_SECONDS,
			! empty( $row['expires_at'] ) ? strtotime( (string) $row['expires_at'] ) : time() + 7 * DAY_IN_SECONDS
		);
		$payload = (int) $row['id'] . '|' . $exp;
		return $payload . '|' . hash_hmac( 'sha256', $payload, wp_salt( 'auth' ) );
	}

	private function read_session() : array {
		if ( empty( $_COOKIE[ self::COOKIE ] ) ) {
			return array();
		}
		$raw   = sanitize_text_field( wp_unslash( $_COOKIE[ self::COOKIE ] ) );
		$parts = explode( '|', $raw );
		if ( 3 !== count( $parts ) ) {
			return array();
		}
		list( $id, $exp, $mac ) = $parts;
		if ( (int) $exp < time() ) {
			return array();
		}
		if ( ! hash_equals( hash_hmac( 'sha256', $id . '|' . $exp, wp_salt( 'auth' ) ), $mac ) ) {
			return array();
		}
		$row = $this->get( (int) $id );
		return $row && $row['usable'] ? $row : array();
	}

	private function set_session( array $row ) : void {
		$value = $this->session_value( $row );
		setcookie(
			self::COOKIE,
			$value,
			array(
				'expires'  => time() + 7 * DAY_IN_SECONDS,
				'path'     => COOKIEPATH ? COOKIEPATH : '/',
				'domain'   => COOKIE_DOMAIN,
				'secure'   => is_ssl(),
				'httponly' => true,
				'samesite' => 'Lax',
			)
		);
		$_COOKIE[ self::COOKIE ] = $value;
	}

	/** The code row this visitor is allowed to see, or an empty array. */
	public function current_access() : array {
		$session = $this->read_session();
		if ( $session ) {
			return $session;
		}
		// A valid signed link also opens the page when OTP is not required.
		if ( ! $this->otp_required() && isset( $_GET['c'], $_GET['t'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			$row = $this->verify_link(
				sanitize_text_field( wp_unslash( $_GET['c'] ) ), // phpcs:ignore WordPress.Security.NonceVerification.Recommended
				sanitize_text_field( wp_unslash( $_GET['t'] ) )  // phpcs:ignore WordPress.Security.NonceVerification.Recommended
			);
			if ( $row ) {
				$this->set_session( $row );
				return $row;
			}
		}
		return array();
	}

	/* -------------------------------------------------------------------- otp */

	/**
	 * Sends the one-time code to the companion's phone.
	 *
	 * The phone must match the number the owner entered, so knowing a code alone
	 * is never enough.
	 */
	public function send_otp( string $code, string $phone ) {
		$phone = preg_replace( '/[^0-9+]/', '', $phone );
		$row   = $this->find_by_code( $code );
		if ( ! $row ) {
			return new WP_Error( 'niva_companion_missing', 'این کد پیدا نشد.', array( 'status' => 404 ) );
		}
		if ( ! $row['usable'] ) {
			return new WP_Error( 'niva_companion_inactive', 'این کد منقضی یا ابطال شده است.', array( 'status' => 403 ) );
		}
		if ( ! $this->phone_matches( (string) $row['companion_phone'], $phone ) ) {
			return new WP_Error( 'niva_companion_phone', 'این شماره با شماره‌ای که صاحب کد ثبت کرده یکی نیست.', array( 'status' => 403 ) );
		}

		$otp = (string) wp_rand( 100000, 999999 );
		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'companion_codes' ),
			array(
				'otp_hash'    => wp_hash_password( $otp ),
				'otp_expires' => gmdate( 'Y-m-d H:i:s', time() + 300 ),
			),
			array( 'id' => (int) $row['id'] )
		);
		update_user_meta( (int) $row['owner_id'], 'niva_companion_otp_tries_' . (int) $row['id'], 0 );

		$sent = apply_filters( 'dr_niva_send_otp', new WP_Error( 'niva_otp_unavailable', 'سرویس پیامک روی این سایت تنظیم نشده است.' ), $phone, $otp, 0 );
		if ( is_wp_error( $sent ) ) {
			return $sent;
		}
		return true;
	}

	/** Verifies the one-time code and opens a session. */
	public function verify_otp( string $code, string $otp ) {
		$row = $this->find_by_code( $code );
		if ( ! $row || ! $row['usable'] ) {
			return new WP_Error( 'niva_companion_missing', 'این کد معتبر نیست.', array( 'status' => 404 ) );
		}

		$tries_key = 'niva_companion_otp_tries_' . (int) $row['id'];
		$tries     = (int) get_user_meta( (int) $row['owner_id'], $tries_key, true );
		if ( $tries >= 6 ) {
			return new WP_Error( 'niva_companion_locked', 'تلاش‌های زیاد؛ چند دقیقه بعد دوباره امتحان کن.', array( 'status' => 429 ) );
		}
		update_user_meta( (int) $row['owner_id'], $tries_key, $tries + 1 );

		$hash    = (string) ( $row['otp_hash'] ?? '' );
		$expires = (string) ( $row['otp_expires'] ?? '' );
		if ( '' === $hash || ! $expires || strtotime( $expires ) < time() ) {
			return new WP_Error( 'niva_companion_expired', 'کد یک‌بارمصرف منقضی شده؛ دوباره درخواست کن.', array( 'status' => 400 ) );
		}
		if ( ! wp_check_password( preg_replace( '/\D/', '', $otp ), $hash ) ) {
			return new WP_Error( 'niva_companion_wrong', 'کد یک‌بارمصرف درست نیست.', array( 'status' => 400 ) );
		}

		global $wpdb;
		$wpdb->update( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'companion_codes' ),
			array( 'phone_verified' => 1, 'otp_hash' => null, 'otp_expires' => null ),
			array( 'id' => (int) $row['id'] )
		);
		update_user_meta( (int) $row['owner_id'], $tries_key, 0 );

		$fresh = $this->get( (int) $row['id'] );
		$this->set_session( $fresh );
		return $fresh;
	}

	private function find_by_code( string $code ) : array {
		global $wpdb;
		$code = strtoupper( preg_replace( '/[^A-Za-z0-9-]/', '', $code ) );
		if ( '' === $code ) {
			return array();
		}
		$id = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT id FROM ' . Niva_DB::table( 'companion_codes' ) . ' WHERE code = %s', $code ) ); // phpcs:ignore WordPress.DB
		return $id ? $this->get( $id ) : array();
	}

	/** Compares two phones on their last 10 digits, so +98/0 forms both work. */
	private function phone_matches( string $stored, string $given ) : bool {
		$tail = static function ( string $phone ) {
			$digits = preg_replace( '/\D/', '', $phone );
			return substr( $digits, -10 );
		};
		return '' !== $tail( $stored ) && $tail( $stored ) === $tail( $given );
	}

	public function mask( string $phone ) : string {
		$digits = preg_replace( '/\D/', '', $phone );
		if ( strlen( $digits ) < 6 ) {
			return '—';
		}
		return substr( $digits, 0, 4 ) . '****' . substr( $digits, -2 );
	}

	/* ------------------------------------------------------------------ views */

	/** Records one companion visit (privacy: the IP is hashed, never stored raw). */
	public function log_view( array $row, string $scope = '' ) : void {
		global $wpdb;
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'companion_views' ),
			array(
				'code_id'    => (int) $row['id'],
				'owner_id'   => (int) $row['owner_id'],
				'scope'      => sanitize_text_field( $scope ),
				'ip_hash'    => '' !== $ip ? substr( hash_hmac( 'sha256', $ip, wp_salt( 'nonce' ) ), 0, 32 ) : '',
				'user_agent' => isset( $_SERVER['HTTP_USER_AGENT'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 180 ) : '',
				'created_at' => current_time( 'mysql', true ),
			)
		);
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'UPDATE ' . Niva_DB::table( 'companion_codes' ) . ' SET views = views + 1, last_view = %s WHERE id = %d', current_time( 'mysql', true ), (int) $row['id'] )
		);
	}

	/* -------------------------------------------------------------- the data */

	/**
	 * The read-only payload a companion may see.
	 *
	 * Built scope by scope: anything the owner did not tick is simply absent,
	 * and the owner's e-mail, phone and address are never included.
	 */
	public function summary( array $row ) : array {
		$owner   = (int) $row['owner_id'];
		$profile = dr_niva()->profile->get( $owner );
		$scopes  = (array) $row['scope_list'];
		$name    = trim( (string) ( $profile['full_name'] ?? '' ) );
		if ( '' === $name ) {
			$user = get_userdata( $owner );
			$name = $user ? (string) $user->display_name : 'کاربر دکتر نیوا';
		}

		$out = array(
			'owner_name' => $name,
			'scopes'     => $scopes,
			'sections'   => array(),
		);

		if ( in_array( 'cycle', $scopes, true ) ) {
			$cycle = Niva_Chrome::cycle_state( $owner );
			$out['sections']['cycle'] = array(
				'title'      => 'چرخه و پریود',
				'configured' => ! empty( $cycle['configured'] ),
				'has_data'   => ! empty( $cycle['has_data'] ),
				'day'        => (int) ( $cycle['cycle_day'] ?? 0 ),
				'length'     => (string) ( $cycle['len_label'] ?? '' ),
				'next_date'  => (string) ( $cycle['next_date'] ?? '' ),
				'next_days'  => (int) ( $cycle['next_in_days'] ?? 0 ),
				'fertile'    => (string) ( $cycle['ranges']['fertile'] ?? '' ),
				'period'     => (string) ( $cycle['ranges']['period'] ?? '' ),
			);
		}

		if ( in_array( 'pregnancy', $scopes, true ) ) {
			$week = ! empty( $profile['pregnant'] ) ? dr_niva()->profile->pregnancy_week( $owner ) : 0;
			$out['sections']['pregnancy'] = array(
				'title'     => 'بارداری',
				'pregnant'  => ! empty( $profile['pregnant'] ),
				'week'      => (int) $week,
				'due_date'  => (string) ( $profile['due_date'] ?? '' ),
			);
		}

		if ( in_array( 'reminders', $scopes, true ) ) {
			global $wpdb;
			$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare( 'SELECT title, time_at, repeat_rule FROM ' . Niva_DB::table( 'reminders' ) . ' WHERE user_id = %d AND done = 0 ORDER BY time_at ASC LIMIT 20', $owner ),
				ARRAY_A
			);
			$out['sections']['reminders'] = array(
				'title' => 'یادآورها',
				'items' => array_map(
					static function ( $item ) {
						return array(
							'title' => (string) $item['title'],
							'time'  => (string) $item['time_at'],
							'repeat' => (string) $item['repeat_rule'],
						);
					},
					(array) $rows
				),
			);
		}

		if ( in_array( 'mood', $scopes, true ) ) {
			$moods = (array) ( $profile['mood_scores'] ?? array() );
			$last  = $moods ? (int) end( $moods ) : 0;
			$out['sections']['mood'] = array(
				'title' => 'خلاصهٔ حال روان',
				'label' => $last >= 22 ? 'خوب' : ( $last >= 12 ? 'متوسط' : ( $last > 0 ? 'نیازمند توجه' : 'ثبت نشده' ) ),
				'count' => count( $moods ),
			);
		}

		if ( in_array( 'labs', $scopes, true ) ) {
			global $wpdb;
			$docs = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare( 'SELECT title, kind, created_at FROM ' . Niva_DB::table( 'documents' ) . ' WHERE user_id = %d ORDER BY id DESC LIMIT 10', $owner ),
				ARRAY_A
			);
			$out['sections']['labs'] = array(
				'title' => 'نتیجهٔ آزمایش‌ها',
				'items' => array_map(
					static function ( $doc ) {
						return array(
							'title' => (string) $doc['title'],
							'kind'  => (string) $doc['kind'],
							'date'  => (string) $doc['created_at'],
						);
					},
					(array) $docs
				),
			);
		}

		return $out;
	}

	/** The owner may switch companion sharing off entirely. */
	public function allowed_by_owner( int $owner_id ) : bool {
		$profile = dr_niva()->profile->get( $owner_id );
		return ! empty( $profile['companion_allowed'] ) || ! array_key_exists( 'companion_allowed', $profile );
	}

	/**
	 * Tells the companions of one owner something (e.g. "period is close").
	 *
	 * Only runs when the owner allowed it and the relevant scope is granted.
	 */
	public function notify_companions( int $owner_id, string $message, string $scope = 'cycle' ) : int {
		if ( ! $this->on() || ! $this->allowed_by_owner( $owner_id ) ) {
			return 0;
		}
		global $wpdb;
		$ids = $wpdb->get_col( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT id FROM " . Niva_DB::table( 'companion_codes' ) . " WHERE owner_id = %d AND status = 'active'", $owner_id )
		);
		$sent = 0;
		foreach ( (array) $ids as $id ) {
			$row = $this->get( (int) $id );
			if ( ! $row || ! in_array( $scope, $row['scope_list'], true ) ) {
				continue;
			}
			do_action( 'dr_niva_companion_notify', $row, $message, $scope );
			$sent++;
		}
		return $sent;
	}

	/* -------------------------------------------------------------------- REST */

	public function routes() : void {
		$member = array( 'permission_callback' => array( $this, 'is_logged_in' ) );
		$open   = array( 'permission_callback' => '__return_true' );

		register_rest_route( Niva_Rest::NS, '/companion/create', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_create' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/companion/list', array( 'methods' => 'GET', 'callback' => array( $this, 'rest_list' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/companion/revoke', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_revoke' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/companion/regenerate', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_regenerate' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/companion/scopes', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_scopes' ) ) + $member );
		register_rest_route( Niva_Rest::NS, '/companion/otp', array( 'methods' => 'POST', 'callback' => array( $this, 'rest_otp' ) ) + $open );
	}

	public function is_logged_in() : bool {
		return is_user_logged_in();
	}

	public function rest_create( WP_REST_Request $request ) {
		$result = $this->create(
			(int) get_current_user_id(),
			array(
				'name'   => $request->get_param( 'name' ),
				'phone'  => $request->get_param( 'phone' ),
				'days'   => (int) $request->get_param( 'days' ),
				'scopes' => (array) $request->get_param( 'scopes' ),
			)
		);
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		/* 2.0.1 — the row travels back so the list updates without a reload. */
		$row = array();
		foreach ( $this->list_for_owner( (int) get_current_user_id() ) as $candidate ) {
			if ( (string) $candidate['code'] === (string) $result ) {
				$row = $candidate;
				break;
			}
		}
		return new WP_REST_Response(
			array(
				'ok'   => true,
				'code' => (string) $result,
				'link' => isset( $row['link'] ) ? (string) $row['link'] : '',
				'row'  => $row ? $this->item_markup( $row ) : '',
			),
			200
		);
	}

	public function rest_list() {
		$rows = $this->list_for_owner( (int) get_current_user_id() );
		foreach ( $rows as &$row ) {
			unset( $row['token_secret'], $row['otp_hash'] );
		}
		return new WP_REST_Response( array( 'items' => $rows ), 200 );
	}

	public function rest_revoke( WP_REST_Request $request ) {
		$ok = $this->revoke( (int) get_current_user_id(), (int) $request->get_param( 'id' ) );
		if ( ! $ok ) {
			return new WP_Error( 'niva_companion_missing', 'این کد پیدا نشد.', array( 'status' => 404 ) );
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	public function rest_regenerate( WP_REST_Request $request ) {
		$result = $this->regenerate( (int) get_current_user_id(), (int) $request->get_param( 'id' ) );
		if ( is_wp_error( $result ) ) {
			return $result;
		}
		unset( $result['token_secret'], $result['otp_hash'] );
		$row = $this->row_for_response( (int) ( $result['id'] ?? 0 ) );
		return new WP_REST_Response(
			array(
				'ok'   => true,
				'code' => (string) ( $row['code'] ?? ( $result['code'] ?? '' ) ),
				'link' => (string) ( $row['link'] ?? '' ),
				'row'  => $row ? $this->item_markup( $row ) : '',
			),
			200
		);
	}

	public function rest_scopes( WP_REST_Request $request ) {
		$ok = $this->update_scopes( (int) get_current_user_id(), (int) $request->get_param( 'id' ), (array) $request->get_param( 'scopes' ) );
		if ( ! $ok ) {
			return new WP_Error( 'niva_companion_missing', 'این کد پیدا نشد.', array( 'status' => 404 ) );
		}
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	/** Public: the companion proves their phone with a one-time code. */
	public function rest_otp( WP_REST_Request $request ) {
		$mode = sanitize_key( (string) $request->get_param( 'mode' ) );
		$code = (string) $request->get_param( 'code' );

		if ( 'send' === $mode ) {
			$result = $this->send_otp( $code, (string) $request->get_param( 'phone' ) );
			return is_wp_error( $result ) ? $result : new WP_REST_Response( array( 'ok' => true ), 200 );
		}
		if ( 'verify' === $mode ) {
			$result = $this->verify_otp( $code, (string) $request->get_param( 'otp' ) );
			return is_wp_error( $result ) ? $result : new WP_REST_Response( array( 'ok' => true ), 200 );
		}
		return new WP_Error( 'niva_companion_mode', 'درخواست نامعتبر است.', array( 'status' => 400 ) );
	}

	/* ------------------------------------------------------------------ assets */

	public function assets() : void {
		if ( ! $this->on() ) {
			return;
		}
		wp_register_style( 'dr-niva-companion', DR_NIVA_URL . 'public/assets/css/companion.css', array( 'dr-niva-base' ), DR_NIVA_VERSION );
		wp_register_script( 'dr-niva-companion', DR_NIVA_URL . 'public/assets/js/companion.js', array( 'dr-niva-router' ), DR_NIVA_VERSION, true );
	}

	public static function enqueue() : void {
		wp_enqueue_style( 'dr-niva-companion' );
		wp_enqueue_script( 'dr-niva-companion' );
	}
}
