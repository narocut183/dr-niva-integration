<?php
/**
 * REST API — the only door between the browser and the credits/AI layer.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Rest {

	public const NS = 'niva/v1';

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
		add_action( 'shutdown', array( $this, 'shutdown_handler' ) );
	}

	public function shutdown_handler() : void {
		if ( ! did_action( 'rest_api_init' ) && ! isset( $_SERVER['REQUEST_URI'] ) ) {
			return;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) $_SERVER['REQUEST_URI'] : '';
		if ( '' === $uri || false === strpos( $uri, '/wp-json/' ) ) {
			return;
		}

		$error = error_get_last();
		if ( ! is_array( $error ) ) {
			return;
		}
		$types = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR );
		if ( ! in_array( (int) $error['type'], $types, true ) ) {
			return;
		}

		if ( headers_sent() ) {
			return;
		}

		$trace = wp_json_encode(
			array(
				'ok'      => false,
				'message' => 'خطای داخلی رخ داد؛ دوباره تلاش کنید.',
				'error_id' => 'niva_' . wp_rand( 100000, 999999 ),
				'error'   => array(
					'file' => (string) ( $error['file'] ?? '' ),
					'line' => (int) ( $error['line'] ?? 0 ),
					'type' => (string) ( $error['type'] ?? '' ),
				),
			)
		);
		if ( false !== $trace ) {
			nocache_headers();
			header( 'Content-Type: application/json; charset=utf-8', true, 500 );
			echo $trace;
		}
	}

	public function routes() : void {

		register_rest_route(
			self::NS,
			'/plan-request',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'plan_request' ),
				'permission_callback' => array( $this, 'logged_in' ),
			)
		);

		register_rest_route(
			self::NS,
			'/labs',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'labs_summary' ),
					'permission_callback' => array( $this, 'logged_in' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'labs' ),
					'permission_callback' => array( $this, 'logged_in' ),
				),
			)
		);
		register_rest_route(
			self::NS,
			'/labs/analyze',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'analyze_lab_report' ),
				'permission_callback' => array( $this, 'logged_in' ),
			)
		);
		register_rest_route(
			self::NS,
			'/me',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'me' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/packages',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'packages' ),
				'permission_callback' => '__return_true',
			)
		);

		register_rest_route(
			self::NS,
			'/wallet',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'wallet' ),
				'permission_callback' => array( $this, 'logged_in' ),
			)
		);

		register_rest_route(
			self::NS,
			'/profile-module',
			array(
				'methods'             => WP_REST_Server::READABLE,
				'callback'            => array( $this, 'profile_module' ),
				'permission_callback' => array( $this, 'logged_in' ),
				'args'                => array(
					'module' => array(
						'required'          => true,
						'sanitize_callback' => 'sanitize_key',
					),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/chat',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'chat' ),
				'permission_callback' => array( $this, 'logged_in' ),
			)
		);

		register_rest_route(
			self::NS,
			'/provider',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'set_provider' ),
				'permission_callback' => array( $this, 'logged_in' ),
			)
		);

		register_rest_route(
			self::NS,
			'/chat/history',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'permission_callback' => array( $this, 'logged_in' ),
					'callback'            => array( $this, 'chat_history' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'permission_callback' => array( $this, 'logged_in' ),
					'callback'            => array( $this, 'chat_history' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/family',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => function () {
					$summary = dr_niva()->plans->summary( get_current_user_id() );
					return array( 'family' => $summary['family'], 'plan' => $summary['plan'] );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/family/accept',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => function ( WP_REST_Request $request ) {
					$result = dr_niva()->plans->accept_invite( get_current_user_id(), (string) $request->get_param( 'code' ) );
					if ( is_wp_error( $result ) ) {
						return $result;
					}
					return array( 'ok' => true, 'plan' => dr_niva()->plans->summary( get_current_user_id() ) );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/family/remove',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => function ( WP_REST_Request $request ) {
					dr_niva()->plans->remove_member( get_current_user_id(), absint( $request->get_param( 'member_id' ) ) );
					return array( 'ok' => true );
				},
			)
		);

		register_rest_route(
			self::NS,
			'/growth',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => array( $this, 'growth' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => array( $this, 'growth' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/logs',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => array( $this, 'logs' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => array( $this, 'logs' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/reminders',
			array(
				array(
					'methods'             => WP_REST_Server::READABLE,
					'callback'            => array( $this, 'reminders_list' ),
					'permission_callback' => array( $this, 'logged_in' ),
				),
				array(
					'methods'             => WP_REST_Server::CREATABLE,
					'callback'            => array( $this, 'reminders_save' ),
					'permission_callback' => array( $this, 'logged_in' ),
				),
				array(
					'methods'             => WP_REST_Server::DELETABLE,
					'callback'            => array( $this, 'reminders_delete' ),
					'permission_callback' => array( $this, 'logged_in' ),
				),
			)
		);

		register_rest_route(
			self::NS,
			'/store/verify',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'store_verify' ),
				'permission_callback' => '__return_true',
			)
		);

		// Locked-tool click signal for the admin «ابزارها و دسترسی» report.
		register_rest_route(
			self::NS,
			'/gate',
			array(
				'methods'             => WP_REST_Server::CREATABLE,
				'callback'            => array( $this, 'gate_click' ),
				'permission_callback' => array( $this, 'logged_in' ),
			)
		);
	}

	public function logged_in() : bool {
		return is_user_logged_in();
	}

	/** Enforces the same plan gates for direct REST calls as for rendered modules. */
	private function require_feature_access( string $module ) {
		$access = dr_niva()->plans->feature_access( get_current_user_id(), $module );
		return is_wp_error( $access ) ? $access : true;
	}

	/**
	 * Renders the private profile modules used by the account hub sheets.
	 *
	 * @return WP_REST_Response|\WP_Error
	 */
	public function profile_module( WP_REST_Request $request ) {
		$module = sanitize_key( (string) $request->get_param( 'module' ) );
		if ( ! in_array( $module, array( 'user_settings', 'wallet' ), true ) ) {
			return new WP_Error( 'niva_invalid_profile_module', 'این بخش معتبر نیست.', array( 'status' => 400 ) );
		}

		$html = Niva_Modules::render( $module );
		if ( '' === $html ) {
			return new WP_Error( 'niva_profile_module_unavailable', 'محتوای این بخش در دسترس نیست.', array( 'status' => 500 ) );
		}

		$response = new WP_REST_Response( array( 'html' => $html ), 200 );
		$response->header( 'Cache-Control', 'no-store, private, max-age=0' );
		return $response;
	}

	/** Everything the front-end needs to render itself. */
	public function me() : WP_REST_Response {
		$plugin   = dr_niva();
		$user_id  = get_current_user_id();
		$logo_id  = (int) $plugin->settings->get( 'brand_logo_id' );
		$logo_url = $logo_id ? wp_get_attachment_image_url( $logo_id, 'medium' ) : '';
		$logo_url = $logo_url ? $logo_url : (string) $plugin->settings->get( 'brand_logo_url' );
		$payload  = array(
			'plugin'    => array(
				'version' => DR_NIVA_VERSION,
				'brand'   => $plugin->settings->get( 'brand_name' ),
				'tagline' => $plugin->settings->get( 'brand_tagline' ),
				'logo_url' => esc_url_raw( $logo_url ),
				'timezone' => wp_timezone_string(),
				'timezone_offset' => (int) round( (float) get_option( 'gmt_offset', 0 ) * HOUR_IN_SECONDS / MINUTE_IN_SECONDS ),
				'home'    => home_url(),
				'rest'    => esc_url_raw( rest_url( self::NS ) ),
				'nonce'   => wp_create_nonce( 'wp_rest' ),
				'numeral' => $plugin->settings->get( 'numeral_style' ),
			),
			'user'      => array(
				'id'        => $user_id,
				'logged_in' => is_user_logged_in(),
				'name'      => is_user_logged_in() ? wp_get_current_user()->display_name : '',
			),
			// configurable destinations + the user's own profile
			'links'     => $plugin->links ? $plugin->links->all() : array(),
			'profile'   => is_user_logged_in() && $plugin->profile ? $plugin->profile->get( $user_id ) : null,
			'is_pregnant' => is_user_logged_in() && $plugin->profile ? $plugin->profile->is_pregnant( $user_id ) : false,
			'pregnancy_week' => is_user_logged_in() && $plugin->profile ? $plugin->profile->pregnancy_week( $user_id ) : 0,
			// subscription state: the front end answers "do I have a plan?" from here
			'plan'      => is_user_logged_in() && $plugin->plans ? $plugin->plans->summary( $user_id ) : null,
			'chat_quota' => is_user_logged_in() && $plugin->plans ? $plugin->plans->chat_quota_summary( $user_id ) : null,
			'modules'   => $plugin->layout->config(),
			'safety'    => array(
				'helplines'  => $plugin->safety->helplines(),
				'referral'   => (string) $plugin->settings->get( 'safety_drug_referral' ),
				'disclaimer' => (string) $plugin->settings->get( 'safety_medical_footer' ),
			),
			'strings'   => array(
				'exhausted' => (string) $plugin->settings->get( 'exhausted_message' ),
				'login_url' => esc_url_raw( wp_login_url( home_url( '/' ) ) ),
			),
			'notifications' => array(
				'unread' => is_user_logged_in() ? (int) Niva_Notifications::unread_count() : 0,
			),
		);
		$payload['wallet'] = is_user_logged_in() ? $plugin->wallet->summary( $user_id ) : null;

		$response = new WP_REST_Response( $payload, 200 );
		$response->header( 'Cache-Control', 'no-store, private, max-age=0' );
		return $response;
	}

	public function packages() : WP_REST_Response {
		$settings = dr_niva()->settings;
		return new WP_REST_Response(
			array(
				'packages' => $settings->packages(),
				'custom'   => $settings->is_on( 'allow_custom_package' ),
				'currency' => function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : '',
			),
			200
		);
	}

	public function wallet() : WP_REST_Response {
		$plugin  = dr_niva();
		$user_id = get_current_user_id();
		return new WP_REST_Response(
			array(
				'summary' => $plugin->wallet->summary( $user_id ),
				'ledger'  => $plugin->wallet->ledger( $user_id, 30 ),
				'usage'   => $plugin->wallet->usage_report( $user_id, 30 ),
			),
			200
		);
	}

	public function set_provider( WP_REST_Request $request ) {
		$provider = sanitize_key( (string) $request->get_param( 'provider' ) );
		$allowed  = dr_niva()->ai->available();
		if ( ! isset( $allowed[ $provider ] ) ) {
			return new WP_Error( 'niva_bad_provider', 'این موتور در دسترس نیست.', array( 'status' => 400 ) );
		}
		update_user_meta( get_current_user_id(), 'niva_provider', $provider );
		return new WP_REST_Response( array( 'provider' => $provider ), 200 );
	}

	/** The chat endpoint: rate limit, safety, credits, model, filter. */
	public function chat( WP_REST_Request $request ) {
		$plugin  = dr_niva();
		$user_id = get_current_user_id();
		$access  = $this->require_feature_access( 'advisor_chat' );
		if ( is_wp_error( $access ) ) {
			return $access;
		}
		$message = trim( (string) $request->get_param( 'message' ) );
		$topic   = sanitize_key( (string) $request->get_param( 'topic' ) );
		$chat_id = absint( $request->get_param( 'chat_id' ) );
		$history = $request->get_param( 'history' );
		$history = is_array( $history ) ? array_slice( $history, -absint( $plugin->settings->get( 'ai_memory_messages' ) ) ) : array();

		if ( '' === $message ) {
			return new WP_Error( 'niva_empty_message', 'پیام خالی است.', array( 'status' => 400 ) );
		}
		if ( preg_match( '/(?:چه\s+مدلی\s+هستی|چه\s+نوع\s+هوش\s+مصنوعی\s+هستی|چه\s+مدل\s+هوش\s+مصنوعی\s+هستی|از\s+چه\s+مدلی\s+استفاده\s+می‌کنی|اسم\s+مدلت\s+چیه|(?:تو|شما)\s+(?:چت[\s‌]*جی[\s‌]*پی[\s‌]*تی|chatgpt)\s*(?:هستی|هستید)|\bwhat model are you\b|\bare you chatgpt\b)/iu', $message ) ) {
			return new WP_REST_Response(
				array(
					'text'     => 'من دستیار هوشمند دکتر نیوا هستم و از مدل تنظیم‌شده در این سایت استفاده می‌کنم؛ این مدل ممکن است با تنظیمات مدیر سایت تغییر کند.',
					'flags'    => array(),
					'crisis'   => false,
					'included' => true,
					'provider' => '',
					'charged'  => false,
					'wallet'   => $plugin->wallet->summary( $user_id ),
					'chat_id'  => 0,
				),
				200
			);
		}

		// 1) rate limit
		$limit = (int) $plugin->settings->get( 'ai_rate_per_minute' );
		if ( $limit > 0 ) {
			$key   = 'niva_rl_' . $user_id;
			$count = (int) get_transient( $key );
			if ( $count >= $limit ) {
				return new WP_Error( 'niva_rate_limited', 'کمی آرام‌تر؛ چند لحظه بعد دوباره امتحان کن.', array( 'status' => 429 ) );
			}
			set_transient( $key, $count + 1, MINUTE_IN_SECONDS );
		}

		// 2) risk check on the *user* message before anything is charged
		$inspect = $plugin->safety->inspect_user_message( $message );
		if ( ! empty( $inspect['risk'] ) && 'stop_and_show' === $plugin->settings->get( 'safety_crisis_behavior' ) ) {
			return new WP_REST_Response(
				array(
					'text'    => $plugin->safety->crisis_message(),
					'crisis'  => true,
					'charged' => false,
					'wallet'  => $plugin->wallet->summary( $user_id ),
				),
				200
			);
		}

		// Included plan messages are free; after that, paid credits are the fallback.
		$plan       = $plugin->plans->plan_of( $user_id );
		$plan_limit = $plugin->plans->limit( $user_id, 'chat_per_day' );
		$included   = 0 === $plan_limit || $plugin->plans->usage( $user_id, 'chat_per_day' ) < $plan_limit;
		$plan_reservation = null;

		// 4) build the conversation before reserving enough credits for the call
		if ( $chat_id ) {
			global $wpdb;
			$owned_chat = (int) $wpdb->get_var(
				$wpdb->prepare( 'SELECT id FROM ' . Niva_DB::table( 'chats' ) . ' WHERE id = %d AND user_id = %d', $chat_id, $user_id ) // phpcs:ignore WordPress.DB
			);
			if ( ! $owned_chat ) {
				return new WP_Error( 'niva_chat_not_found', 'این گفت‌وگو پیدا نشد.', array( 'status' => 404 ) );
			}
		}
		$topic_title = sanitize_text_field( (string) $request->get_param( 'topic_title' ) );
		$messages    = array(
			array( 'role' => 'system', 'content' => $plugin->safety->system_prompt( $topic_title, (string) $plugin->settings->get( 'ai_tone' ) ) . self::context_block( $user_id, $topic_title ) ),
		);
		foreach ( $history as $turn ) {
			if ( empty( $turn['role'] ) || ! isset( $turn['content'] ) ) {
				continue;
			}
			$role       = in_array( $turn['role'], array( 'user', 'assistant' ), true ) ? $turn['role'] : 'user';
			$messages[] = array( 'role' => $role, 'content' => (string) $turn['content'] );
		}
		$messages[] = array( 'role' => 'user', 'content' => $message );

		if ( $included ) {
			$plan_reservation = $plugin->plans->reserve_usage( $user_id, 'chat_per_day', 'chat' );
			if ( is_wp_error( $plan_reservation ) ) {
				if ( 'niva_limit' !== $plan_reservation->get_error_code() ) {
					return $plan_reservation;
				}
				$included = false;
			}
		}
		$cost = $included ? 0 : $this->reserved_chat_cost( $messages, $plugin->settings );
		$paid = $included
			? array(
				'charged_from' => 'plan',
				'cost'         => 0,
				'usage_id'     => (int) $plan_reservation['usage_id'],
				'summary'      => $plugin->wallet->summary( $user_id ),
			)
			: $plugin->wallet->spend(
				$user_id,
				$cost,
				'chat',
				'chat:' . wp_generate_uuid4(),
				array( 'force_balance' => true )
			);
		if ( is_wp_error( $paid ) ) {
			return $paid;
		}
		$usage_id = (int) ( $paid['usage_id'] ?? 0 );

		// 5) call the model
		$result = $plugin->ai->chat(
			$messages,
			array(
				'topic'   => $topic,
				'provider' => $this->current_provider( $user_id ),
			)
		);

		if ( is_wp_error( $result ) ) {
			if ( $included && $usage_id ) {
				$plugin->wallet->refund_usage( $usage_id );
			} elseif ( $usage_id ) {
				$plugin->wallet->refund_usage( $usage_id );
			}
			return new WP_Error( 'niva_ai_failed', $result->get_error_message(), array( 'status' => 502 ) );
		}
		$plugin->wallet->record_usage_tokens( $usage_id, $result );
		if ( $included && $usage_id > 0 && ! $plugin->wallet->complete_plan_usage( $usage_id ) ) {
			$plugin->wallet->refund_usage( $usage_id );
			return new WP_Error( 'niva_quota_settlement_failed', 'ثبت مصرف سهمیه انجام نشد؛ دوباره تلاش کن.', array( 'status' => 500 ) );
		}
		if ( ! $included && $usage_id > 0 ) {
			$actual_cost = $this->actual_chat_cost( $result, $plugin->settings, (int) ( $paid['cost'] ?? $cost ) );
			if ( ! $plugin->wallet->reconcile_usage( $usage_id, $actual_cost ) ) {
				return new WP_Error(
					'niva_chat_settlement_failed',
					'اعتبار برای تسویهٔ دقیق مصرف کافی نیست؛ پاسخ ثبت نشد. لطفاً اعتبار را شارژ کن.',
					array( 'status' => 402 )
				);
			}
			$paid['cost'] = $actual_cost;
			$paid['tokens_in'] = max( 0, (int) ( $result['tokens_in'] ?? 0 ) );
			$paid['tokens_out'] = max( 0, (int) ( $result['tokens_out'] ?? 0 ) );
		} else {
			$paid['tokens_in'] = max( 0, (int) ( $result['tokens_in'] ?? 0 ) );
			$paid['tokens_out'] = max( 0, (int) ( $result['tokens_out'] ?? 0 ) );
		}

		// 6) deterministic safety filter on the way out
		$filtered = $plugin->safety->filter_reply(
			(string) $result['text'],
			array(
				'user_id'  => $user_id,
				'drug'     => ! empty( $inspect['drug'] ),
				'medical'  => true,
				'provider' => (string) $result['provider'],
				'question' => $message,
			)
		);

		if ( $plugin->settings->is_on( 'log_conversations' ) ) {
			update_user_meta( $user_id, 'niva_last_chat', current_time( 'mysql' ) );
		}

		if ( $plugin->settings->is_on( 'log_conversations' ) ) {
			$chat_id = self::store_chat( $user_id, $topic, $message, $filtered['text'], (string) $result['provider'], (int) $paid['cost'], $chat_id );
		}

		return new WP_REST_Response(
			array(
				'text'     => $filtered['text'],
				'flags'    => $filtered['flags'],
				'crisis'   => false,
				'included' => $included,
				'provider' => '',
				'charged'  => array( 'included' => $included ),
				'wallet'   => $plugin->wallet->summary( $user_id ),
				'plan_quota' => $plugin->plans->chat_quota_summary( $user_id ),
				'chat_id'  => $chat_id,
			),
			200
		);
	}

	/**
	 * A short factual brief from the user's own file, so the advisor answers like
	 * a doctor who already knows the case. It only repeats stored data: nothing is
	 * inferred and nothing is invented.
	 */
	public static function context_block( int $user_id, string $topic ) : string {
		global $wpdb;
		$lines = array();

		$user = get_userdata( $user_id );
		if ( $user ) {
			$lines[] = 'نام: ' . $user->display_name;
		}
		if ( dr_niva()->plans ) {
			$plan    = dr_niva()->plans->plan_of( $user_id );
			$lines[] = 'پلن اشتراک: ' . $plan['label'];
		}

		$week = (int) get_user_meta( $user_id, 'niva_pregnancy_week', true );
		if ( $week ) {
			$lines[] = 'هفته‌ی بارداری: ' . $week;
		}

		$growth = $wpdb->get_row(
			$wpdb->prepare( 'SELECT name, age_months, weight, height FROM ' . Niva_DB::table( 'growth' ) . ' WHERE user_id = %d ORDER BY measured_on DESC LIMIT 1', $user_id ),
			ARRAY_A
		);
		if ( $growth ) {
			$lines[] = 'آخرین اندازه‌ی کودک (' . $growth['name'] . '): ' . $growth['age_months'] . ' ماه، وزن ' . $growth['weight'] . ' کیلوگرم، قد ' . $growth['height'] . ' سانتی‌متر';
		}

		$moods = $wpdb->get_col(
			$wpdb->prepare( "SELECT value FROM " . Niva_DB::table( 'daily_logs' ) . " WHERE user_id = %d AND kind = 'mood' ORDER BY id DESC LIMIT 5", $user_id )
		);
		if ( $moods ) {
			$lines[] = 'حال روزهای اخیر (۱ تا ۵): ' . implode( ', ', array_map( 'strval', $moods ) );
		}

		if ( '' !== $topic ) {
			$lines[] = 'موضوع گفت‌وگو: ' . $topic;
		}
		if ( ! $lines ) {
			return '';
		}

		return "\n\n[زمینه‌ی پرونده — فقط برای شخصی‌سازی پاسخ؛ از آن به‌عنوان تشخیص استفاده نکن]\n" . implode( "\n", $lines );
	}

	/** Lists, loads, or deletes only the signed-in user's stored conversations. */
	public function chat_history( WP_REST_Request $request ) {
		global $wpdb;
		$user_id = get_current_user_id();
		$chats   = Niva_DB::table( 'chats' );
		$messages = Niva_DB::table( 'chat_messages' );
		$access  = $this->require_feature_access( 'advisor_chat' );
		if ( is_wp_error( $access ) ) {
			return $access;
		}

		if ( WP_REST_Server::DELETABLE === $request->get_method() ) {
			$chat_id = absint( $request->get_param( 'chat_id' ) );
			if ( ! $chat_id ) {
				return new WP_Error( 'niva_chat_id_invalid', 'گفت‌وگوی انتخاب‌شده معتبر نیست.', array( 'status' => 400 ) );
			}
			$owned = (int) $wpdb->get_var(
				$wpdb->prepare( "SELECT id FROM {$chats} WHERE id = %d AND user_id = %d", $chat_id, $user_id ) // phpcs:ignore WordPress.DB
			);
			if ( ! $owned ) {
				return new WP_Error( 'niva_chat_not_found', 'این گفت‌وگو پیدا نشد.', array( 'status' => 404 ) );
			}
			if ( false === $wpdb->delete( $messages, array( 'chat_id' => $chat_id, 'user_id' => $user_id ), array( '%d', '%d' ) ) ) {
				return new WP_Error( 'niva_chat_delete_failed', 'حذف پیام‌های گفت‌وگو انجام نشد.', array( 'status' => 500 ) );
			}
			if ( false === $wpdb->delete( $chats, array( 'id' => $chat_id, 'user_id' => $user_id ), array( '%d', '%d' ) ) ) {
				return new WP_Error( 'niva_chat_delete_failed', 'حذف گفت‌وگو انجام نشد.', array( 'status' => 500 ) );
			}
			return array( 'ok' => true, 'chat_id' => $chat_id );
		}

		$chat_id = absint( $request->get_param( 'chat_id' ) );
		if ( ! $chat_id && ! $request->get_param( 'topic' ) ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare(
					"SELECT id, topic, title, updated_at, created_at FROM {$chats} WHERE user_id = %d ORDER BY updated_at DESC, id DESC LIMIT 100",
					$user_id
				), // phpcs:ignore WordPress.DB
				ARRAY_A
			);
			foreach ( (array) $rows as &$row ) {
				$row['updated_at_label'] = Niva_Chrome::format_datetime( (string) $row['updated_at'] );
			}
			unset( $row );
			return array( 'chats' => $rows ? $rows : array() );
		}

		if ( ! $chat_id ) {
			$topic = sanitize_key( (string) $request->get_param( 'topic' ) );
			$chat_id = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT id FROM {$chats} WHERE user_id = %d AND topic = %s ORDER BY id DESC LIMIT 1", $user_id, $topic )
			);
		} else {
			$chat_id = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT id FROM {$chats} WHERE user_id = %d AND id = %d", $user_id, $chat_id )
			);
		}
		if ( ! $chat_id ) {
			return array( 'chat_id' => 0, 'messages' => array() );
		}

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT role, content, created_at FROM {$messages} WHERE chat_id = %d AND user_id = %d ORDER BY id ASC LIMIT 200", // phpcs:ignore WordPress.DB
				$chat_id,
				$user_id
			),
			ARRAY_A
		);
		foreach ( (array) $rows as &$row ) {
			$row['created_at_label'] = Niva_Chrome::format_datetime( (string) $row['created_at'] );
		}
		unset( $row );
		$chat = $wpdb->get_row(
			$wpdb->prepare( "SELECT id, topic, title FROM {$chats} WHERE id = %d AND user_id = %d", $chat_id, $user_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		if ( ! $chat ) {
			return new WP_Error( 'niva_chat_not_found', 'این گفت‌وگو پیدا نشد.', array( 'status' => 404 ) );
		}

		return array( 'chat_id' => $chat_id, 'chat' => $chat, 'messages' => $rows ? $rows : array() );
	}

	/** Persists the conversation so the back office can read it later. */
	private static function store_chat( int $user_id, string $topic, string $question, string $answer, string $provider, int $cost, int $chat_id = 0 ) : int {
		global $wpdb;
		$chats = Niva_DB::table( 'chats' );
		$msgs  = Niva_DB::table( 'chat_messages' );

		if ( ! $chat_id ) {
			$chat_id = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
				$wpdb->prepare(
					"SELECT id FROM {$chats} WHERE user_id = %d AND topic = %s AND status = 'open' ORDER BY id DESC LIMIT 1", // phpcs:ignore WordPress.DB
					$user_id,
					$topic
				)
			);
		}
		if ( ! $chat_id ) {
			$wpdb->insert( // phpcs:ignore WordPress.DB
				$chats,
				array(
					'user_id'    => $user_id,
					'topic'      => $topic,
					'title'      => mb_substr( wp_strip_all_tags( $question ), 0, 80 ),
					'provider'   => $provider,
					'created_at' => current_time( 'mysql' ),
					'updated_at' => current_time( 'mysql' ),
				)
			);
			$chat_id = (int) $wpdb->insert_id;
		} else {
			$wpdb->update( $chats, array( 'updated_at' => current_time( 'mysql' ), 'provider' => $provider ), array( 'id' => $chat_id ) ); // phpcs:ignore WordPress.DB
		}

		$wpdb->insert( $msgs, array( 'chat_id' => $chat_id, 'user_id' => $user_id, 'role' => 'user', 'content' => $question, 'cost' => 0, 'created_at' => current_time( 'mysql' ) ) ); // phpcs:ignore WordPress.DB
		$wpdb->insert( $msgs, array( 'chat_id' => $chat_id, 'user_id' => $user_id, 'role' => 'assistant', 'content' => $answer, 'cost' => $cost, 'created_at' => current_time( 'mysql' ) ) ); // phpcs:ignore WordPress.DB
		return $chat_id;
	}

	/** Baby growth measurements (write-through from the browser). */
	public function growth( WP_REST_Request $request ) {
		$user_id = get_current_user_id();
		global $wpdb;
		$table = Niva_DB::table( 'growth' );

		if ( 'POST' === $request->get_method() ) {
			$access = $this->require_feature_access( 'baby_baby-measure' );
			if ( is_wp_error( $access ) ) {
				return $access;
			}
		}

		if ( 'GET' === $request->get_method() ) {
			$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d ORDER BY measured_on DESC LIMIT 100", $user_id ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);
			$member = dr_niva()->plans->summary( $user_id );
			return array( 'items' => $rows ? $rows : array(), 'plan' => $member );
		}

		$profile_id = sanitize_text_field( (string) $request->get_param( 'profile_id' ) );
		$profile_id = $profile_id ?: 'default';
		$known_query = 'default' === $profile_id
			? $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND (profile_id = %s OR profile_id IS NULL OR profile_id = '')", $user_id, $profile_id )
			: $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND profile_id = %s", $user_id, $profile_id );
		$known = (int) $wpdb->get_var( $known_query ); // phpcs:ignore WordPress.DB
		if ( ! $known ) {
			$gate = dr_niva()->plans->can( $user_id, 'growth_profiles' );
			if ( is_wp_error( $gate ) ) {
				return $gate;
			}
		}

		$birth_year  = absint( $request->get_param( 'birth_year' ) );
		$birth_month = absint( $request->get_param( 'birth_month' ) );
		$birth_day   = absint( $request->get_param( 'birth_day' ) );
		$measured_on = sanitize_text_field( (string) $request->get_param( 'measured_on' ) );
		$weight      = $request->get_param( 'weight' );
		$height      = $request->get_param( 'height' );
		if ( $birth_year < 1300 || $birth_year > 1500 || $birth_month < 1 || $birth_month > 12 || $birth_day < 1 || $birth_day > 31 ) {
			return new WP_Error( 'niva_growth_birth_invalid', 'تاریخ تولد کودک در پروفایل معتبر نیست.', array( 'status' => 400 ) );
		}
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $measured_on ) || ! checkdate( (int) substr( $measured_on, 5, 2 ), (int) substr( $measured_on, 8, 2 ), (int) substr( $measured_on, 0, 4 ) ) ) {
			return new WP_Error( 'niva_growth_date_invalid', 'تاریخ اندازه‌گیری معتبر نیست.', array( 'status' => 400 ) );
		}
		if ( ! is_numeric( $weight ) || (float) $weight <= 0 || ! is_numeric( $height ) || (float) $height <= 0 ) {
			return new WP_Error( 'niva_growth_measure_invalid', 'وزن و قد باید عددهای معتبر و بزرگ‌تر از صفر باشند.', array( 'status' => 400 ) );
		}

		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB
			$table,
			array(
				'user_id'     => $user_id,
				'profile_id'  => $profile_id,
				'name'        => sanitize_text_field( (string) $request->get_param( 'name' ) ),
				'sex'         => sanitize_text_field( (string) $request->get_param( 'sex' ) ),
				'birth_year'  => $birth_year,
				'birth_month' => $birth_month,
				'birth_day'   => $birth_day,
				'measured_on' => $measured_on,
				'age_months'  => absint( $request->get_param( 'age_months' ) ),
				'weight'      => (float) $weight,
				'height'      => (float) $height,
				'head'        => null !== $request->get_param( 'head' ) ? (float) $request->get_param( 'head' ) : null,
				'analysis'    => sanitize_text_field( (string) $request->get_param( 'analysis' ) ),
				'created_at'  => current_time( 'mysql' ),
			)
		);
		if ( ! $inserted ) {
			return new WP_Error( 'niva_growth_save_failed', 'ذخیرهٔ اندازه در پرونده ممکن نشد؛ دوباره تلاش کن.', array( 'status' => 500 ) );
		}
		return array( 'ok' => true, 'id' => (int) $wpdb->insert_id );
	}

	/** Daily actions: mood, water, sleep, symptoms, checklist ticks. */
	public function logs( WP_REST_Request $request ) {
		$user_id = get_current_user_id();
		if ( 'POST' === $request->get_method() && 'exercise' === sanitize_key( (string) $request->get_param( 'kind' ) ) ) {
			$access = $this->require_feature_access( 'exercises' );
			if ( is_wp_error( $access ) ) {
				return $access;
			}
		}
		global $wpdb;
		$table = Niva_DB::table( 'daily_logs' );

		if ( 'GET' === $request->get_method() ) {
			$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
				$wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT 200", $user_id ), // phpcs:ignore WordPress.DB
				ARRAY_A
			);
			if ( '' !== $wpdb->last_error ) {
				return new WP_Error( 'niva_logs_load_failed', 'خواندن سابقهٔ علائم ممکن نشد.', array( 'status' => 500 ) );
			}
			return array( 'items' => $rows ? $rows : array() );
		}

		$kind = sanitize_key( (string) $request->get_param( 'kind' ) );
		$date = sanitize_text_field( (string) $request->get_param( 'date' ) );
		$date = '' !== $date ? $date : current_time( 'Y-m-d' );
		$date_object = DateTime::createFromFormat( '!Y-m-d', $date );
		if ( ! $date_object || $date_object->format( 'Y-m-d' ) !== $date ) {
			return new WP_Error( 'niva_log_date_invalid', 'تاریخ واردشده معتبر نیست.', array( 'status' => 400 ) );
		}
		if ( '' === $kind ) {
			return new WP_Error( 'niva_log_kind_required', 'نوع ثبت را مشخص کن.', array( 'status' => 400 ) );
		}
		$value = sanitize_text_field( (string) $request->get_param( 'value' ) );
		if ( 'cycle_symptom' === $kind && ! in_array( $value, array( 'cramps', 'bloating', 'headache', 'fatigue', 'mood', 'spotting' ), true ) ) {
			return new WP_Error( 'niva_cycle_symptom_invalid', 'علامت انتخاب‌شده معتبر نیست.', array( 'status' => 400 ) );
		}
		if ( 'exercise' === $kind ) {
			if ( ! preg_match( '/^exercise-[1-9][0-9]*$/', $value ) ) {
				return new WP_Error( 'niva_exercise_invalid', 'شناسهٔ تمرین معتبر نیست.', array( 'status' => 400 ) );
			}
			$existing = $wpdb->get_var(
				$wpdb->prepare( "SELECT id FROM {$table} WHERE user_id = %d AND log_date = %s AND kind = 'exercise' AND value = %s LIMIT 1", $user_id, $date, $value ) // phpcs:ignore WordPress.DB
			);
			if ( $existing ) {
				return array( 'ok' => true, 'id' => (int) $existing, 'existing' => true );
			}
		}
		$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB
			$table,
			array(
				'user_id'    => $user_id,
				'log_date'   => $date,
				'kind'       => $kind,
				'value'      => $value,
				'note'       => sanitize_textarea_field( (string) $request->get_param( 'note' ) ),
				'created_at' => current_time( 'mysql' ),
			)
		);
		if ( ! $inserted ) {
			return new WP_Error( 'niva_log_save_failed', 'ذخیرهٔ علامت در پرونده ممکن نشد؛ دوباره تلاش کن.', array( 'status' => 500 ) );
		}
		return array( 'ok' => true, 'id' => (int) $wpdb->insert_id );
	}

	public function reminders_list() : WP_REST_Response {
		$reminders = new Niva_Reminders();
		return new WP_REST_Response( array( 'items' => $reminders->all( get_current_user_id() ) ), 200 );
	}

	public function reminders_save( WP_REST_Request $request ) {
		$access = $this->require_feature_access( 'reminders_reminder-list' );
		if ( is_wp_error( $access ) ) {
			return $access;
		}
		$gate = dr_niva()->plans->can( get_current_user_id(), 'reminders' );
		if ( is_wp_error( $gate ) ) {
			return $gate;
		}

		$reminders = new Niva_Reminders();
		$user_id   = get_current_user_id();
		$action    = sanitize_key( (string) $request->get_param( 'action' ) );

		if ( 'toggle' === $action ) {
			if ( ! $reminders->toggle( $user_id, absint( $request->get_param( 'id' ) ) ) ) {
				return new WP_Error( 'niva_reminder_not_found', 'یادآور پیدا نشد.', array( 'status' => 404 ) );
			}
		} else {
			$title = sanitize_text_field( (string) $request->get_param( 'title' ) );
			$time  = sanitize_text_field( (string) $request->get_param( 'time' ) );
			if ( '' === $title ) {
				return new WP_Error( 'niva_reminder_title_required', 'عنوان یادآور را وارد کن.', array( 'status' => 400 ) );
			}
			if ( ! preg_match( '/^(?:[01]\d|2[0-3]):[0-5]\d$/', $time ) ) {
				return new WP_Error( 'niva_reminder_time_invalid', 'ساعت را در قالب ۲۴ساعته مثل ۲۱:۰۰ وارد کن.', array( 'status' => 400 ) );
			}
			if ( 'update' === $action ) {
				if ( ! $reminders->update( $user_id, absint( $request->get_param( 'id' ) ), $title, $time, (string) $request->get_param( 'repeat' ) ) ) {
					return new WP_Error( 'niva_reminder_not_found', 'یادآور پیدا نشد یا قابل ویرایش نیست.', array( 'status' => 404 ) );
				}
				return new WP_REST_Response( array( 'items' => $reminders->all( $user_id ) ), 200 );
			}
			$id = $reminders->add(
				$user_id,
				$title,
				$time,
				(string) $request->get_param( 'repeat' )
			);
			if ( ! $id ) {
				return new WP_Error( 'niva_reminder_limit', 'به سقف تعداد یادآور رسیدی.', array( 'status' => 400 ) );
			}
		}
		return new WP_REST_Response( array( 'items' => $reminders->all( $user_id ) ), 200 );
	}

	public function reminders_delete( WP_REST_Request $request ) {
		$access = $this->require_feature_access( 'reminders_reminder-list' );
		if ( is_wp_error( $access ) ) {
			return $access;
		}
		$reminders = new Niva_Reminders();
		$user_id   = get_current_user_id();
		if ( ! $reminders->remove( $user_id, absint( $request->get_param( 'id' ) ) ) ) {
			return new WP_Error( 'niva_reminder_not_found', 'یادآور پیدا نشد یا قبلاً حذف شده است.', array( 'status' => 404 ) );
		}
		return new WP_REST_Response( array( 'items' => $reminders->all( $user_id ) ), 200 );
	}

	/**
	 * In-app purchase receipt verification.
	 *
	 * The Android wrapper sends the store, the SKU and the purchase token here;
	 * credits are granted only after the server validated the receipt.
	 */
	/**
	 * Records that a user opened the upgrade sheet of a locked tool.
	 *
	 * This is the demand signal behind the admin report, so it is deliberately
	 * fire-and-forget: it never charges anything and never blocks the user.
	 */
	public function gate_click( WP_REST_Request $request ) {
		$module = sanitize_key( (string) $request->get_param( 'module' ) );
		if ( '' === $module ) {
			return new WP_Error( 'niva_gate_module', 'ماژول مشخص نشده است.', array( 'status' => 400 ) );
		}
		Niva_Modules::log_gate_click( $module );
		return new WP_REST_Response( array( 'ok' => true ), 200 );
	}

	public function store_verify( WP_REST_Request $request ) {
		$plugin = dr_niva();
		$store  = sanitize_key( (string) $request->get_param( 'store' ) );
		$sku    = sanitize_text_field( (string) $request->get_param( 'sku' ) );
		$token  = sanitize_text_field( (string) $request->get_param( 'token' ) );
		$user   = absint( $request->get_param( 'user_id' ) );

		if ( ! $user || ! $token || ! $sku ) {
			return new WP_Error( 'niva_store_bad_request', 'اطلاعات خرید ناقص است.', array( 'status' => 400 ) );
		}
		if ( ! in_array( $store, array( 'bazaar', 'myket' ), true ) ) {
			return new WP_Error( 'niva_store_unknown', 'فروشگاه ناشناخته است.', array( 'status' => 400 ) );
		}

		$enabled = 'bazaar' === $store ? $plugin->settings->is_on( 'store_bazaar' ) : $plugin->settings->is_on( 'store_myket' );
		$secret  = (string) $plugin->settings->get( 'bazaar' === $store ? 'store_bazaar_secret' : 'store_myket_secret' );
		if ( ! $enabled || '' === $secret ) {
			return new WP_Error( 'niva_store_not_configured', 'تایید رسید این فروشگاه هنوز در تنظیمات فعال نشده است.', array( 'status' => 501 ) );
		}

		/*
		 * SKU → grant map.
		 *
		 * Current format: sku | type(credit|plan) | value | store | days
		 * Legacy format (still supported): sku | credits | store
		 * A row that names another store is rejected instead of granted.
		 */
		$grant = array( 'type' => '', 'value' => '', 'store' => '', 'days' => 0 );
		foreach ( $plugin->settings->as_rows( 'store_skus' ) as $row ) {
			$parts = array_map( 'trim', array_map( 'strval', (array) $row ) );
			if ( ! isset( $parts[0] ) || $parts[0] !== $sku ) {
				continue;
			}
			$type = strtolower( (string) ( $parts[1] ?? '' ) );
			if ( in_array( $type, array( 'credit', 'plan' ), true ) ) {
				$grant = array(
					'type'  => $type,
					'value' => (string) ( $parts[2] ?? '' ),
					'store' => strtolower( (string) ( $parts[3] ?? '' ) ),
					'days'  => (int) ( $parts[4] ?? 0 ),
				);
			} else {
				$grant = array(
					'type'  => 'credit',
					'value' => (string) (int) ( $parts[1] ?? 0 ),
					'store' => strtolower( (string) ( $parts[2] ?? '' ) ),
					'days'  => 0,
				);
			}
			break;
		}

		if ( '' === $grant['type'] ) {
			return new WP_Error( 'niva_store_unknown_sku', 'این محصول به بستهٔ اعتباری یا پلنی وصل نشده است.', array( 'status' => 400 ) );
		}
		if ( '' !== $grant['store'] && $grant['store'] !== $store ) {
			return new WP_Error( 'niva_store_wrong_store', 'این محصول مربوط به فروشگاه دیگری است.', array( 'status' => 400 ) );
		}
		if ( 'credit' === $grant['type'] && (int) $grant['value'] <= 0 ) {
			return new WP_Error( 'niva_store_unknown_sku', 'مقدار اعتبار این محصول درست تنظیم نشده است.', array( 'status' => 400 ) );
		}

		// Idempotency: the same token is never granted twice (cache + table).
		$key = 'niva_store_' . md5( $store . '|' . $token );
		if ( get_transient( $key ) ) {
			return new WP_REST_Response( array( 'granted' => false, 'reason' => 'already' ), 200 );
		}
		global $wpdb;
		$already = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				'SELECT id FROM ' . Niva_DB::table( 'store_purchases' ) . ' WHERE store = %s AND purchase_token = %s',
				$store,
				$token
			)
		);
		if ( $already ) {
			return new WP_REST_Response( array( 'granted' => false, 'reason' => 'already' ), 200 );
		}

		/**
		 * Lets a site hook in the real store validation call (their REST API
		 * needs the developer secret and the refresh token).
		 */
		$validated = apply_filters( 'dr_niva_validate_store_receipt', null, $store, $sku, $token, $secret );
		if ( is_wp_error( $validated ) ) {
			return $validated;
		}
		if ( true !== $validated ) {
			return new WP_Error(
				'niva_store_unverified',
				'تایید رسید انجام نشد. برای اتصال به API فروشگاه باید فیلتر dr_niva_validate_store_receipt پیاده‌سازی شود.',
				array( 'status' => 501 )
			);
		}

		set_transient( $key, 1, MONTH_IN_SECONDS );

		// Record the receipt first, so a failure after this point is auditable
		// and the unique (store, token) key blocks any second grant.
		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'store_purchases' ),
			array(
				'user_id'        => $user,
				'store'          => $store,
				'sku'            => $sku,
				'purchase_token' => $token,
				'grant_type'     => $grant['type'],
				'grant_value'    => (string) $grant['value'],
				'amount'         => (float) $request->get_param( 'amount' ),
				'status'         => 'granted',
				'granted_at'     => current_time( 'mysql', true ),
				'created_at'     => current_time( 'mysql', true ),
			)
		);

		if ( 'plan' === $grant['type'] ) {
			$days = $grant['days'] > 0 ? $grant['days'] : 30;
			$plan = sanitize_key( (string) $grant['value'] );
			$plugin->plans->assign( $user, $plan, 'store:' . $store, $days, $token );
			return new WP_REST_Response(
				array(
					'granted' => true,
					'plan'    => $plan,
					'days'    => $days,
					'message' => 'پلن ' . $plugin->plans->label( $plan ) . ' برای ' . $days . ' روز فعال شد.',
				),
				200
			);
		}

		$credits = (int) $grant['value'];
		$summary = $plugin->wallet->grant( $user, $credits, 'store:' . $store, $token );
		return new WP_REST_Response( array( 'granted' => true, 'credits' => $credits, 'wallet' => $summary ), 200 );
	}

	private function current_provider( int $user_id ) : string {
		return 'gapgpt';
	}

	private function reserved_chat_cost( array $messages, Niva_Settings $settings ) : int {
		$input_rate  = max( 0, (int) $settings->get( 'ai_input_credits_per_1k_tokens' ) );
		$output_rate = max( 0, (int) $settings->get( 'ai_output_credits_per_1k_tokens' ) );
		if ( 0 === $input_rate && 0 === $output_rate ) {
			return max( 0, (int) $settings->get( 'cost_message' ) );
		}

		$characters = 512;
		foreach ( $messages as $turn ) {
			$content = (string) ( $turn['content'] ?? '' );
			$characters += function_exists( 'mb_strlen' ) ? mb_strlen( $content, 'UTF-8' ) : strlen( $content );
		}
		$estimated_input = (int) ceil( $characters * 1.5 );
		$max_output = max( 1, (int) $settings->get( 'ai_max_tokens' ) );
		$variable = (int) ceil( ( $estimated_input * $input_rate + $max_output * $output_rate ) / 1000 );
		return max( (int) $settings->get( 'cost_message' ), $variable );
	}

	private function actual_chat_cost( array $result, Niva_Settings $settings, int $reserved_cost ) : int {
		$input_rate  = max( 0, (int) $settings->get( 'ai_input_credits_per_1k_tokens' ) );
		$output_rate = max( 0, (int) $settings->get( 'ai_output_credits_per_1k_tokens' ) );
		if ( 0 === $input_rate && 0 === $output_rate ) {
			return max( 0, (int) $settings->get( 'cost_message' ) );
		}
		$tokens_in  = max( 0, (int) ( $result['tokens_in'] ?? 0 ) );
		$tokens_out = max( 0, (int) ( $result['tokens_out'] ?? 0 ) );
		if ( 0 === $tokens_in && 0 === $tokens_out ) {
			return max( 0, $reserved_cost );
		}
		$variable = (int) ceil( ( $tokens_in * $input_rate + $tokens_out * $output_rate ) / 1000 );
		return max( (int) $settings->get( 'cost_message' ), $variable );
	}

	/**
	 * Add or remove one of the user's own lab results.
	 *
	 * POST { marker, value, date }  -> add
	 * POST { delete: <index> }      -> remove
	 */
	public function labs( WP_REST_Request $request ) {
		if ( 'POST' === $request->get_method() ) {
			$access = $this->require_feature_access( $request->has_param( 'delete' ) ? 'lab_values' : 'lab_entry' );
			if ( is_wp_error( $access ) ) {
				return $access;
			}
		}
		$user   = (int) get_current_user_id();
		$params = (array) $request->get_json_params();

		if ( isset( $params['delete'] ) ) {
			if ( ! Niva_Labs::forget( $user, (int) $params['delete'] ) ) {
				return new WP_Error( 'niva_lab_not_found', 'این نتیجهٔ آزمایش پیدا نشد.', array( 'status' => 404 ) );
			}
		} elseif ( isset( $params['marker'], $params['value'] ) ) {
			$ok = Niva_Labs::add( $user, sanitize_key( (string) $params['marker'] ), $params['value'], (string) ( $params['date'] ?? '' ) );
			if ( ! $ok ) {
				return new WP_Error( 'niva_labs_invalid', 'مقدار آزمایش معتبر نیست.', array( 'status' => 400 ) );
			}
		}

		return rest_ensure_response(
			array(
				'ok'           => true,
				'entries'      => Niva_Labs::all( $user ),
				'modules_html' => Niva_Modules::render( 'lab_values' )
					. Niva_Modules::render( 'lab_chart' )
					. Niva_Modules::render( 'lab_print' ),
			)
		);
	}

	public function labs_summary() {
		$access = $this->require_feature_access( 'lab_values' );
		if ( is_wp_error( $access ) ) {
			return $access;
		}
		$modules = Niva_Modules::render( 'lab_values' )
			. Niva_Modules::render( 'lab_chart' )
			. Niva_Modules::render( 'lab_print' );
		return new WP_REST_Response(
			array(
				'entries'      => Niva_Labs::all( get_current_user_id() ),
				'modules_html' => $modules,
			),
			200
		);
	}

	/** Reads an uploaded lab image with the configured vision model and saves its extracted values. */
	public function analyze_lab_report( WP_REST_Request $request ) {
		$access = $this->require_feature_access( 'lab_upload' );
		if ( is_wp_error( $access ) ) {
			return $access;
		}
		$user_id = get_current_user_id();
		$file    = $request->get_file_params()['report'] ?? null;

		if ( ! is_array( $file ) || ! isset( $file['tmp_name'], $file['error'], $file['size'], $file['name'] ) || UPLOAD_ERR_OK !== (int) $file['error'] ) {
			return new WP_Error( 'niva_lab_upload_invalid', 'تصویر آزمایش دریافت نشد؛ دوباره انتخابش کن.', array( 'status' => 400 ) );
		}
		$maximum = max( 1, min( 20, (int) dr_niva()->settings->get( 'lab_max_mb' ) ) ) * MB_IN_BYTES;
		if ( (int) $file['size'] > $maximum ) {
			return new WP_Error( 'niva_lab_upload_too_large', 'حجم تصویر از سقف مجاز بیشتر است.', array( 'status' => 413 ) );
		}
		if ( ! is_uploaded_file( $file['tmp_name'] ) ) {
			return new WP_Error( 'niva_lab_upload_invalid', 'فایل بارگذاری‌شده معتبر نیست.', array( 'status' => 400 ) );
		}

		$image_info = wp_check_filetype_and_ext( $file['tmp_name'], sanitize_file_name( $file['name'] ) );
		$mime       = isset( $image_info['type'] ) ? (string) $image_info['type'] : '';
		$image_data = function_exists( 'getimagesize' ) ? getimagesize( $file['tmp_name'] ) : false;
		if ( ! in_array( $mime, array( 'image/jpeg', 'image/png', 'image/webp' ), true ) || ! is_array( $image_data ) || ( $image_data['mime'] ?? '' ) !== $mime ) {
			return new WP_Error( 'niva_lab_upload_type', 'فقط تصویر معتبر JPG، PNG یا WebP پذیرفته می‌شود.', array( 'status' => 415 ) );
		}

		$provider = dr_niva()->ai->configured_vision();
		if ( ! $provider ) {
			return new WP_Error( 'niva_vision_unavailable', 'تحلیل هوش مصنوعی هنوز فعال نشده است؛ مدیر سایت باید کلید API گپ‌جی‌پی‌تی را در تنظیمات وارد کند.', array( 'status' => 503 ) );
		}
		$contents = file_get_contents( $file['tmp_name'] ); // phpcs:ignore WordPress.WP.AlternativeFunctions.file_get_contents_file_get_contents
		if ( false === $contents ) {
			return new WP_Error( 'niva_lab_file_read', 'خواندن تصویر بارگذاری‌شده ممکن نشد.', array( 'status' => 500 ) );
		}

		$cost            = max( 0, (int) dr_niva()->settings->get( 'cost_lab_report' ) );
		$payment_source  = sanitize_key( (string) $request->get_param( 'payment_source' ) );
		$credits_enabled = dr_niva()->settings->is_on( 'credits_enabled' );
		$plan_reservation = null;
		$charge           = null;
		$plan_limit       = dr_niva()->plans->limit( $user_id, 'lab_per_month' );
		$plan_used        = dr_niva()->plans->usage( $user_id, 'lab_per_month' );
		$has_plan_quota   = 0 === $plan_limit || $plan_used < $plan_limit;
		if ( 'credits' === $payment_source && ! $credits_enabled ) {
			unset( $contents );
			return new WP_Error(
				'niva_lab_credits_disabled',
				'پرداخت با اعتبار برای این سایت فعال نیست؛ برای ادامه، اشتراکت را ارتقا بده.',
				array( 'status' => 402, 'upgrade_url' => ( new Niva_Links() )->url( 'plans' ) )
			);
		}

		if ( $has_plan_quota ) {
			$plan_reservation = dr_niva()->plans->reserve_usage( $user_id, 'lab_per_month', 'lab' );
			if ( is_wp_error( $plan_reservation ) ) {
				if ( 'niva_limit' !== $plan_reservation->get_error_code() ) {
					unset( $contents );
					return $plan_reservation;
				}
				$has_plan_quota = false;
			}
		}

		if ( ! $plan_reservation ) {
			if ( 'credits' !== $payment_source ) {
				unset( $contents );
				$wallet = dr_niva()->wallet->summary( $user_id );
				return new WP_Error(
					'niva_lab_payment_choice_required',
					'برای ادامه، روش پرداخت تحلیل را انتخاب کن.',
					array(
						'status'       => 402,
						'payment_required' => true,
						'payment_available' => $credits_enabled,
						'cost'         => $cost,
						'balance'      => (int) $wallet['balance'],
						'plan'         => dr_niva()->plans->plan_of( $user_id ),
						'quota'        => array( 'limit' => $plan_limit, 'used' => $plan_used ),
						'credits_url'  => ( new Niva_Links() )->url( 'wallet' ),
						'upgrade_url'  => ( new Niva_Links() )->url( 'plans' ),
					)
				);
			}
			$charge = dr_niva()->wallet->spend(
				$user_id,
				$cost,
				'lab',
				'lab-report:' . wp_generate_uuid4(),
				array( 'provider' => $provider, 'force_balance' => true )
			);
			if ( is_wp_error( $charge ) ) {
				unset( $contents );
				return $charge;
			}
		}

		$marker_names = array();
		foreach ( Niva_Labs::markers() as $key => $marker ) {
			$marker_names[] = $key . ' = ' . $marker[0] . ' (' . $marker[1] . ')';
		}
		$prompt = "این تصویر یک برگه آزمایش پزشکی است. همهٔ ردیف‌های آزمایش را، چه طبیعی و چه خارج از محدوده، جداگانه بررسی کن و هر عددی را که با اطمینان خوانده می‌شود استخراج کن؛ هیچ مورد خوانایی را به‌دلیل طبیعی‌بودن حذف نکن. هیچ تشخیص، توصیه درمانی یا دوز دارویی نساز و دربارهٔ علت نتیجه حدس نزن. تاریخ را میلادی و ISO (YYYY-MM-DD) بنویس و اگر خوانا نیست رشته خالی بگذار. محدودهٔ مرجع را فقط اگر عیناً روی برگه دیده می‌شود در reference_low و reference_high قرار بده؛ هرگز آن را حدس نزن. فقط JSON معتبر با این ساختار برگردان: {\"title\":\"عنوان کوتاه\",\"date\":\"YYYY-MM-DD\",\"values\":[{\"marker\":\"کلید یا custom\",\"name\":\"نام آزمایش اگر کلید شناخته‌شده نیست\",\"value\":12.3,\"unit\":\"واحد درج‌شده\",\"reference_low\":10,\"reference_high\":20}]}. برای marker شناخته‌شده از کلیدهای زیر استفاده کن، و برای سایر آزمایش‌های خوانا marker را custom و نام دقیق روی برگه را در name بگذار: "
			. implode( '; ', $marker_names )
			. '. اگر عدد یا نام خوانا نیست، آن ردیف را حذف کن.';
		$image_data = 'data:' . $mime . ';base64,' . base64_encode( $contents );
		unset( $contents );

		$result = dr_niva()->ai->read_document( $image_data, $prompt );
		if ( is_wp_error( $result ) ) {
			if ( ! empty( $plan_reservation['usage_id'] ) ) {
				dr_niva()->wallet->refund_usage( (int) $plan_reservation['usage_id'] );
			} elseif ( ! empty( $charge['usage_id'] ) ) {
				dr_niva()->wallet->refund_usage( (int) $charge['usage_id'] );
			}
			return new WP_Error( $result->get_error_code(), $result->get_error_message(), array( 'status' => 502 ) );
		}

		$data     = $result['data'] ?? array();
		$markers  = Niva_Labs::markers();
		$raw_date   = sanitize_text_field( (string) ( $data['date'] ?? '' ) );
		$date_parts = array();
		$date       = preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $raw_date, $date_parts )
			&& checkdate( (int) $date_parts[2], (int) $date_parts[3], (int) $date_parts[1] )
			? $raw_date
			: '';
		$values   = array();
		$seen     = array();
		foreach ( (array) ( $data['values'] ?? array() ) as $item ) {
			if ( ! is_array( $item ) || ! isset( $item['marker'], $item['value'] ) || ! is_numeric( $item['value'] ) ) {
				continue;
			}
			$marker = sanitize_key( (string) $item['marker'] );
			$custom_name = sanitize_text_field( (string) ( $item['name'] ?? '' ) );
			if ( ! isset( $markers[ $marker ] ) && '' === $custom_name ) {
				continue;
			}
			$unit = sanitize_text_field( (string) ( $item['unit'] ?? '' ) );
			$reference = array();
			if ( is_numeric( $item['reference_low'] ?? null ) && is_numeric( $item['reference_high'] ?? null ) && (float) $item['reference_high'] >= (float) $item['reference_low'] ) {
				$reference = array( 'low' => (float) $item['reference_low'], 'high' => (float) $item['reference_high'] );
			}
			$value = (float) $item['value'];
			if ( $value <= 0 || $value > 100000 ) {
				continue;
			}
			if ( isset( $markers[ $marker ] ) ) {
				$name = $markers[ $marker ][0];
				$unit = $unit ?: $markers[ $marker ][1];
				$entry_marker = $marker;
			} else {
				$name = $custom_name;
				$entry_marker = 'custom-' . substr( hash( 'sha256', function_exists( 'mb_strtolower' ) ? mb_strtolower( $name, 'UTF-8' ) : strtolower( $name ) ), 0, 16 );
			}
			if ( isset( $seen[ $entry_marker ] ) ) {
				continue;
			}
			$added = isset( $markers[ $marker ] )
				? Niva_Labs::add( $user_id, $marker, $value, $date, false, $reference, $name, $unit )
				: Niva_Labs::add_custom( $user_id, $name, $value, $unit, $date, $reference );
			if ( ! $added ) {
				continue;
			}
			$seen[ $entry_marker ] = true;
			$status = Niva_Labs::status( $entry_marker, $value, $reference['low'] ?? null, $reference['high'] ?? null );
			$values[] = array(
				'name'   => $name,
				'value'  => $value,
				'unit'   => $unit,
				'status' => Niva_Labs::status_label( $status ),
				'explanation' => Niva_Labs::explanation( $entry_marker, $value, $reference['low'] ?? null, $reference['high'] ?? null ),
			);
		}
		if ( ! $values ) {
			if ( ! empty( $plan_reservation['usage_id'] ) ) {
				dr_niva()->wallet->refund_usage( (int) $plan_reservation['usage_id'] );
			} elseif ( ! empty( $charge['usage_id'] ) ) {
				dr_niva()->wallet->refund_usage( (int) $charge['usage_id'] );
			}
			return new WP_Error( 'niva_lab_no_values', 'مقدار قابل ثبت با اطمینان از تصویر پیدا نشد؛ تصویر واضح‌تری بفرست یا نتیجه را با پزشکت بررسی کن.', array( 'status' => 422 ) );
		}
		if ( ! empty( $plan_reservation['usage_id'] ) && ! dr_niva()->wallet->complete_plan_usage( (int) $plan_reservation['usage_id'] ) ) {
			dr_niva()->wallet->refund_usage( (int) $plan_reservation['usage_id'] );
			return new WP_Error( 'niva_lab_quota_settlement_failed', 'ثبت مصرف سهمیه انجام نشد؛ نتیجه ذخیره شد اما وضعیت مصرف نیاز به بررسی مدیر دارد.', array( 'status' => 500 ) );
		}

		$out_of_range = array_filter( $values, static function ( $value ) {
			return in_array( $value['status'], array( 'کمتر از محدوده', 'بیشتر از محدوده' ), true );
		} );
		$summary = sprintf( '%s مقدار خوانا بررسی و ذخیره شد.', Niva_Chrome::digits( count( $values ) ) );
		if ( $out_of_range ) {
			$summary .= ' خارج از محدوده: ' . implode(
				'، ',
				array_map(
					static function ( $value ) {
						return $value['name'] . ' (' . $value['status'] . ')';
					},
					$out_of_range
				)
			) . '.';
		} else {
			$summary .= ' هیچ‌یک از موارد قابل ارزیابی خارج از محدودهٔ مرجع تشخیص داده‌شده نبود.';
		}
		$summary .= ' محدوده‌های عمومی ممکن است با شرایط فردی و بازهٔ آزمایشگاه فرق داشته باشند؛ این بررسی تشخیص پزشکی نیست.';

		return rest_ensure_response(
			array(
				'message' => 'تحلیل انجام شد و مقادیر خوانا در پروندهٔ آزمایش ذخیره شدند.',
				'title'   => sanitize_text_field( (string) ( $data['title'] ?? 'نتیجهٔ آزمایش' ) ),
				'summary' => $summary,
				'date'    => $date,
				'values'  => $values,
				'payment' => array(
					'source' => $plan_reservation ? 'plan' : 'credits',
					'cost'   => $plan_reservation ? 0 : (int) ( $charge['cost'] ?? 0 ),
				),
				'wallet' => dr_niva()->wallet->summary( $user_id ),
				'plan_quota' => dr_niva()->plans->summary( $user_id )['limits']['lab_per_month'] ?? null,
				'entries' => Niva_Labs::all( $user_id ),
				'modules_html' => Niva_Modules::render( 'lab_values' )
					. Niva_Modules::render( 'lab_chart' )
					. Niva_Modules::render( 'lab_print' ),
			)
		);
	}

	/** A user asks for a paid plan; the owner activates it and gets an email. */
	public function plan_request( WP_REST_Request $request ) {
		$user   = (int) get_current_user_id();
		$params = (array) $request->get_json_params();
		$plan   = sanitize_key( (string) ( $params['plan'] ?? '' ) );

		if ( ! in_array( $plan, array( 'free', 'plus', 'family', 'partner' ), true ) ) {
			return new WP_Error( 'niva_plan_invalid', 'پلن انتخابی معتبر نیست.', array( 'status' => 400 ) );
		}

		update_user_meta( $user, 'dr_niva_plan_request', array( 'plan' => $plan, 'at' => current_time( 'mysql' ) ) );
		do_action( 'dr_niva_plan_requested', $user, $plan );

		$catalog = Niva_Plans::catalog();
		$label   = $catalog[ $plan ]['label'] ?? $plan;
		$who     = wp_get_current_user();
		wp_mail(
			get_option( 'admin_email' ),
			'درخواست فعال‌سازی اشتراک — ' . $label,
			sprintf( "کاربر: %s (%s)\nپلن درخواستی: %s\nقیمت ماهیانه: %s تومان\nبرای فعال‌سازی: %s", $who->display_name, $who->user_email, $label, number_format_i18n( $catalog[ $plan ]['payable'] ?? 0 ), admin_url( 'admin.php?page=dr-niva-plans' ) )
		);

		return rest_ensure_response( array( 'ok' => true, 'plan' => $plan ) );
	}
}
