<?php
/**
 * Push to the mobile app (Android / iOS) as well as to browsers.
 *
 * The app wrapper hands its device token to the page through a small JS bridge
 * (`window.AvaApp.getPushToken()`), the page posts it here, and every
 * notification is then delivered to the device. The transport is a sender:
 * by default the FCM HTTP endpoint with the key from the settings, and any
 * custom transport can replace it with a filter.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Push {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	public function routes() : void {
		register_rest_route(
			Niva_Rest::NS,
			'/app/push/register',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( $this, 'register_device' ),
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/app/push/unregister',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( $this, 'unregister_device' ),
			)
		);
	}

	public function register_device( WP_REST_Request $request ) {
		global $wpdb;

		$token    = sanitize_text_field( (string) $request->get_param( 'token' ) );
		$platform = sanitize_key( (string) $request->get_param( 'platform' ) );
		$version  = sanitize_text_field( (string) $request->get_param( 'app_version' ) );
		$user_id  = get_current_user_id();

		if ( '' === $token ) {
			return new WP_Error( 'niva_push_no_token', 'توکن دستگاه دریافت نشد.', array( 'status' => 400 ) );
		}
		if ( ! in_array( $platform, array( 'android', 'ios', 'web', 'huawei' ), true ) ) {
			$platform = 'android';
		}

		$table    = Niva_DB::table( 'push_devices' );
		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE token = %s", $token ) ); // phpcs:ignore WordPress.DB

		$data = array(
			'user_id'    => $user_id,
			'token'      => $token,
			'platform'   => $platform,
			'app_version' => $version,
			'enabled'    => 1,
			'last_seen'  => current_time( 'mysql' ),
		);
		if ( $existing ) {
			$wpdb->update( $table, $data, array( 'id' => (int) $existing ) ); // phpcs:ignore WordPress.DB
		} else {
			$data['created_at'] = current_time( 'mysql' );
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB
		}

		return array( 'ok' => true );
	}

	public function unregister_device( WP_REST_Request $request ) {
		global $wpdb;
		$token = sanitize_text_field( (string) $request->get_param( 'token' ) );
		if ( $token ) {
			$wpdb->update( Niva_DB::table( 'push_devices' ), array( 'enabled' => 0 ), array( 'token' => $token ) ); // phpcs:ignore WordPress.DB
		}
		return array( 'ok' => true );
	}

	public function devices_of( int $user_id ) : array {
		global $wpdb;
		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'push_devices' ) . ' WHERE user_id = %d AND enabled = 1', $user_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		return $rows ? $rows : array();
	}

	/**
	 * Sends one notification to every device of a user.
	 *
	 * @return int Number of devices the message was accepted for.
	 */
	public static function send( int $user_id, string $title, string $body, string $url = '' ) : int {
		$devices = dr_niva()->push->devices_of( $user_id );
		if ( ! $devices ) {
			return 0;
		}

		/** Custom transport (FCM v1, OneSignal, درگاه محلی …). */
		$custom = apply_filters( 'dr_niva_app_push_sender', null, $user_id, $title, $body, $url, $devices );
		if ( null !== $custom ) {
			return (int) $custom;
		}

		$key = (string) dr_niva()->settings->get( 'push_fcm_key' );
		if ( '' === $key ) {
			do_action( 'dr_niva_app_push_skipped', $user_id, 'no-key' );
			return 0;
		}

		$endpoint = (string) dr_niva()->settings->get( 'push_fcm_endpoint' );
		if ( '' === $endpoint ) {
			$endpoint = 'https://fcm.googleapis.com/fcm/send';
		}

		$sent = 0;
		foreach ( $devices as $device ) {
			$payload = array(
				'to'           => $device['token'],
				'priority'     => 'high',
				'notification' => array(
					'title' => wp_strip_all_tags( $title ),
					'body'  => wp_strip_all_tags( $body ),
					'sound' => 'default',
				),
				'data'         => array(
					'url'   => $url ? $url : home_url( '/' ),
					'title' => wp_strip_all_tags( $title ),
					'body'  => wp_strip_all_tags( $body ),
				),
			);

			$response = wp_remote_post(
				$endpoint,
				array(
					'timeout' => 15,
					'headers' => array(
						'Authorization' => 'key=' . $key,
						'Content-Type'  => 'application/json',
					),
					'body'    => wp_json_encode( $payload ),
				)
			);

			if ( is_wp_error( $response ) ) {
				do_action( 'dr_niva_app_push_error', $user_id, $response->get_error_message() );
				continue;
			}

			$code = (int) wp_remote_retrieve_response_code( $response );
			$data = json_decode( (string) wp_remote_retrieve_body( $response ), true );

			if ( $code >= 200 && $code < 300 && is_array( $data ) && empty( $data['failure'] ) ) {
				$sent++;
				continue;
			}

			// the store told us the token is dead: stop using it
			$errors = isset( $data['results'][0]['error'] ) ? (string) $data['results'][0]['error'] : '';
			if ( in_array( $errors, array( 'NotRegistered', 'InvalidRegistration', 'MismatchSenderId' ), true ) ) {
				global $wpdb;
				$wpdb->update( Niva_DB::table( 'push_devices' ), array( 'enabled' => 0 ), array( 'token' => $device['token'] ) ); // phpcs:ignore WordPress.DB
			}
		}

		return $sent;
	}
}
