<?php
/**
 * Insight engine.
 *
 * Turns the data that already lives in the plugin (usage log, reminders,
 * membership) into the kind of thing a paid health app shows on its home
 * screen: a health score, a weekly activity chart, a streak and a short list of
 * personalised suggestions.
 *
 * Everything here is deterministic, local and read-only — no external call, and
 * a brand-new site with no data still renders a sensible empty state instead of
 * an error.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Insights {

	/* -------------------------------------------------------------- health */

	/**
	 * A 0–100 score built from signals the plugin really has.
	 *
	 * @return array ['score' => int, 'band' => array, 'parts' => array]
	 */
	public static function health_score( int $user_id ) : array {
		$parts = array();

		// 1) Activity in the last 7 days (up to 34 points).
		$week  = self::weekly_series( $user_id );
		$total = 0;
		foreach ( $week as $day ) {
			$total += (int) $day['value'];
		}
		$parts[] = array(
			'key'   => 'activity',
			'label' => 'فعالیت هفته',
			'value' => min( 34, $total * 3 ),
			'max'   => 34,
			'hint'  => self::fa( $total ) . ' اقدام در ۷ روز گذشته',
		);

		// 2) Tracked items this month (up to 26 points).
		$month_usage = self::usage_count( $user_id, 30 );
		$parts[]     = array(
			'key'   => 'tracking',
			'label' => 'پیگیری منظم',
			'value' => min( 26, $month_usage * 2 ),
			'max'   => 26,
			'hint'  => self::fa( $month_usage ) . ' ثبت در ۳۰ روز گذشته',
		);

		// 3) A plan that unlocks the full toolkit (15 points).
		$plan    = dr_niva()->plans ? dr_niva()->plans->plan_of( $user_id ) : array( 'active' => false, 'label' => 'رایگان' );
		$parts[] = array(
			'key'   => 'plan',
			'label' => 'اشتراک فعال',
			'value' => ! empty( $plan['active'] ) ? 15 : 0,
			'max'   => 15,
			'hint'  => $plan['label'],
		);

		// 4) Open reminders are a care signal, not a chore (up to 25 points).
		$open    = self::open_reminders( $user_id );
		$parts[] = array(
			'key'   => 'care',
			'label' => 'برنامه‌ی مراقبت',
			'value' => min( 25, $open * 5 ),
			'max'   => 25,
			'hint'  => $open ? self::fa( $open ) . ' یادآور فعال' : 'هنوز یادآوری نساخته‌ای',
		);

		$score = 0;
		foreach ( $parts as $part ) {
			$score += (int) $part['value'];
		}
		$score = max( 0, min( 100, $score ) );

		return array(
			'score' => $score,
			'band'  => self::band( $score ),
			'parts' => $parts,
		);
	}

	/** Label + tone + advice for a score. */
	public static function band( int $score ) : array {
		if ( $score >= 80 ) {
			return array( 'label' => 'خیلی خوب', 'tone' => 'success', 'note' => 'مسیر مراقبتت منظم است؛ همین‌طور ادامه بده.' );
		}
		if ( $score >= 55 ) {
			return array( 'label' => 'خوب', 'tone' => 'info', 'note' => 'با یکی‌دو کار کوچک امتیازت بالاتر می‌رود.' );
		}
		if ( $score >= 30 ) {
			return array( 'label' => 'قابل بهتر شدن', 'tone' => 'caution', 'note' => 'ثبت روزانه و یک یادآور تازه، سریع فرق را نشان می‌دهد.' );
		}
		return array( 'label' => 'شروع تازه', 'tone' => 'caution', 'note' => 'از یک قدم کوچک شروع کن؛ همین امروز یک نشانه ثبت کن.' );
	}

	/** SVG ring geometry for a 0–100 score. */
	public static function ring( int $score, float $radius = 52 ) : array {
		$score   = max( 0, min( 100, $score ) );
		$circumf = 2 * M_PI * $radius;

		/*
		 * A true zero draws nothing at all, so the gauge looked broken rather than
		 * empty. Draw a small always-visible cap; the printed number stays honest.
		 */
		$drawn = $score > 0 ? $score : 1.5;

		return array(
			'radius'        => $radius,
			'circumference' => $circumf,
			'offset'        => $circumf * ( 1 - ( $drawn / 100 ) ),
			'value'         => $score,
		);
	}

	/* ------------------------------------------------------------ activity */

	/** Counts of recorded actions per day for the last 7 days. */
	public static function weekly_series( int $user_id ) : array {
		$days   = array();
		$labels = array( 'ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج' );
		$today  = new DateTimeImmutable( 'now', wp_timezone() );

		for ( $i = 6; $i >= 0; $i-- ) {
			$date = $today->modify( '-' . $i . ' days' );
			$key  = $date->format( 'Y-m-d' );
			$days[ $key ] = array(
				'label' => $labels[ Niva_Chrome::weekday_index( $date->getTimestamp() ) ],
				'value' => 0,
			);
		}

		$counts = self::usage_by_day( $user_id );
		foreach ( $counts as $date => $count ) {
			if ( isset( $days[ $date ] ) ) {
				$days[ $date ]['value'] = (int) $count;
			}
		}

		$out = array_values( $days );
		$max = 0;
		foreach ( $out as $day ) {
			$max = max( $max, (int) $day['value'] );
		}
		$max = max( 1, $max );

		foreach ( $out as $i => $day ) {
			$out[ $i ]['height'] = (int) round( ( (int) $day['value'] / $max ) * 100 );
		}

		return $out;
	}

	/** Days in a row, ending today, with at least one recorded action. */
	public static function streak( int $user_id ) : int {
		$counts = self::usage_by_day( $user_id );
		if ( ! $counts ) {
			return 0;
		}
		$streak = 0;
		$today  = new DateTimeImmutable( 'today', wp_timezone() );
		for ( $i = 0; $i < 60; $i++ ) {
			$key = $today->modify( '-' . $i . ' days' )->format( 'Y-m-d' );
			if ( ! empty( $counts[ $key ] ) ) {
				$streak++;
			} elseif ( $i > 0 ) {
				break;
			}
		}
		return $streak;
	}

	/* ------------------------------------------------------------ insights */

	/**
	 * Short, actionable suggestions. Rules only — never a generated medical claim.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public static function insights( int $user_id, int $limit = 4 ) : array {
		$out    = array();
		$today  = self::usage_count( $user_id, 1 );
		$week   = self::usage_count( $user_id, 7 );
		$month  = self::usage_count( $user_id, 30 );
		$open   = self::open_reminders( $user_id );
		$streak = self::streak( $user_id );
		$plan   = dr_niva()->plans ? dr_niva()->plans->plan_of( $user_id ) : array( 'plan' => 'free', 'label' => 'رایگان', 'active' => false );

		if ( 0 === $week ) {
			$out[] = array(
				'icon'  => 'sparkles',
				'tone'  => 'info',
				'title' => 'از یک قدم کوچک شروع کن',
				'text'  => 'این هفته چیزی ثبت نکرده‌ای. یک گفت‌وگوی کوتاه با مشاور یا ثبت یک نشانه، شروع خوبی است.',
				'cta'   => 'شروع گفت‌وگو با مشاور',
				'key'   => 'advisor',
			);
		} elseif ( $streak >= 3 ) {
			$out[] = array(
				'icon'  => 'trending-up',
				'tone'  => 'ok',
				'title' => self::fa( $streak ) . ' روز پیاپی همراه بودی',
				'text'  => 'تداوم مهم‌ترین بخش مراقبت است. برای اینکه روند را ببینی، یک آزمایش یا اندازه‌ی تازه بارگذاری کن.',
				'cta'   => 'بارگذاری نتیجه‌ی تازه',
				'key'   => 'lab',
			);
		}

		if ( $today >= 4 ) {
			$out[] = array(
				'icon'  => 'message-circle',
				'tone'  => 'info',
				'title' => 'امروز پرسش‌های زیادی داشتی',
				'text'  => 'پاسخ‌های مهم را در دفتر افکار یا یادداشت سلامت ذخیره کن تا بعداً مرورشان آسان باشد.',
				'cta'   => 'مرور یادداشت‌ها',
				'key'   => 'tools',
			);
		}

		if ( 0 === $open ) {
			$out[] = array(
				'icon'  => 'bell',
				'tone'  => 'warn',
				'title' => 'هیچ یادآور فعالی نداری',
				'text'  => 'دارو، ویتامین، واکسن یا قرار ملاقات — یک یادآور بساز تا مراقبت از ذهنت بیرون بیاید.',
				'cta'   => 'ساخت یادآور',
				'key'   => 'reminders',
			);
		}

		if ( 0 === $month ) {
			$out[] = array(
				'icon'  => 'file-text',
				'tone'  => 'info',
				'title' => 'این ماه آزمایشی ثبت نکرده‌ای',
				'text'  => 'اگر برگه‌ی آزمایش داری، بارگذاری کن تا تحلیل ساده و برگه‌ی قابل چاپ برای پزشک بگیری.',
				'cta'   => 'تحلیل آزمایش',
				'key'   => 'lab',
			);
		}

		if ( empty( $plan['active'] ) ) {
			$out[] = array(
				'icon'  => 'credit-card',
				'tone'  => 'info',
				'title' => 'سقف پلن رایگان',
				'text'  => 'با پلاس، تحلیل نامحدود اسناد و تصاویر و خروجی PDF برای پزشک فعال می‌شود.',
				'cta'   => 'دیدن پلن‌ها',
				'key'   => 'plans',
			);
		}

		if ( count( $out ) < 2 ) {
			$out[] = array(
				'icon'  => 'heart',
				'tone'  => 'ok',
				'title' => 'وضعیتت مرتب است',
				'text'  => 'چیز فوری‌ای پیدا نکردیم. برای دقت بیشتر، هر چند روز یک‌بار نشانه‌ها یا اندازه‌ها را ثبت کن.',
				'cta'   => 'بخش‌های مراقبت',
				'key'   => 'tools',
			);
		}

		return array_slice( $out, 0, max( 1, $limit ) );
	}

	/** The tile grid — every tile can be retargeted from the Elementor panel. */
	public static function quick_actions() : array {
		return array(
			array( 'icon' => 'message-circle', 'title' => 'گفت‌وگو با مشاور', 'text' => 'سؤال سلامتت را بپرس', 'key' => 'advisor', 'tone' => 'primary' ),
			array( 'icon' => 'file-text', 'title' => 'تحلیل آزمایش', 'text' => 'برگه را بفرست، خلاصه بگیر', 'key' => 'lab', 'tone' => 'plain' ),
			array( 'icon' => 'calendar-heart', 'title' => 'چرخه و بارداری', 'text' => 'تقویم و هفته‌به‌هفته', 'key' => 'cycle', 'tone' => 'plain' ),
			array( 'icon' => 'baby', 'title' => 'رشد نوزاد', 'text' => 'وزن، قد و جدول مرجع', 'key' => 'baby', 'tone' => 'plain' ),
			array( 'icon' => 'smile', 'title' => 'حال روان', 'text' => 'تمرین آرام‌سازی و ثبت خلق', 'key' => 'mind', 'tone' => 'plain' ),
			array( 'icon' => 'bell', 'title' => 'یادآورها', 'text' => 'دارو، واکسن، قرار', 'key' => 'reminders', 'tone' => 'plain' ),
		);
	}

	/**
	 * Open reminders, normalised so the screen never depends on one column name.
	 *
	 * @return array<int,array<string,string|bool>>
	 */
	public static function care_items( int $user_id, int $limit = 4 ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'reminders' );
		$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE user_id = %d AND done = 0 ORDER BY id DESC LIMIT %d", $user_id, $limit ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		if ( ! $rows ) {
			return array();
		}

		$out = array();
		foreach ( $rows as $row ) {
			$title = '';
			foreach ( array( 'title', 'label', 'name', 'text', 'note', 'body' ) as $column ) {
				if ( ! empty( $row[ $column ] ) ) {
					$title = (string) $row[ $column ];
					break;
				}
			}
			$when = '';
			foreach ( array( 'remind_at', 'at', 'time', 'when', 'note_time' ) as $column ) {
				if ( ! empty( $row[ $column ] ) ) {
					$when = (string) $row[ $column ];
					break;
				}
			}
			if ( strlen( $when ) > 5 ) {
				$stamp = strtotime( $when );
				$when  = $stamp ? date_i18n( 'H:i', $stamp ) : $when;
			}
			$when = substr( str_replace( array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹' ), array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ), $when ), 0, 5 );

			$out[] = array(
				'title' => $title ? $title : 'یادآور بدون عنوان',
				'when'  => $when,
			);
		}
		return $out;
	}

	/* ---------------------------------------------------------------- data */

	/** Recorded actions per calendar day, newest 60 days. */
	private static function usage_by_day( int $user_id ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'usage' );
		$start = ( new DateTimeImmutable( 'today', wp_timezone() ) )
			->modify( '-59 days' )
			->format( 'Y-m-d H:i:s' );
		$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT DATE(created_at) AS d, COUNT(*) AS c FROM {$table} WHERE user_id = %d AND created_at >= %s GROUP BY DATE(created_at)", // phpcs:ignore WordPress.DB
				$user_id,
				$start
			),
			ARRAY_A
		);
		$out = array();
		foreach ( (array) $rows as $row ) {
			$out[ (string) $row['d'] ] = (int) $row['c'];
		}
		return $out;
	}

	/** How many actions in the last N days. */
	public static function usage_count( int $user_id, int $days ) : int {
		global $wpdb;
		$table = Niva_DB::table( 'usage' );
		$start = ( new DateTimeImmutable( 'today', wp_timezone() ) )
			->modify( '-' . max( 0, $days - 1 ) . ' days' )
			->format( 'Y-m-d H:i:s' );
		return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND created_at >= %s", $user_id, $start ) // phpcs:ignore WordPress.DB
		);
	}

	/** Open (not done) reminders. */
	public static function open_reminders( int $user_id ) : int {
		global $wpdb;
		$table = Niva_DB::table( 'reminders' );
		return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND done = 0", $user_id ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * The week board: one row per activity kind, one column per day.
	 *
	 * @return array ['days' => [...], 'rows' => [ ['label' => ..., 'cells' => [7 ints]] ]]
	 */
	public static function kind_week( int $user_id ) : array {
		$labels = array( 'ش', 'ی', 'د', 'س', 'چ', 'پ', 'ج' );
		$today  = new DateTimeImmutable( 'today', wp_timezone() );
		$days   = array();

		for ( $i = 6; $i >= 0; $i-- ) {
			$date         = $today->modify( '-' . $i . ' days' );
			$key          = $date->format( 'Y-m-d' );
			$days[ $key ] = array( 'key' => $key, 'label' => $labels[ Niva_Chrome::weekday_index( $date->getTimestamp() ) ] );
		}

		$names = array(
			'chat'  => 'گفت‌وگو با مشاور',
			'lab'   => 'تحلیل آزمایش',
			'image' => 'تصویر و سونوگرافی',
			'other' => 'سایر',
		);

		global $wpdb;
		$table = Niva_DB::table( 'usage' );
		$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT kind, DATE(created_at) AS d, COUNT(*) AS c FROM {$table} WHERE user_id = %d AND created_at >= %s GROUP BY kind, DATE(created_at)", // phpcs:ignore WordPress.DB
				$user_id,
				$today->modify( '-6 days' )->format( 'Y-m-d H:i:s' )
			),
			ARRAY_A
		);

		$by_kind = array();
		foreach ( (array) $rows as $row ) {
			$kind                = (string) $row['kind'];
			$bucket              = isset( $names[ $kind ] ) ? $kind : 'other';
			$by_kind[ $bucket ][ (string) $row['d'] ] = (int) $row['c'];
		}

		$out = array();
		foreach ( array( 'chat', 'lab', 'image', 'other' ) as $kind ) {
			if ( empty( $by_kind[ $kind ] ) ) {
				continue;
			}
			$cells = array();
			foreach ( $days as $key => $day ) {
				$cells[] = isset( $by_kind[ $kind ][ $key ] ) ? (int) $by_kind[ $kind ][ $key ] : 0;
			}
			$out[] = array( 'label' => $names[ $kind ], 'cells' => $cells );
		}

		return array( 'days' => array_values( $days ), 'rows' => $out );
	}

	/** Persian digits, delegated so the numeral setting keeps working. */
	private static function fa( $value ) : string {
		return Niva_Chrome::digits( number_format_i18n( $value ) );
	}
}
