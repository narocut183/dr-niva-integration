<?php
/**
 * Medical safety layer.
 *
 * Three independent guards, in this order:
 *   1. a locked system prompt (no prescribing, no dosage, no diagnosis)
 *   2. a deterministic reply filter (regex + phrase lists) that runs on the
 *      text a model returned — it does not rely on the model behaving
 *   3. a review queue for anything that got flagged
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Safety {

	/** The locked instruction set sent as the system message. */
	public function system_prompt( string $topic_title = '', string $tone = 'warm_plain' ) : string {
		$settings = dr_niva()->settings;
		$lines    = array();

		$lines[] = 'تو «همراه سلامت» هستی: همدل، ساده‌گو و صادق درباره‌ی محدودیت‌هایت.';
		$lines[] = 'اگر کاربر پرسید چه کسی هستی یا از چه مدلی استفاده می‌کنی، خودت را «دستیار هوشمند دکتر نیوا» معرفی کن و بگو از مدل هوش مصنوعی تنظیم‌شده در این سایت استفاده می‌کنی؛ خودت را ChatGPT یا محصول شرکت دیگری معرفی نکن و دربارهٔ سازنده حدس نزن.';
		if ( '' !== $topic_title ) {
			$lines[] = 'موضوع گفت‌وگو: ' . $topic_title . '.';
		}

		$lines[] = 'قواعد سخت (هیچ استثنایی ندارند):';
		if ( $settings->is_on( 'safety_no_prescribing' ) ) {
			$lines[] = '- هیچ دارویی تجویز نکن، دوز تعیین نکن، مصرف را کم یا زیاد یا قطع نکن و نگو «این را بخور».';
		}
		if ( $settings->is_on( 'safety_no_dosage' ) ) {
			$lines[] = '- هیچ مقدار، میلی‌گرم، تعداد قرص، تعداد دفعات مصرف یا بازه‌ی زمانی مصرف را ذکر نکن؛ حتی به‌صورت مثال.';
		}
		if ( $settings->is_on( 'safety_no_diagnosis' ) ) {
			$lines[] = '- تشخیص قطعی نده و نگو «تو فلان بیماری را داری». پاسخ را روشن و کاربردی نگه دار و فقط وقتی واقعاً لازم است، پیگیری تخصصی را پیشنهاد کن؛ هشدار ثابت و تکراری به همهٔ پاسخ‌ها اضافه نکن.';
		}
		if ( $settings->is_on( 'safety_drug_explain' ) ) {
			$lines[] = '- اگر کاربر درباره‌ی یک دارو پرسید، فقط توضیح بده: این دارو به‌طور کلی چه کاری می‌کند، برای چه گروهی تجویز می‌شود و چه نکات عمومی‌ای دارد. در پایان همان پاسخ، این جمله را عیناً بنویس: «' . $settings->get( 'safety_drug_referral' ) . '»';
		}
		if ( $settings->is_on( 'safety_food_tips' ) ) {
			$lines[] = '- پیشنهاد میوه، سبزی، غذاهای ساده و عادت‌های غذایی سالم آزاد است، ولی هیچ ادعای درمانی برای غذاها مطرح نکن.';
		}
		if ( $settings->is_on( 'safety_medical_footer' ) ) {
			$lines[] = '- در پاسخ‌های پزشکی، در پایان این جمله را بنویس: «' . $settings->get( 'safety_medical_footer' ) . '»';
		}
		$lines[] = '- اگر نشانه‌ی خطر (خونریزی، تنگی نفس، تب نوزاد زیر سه ماه، افکار آسیب به خود) شنیدی، کاربر را به مراجعه‌ی فوری ارجاع بده.';
		$lines[] = '- وقتی مطمئن نیستی، بگو مطمئن نیستی. عدد، آمار یا منبع از خودت نساز.';

		switch ( $tone ) {
			case 'clinical':
				$lines[] = 'سبک: کوتاه، دقیق و بی‌حاشیه؛ حداکثر ۳ جمله در هر پاسخ.';
				break;
			case 'friendly':
				$lines[] = 'سبک: صمیمی و ساده با جملات کوتاه؛ بدون اصطلاح تخصصی.';
				break;
			default:
				$lines[] = 'سبک: آرام، همدل و ساده؛ اول یک جمله‌ی همدلی، بعد یک یا دو قدم عملی.';
		}

		$lines[] = 'زبان پاسخ همان زبان پیام کاربر باشد (پیش‌فرض فارسی).';

		return implode( "\n", $lines );
	}

	/** Reads the incoming user message before it is sent to a model. */
	public function inspect_user_message( string $text ) : array {
		return array(
			'risk'        => $this->hits( $text, dr_niva()->settings->as_list( 'safety_risk_phrases' ) ),
			'drug'        => $this->hits( $text, dr_niva()->settings->as_list( 'safety_drug_names' ) ),
			'asked_dose'  => $this->dose_hits( $text ),
		);
	}

	/**
	 * Deterministic post-filter on the model reply.
	 *
	 * @return array{text:string,flags:array<int,string>,blocked:bool}
	 */
	public function filter_reply( string $text, array $context = array() ) : array {
		$settings = dr_niva()->settings;
		$flags    = array();
		$out      = $text;

		// 1) dosage patterns -> drop the offending sentence
		if ( $settings->is_on( 'safety_no_dosage' ) ) {
			$patterns = $this->dose_patterns();
			if ( $patterns ) {
				$before = $out;
				$out    = $this->strip_sentences(
					$out,
					function ( $sentence ) use ( $patterns ) {
						foreach ( $patterns as $pattern ) {
							if ( preg_match( $pattern, $sentence ) ) {
								return true;
							}
						}
						return false;
					}
				);
				if ( $before !== $out ) {
					$flags[] = 'dosage_removed';
				}
			}
		}

		// 2) forbidden phrases -> drop the offending sentence
		$blocked = $settings->as_list( 'safety_blocked_phrases' );
		if ( $blocked ) {
			$before = $out;
			$out    = $this->strip_sentences(
				$out,
				function ( $sentence ) use ( $blocked ) {
					foreach ( $blocked as $phrase ) {
						if ( '' !== $phrase && false !== mb_strpos( $sentence, $phrase ) ) {
							return true;
						}
					}
					return false;
				}
			);
			if ( $before !== $out ) {
				$flags[] = 'forbidden_phrase_removed';
			}
		}

		// 3) drug talk -> always append the referral sentence
		$drug_context = ! empty( $context['drug'] ) || $this->hits( $out, $settings->as_list( 'safety_drug_names' ) );
		if ( $drug_context ) {
			$referral = (string) $settings->get( 'safety_drug_referral' );
			if ( '' !== $referral && false === mb_strpos( $out, $referral ) ) {
				$out    .= "\n\n" . $referral;
				$flags[] = 'drug_referral_appended';
			}
		}

		// 4) medical answers always close with the disclaimer
		$footer = (string) $settings->get( 'safety_medical_footer' );
		if ( ! empty( $context['medical'] ) && '' !== $footer && false === mb_strpos( $out, $footer ) ) {
			$out    .= "\n\n" . $footer;
			$flags[] = 'disclaimer_appended';
		}

		if ( trim( $out ) === '' ) {
			$out = 'برای این سؤال نمی‌توانم پاسخ مطمئنی بدهم. بهترین کار این است که این مورد را با پزشک یا روان‌شناس خودت در میان بگذاری.';
			$flags[] = 'emptied_by_filter';
		}

		if ( $flags && $settings->is_on( 'safety_review_queue' ) ) {
			$this->queue_review( $out, $flags, $context );
		}

		return array(
			'text'    => $out,
			'flags'   => $flags,
			'blocked' => in_array( 'emptied_by_filter', $flags, true ),
		);
	}

	/** The text shown when a user is in crisis. */
	public function crisis_message() : string {
		$lines = array();
		foreach ( $this->helplines() as $line ) {
			$lines[] = $line['title'] . ': ' . $line['number'];
		}
		$body = 'نگرانم درباره‌ی چیزی که نوشتی و نمی‌خواهم از آن سریع بگذرم. اگر همین حالا به فکر آسیب رساندن به خودت هستی، همین حالا با یکی از این خطوط تماس بگیر و از یک فرد مورد اعتماد بخواه کنارت باشد:';
		return $body . "\n" . implode( "\n", $lines ) . "\n" . 'این گفت‌وگو جای کمک فوری نیست.';
	}

	/** Helplines configured by the site owner. */
	public function helplines() : array {
		$rows = dr_niva()->settings->as_rows( 'safety_helplines' );
		$out  = array();
		foreach ( $rows as $row ) {
			if ( empty( $row[0] ) ) {
				continue;
			}
			$out[] = array(
				'title'  => $row[0],
				'number' => isset( $row[1] ) ? $row[1] : '',
				'note'   => isset( $row[2] ) ? $row[2] : '',
			);
		}
		return $out;
	}

	/** @return array<int,string> matched needles */
	private function hits( string $text, array $needles ) : array {
		$found = array();
		foreach ( $needles as $needle ) {
			$needle = trim( (string) $needle );
			if ( '' === $needle ) {
				continue;
			}
			if ( false !== mb_strpos( mb_strtolower( $text ), mb_strtolower( $needle ) ) ) {
				$found[] = $needle;
			}
		}
		return $found;
	}

	/** @return array<int,string> */
	private function dose_patterns() : array {
		$raw   = (string) dr_niva()->settings->get( 'safety_dose_patterns', '' );
		$lines = preg_split( '/\r\n|\r|\n/', $raw );
		$out   = array();
		foreach ( $lines as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$delimiter = '#' . uniqid() . '#';
			$regex     = $delimiter . $line . $delimiter . 'u';
			if ( false !== @preg_match( $regex, '' ) ) { // phpcs:ignore
				$out[] = $regex;
			}
		}
		return $out;
	}

	private function dose_hits( string $text ) : array {
		$hits = array();
		foreach ( $this->dose_patterns() as $pattern ) {
			if ( preg_match( $pattern, $text, $m ) ) {
				$hits[] = $m[0];
			}
		}
		return $hits;
	}

	/** Removes every sentence for which the predicate returns true. */
	private function strip_sentences( string $text, callable $predicate ) : string {
		$parts = preg_split( '/(?<=[.!?؟؛\n])\s*/u', $text );
		if ( ! is_array( $parts ) ) {
			return $text;
		}
		$kept = array();
		foreach ( $parts as $part ) {
			if ( '' === trim( $part ) ) {
				continue;
			}
			if ( ! $predicate( $part ) ) {
				$kept[] = $part;
			}
		}
		return trim( implode( ' ', $kept ) );
	}

	private function queue_review( string $text, array $flags, array $context ) : void {
		global $wpdb;
		$wpdb->insert(
			Niva_DB::table( 'reviews' ),
			array(
				'user_id'    => isset( $context['user_id'] ) ? (int) $context['user_id'] : 0,
				'ref'        => isset( $context['ref'] ) ? (string) $context['ref'] : '',
				'reason'     => implode( ',', $flags ),
				'payload'    => wp_json_encode(
					array(
						'reply'    => $text,
						'question' => isset( $context['question'] ) ? (string) $context['question'] : '',
						'provider' => isset( $context['provider'] ) ? (string) $context['provider'] : '',
					)
				),
				'status'     => 'open',
				'created_at' => current_time( 'mysql' ),
			),
			array( '%d', '%s', '%s', '%s', '%s', '%s' )
		);
	}
}
