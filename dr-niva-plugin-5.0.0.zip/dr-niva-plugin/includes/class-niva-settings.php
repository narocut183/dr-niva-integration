<?php
/**
 * Settings registry.
 *
 * Every switch of the product lives here: one option row (array) with typed
 * defaults, so the admin page, the REST layer and the front-end all read from
 * the same source of truth.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Settings {

	/** @var array|null */
	private $cache = null;

	/** Groups with every field of the plugin (label, type, default). */
	public static function groups() : array {
		return array(
			'notifications' => array(
				'label'  => 'اعلان و پوش',
				'fields' => array(
					'push_enabled'    => array( 'label' => 'پوش‌نوتیفیکیشن فعال باشد', 'type' => 'toggle', 'default' => 1 ),
					'vapid_public'    => array( 'label' => 'کلید عمومی VAPID', 'type' => 'text', 'default' => '', 'hint' => 'به‌صورت خودکار ساخته می‌شود؛ برای ارسال پوش پس‌زمینه، سرویس رمزنگاری Web Push نیز باید از طریق افزونه/فیلتر فرستنده نصب شود.' ),
					'vapid_private'   => array( 'label' => 'کلید خصوصی VAPID', 'type' => 'secret', 'default' => '' ),
					'notify_channels' => array( 'label' => 'کانال‌های پیش‌فرض', 'type' => 'checks', 'default' => array( 'inapp' => 1, 'push' => 1, 'email' => 0 ), 'options' => array( 'inapp' => 'داخل برنامه', 'push' => 'پوش مرورگر', 'email' => 'ایمیل' ) ),
					'reminder_lead'   => array( 'label' => 'چند دقیقه قبل از یادآور خبر بدهد', 'type' => 'number', 'default' => 0 ),
					'daily_digest'    => array( 'label' => 'ارسال خلاصه‌ی روزانه', 'type' => 'toggle', 'default' => 0 ),
				),
			),
			'feature_access' => array(
				'label'  => 'قفل پیشرفتهٔ امکانات',
				'fields' => array(
					'feature_plan_gates' => array(
						'label'   => 'دسترسی امکانات بر اساس پلن',
						'type'    => 'feature_gates',
						'default' => '',
						'hint'    => 'برای هر امکان، پلن‌های مجاز را انتخاب کن. برداشتن همهٔ گزینه‌ها، امکان را برای همهٔ پلن‌ها قفل می‌کند؛ محدودیت تعداد مصرف در بخش پلن‌ها جداگانه تنظیم می‌شود.',
					),
				),
			),
			'app_push' => array(
				'label'  => 'پوش اپلیکیشن (اندروید و iOS)',
				'fields' => array(
					'app_push_enabled' => array( 'label' => 'پوش اپ فعال باشد', 'type' => 'toggle', 'default' => 1 ),
					'push_fcm_key'     => array( 'label' => 'کلید سرور FCM', 'type' => 'secret', 'default' => '', 'hint' => 'از پنل Firebase > Cloud Messaging بردار و اینجا بگذار. بدون آن، پوش اپ ارسال نمی‌شود ولی اعلان داخل برنامه کار می‌کند.' ),
					'push_fcm_endpoint' => array( 'label' => 'آدرس سرویس ارسال', 'type' => 'text', 'default' => 'https://fcm.googleapis.com/fcm/send' ),
					'app_min_version'  => array( 'label' => 'کمترین نسخه‌ی پشتیبانی‌شده‌ی اپ', 'type' => 'text', 'default' => '1.0.0' ),
				),
			),
			'partners' => array(
				'label'  => 'برنامه‌ی همکاران',
				'fields' => array(
					'partners_enabled'   => array( 'label' => 'ثبت‌نام همکاری فعال باشد', 'type' => 'toggle', 'default' => 1 ),
					'partner_commission' => array( 'label' => 'درصد پورسانت پیش‌فرض', 'type' => 'number', 'default' => 15, 'hint' => 'درصدی از مبلغ سفارش‌های کاربران معرفی‌شده.' ),
					'partner_plan'       => array( 'label' => 'پلنی که همکار تأییدشده رایگان می‌گیرد', 'type' => 'select', 'default' => 'partner', 'options' => array( 'partner' => 'پلن همکاران', 'clinic' => 'کلینیکی و همکاران', 'family' => 'خانوادگی', 'plus' => 'پلاس', 'free' => 'رایگان' ) ),
					'partner_gets_plan'  => array( 'label' => 'به همکار تأییدشده اشتراک داده شود', 'type' => 'toggle', 'default' => 1 ),
					'partner_plan_title' => array( 'label' => 'عنوان پلن همکاران در سایت', 'type' => 'text', 'default' => 'پلن همکاران دکتر نیوا', 'hint' => 'همین عنوان روی کارت پلن همکاران در صفحه‌ی «همکاری با ما» نشان داده می‌شود.' ),
					'partner_plan_days'  => array( 'label' => 'مدت اعتبار پلن همکاران (روز)', 'type' => 'number', 'default' => 0, 'hint' => '۰ یعنی بدون تاریخ انقضا (تا وقتی خودت خاموشش کنی). عدد بزرگ‌تر یعنی اعتبار موقت.' ),
					'partner_plan_note'  => array( 'label' => 'توضیح کوتاه زیر عنوان پلن همکاران', 'type' => 'textarea', 'rows' => 3, 'default' => 'برای کلینیک، مطب، داروخانه، آزمایشگاه و تولیدکنندگان محتوای سلامت؛ همه‌ی امکانات حرفه‌ای بدون هزینه، تا وقتی همکاری فعال است.' ),
					'partner_plan_perks' => array( 'label' => 'مزایای پلن همکاران (هر خط یک مورد)', 'type' => 'textarea', 'rows' => 7, 'default' => "دسترسی کامل به مشاور هوشمند بدون سقف\nپورسانت از سفارش کاربران معرفی‌شده\nکد و لینک معرف اختصاصی + پنل آمار\nپرونده‌ی خانوادگی با ۴ صندلی\nخروجی PDF و بازبینی نتیجه توسط تیم پزشکی\nپشتیبانی مستقیم تیم دکتر نیوا" ),
					'partner_plan_cta'   => array( 'label' => 'متن دکمه‌ی پلن همکاران', 'type' => 'text', 'default' => 'درخواست فعال‌سازی پلن همکاران' ),
					'partner_types'      => array( 'label' => 'انواع همکاری (هر خط یک مورد)', 'type' => 'textarea', 'rows' => 6, 'default' => "clinic = کلینیک و مطب\npharmacy = داروخانه\nlab = آزمایشگاه\ncontent = تولید محتوا و اینفلوئنسر\nmidwife = مامایی و مشاور شیردهی\nnutrition = تغذیه" ),
				),
			),
			'links' => array(
				'label'  => 'نشانی صفحه‌ها (لینک‌ها)',
				'fields' => Niva_Links::settings_fields(),
			),
			'chrome' => array(
				'label'  => 'هدر، فوتر و نوار پایین',
				'fields' => array(
					'chrome_header'               => array( 'label' => 'هدر دکتر نیوا', 'type' => 'select', 'default' => 'auto', 'options' => array( 'auto' => 'خودکار در همهٔ صفحه‌های غیرالمنتوری', 'widgets' => 'خودکار در همهٔ صفحه‌های غیرالمنتوری (تنظیم قدیمی)', 'off' => 'خاموش' ), 'hint' => 'صفحه‌های ساخته‌شده با Elementor و صفحه‌های خود اپ مستثنا هستند تا هدر تکراری نشود. برای خاموش‌کردن هدر خودکار، «خاموش» را انتخاب کن.' ),
					'chrome_footer'               => array( 'label' => 'فوتر اپ', 'type' => 'select', 'default' => 'auto', 'options' => array( 'auto' => 'خودکار در همه صفحات', 'widgets' => 'فقط ویجت المنتور', 'off' => 'خاموش' ) ),
					'chrome_dock'                 => array( 'label' => 'نوار پایین موبایل', 'type' => 'select', 'default' => 'auto', 'hint' => 'در حالت خودکار، در همه‌ی صفحات سایت نمایش داده می‌شود.', 'options' => array( 'auto' => 'خودکار در همه صفحات', 'widgets' => 'فقط ویجت المنتور', 'off' => 'خاموش' ) ),
					'hide_plugin_footer_with_theme' => array( 'label' => 'اگر قالب فوتر دارد، فوتر افزونه خاموش شود', 'type' => 'toggle', 'default' => 1, 'hint' => 'توصیه‌شده: از فوتر تکراری جلوگیری می‌کند.' ),
				),
			),
			'branding'  => array(
				'label'  => 'برند، لوگو و هدر/فوتر',
				'fields' => array(
					'brand_logo_id'      => array( 'label' => 'لوگوی برند', 'type' => 'media', 'default' => 0, 'hint' => 'لوگو را از کتابخانهٔ رسانه انتخاب کن؛ اگر انتخاب نشود، آدرس لوگوی جایگزین یا لوگوی قالب استفاده می‌شود.' ),
					'brand_logo_url'     => array( 'label' => 'یا آدرس مستقیم لوگو', 'type' => 'text', 'default' => '' ),
					// 5.0.0 — «Niva Blue» palette, matched to the approved app design.
					'brand_color'        => array( 'label' => 'رنگ اصلی برند', 'type' => 'color', 'default' => '#0878E8', 'hint' => 'این رنگ روی همه‌ی دکمه‌ها، لینک‌ها و نوارهای تأکید سایت اعمال می‌شود.' ),
					'brand_color_2'      => array( 'label' => 'رنگ فرعی برند', 'type' => 'color', 'default' => '#4FA8F5' ),
					'brand_color_3'      => array( 'label' => 'رنگ مکمل/ملایم برند', 'type' => 'color', 'default' => '#DDF7EC' ),
					'theme_harmonize'    => array( 'label' => 'هم‌رنگ‌کردن هدر، دکمه‌ها و فوتر قالب با رنگ برند', 'type' => 'toggle', 'default' => 1, 'hint' => 'دکمه‌ها، لینک‌ها، تیتر برگه و پس‌زمینه‌ی هدر/فوتر قالبِ فعال را به همان سه رنگ برند می‌آورد تا سایت یک‌دست دیده شود. اگر با قالب دیگری به‌هم ریخت، خاموشش کن.' ),
					'theme_hide_title'    => array( 'label' => 'پنهان‌کردن تیتر برگه‌ی قالب روی صفحه‌های افزونه', 'type' => 'toggle', 'default' => 1, 'hint' => 'قالب تیتر برگه را روی لوگو می‌انداخت؛ افزونه سربرگ خودش را دارد. اگر تیتر برگه را لازم داری، خاموشش کن.' ),
					'chrome_position'    => array( 'label' => 'جای هدر اپ', 'type' => 'select', 'default' => 'top', 'options' => array( 'top' => 'بالای صفحه', 'bottom' => 'پایین صفحه (شبیه اپ)' ) ),
					'use_theme_header'   => array( 'label' => 'استفاده از هدر/فوتر قالب', 'type' => 'toggle', 'default' => 1, 'hint' => 'اگر خاموش باشد، هدر و فوتر قالب پنهان می‌شود تا اپ تمام‌صفحه دیده شود.' ),
					'header_menu_source' => array( 'label' => 'منبع منوی هدر', 'type' => 'select', 'default' => 'plugin', 'options' => array( 'plugin' => 'منوی پیش‌فرض اپ', 'wp' => 'منوی وردپرس (نمایش > فهرست‌ها)' ) ),
					'footer_note'        => array( 'label' => 'متن پایین سایت', 'type' => 'textarea', 'default' => '' ),
				),
			),
			'general'   => array(
				'label'  => 'عمومی',
				'fields' => array(
					'enabled'              => array( 'label' => 'فعال بودن کل افزونه', 'type' => 'toggle', 'default' => 1 ),
					'brand_name'           => array( 'label' => 'نام سرویس', 'type' => 'text', 'default' => 'دکتر نیوا' ),
					'brand_tagline'        => array( 'label' => 'شعار', 'type' => 'text', 'default' => 'همراه سلامت شما' ),
					'locale_mode'          => array( 'label' => 'زبان رابط', 'type' => 'select', 'default' => 'fa', 'options' => array( 'fa' => 'فارسی', 'bi' => 'دوزبانه' ) ),
					'numeral_style'        => array( 'label' => 'نمایش اعداد', 'type' => 'select', 'default' => 'fa', 'options' => array( 'fa' => 'فارسی', 'latin' => 'لاتین' ) ),
					'after_login_redirect' => array( 'label' => 'مسیر پیش‌فرض پس از ورود', 'type' => 'text', 'default' => 'home' ),
					'keep_data_on_uninstall' => array( 'label' => 'نگه‌داشتن داده پس از حذف افزونه', 'type' => 'toggle', 'default' => 0 ),
				),
			),
			'layout'    => array(
				'label'  => 'چیدمان و ماژول‌ها',
				'fields' => array(
					'viewer_show_in_webview' => array( 'label' => 'نمایش در حالت وب‌ویو', 'type' => 'toggle', 'default' => 1 ),
					'viewer_guest_modules'   => array( 'label' => 'نشانی ماژول‌های عمومی به مهمان', 'type' => 'text', 'default' => 'about,faq,plans' ),
					'viewer_use_theme_header' => array( 'label' => 'استفاده از هدر/فوتر قالب سایت', 'type' => 'toggle', 'default' => 1, 'hint' => 'اگر خاموش باشد، افزونه تلاش می‌کند هدر و فوتر قالب را پنهان کند تا اپ تمام‌صفحه دیده شود. توصیه: صفحه را با قالب «تمام‌عرض / بدون عنوان» بساز.' ),
				),
			),
			'account'   => array(
				'label'  => 'حساب کاربری و دسترسی',
				'fields' => array(
					'login_otp'            => array( 'label' => 'ورود با موبایل (کد یک‌بارمصرف)', 'type' => 'toggle', 'default' => 1 ),
					'login_password'       => array( 'label' => 'ورود با ایمیل و رمز', 'type' => 'toggle', 'default' => 1 ),
					'require_verified'     => array( 'label' => 'الزام تایید شماره موبایل', 'type' => 'toggle', 'default' => 1 ),
					'login_google'         => array( 'label' => 'ورود با گوگل', 'type' => 'toggle', 'default' => 0 ),
					'signup_bonus'         => array( 'label' => 'هدیه‌ی ثبت‌نام (اعتبار)', 'type' => 'number', 'default' => 50 ),
					'allow_delete_account' => array( 'label' => 'امکان حذف حساب توسط کاربر', 'type' => 'toggle', 'default' => 1 ),
				),
			),
			'credits'   => array(
				'label'  => 'اعتبار، سهمیه و بسته‌ها',
				'fields' => array(
					'credits_enabled'      => array( 'label' => 'فعال بودن سیستم اعتبار', 'type' => 'toggle', 'default' => 1 ),
					'free_daily_quota'     => array( 'label' => 'سهمیه‌ی رایگان روزانه (پیام)', 'type' => 'number', 'default' => 5 ),
					'quota_reset_hour'     => array( 'label' => 'ساعت بازنشانی سهمیه', 'type' => 'time', 'default' => '00:00' ),
					'cost_message'         => array( 'label' => 'هزینه‌ی هر پیام مشاور', 'type' => 'number', 'default' => 1 ),
					'cost_lab_report'      => array( 'label' => 'هزینه‌ی تحلیل یک گزارش آزمایش', 'type' => 'number', 'default' => 5 ),
					'cost_image_analysis'  => array( 'label' => 'هزینه‌ی تحلیل تصویر (سونوگرافی/رادیولوژی)', 'type' => 'number', 'default' => 3 ),
					'cost_summary'         => array( 'label' => 'هزینه‌ی خلاصه‌سازی گزارش', 'type' => 'number', 'default' => 2 ),
					'cost_pdf'             => array( 'label' => 'هزینه‌ی خروجی PDF', 'type' => 'number', 'default' => 1 ),
					'ai_input_credits_per_1k_tokens' => array( 'label' => 'هزینهٔ اعتبار هر ۱۰۰۰ توکن ورودی AI', 'type' => 'number', 'default' => 0, 'hint' => 'بر اساس تعرفهٔ واقعی API، نرخ تبدیل ارز و حاشیهٔ امن تنظیم شود؛ صفر یعنی استفاده از هزینهٔ ثابت هر پیام.' ),
					'ai_output_credits_per_1k_tokens' => array( 'label' => 'هزینهٔ اعتبار هر ۱۰۰۰ توکن خروجی AI', 'type' => 'number', 'default' => 0, 'hint' => 'بر اساس تعرفهٔ واقعی API، نرخ تبدیل ارز و حاشیهٔ امن تنظیم شود؛ صفر یعنی استفاده از هزینهٔ ثابت هر پیام.' ),
					'low_balance_threshold' => array( 'label' => 'آستانه‌ی هشدار «اعتبار کم»', 'type' => 'number', 'default' => 10 ),
					'exhausted_message'    => array( 'label' => 'پیام پایان اعتبار', 'type' => 'text', 'default' => 'اعتبارت تموم شده؛ برای ادامه شارژش کن.' ),
					'refund_on_ai_error'   => array( 'label' => 'بازگشت خودکار اعتبار در خطای سرویس', 'type' => 'toggle', 'default' => 1 ),
					'referral_bonus'       => array( 'label' => 'هدیه‌ی معرفی دوستان (هر طرف)', 'type' => 'number', 'default' => 20 ),
					'packages'             => array( 'label' => 'بسته‌های اعتبار (اعتبار | قیمت تومان)', 'type' => 'rows', 'default' => array( array( 100, 50000 ), array( 500, 200000 ), array( 1200, 450000 ) ) ),
					'allow_custom_package' => array( 'label' => 'بسته‌ی دلخواه توسط کاربر', 'type' => 'toggle', 'default' => 1 ),
					'credit_notify_thresholds' => array( 'label' => 'اعلان کمبود اعتبار در درصدهای (list)', 'type' => 'list', 'default' => '80,100', 'hint' => 'مثلاً 80,100 یعنی در ۸۰٪ و ۱۰۰٪ مصرف به کاربر خبر بده.' ),
					'quota_notify_on_empty'     => array( 'label' => 'اعلان پایان سهمیهٔ روزانه و شروع مصرف اعتبار', 'type' => 'toggle', 'default' => 1, 'hint' => 'پیش از کسر از کیف پول، به کاربر اعلام و تأیید گرفته می‌شود.' ),
				),
			),
			'ai'        => array(
				'label'  => 'هوش مصنوعی',
				'fields' => array(
					'ai_key_gapgpt'      => array( 'label' => 'کلید API گپ‌جی‌پی‌تی', 'type' => 'secret', 'default' => '', 'hint' => 'کلید را از پنل API گپ‌جی‌پی‌تی بساز و اینجا وارد کن. همهٔ درخواست‌های چت و تصویر از مسیر api.gapgpt.app ارسال می‌شوند؛ کلید فقط روی سرور می‌ماند.' ),
					'ai_model_chat'      => array( 'label' => 'مدل چت (GapGPT)', 'type' => 'text', 'default' => 'gpt-6-luna', 'hint' => 'پیش‌فرض gpt-6-luna از مدل‌های GPT میزبانی‌شده در GapGPT و گزینهٔ سریع و اقتصادی کاتالوگ آن‌هاست. شناسه باید در حساب API فعال باشد.' ),
					'ai_model_vision'    => array( 'label' => 'مدل تحلیل تصویر آزمایش (GapGPT)', 'type' => 'text', 'default' => 'gpt-6-luna', 'hint' => 'مدل باید ورودی تصویر داشته باشد. gpt-6-luna در کاتالوگ فعلی GapGPT ورودی متن و تصویر و API چت را اعلام می‌کند.' ),
					'ai_tone'            => array( 'label' => 'لحن پاسخ چت', 'type' => 'select', 'default' => 'warm_plain', 'options' => array( 'warm_plain' => 'همدل و ساده', 'clinical' => 'بالینی و کوتاه', 'friendly' => 'دوستانه و صمیمی' ) ),
					'ai_memory_messages' => array( 'label' => 'تعداد پیام‌های قبلی در زمینهٔ چت', 'type' => 'number', 'default' => 10 ),
					'ai_max_tokens'      => array( 'label' => 'حداکثر طول پاسخ چت', 'type' => 'number', 'default' => 800 ),
					'ai_temperature'     => array( 'label' => 'تنوع پاسخ چت (۰ تا ۱)', 'type' => 'text', 'default' => '0.4' ),
					'ai_rate_per_minute' => array( 'label' => 'سقف پیام هر کاربر در دقیقه', 'type' => 'number', 'default' => 10 ),
					'log_conversations'  => array( 'label' => 'ثبت گفت‌وگو برای تاریخچهٔ کاربر', 'type' => 'toggle', 'default' => 1 ),
					'retention_chat_days' => array( 'label' => 'مدت نگهداری تاریخچه (روز)', 'type' => 'number', 'default' => 90 ),
					'timeout_seconds'    => array( 'label' => 'مهلت پاسخ سرویس (ثانیه)', 'type' => 'number', 'default' => 45 ),
				),
			),
			'safety'    => array(
				'label'  => 'ایمنی پزشکی',
				'fields' => array(
					'safety_no_prescribing'   => array( 'label' => 'ممنوعیت تجویز دارو (پیشنهاد می‌شود قفل بماند)', 'type' => 'toggle', 'default' => 1, 'locked' => 1 ),
					'safety_no_dosage'        => array( 'label' => 'ممنوعیت ذکر دوز و مقدار', 'type' => 'toggle', 'default' => 1, 'locked' => 1 ),
					'safety_no_diagnosis'     => array( 'label' => 'ممنوعیت تشخیص قطعی', 'type' => 'toggle', 'default' => 1, 'locked' => 1 ),
					'safety_drug_explain'     => array( 'label' => 'اجازه‌ی توضیح «این دارو چیست»', 'type' => 'toggle', 'default' => 1 ),
					'safety_drug_referral'    => array( 'label' => 'جمله‌ی الزامی هنگام پرسش دارو', 'type' => 'text', 'default' => 'برای مصرف این دارو حتماً به پزشک مراجعه کن.' ),
					'safety_food_tips'        => array( 'label' => 'پیشنهاد میوه و غذای سالم', 'type' => 'toggle', 'default' => 1 ),
					'safety_medical_footer'   => array( 'label' => 'جمله‌ی اختیاری پایان پاسخ پزشکی', 'type' => 'text', 'default' => '' ),
					'safety_blocked_phrases'  => array( 'label' => 'فهرست واژه‌های ممنوع پاسخ', 'type' => 'list', 'default' => 'قطع کن,دو برابر کن,نصف کن,خودت تجویز,بدون نسخه مصرف کن,مصرف را افزایش بده' ),
					'safety_dose_patterns'    => array( 'label' => 'الگوهای دوز (Regex، هر خط یکی)', 'type' => 'lines', 'default' => "\\d+\\s*(mg|میلی\\s*گرم|گرم|میکروگرم|واحد|عدد|قرص|سی\\s*سی|قطره)\\s*(در روز|روزانه|هر\\s*\\d+\\s*ساعت)?\nروزی\\s*\\d+\\s*(بار|عدد|قرص)\n(هر|تا)\\s*\\d+\\s*(ساعت|روز)\\s*یک\\s*(قرص|عدد)" ),
					'safety_drug_names'       => array( 'label' => 'نام داروهای شناخته‌شده (برای افزودن جمله‌ی ارجاع)', 'type' => 'list', 'default' => 'استامینوفن,ژلوفن,ایبوپروفن,دیکلوفناک,ناپروکسن,آسپرین,متformin,متفورمین,انسولین,لووتیروکسین,آهن,فروسسولفات,فولیک اسید,ویتامین د,آملودیپین,لوزارتان,متوپرولول,سرترالین,فلوکستین,رتالین,آلپرازولام,پروژسترون,اکسی‌توسین,کلوماید,لتروزول,آنتی‌بیوتیک,آموکسی‌سیلین,سفیکسیم,مترونیدازول,پنتوپرازول,امپرازول' ),
					'safety_risk_phrases'     => array( 'label' => 'واژه‌های پرخطر روانی', 'type' => 'list', 'default' => 'خودکشی,خودم را بکشم,آسیب به خودم,تمومش کنم,نمی‌خوام زنده باشم,دلم می‌خواد بمیرم' ),
					'safety_crisis_behavior'  => array( 'label' => 'رفتار در تشخیص خطر', 'type' => 'select', 'default' => 'stop_and_show', 'options' => array( 'stop_and_show' => 'توقف گفت‌وگو + نمایش خطوط کمک', 'append_only' => 'ادامه‌ی گفت‌وگو + افزودن هشدار' ) ),
					'safety_review_queue'     => array( 'label' => 'ارسال پاسخ‌های پرچم‌خورده به صف بازبینی پزشک', 'type' => 'toggle', 'default' => 1 ),
					'safety_helplines'        => array( 'label' => 'خطوط کمک فوری (هر خط: عنوان | شماره | توضیح)', 'type' => 'lines', 'default' => "صدای مشاور|1480|مشاوره‌ی تلفنی، شبانه‌روزی و رایگان\nاورژانس اجتماعی|123|برای موقعیت‌های بحرانی و خطر فوری" ),
				),
			),
			'lab'       => array(
				'label'  => 'تحلیل آزمایش',
				'fields' => array(
					'lab_enabled'        => array( 'label' => 'فعال بودن بخش تحلیل', 'type' => 'toggle', 'default' => 1 ),
					'lab_reader'         => array( 'label' => 'روش خواندن فایل', 'type' => 'select', 'default' => 'vision', 'options' => array( 'vision' => 'مدل بینایی (تصویر)', 'ocr_vision' => 'OCR + مدل بینایی', 'text_ai' => 'فقط متن (PDF متنی)' ) ),
					'lab_allowed_types'  => array( 'label' => 'فرمت‌های مجاز', 'type' => 'list', 'default' => 'jpg,jpeg,png,webp,pdf' ),
					'lab_max_mb'         => array( 'label' => 'حداکثر حجم فایل (مگابایت)', 'type' => 'number', 'default' => 10 ),
					'lab_range_source'   => array( 'label' => 'منبع بازه‌ی مرجع', 'type' => 'select', 'default' => 'document', 'options' => array( 'document' => 'بازه‌ی خود برگه‌ی آزمایشگاه', 'custom' => 'جدول بازه‌ی اختصاصی افزونه' ) ),
					'lab_ai_summary'     => array( 'label' => 'نوشتن خلاصه با هوش مصنوعی', 'type' => 'toggle', 'default' => 1 ),
					'lab_print_sheet'    => array( 'label' => 'ساخت برگه‌ی چاپی برای پزشک', 'type' => 'toggle', 'default' => 1 ),
					'lab_image_retention' => array( 'label' => 'نگهداری تصویر خام', 'type' => 'select', 'default' => 'delete', 'options' => array( 'delete' => 'حذف پس از تحلیل', 'keep' => 'نگه‌داشتن در پرونده' ) ),
					'lab_result_days'    => array( 'label' => 'مدت نگهداری نتایج (روز)', 'type' => 'number', 'default' => 365 ),
				),
			),
			'notify'    => array(
				'label'  => 'اعلان و یادآور',
				'fields' => array(
					'reminders_enabled' => array( 'label' => 'فعال بودن یادآور', 'type' => 'toggle', 'default' => 1 ),
					'reminders_sound'   => array( 'label' => 'صدای اعلان', 'type' => 'toggle', 'default' => 1 ),
					'reminders_limit'   => array( 'label' => 'سقف یادآور هر کاربر', 'type' => 'number', 'default' => 20 ),
					'web_push'          => array( 'label' => 'پشتیبانی Web Push', 'type' => 'toggle', 'default' => 0 ),
				),
			),
			'store'     => array(
				'label'  => 'فروشگاه و پرداخت',
				'fields' => array(
					'store_primary'      => array( 'label' => 'فروشگاه اصلی', 'type' => 'select', 'default' => 'woocommerce', 'options' => array( 'woocommerce' => 'ووکامرس' ) ),
					'credit_on_status'    => array( 'label' => 'افزودن اعتبار در وضعیت سفارش', 'type' => 'select', 'default' => 'completed', 'options' => array( 'completed' => 'تکمیل‌شده', 'processing' => 'در حال انجام' ) ),
					'refund_reverses'    => array( 'label' => 'بازگشت اعتبار در بازپرداخت', 'type' => 'toggle', 'default' => 1 ),
					'wallet_in_my_account' => array( 'label' => 'نمایش کیف پول در «حساب من» ووکامرس', 'type' => 'toggle', 'default' => 1 ),
					'email_on_credit'    => array( 'label' => 'ایمیل تایید شارژ', 'type' => 'toggle', 'default' => 1 ),
					'store_bazaar'       => array( 'label' => 'کافه‌بازار (خرید درون‌برنامه‌ای)', 'type' => 'toggle', 'default' => 0 ),
					'store_myket'        => array( 'label' => 'مایکت (خرید درون‌برنامه‌ای)', 'type' => 'toggle', 'default' => 0 ),
					'store_bazaar_secret' => array( 'label' => 'کلید تایید رسید کافه‌بازار', 'type' => 'secret', 'default' => '' ),
					'store_myket_secret' => array( 'label' => 'کلید تایید رسید مایکت', 'type' => 'secret', 'default' => '' ),
					'store_skus'         => array(
						'label'   => 'نگاشت SKU فروشگاه‌ها (خطی)',
						'type'    => 'lines',
						// Format: sku | type(credit|plan) | value | store | days(optional)
						'default' => "niva_credit_100|credit|100|bazaar\nniva_credit_500|credit|500|bazaar\nniva_credit_1200|credit|1200|bazaar\nmyket_credit_100|credit|100|myket\nmyket_credit_500|credit|500|myket",
						'hint'    => 'هر خط: شناسهٔ محصول | نوع (credit یا plan) | مقدار (تعداد اعتبار یا شناسهٔ پلن) | فروشگاه (bazaar/myket) | روز (برای پلن؛ اختیاری). اگر ستون نوع خالی باشد، رفتار قدیمی (اعتبار) حفظ می‌شود.',
					),
				),
			),
			'onboarding' => array(
				'label'  => 'ویزارد تکمیل پروفایل',
				'fields' => array(
					'onboarding_wizard_enabled' => array( 'label' => 'ویزارد تکمیل پروفایل فعال باشد', 'type' => 'toggle', 'default' => 1 ),
					'onboarding_snooze_days'    => array( 'label' => 'پس از بستن ویزارد، چند روز کارت پنهان بماند', 'type' => 'number', 'default' => 7, 'hint' => 'کاربری که ویزارد را می‌بندد نباید هر بار آزار ببیند؛ پیش‌فرض ۷ روز.' ),
					'onboarding_notice_enabled' => array( 'label' => 'اعلان داخلی «پروفایلت کامل نیست» یک‌بار ارسال شود', 'type' => 'toggle', 'default' => 1, 'hint' => 'برای هر کاربر حداکثر یک بار؛ بدون اسپم.' ),
					'onboarding_require_complete' => array( 'label' => 'اجبار به تکمیل قبل از استفاده از امکانات', 'type' => 'toggle', 'default' => 0, 'hint' => 'پیش‌فرض خاموش است تا کاربران فعلی محدود نشوند.' ),
				),
			),
			'avatar'     => array(
				'label'  => 'عکس پروفایل',
				'fields' => array(
					'avatar_allow_user_upload' => array( 'label' => 'کاربر بتواند عکس پروفایل بگذارد', 'type' => 'toggle', 'default' => 1 ),
					'avatar_max_mb'            => array( 'label' => 'حداکثر حجم عکس (مگابایت)', 'type' => 'number', 'default' => 2 ),
					'avatar_allowed_types'     => array( 'label' => 'فرمت‌های مجاز عکس', 'type' => 'list', 'default' => 'jpg,jpeg,png,webp' ),
				),
			),
			'community'  => array(
				'label'  => 'گفتگو با کاربران (انجمن)',
				'fields' => array(
					'community_enabled'         => array( 'label' => 'بخش گفتگو با کاربران فعال باشد', 'type' => 'toggle', 'default' => 1 ),
					'community_mode'            => array(
						'label'   => 'شیوهٔ انتشار',
						'type'    => 'select',
						'default' => 'moderated',
						'options' => array( 'moderated' => 'تأیید پیش از نمایش (پیشنهادی)', 'auto' => 'انتشار فوری + بازبینی پس از انتشار' ),
					),
					'community_hide_contacts'   => array( 'label' => 'پنهان‌کردن شماره/آیدی/لینک در متن کاربران', 'type' => 'toggle', 'default' => 1, 'hint' => 'برای ایمنی حوزهٔ سلامت، اطلاعات تماس به‌صورت خودکار پنهان می‌شود.' ),
					'community_require_login'   => array( 'label' => 'فقط کاربران وارد‌شده بتوانند بنویسند', 'type' => 'toggle', 'default' => 1 ),
					'community_threads_per_day' => array( 'label' => 'سقف گفتگوی تازهٔ هر کاربر در روز', 'type' => 'number', 'default' => 3 ),
					'community_comments_per_day' => array( 'label' => 'سقف نظر هر کاربر در روز', 'type' => 'number', 'default' => 10 ),
					'community_max_image_mb'    => array( 'label' => 'حداکثر حجم عکس پیوست (مگابایت)', 'type' => 'number', 'default' => 3 ),
					'community_auto_close_days' => array( 'label' => 'بستن خودکار گفتگوی بی‌تحرک پس از چند روز (۰ = هرگز)', 'type' => 'number', 'default' => 0 ),
				),
			),
			'companion'  => array(
				'label'  => 'کد همراهی',
				'fields' => array(
					'companion_enabled'        => array( 'label' => 'ساخت کد همراهی فعال باشد', 'type' => 'toggle', 'default' => 1 ),
					'companion_max_active'     => array( 'label' => 'حداکثر همراه فعال برای هر کاربر', 'type' => 'number', 'default' => 3 ),
					'companion_default_days'   => array( 'label' => 'اعتبار پیش‌فرض کد (روز)', 'type' => 'number', 'default' => 30, 'hint' => 'گزینه‌های ۷/۳۰/۹۰ روز و بدون‌انقضا در اختیار کاربر است؛ این عدد پیش‌فرض انتخاب‌شده است.' ),
					'companion_otp_required'   => array( 'label' => 'تأیید شمارهٔ همراه با کد یک‌بارمصرف', 'type' => 'toggle', 'default' => 1 ),
					'companion_default_scopes' => array( 'label' => 'دامنهٔ دسترسی پیش‌فرض (list)', 'type' => 'list', 'default' => 'cycle', 'hint' => 'کلیدهای مجاز: cycle, pregnancy, reminders, mood, labs' ),
					'companion_log_retention_days' => array( 'label' => 'نگهداری لاگ بازدید همراه (روز)', 'type' => 'number', 'default' => 180 ),
				),
			),
			'subscription' => array(
				'label'  => 'دوره‌های اشتراک و اعتبار پلن',
				'fields' => array(
					'subscription_periods'   => array(
						'label'   => 'دوره‌های فروش پلن (هر خط: ماه | برچسب | درصد تخفیف)',
						'type'    => 'lines',
						'default' => "1|یک ماهه|0\n3|سه ماهه|10\n6|شش ماهه|15\n12|دوازده ماهه|25",
						'hint'    => 'درصد تخفیف نسبت به قیمت یک‌ماهه در سایت نمایش داده می‌شود؛ قیمت پایه از محصول ووکامرس هر دوره خوانده می‌شود.',
					),
					'subscription_default_period' => array( 'label' => 'دورهٔ پیش‌فرض انتخاب‌شده', 'type' => 'number', 'default' => 1 ),
					'subscription_rollover'  => array( 'label' => 'انتقال سهمیهٔ ماهانهٔ مصرف‌نشده به دورهٔ بعد', 'type' => 'toggle', 'default' => 0, 'hint' => 'پیش‌فرض «انتقال ندارد».' ),
					'subscription_renew_notice_days' => array( 'label' => 'اعلان تمدید چند روز قبل (list)', 'type' => 'list', 'default' => '7,1' ),
					'subscription_upgrade_prorate' => array( 'label' => 'محاسبهٔ تفاضل قیمت هنگام ارتقای پلن', 'type' => 'toggle', 'default' => 0, 'hint' => 'اگر خاموش باشد، دورهٔ جدید از تاریخ انقضای فعلی ادامه پیدا می‌کند.' ),
					'plan_monthly_credits'   => array(
						'label'   => 'اعتبار ماهانهٔ هر پلن (هر خط: شناسهٔ پلن | مقدار؛ ۰ = ندارد)',
						'type'    => 'lines',
						'default' => "plus|300\nfamily|500\nclinic|1500\npartner|1400",
					),
				),
			),
		);
	}

	/** Flat key => default map. */

	/**
	 * One-time palette repair.
	 *
	 * Sites installed before 1.2.0 still carry the old terracotta default in the
	 * database, and a stored value always wins over a new default — which is why
	 * the front end stayed orange. This rewrites only that legacy value, once,
	 * and never touches a colour the owner chose on purpose.
	 */
	public function migrate_palette() : void {
		// 5.0.0 — a site that already ran the 1.2.0 repair still needs the move
		// to the app palette, so both flags must be set before we stand down.
		if ( '1' === get_option( 'dr_niva_palette_migrated' ) && '1' === get_option( 'dr_niva_palette_2026' ) ) {
			return;
		}

		/*
		 * 5.0.0 — the shipped palette moved from the muted «clinical blue» trio
		 * (#3368A0 / #66A3BF / #C8DFDB) to the approved app palette
		 * (#0878E8 / #4FA8F5 / #DDF7EC). An install that still carries the old
		 * shipped values is treated as «never customised» and moved across;
		 * a colour the owner typed in themselves is never touched.
		 */
		$legacy = array( '', '#e4634a', '#E4634A', 'e4634a', '#c9503a', '#f08a5d', '#3368A0', '#3368a0', '3368a0', '#27527F', '#27527f' );
		$next   = array( 'brand_color' => '#0878E8', 'brand_color_2' => '#4FA8F5', 'brand_color_3' => '#DDF7EC' );
		$patch  = array();

		if ( in_array( trim( (string) $this->get( 'brand_color', '' ) ), $legacy, true ) ) {
			$patch['brand_color'] = $next['brand_color'];
		}
		$legacy_secondaries = array( '', '#66A3BF', '#66a3bf', '66a3bf', '#4F88A4', '#4f88a4' );
		foreach ( array( 'brand_color_2' => $next['brand_color_2'], 'brand_color_3' => $next['brand_color_3'] ) as $key => $value ) {
			$current = trim( (string) $this->get( $key, '' ) );
			if ( '' === $current ) {
				$patch[ $key ] = $value;
			} elseif ( 'brand_color_2' === $key && in_array( $current, $legacy_secondaries, true ) ) {
				$patch[ $key ] = $value;
			} elseif ( 'brand_color_3' === $key && in_array( $current, array( '#C8DFDB', '#c8dfdb', 'c8dfdb' ), true ) ) {
				$patch[ $key ] = $value;
			}
		}

		if ( $patch ) {
			$this->update( $patch );

			/*
			 * Belt and braces: if the settings writer ever refuses the patch
			 * (capability checks, a filter, a changed field list), write the
			 * option directly so the palette can never stay on the old default.
			 */
			if ( in_array( trim( (string) $this->get( 'brand_color', '' ) ), $legacy, true ) ) {
				$stored = get_option( DR_NIVA_OPTION, array() );
				$stored = is_array( $stored ) ? $stored : array();

				$stored['brand_color'] = '#3368A0';
				foreach ( array( 'brand_color_2' => '#66A3BF', 'brand_color_3' => '#C8DFDB' ) as $key => $value ) {
					if ( empty( $stored[ $key ] ) || '' === trim( (string) $stored[ $key ] ) ) {
						$stored[ $key ] = $value;
					}
				}
				update_option( DR_NIVA_OPTION, $stored );
			}
		}
		update_option( 'dr_niva_palette_migrated', '1', false );
		update_option( 'dr_niva_palette_2026', '1', false );

		/*
		 * The inline `--brand-*` tokens are printed from the stored values, so a
		 * cached page would keep the old trio until the next cache flush. Bumping
		 * this option makes every stylesheet URL change, which busts it for us.
		 */
		if ( ! get_option( 'dr_niva_palette_rev' ) ) {
			update_option( 'dr_niva_palette_rev', '5.0.0', false );
		}
	}

	public static function defaults() : array {
		$out = array();
		foreach ( self::groups() as $group ) {
			foreach ( $group['fields'] as $key => $field ) {
				$out[ $key ] = $field['default'];
			}
		}
		return $out;
	}

	/** Field definition for a key. */
	public static function field( string $key ) : ?array {
		foreach ( self::groups() as $group ) {
			if ( isset( $group['fields'][ $key ] ) ) {
				return $group['fields'][ $key ];
			}
		}
		return null;
	}

	public function all() : array {
		if ( null === $this->cache ) {
			$stored      = get_option( DR_NIVA_OPTION, array() );
			$this->cache = wp_parse_args( is_array( $stored ) ? $stored : array(), self::defaults() );
			$legacy_model = is_array( $stored )
				? (string) ( $stored['ai_model_gapgpt'] ?? '' )
				: '';
			if ( is_array( $stored ) && ! isset( $stored['ai_model_chat'] ) && '' !== $legacy_model ) {
				$this->cache['ai_model_chat'] = $legacy_model;
			}
			if ( is_array( $stored ) && ! isset( $stored['ai_model_vision'] ) && '' !== $legacy_model ) {
				$this->cache['ai_model_vision'] = $legacy_model;
			}
			if ( 'این توضیح جای تشخیص و درمان پزشک نیست.' === (string) $this->cache['safety_medical_footer'] ) {
				$this->cache['safety_medical_footer'] = '';
			}
			if ( 'دکتر نیوا جایگزین پزشک نیست؛ برای تشخیص و درمان به پزشک مراجعه کنید.' === (string) $this->cache['footer_note'] ) {
				$this->cache['footer_note'] = '';
			}
		}
		return $this->cache;
	}

	/** @return mixed */
	public function get( string $key, $fallback = null ) {
		$all = $this->all();
		return array_key_exists( $key, $all ) ? $all[ $key ] : $fallback;
	}

	public function is_on( string $key ) : bool {
		return (bool) $this->get( $key );
	}

	public function as_list( string $key ) : array {
		$value = (string) $this->get( $key, '' );
		$parts = array_filter( array_map( 'trim', explode( ',', $value ) ) );
		return array_values( $parts );
	}

	/** Lines of "a|b|c" rows turned into arrays. */
	public function as_rows( string $key ) : array {
		$value = (string) $this->get( $key, '' );
		$rows  = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $value ) as $line ) {
			$line = trim( $line );
			if ( '' === $line ) {
				continue;
			}
			$rows[] = array_map( 'trim', explode( '|', $line ) );
		}
		return $rows;
	}

	/** Credit packages as [credits, price]. */
	public function packages() : array {
		$rows = $this->get( 'packages', array() );
		$out  = array();
		if ( is_array( $rows ) ) {
			foreach ( $rows as $row ) {
				if ( is_array( $row ) && isset( $row[0], $row[1] ) && (int) $row[0] > 0 ) {
					$out[] = array( 'credits' => (int) $row[0], 'price' => (int) $row[1] );
				}
			}
		}
		return $out;
	}

	public function seed_defaults() : void {
		if ( false === get_option( DR_NIVA_OPTION, false ) ) {
			add_option( DR_NIVA_OPTION, self::defaults() );
		}
	}

	/** Sanitises one posted value according to its field type. */
	public static function sanitize( string $key, $value ) {
		$field = self::field( $key );
		if ( ! $field ) {
			return null;
		}
		switch ( $field['type'] ) {
			case 'toggle':
				return empty( $value ) ? 0 : 1;
			case 'number':
				return (int) $value;
			case 'media':
				return absint( $value );
			case 'color':
				return sanitize_hex_color( (string) $value ) ?: '#3368A0';
			case 'url':
				return esc_url_raw( (string) $value );
			case 'secret':
				return trim( (string) $value );
			case 'lines':
				return wp_kses( (string) $value, array() );
			case 'feature_gates':
				return is_scalar( $value ) ? wp_kses( (string) $value, array() ) : '';
			case 'rows':
				$rows = array();
				if ( is_array( $value ) ) {
					foreach ( $value as $row ) {
						$credits = isset( $row[0] ) ? (int) $row[0] : 0;
						$price   = isset( $row[1] ) ? (int) $row[1] : 0;
						if ( $credits > 0 ) {
							$rows[] = array( $credits, $price );
						}
					}
				}
				return $rows;
			case 'list':
			default:
				return wp_kses( (string) $value, array() );
		}
	}

	/** Persists a partial patch from the admin form or the REST layer. */
	public function update( array $patch ) : array {
		$current = $this->all();
		foreach ( $patch as $key => $value ) {
			$field = self::field( $key );
			if ( ! $field ) {
				continue;
			}
			if ( ! empty( $field['locked'] ) ) {
				continue; // safety locks can not be switched off from a request
			}
			if ( 'feature_gates' === ( $field['type'] ?? '' ) && is_array( $value ) ) {
				$current[ $key ] = Niva_Plans::serialize_feature_gate_matrix(
					$value,
					(string) ( $current[ $key ] ?? '' )
				);
			} else {
				$current[ $key ] = self::sanitize( $key, $value );
			}
		}
		update_option( DR_NIVA_OPTION, $current );
		$this->cache = $current;
		return $current;
	}

	/** Masked key for display, e.g. sk-…9f2a */
	public function masked( string $key ) : string {
		$value = (string) $this->get( $key, '' );
		if ( '' === $value ) {
			return '';
		}
		return mb_substr( $value, 0, 4 ) . '…' . mb_substr( $value, -4 );
	}
}
