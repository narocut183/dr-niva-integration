<?php
/**
 * Subscription periods, plan quota windows and the three credit layers (2.0.0).
 *
 * Owns three related jobs:
 *   1. Periods  — every plan can be sold as 1 / 3 / 6 / 12 months, each with its
 *      own discount and badge, and the screen shows the monthly equivalent and
 *      how much the buyer saves.
 *   2. Plan quota window — the monthly allowance each plan grants (chat / lab /
 *      image), when it resets, and whether leftovers carry over.
 *   3. Layer order — free daily → plan quota → wallet balance, always in that
 *      order, always announced before the wallet is touched.
 *
 * Nothing here invents a price: a period price comes from the WooCommerce
 * product for that plan/period, or from the settings screen. When neither
 * exists the period is reported as "not sellable yet" instead of guessing.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Subscription {

	/** Quota counters that live on the membership row. */
	public static function counters() : array {
		return array( 'chat' => 'quota_chat_used', 'lab' => 'quota_lab_used', 'image' => 'quota_image_used' );
	}

	/* --------------------------------------------------------------- periods */

	/**
	 * Sellable periods, from the settings screen.
	 *
	 * Format: "months|label|discount" per line. A malformed line is skipped
	 * rather than turned into a made-up period.
	 *
	 * @return array<int,array{months:int,label:string,discount:float}>
	 */
	public function periods() : array {
		$raw   = (string) dr_niva()->settings->get( 'subscription_periods', "1|یک ماهه|0\n3|سه ماهه|10\n6|شش ماهه|15\n12|دوازده ماهه|25" );
		$out   = array();
		$label_fallback = array( 1 => 'یک ماهه', 3 => 'سه ماهه', 6 => 'شش ماهه', 12 => 'دوازده ماهه' );

		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
			$line = trim( (string) $line );
			if ( '' === $line ) {
				continue;
			}
			$parts  = array_map( 'trim', explode( '|', $line ) );
			$months = (int) ( $parts[0] ?? 0 );
			if ( $months < 1 || $months > 60 ) {
				continue;
			}
			$out[ $months ] = array(
				'months'   => $months,
				'label'    => '' !== ( $parts[1] ?? '' ) ? (string) $parts[1] : ( $label_fallback[ $months ] ?? $months . ' ماهه' ),
				'discount' => max( 0.0, min( 90.0, (float) ( $parts[2] ?? 0 ) ) ),
			);
		}
		ksort( $out );
		return array_values( $out );
	}

	public function period( int $months ) : array {
		foreach ( $this->periods() as $period ) {
			if ( $period['months'] === $months ) {
				return $period;
			}
		}
		return array();
	}

	public function default_period() : int {
		$months  = (int) dr_niva()->settings->get( 'subscription_default_period', 1 );
		$allowed = wp_list_pluck( $this->periods(), 'months' );
		return in_array( $months, $allowed, true ) ? $months : (int) ( $allowed[0] ?? 1 );
	}

	/**
	 * Price of one period for one plan.
	 *
	 * The base price comes from the WooCommerce plan product; the discount for
	 * the longer period is applied on top as an explicit, visible line.
	 *
	 * @return array{available:bool,base:float,months:int,discount:float,total:float,per_month:float,savings:float,label:string}
	 */
	public function price( string $plan, int $months ) : array {
		$period = $this->period( $months );
		$base   = $this->monthly_base( $plan );
		$months = $period ? $period['months'] : max( 1, $months );
		$discount = $period ? (float) $period['discount'] : 0.0;

		if ( $base <= 0 ) {
			return array(
				'available' => false,
				'base'      => 0.0,
				'months'    => $months,
				'discount'  => $discount,
				'total'     => 0.0,
				'per_month' => 0.0,
				'savings'   => 0.0,
				'label'     => $period ? (string) $period['label'] : '',
			);
		}

		$gross     = $base * $months;
		$total     = $gross * ( 1 - $discount / 100 );
		$per_month = $total / $months;

		return array(
			'available' => true,
			'base'      => $base,
			'months'    => $months,
			'discount'  => $discount,
			'total'     => round( $total ),
			'per_month' => round( $per_month ),
			'savings'   => round( $gross - $total ),
			'label'     => $period ? (string) $period['label'] : '',
		);
	}

	/** The site's own one-month price for a plan (0 = not sellable yet). */
	public function monthly_base( string $plan ) : float {
		if ( ! function_exists( 'wc_get_products' ) ) {
			return 0.0;
		}
		$ids = wc_get_products(
			array(
				'limit'      => 1,
				'return'     => 'ids',
				'status'     => 'publish',
				'meta_query' => array( // phpcs:ignore WordPress.DB.SlowDBQuery
					array( 'key' => '_niva_is_plan', 'value' => 'yes' ),
					array( 'key' => '_niva_plan', 'value' => $plan ),
				),
			)
		);
		if ( ! $ids ) {
			return 0.0;
		}
		$product = wc_get_product( (int) $ids[0] );
		return $product ? (float) $product->get_price() : 0.0;
	}

	/** All periods with their computed prices, for the plans screen. */
	public function matrix( string $plan ) : array {
		$rows = array();
		foreach ( $this->periods() as $period ) {
			$rows[] = array_merge( $period, $this->price( $plan, (int) $period['months'] ) );
		}
		return $rows;
	}

	/** Days a period lasts (used by the order handlers). */
	public function days_for( int $months ) : int {
		return max( 1, $months ) * 30;
	}

	/* --------------------------------------------------------- plan quota */

	/**
	 * The plan allowance this user has for one counter, and how much is left.
	 *
	 * The window resets at the start of each period; leftovers carry over only
	 * when the owner turned rollover on.
	 *
	 * @return array{plan:string,limit:int,used:int,left:int,window:string,rollover:bool}
	 */
	public function plan_quota( int $user_id, string $counter ) : array {
		global $wpdb;
		$col    = self::counters()[ $counter ] ?? '';
		$plan   = dr_niva()->plans ? dr_niva()->plans->plan_of( $user_id ) : array( 'plan' => 'free' );
		$limits = dr_niva()->plans ? dr_niva()->plans->limits( (string) $plan['plan'] ) : array();
		$limit  = (int) ( $limits[ $this->limit_key( $counter ) ] ?? 0 );

		$out = array(
			'plan'     => (string) $plan['plan'],
			'limit'    => $limit,
			'used'     => 0,
			'left'     => $limit,
			'window'   => '',
			'rollover' => dr_niva()->settings->is_on( 'subscription_rollover' ),
		);

		if ( '' === $col || ! $plan['active'] ) {
			return $out;
		}

		$table = Niva_DB::table( 'memberships' );
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT quota_window_start, {$col} AS used FROM {$table} WHERE user_id = %d", $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		if ( ! $row ) {
			return $out;
		}

		$started = (string) ( $row['quota_window_start'] ?? '' );
		$expires = (string) ( $plan['expires'] ?? '' );
		$needs_reset = '' === $started
			|| ( $expires && strtotime( $started ) < strtotime( $expires . ' -30 days' ) );

		if ( $needs_reset ) {
			$this->open_window( $user_id, ! empty( $plan['expires'] ) ? (string) $plan['expires'] : '' );
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT quota_window_start, {$col} AS used FROM {$table} WHERE user_id = %d", $user_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		}

		$out['used']   = (int) ( $row['used'] ?? 0 );
		$out['window'] = (string) ( $row['quota_window_start'] ?? '' );
		$out['left']   = $limit > 0 ? max( 0, $limit - $out['used'] ) : 0;
		return $out;
	}

	private function limit_key( string $counter ) : string {
		switch ( $counter ) {
			case 'lab':
				return 'lab_per_month';
			case 'image':
				return 'image_per_month';
			default:
				return 'chat_per_day';
		}
	}

	/**
	 * Opens a fresh quota window.
	 *
	 * With rollover on, the unused part of the previous window is carried into
	 * the new one (recorded separately so the report can show both numbers).
	 */
	public function open_window( int $user_id, string $period_end = '' ) : void {
		global $wpdb;
		$table   = Niva_DB::table( 'memberships' );
		$start   = '' !== $period_end
			? gmdate( 'Y-m-d H:i:s', strtotime( $period_end . ' -30 days' ) )
			: current_time( 'mysql', true );
		$carried = 0;

		if ( dr_niva()->settings->is_on( 'subscription_rollover' ) ) {
			$usage  = $this->plan_quota( $user_id, 'chat' );
			$carried = $usage['limit'] > 0 ? max( 0, $usage['limit'] - $usage['used'] ) : 0;
		}

		$wpdb->update( // phpcs:ignore WordPress.DB
			$table,
			array(
				'quota_window_start' => $start,
				'quota_chat_used'    => 0,
				'quota_lab_used'     => 0,
				'quota_image_used'   => 0,
				'quota_carried_chat' => $carried,
				'updated_at'         => current_time( 'mysql' ),
			),
			array( 'user_id' => $user_id )
		);
	}

	/** Consumes one unit of the plan allowance. Returns false when it is spent. */
	public function consume_plan_quota( int $user_id, string $counter ) : bool {
		global $wpdb;
		$col   = self::counters()[ $counter ] ?? '';
		$state = $this->plan_quota( $user_id, $counter );
		if ( '' === $col || ! $state['plan'] || 'free' === $state['plan'] ) {
			return false;
		}
		if ( $state['limit'] > 0 && $state['left'] <= 0 ) {
			return false;
		}
		$table   = Niva_DB::table( 'memberships' );
		$updated = $wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"UPDATE {$table} SET {$col} = {$col} + 1, updated_at = %s WHERE user_id = %d AND ( %d = 0 OR {$col} < %d )",
				current_time( 'mysql' ),
				$user_id,
				$state['limit'],
				$state['limit']
			)
		);
		return 1 === $updated;
	}

	/** Gives one plan unit back when the AI call failed. */
	public function refund_plan_quota( int $user_id, string $counter ) : void {
		global $wpdb;
		$col = self::counters()[ $counter ] ?? '';
		if ( '' === $col ) {
			return;
		}
		$table = Niva_DB::table( 'memberships' );
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "UPDATE {$table} SET {$col} = GREATEST(0, {$col} - 1) WHERE user_id = %d", $user_id )
		);
	}

	/* ------------------------------------------------------------- renewals */

	/**
	 * Expiry notices for the current user (7 and 1 days before, configurable).
	 *
	 * Returns only what is actually due; the caller decides how to show it.
	 */
	public function expiry_notice( int $user_id = 0 ) : array {
		$user_id = $user_id ? $user_id : (int) get_current_user_id();
		if ( ! $user_id || ! dr_niva()->plans ) {
			return array();
		}
		$plan = dr_niva()->plans->plan_of( $user_id );
		if ( empty( $plan['expires'] ) || ! $plan['active'] ) {
			return array();
		}
		$days = (int) floor( ( strtotime( (string) $plan['expires'] ) - time() ) / DAY_IN_SECONDS );
		if ( $days > 7 ) {
			return array();
		}

		$thresholds = array_filter( array_map( 'absint', explode( ',', (string) dr_niva()->settings->get( 'subscription_renew_notice_days', '7,1' ) ) ) );
		sort( $thresholds );
		$match = null;
		foreach ( $thresholds as $threshold ) {
			if ( $days <= $threshold ) {
				$match = $threshold;
				break;
			}
		}
		if ( null === $match ) {
			return array();
		}

		return array(
			'plan'    => (string) $plan['plan'],
			'label'   => (string) $plan['label'],
			'days'    => max( 0, $days ),
			'expires' => (string) $plan['expires'],
			'expired' => $days < 0,
			'message' => $days <= 0
				? 'اشتراکت به پایان رسید؛ امکانات به حالت پلن رایگان برگشت، اما داده‌هایت دست‌نخورده مانده است.'
				: 'اشتراکت ' . Niva_Chrome::digits( (string) max( 0, $days ) ) . ' روز دیگر تمام می‌شود. برای ادامه، تمدید کن.',
			'renew_url' => ( new Niva_Links() )->url( 'plans' ),
		);
	}

	/**
	 * Whether access was re-evaluated from the live membership.
	 *
	 * An expired membership does not delete anything: the plan simply falls back
	 * to free limits, and this reports that so a screen can explain it.
	 */
	public function access_state( int $user_id ) : array {
		$plan = dr_niva()->plans ? dr_niva()->plans->plan_of( $user_id ) : array();
		return array(
			'plan'        => (string) ( $plan['plan'] ?? 'free' ),
			'active'      => ! empty( $plan['active'] ),
			'expires'     => (string) ( $plan['expires'] ?? '' ),
			'fallback'    => empty( $plan['active'] ) && ! empty( $plan['expires'] ),
		);
	}

	/** Renewal policy: continue from the current expiry, or start fresh. */
	public function renewal_start( int $user_id ) : string {
		if ( ! dr_niva()->settings->is_on( 'subscription_upgrade_prorate' ) ) {
			$plan = dr_niva()->plans ? dr_niva()->plans->plan_of( $user_id ) : array();
			if ( ! empty( $plan['active'] ) && ! empty( $plan['expires'] ) && strtotime( (string) $plan['expires'] ) > time() ) {
				return (string) $plan['expires']; // stack the new period after the old one
			}
		}
		return current_time( 'mysql', true );
	}
}
