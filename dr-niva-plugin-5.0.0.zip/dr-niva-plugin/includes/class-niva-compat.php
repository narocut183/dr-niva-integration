<?php
/**
 * Compatibility + crash forensics.
 *
 * Two jobs:
 *   1. keep the plugin safe on older PHP (a friendly notice instead of a site
 *      killing fatal), and
 *   2. record the last fatal error that happened inside this plugin, so the
 *      reason is readable from the dashboard instead of a blank screen.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Compat {

	const FATAL_OPTION = 'dr_niva_last_fatal';
	const BOOT_OPTION  = 'dr_niva_boot_errors';
	const ACT_OPTION   = 'dr_niva_activation_error';

	public static function init() : void {
		register_shutdown_function( array( __CLASS__, 'trap_fatal' ) );
		add_action( 'admin_notices', array( __CLASS__, 'notices' ) );
	}

	public static function php_ok() : bool {
		return version_compare( PHP_VERSION, '7.4', '>=' );
	}

	/** PHP 8 helpers, with a 7.4-safe fallback. */
	public static function starts_with( string $haystack, string $needle ) : bool {
		if ( function_exists( 'str_starts_with' ) ) {
			return str_starts_with( $haystack, $needle );
		}
		return '' === $needle || 0 === strpos( $haystack, $needle );
	}

	public static function contains( string $haystack, string $needle ) : bool {
		if ( function_exists( 'str_contains' ) ) {
			return str_contains( $haystack, $needle );
		}
		return '' === $needle || false !== strpos( $haystack, $needle );
	}

	/** Records a fatal error that happened inside our own files. */
	public static function trap_fatal() : void {
		$error = error_get_last();
		if ( ! is_array( $error ) || ! in_array( (int) $error['type'], array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR ), true ) ) {
			return;
		}
		$file = isset( $error['file'] ) ? (string) $error['file'] : '';
		if ( false === strpos( str_replace( '\\', '/', $file ), '/dr-niva-plugin/' ) ) {
			return;
		}
		update_option(
			self::FATAL_OPTION,
			array(
				'message' => isset( $error['message'] ) ? (string) $error['message'] : '',
				'file'    => $file,
				'line'    => isset( $error['line'] ) ? (int) $error['line'] : 0,
				'url'     => isset( $_SERVER['REQUEST_URI'] ) ? esc_url_raw( wp_unslash( (string) $_SERVER['REQUEST_URI'] ) ) : '',
				'php'     => PHP_VERSION,
				'when'    => current_time( 'mysql' ),
			),
			false
		);

			// Also on disk: readable even when the admin screen is unreachable.
			if ( function_exists( 'wp_upload_dir' ) && ! defined( 'DR_NIVA_FATAL_LOGGED' ) ) {
				define( 'DR_NIVA_FATAL_LOGGED', true );
				try {
					$upload = wp_upload_dir();
					if ( empty( $upload['error'] ) && ! empty( $upload['basedir'] ) ) {
						@file_put_contents( $upload['basedir'] . '/dr-niva-fatal.log', gmdate( 'c' ) . ' ' . $line . "\n", FILE_APPEND ); // phpcs:ignore
					}
				} catch ( \Throwable $ignore ) {
					// A shutdown handler must never add to the problem it reports.
				}
			}
	}

	public static function last_fatal() : array {
		$value = get_option( self::FATAL_OPTION );
		return is_array( $value ) ? $value : array();
	}

	public static function clear_fatal() : void {
		delete_option( self::FATAL_OPTION );
	}

	public static function add_boot_error( string $class, string $message ) : void {
		$errors   = (array) get_option( self::BOOT_OPTION, array() );
		$errors[] = array( 'class' => $class, 'message' => $message, 'when' => current_time( 'mysql' ) );
		update_option( self::BOOT_OPTION, array_slice( $errors, -10 ), false );
	}

	/** Shows the recorded problems to an administrator. */
	public static function notices() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}

		$missing = (array) get_option( 'dr_niva_missing_tables', array() );
		if ( $missing ) {
			printf(
				'<div class="notice notice-error"><p><strong>دکتر نیوا:</strong> این جدول‌ها ساخته نشده‌اند: %s. <a href="%s">ترمیم کن</a></p></div>',
				esc_html( implode( ', ', $missing ) ),
				esc_url( admin_url( 'admin.php?page=dr-niva-health' ) )
			);
		}

		$fatal = self::last_fatal();
		if ( $fatal ) {
			printf(
				'<div class="notice notice-error"><p><strong>دکتر نیوا:</strong> آخرین خطای مهلک ثبت شد — %s (فایل %s، خط %s). <a href="%s">مشاهده و پاک‌کردن</a></p></div>',
				esc_html( (string) $fatal['message'] ),
				esc_html( basename( (string) $fatal['file'] ) ),
				esc_html( (string) $fatal['line'] ),
				esc_url( admin_url( 'admin.php?page=dr-niva-health' ) )
			);
		}

		$boot = (array) get_option( self::BOOT_OPTION, array() );
		if ( $boot ) {
			$last = end( $boot );
			printf(
				'<div class="notice notice-warning"><p><strong>دکتر نیوا:</strong> بخش «%s» بارگذاری نشد — %s. <a href="%s">جزئیات بیشتر</a></p></div>',
				esc_html( (string) $last['class'] ),
				esc_html( (string) $last['message'] ),
				esc_url( admin_url( 'admin.php?page=dr-niva-health' ) )
			);
		}

		if ( ! self::php_ok() ) {
			printf(
				'<div class="notice notice-error"><p><strong>دکتر نیوا:</strong> نسخه‌ی PHP این سرور %s است؛ برای کارکرد کامل افزونه حداقل ۷.۴ لازم است. با هاست خود تماس بگیر.</p></div>',
				esc_html( PHP_VERSION )
			);
		}
	}
}

Niva_Compat::init();
