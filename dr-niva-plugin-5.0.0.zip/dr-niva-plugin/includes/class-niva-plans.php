<?php
/**
 * Subscription engine.
 *
 * Every plan is a real set of limits that the server enforces — not a label in
 * the pricing table. A family membership covers several people through seats,
 * and a member without a plan inherits the family owner's limits.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Plans {

	/** Feature keys used across the product. 0 means unlimited. */
	public static function default_limits() : array {
		return array(
			'free'   => array(
				'chat_per_day'   => 5,
				'lab_per_month'  => 1,
				'image_per_month' => 1,
				'advisor_topics' => 3,
				'growth_profiles' => 1,
				'reminders'      => 3,
				'family_seats'   => 0,
				'pdf_export'     => 0,
				'doctor_review'  => 0,
			),
			'plus'   => array(
				'chat_per_day'   => 60,
				'lab_per_month'  => 20,
				'image_per_month' => 20,
				'advisor_topics' => 0,
				'growth_profiles' => 3,
				'reminders'      => 30,
				'family_seats'   => 0,
				'pdf_export'     => 1,
				'doctor_review'  => 0,
			),
			'family' => array(
				'chat_per_day'   => 60,
				'lab_per_month'  => 30,
				'image_per_month' => 30,
				'advisor_topics' => 0,
				'growth_profiles' => 6,
				'reminders'      => 60,
				'family_seats'   => 4,
				'pdf_export'     => 1,
				'doctor_review'  => 0,
			),
			'clinic' => array(
				'chat_per_day'   => 0,
				'lab_per_month'  => 0,
				'image_per_month' => 0,
				'advisor_topics' => 0,
				'growth_profiles' => 0,
				'reminders'      => 0,
				'family_seats'   => 20,
				'pdf_export'     => 1,
				'doctor_review'  => 1,
			),
			/*
			 * Partner access is a paid monthly plan; it remains capped by default
			 * and the owner can tune its price and limits in the plan editor.
			 */
			'partner' => array(
				'chat_per_day'   => 200,
				'lab_per_month'  => 60,
				'image_per_month' => 40,
				'advisor_topics' => 8,
				'growth_profiles' => 6,
				'reminders'      => 60,
				'family_seats'   => 50,
				'pdf_export'     => 1,
				'doctor_review'  => 1,
			),
		);
	}

	public static function labels() : array {
		return array(
			'free'    => 'رایگان',
			'plus'    => 'پلاس',
			'family'  => 'خانوادگی',
			'clinic'  => 'کلینیکی و همکاران',
			'partner' => 'پلن همکاران',
		);
	}

	/** Human labels for every limit key, in the order a plan card shows them. */
	public static function feature_labels() : array {
		return array(
			'chat_per_day'    => 'گفت‌وگوی روزانه با مشاور',
			'lab_per_month'   => 'تحلیل آزمایش در ماه',
			'image_per_month' => 'تحلیل تصویر و سونوگرافی در ماه',
			'advisor_topics'  => 'موضوع‌های گفت‌وگو',
			'growth_profiles' => 'پرونده‌ی رشد کودک',
			'reminders'       => 'یادآور فعال',
			'family_seats'    => 'صندلی اعضای خانواده',
			'pdf_export'      => 'خروجی PDF برای پزشک',
			'doctor_review'   => 'بازبینی نتیجه توسط تیم پزشکی',
		);
	}

	/** Every real module that can be gated from the administrator screen. */
	public static function feature_gate_catalog() : array {
		$catalog = array();
		foreach ( Niva_Modules::map() as $id => $module ) {
			$catalog[ $id ] = array(
				'label' => (string) ( $module['label'] ?? $id ),
				'group' => (string) ( $module['group'] ?? 'عمومی' ),
			);
		}
		return $catalog;
	}

	/** Parses the persisted line format, retained for backward compatibility. */
	public static function feature_gate_rules( string $raw ) : array {
		$rules = array();
		foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
			$parts = explode( '=', $line, 2 );
			if ( 2 !== count( $parts ) ) {
				continue;
			}
			$key = sanitize_key( trim( $parts[0] ) );
			if ( '' === $key ) {
				continue;
			}
			$rules[ $key ] = array_values(
				array_filter(
					array_map( 'sanitize_key', array_map( 'trim', explode( ',', $parts[1] ) ) ),
					static function ( $plan ) {
						return isset( self::default_limits()[ $plan ] );
					}
				)
			);
		}
		return $rules;
	}

	/** Matrix values shown in the visual editor; an absent rule means all plans. */
	public static function feature_gate_matrix( string $raw ) : array {
		$rules   = self::feature_gate_rules( $raw );
		$plans   = array_keys( self::default_limits() );
		$matrix  = array();
		foreach ( self::feature_gate_catalog() as $feature => $module ) {
			$matrix[ $feature ] = isset( $rules[ $feature ] ) ? $rules[ $feature ] : $plans;
		}
		return $matrix;
	}

	/**
	 * Serializes visual choices while retaining legacy/custom gate rows that do
	 * not correspond to a module in the current release.
	 */
	public static function serialize_feature_gate_matrix( array $matrix, string $legacy = '' ) : string {
		$plans   = array_keys( self::default_limits() );
		$catalog = self::feature_gate_catalog();
		$lines   = array();
		foreach ( $catalog as $feature => $module ) {
			$selected = isset( $matrix[ $feature ] ) && is_array( $matrix[ $feature ] ) ? $matrix[ $feature ] : array();
			$allowed  = array_values( array_intersect( $plans, array_map( 'sanitize_key', $selected ) ) );
			$lines[]  = $feature . ' = ' . implode( ', ', $allowed );
		}
		foreach ( self::feature_gate_rules( $legacy ) as $feature => $allowed ) {
			if ( ! isset( $catalog[ $feature ] ) ) {
				$lines[] = $feature . ' = ' . implode( ', ', $allowed );
			}
		}
		return implode( "\n", $lines );
	}

	/** «۰» is the "unlimited" marker, everywhere in the product. */
	public static function human_limit( int $value ) : string {
		if ( 0 === $value ) {
			return 'بی‌نهایت';
		}
		return Niva_Chrome::digits( number_format_i18n( $value ) );
	}

	/**
	 * A plan as a ready-to-render list: ['label' => …, 'value' => …].
	 *
	 * @return array<int,array<string,string>>
	 */
	public function features( string $plan ) : array {
		$limits  = $this->limits();
		$labels  = self::feature_labels();
		$row     = isset( $limits[ $plan ] ) ? $limits[ $plan ] : array();
		$out     = array();

		foreach ( $labels as $key => $label ) {
			if ( ! array_key_exists( $key, $row ) ) {
				continue;
			}
			$value   = (int) $row[ $key ];
			// Booleans read better as yes/no than as 1/0.
			$out[] = array(
				'key'   => $key,
				'label' => $label,
				'value' => in_array( $key, array( 'pdf_export', 'doctor_review' ), true )
					? ( $value > 0 ? 'دارد' : 'ندارد' )
					: self::human_limit( $value ),
				'on'    => $value > 0,
			);
		}

		return $out;
	}

	/** Plan keys the back office may hand out manually. */
	public static function assignable() : array {
		$limits = self::default_limits();
		$labels = self::labels();
		$out    = array();
		foreach ( array_keys( $limits ) as $plan ) {
			$out[ $plan ] = isset( $labels[ $plan ] ) ? $labels[ $plan ] : $plan;
		}
		return $out;
	}

	/** Limits merged with the admin overrides (lines of plan.feature = value). */
	public function limits() : array {
		$limits = self::default_limits();
		foreach ( self::plan_config() as $key => $row ) {
			if ( ! isset( $limits[ $key ] ) ) {
				continue;
			}
			foreach ( $row as $feature => $value ) {
				if ( 'price' === $feature || 'discount' === $feature ) {
					continue;
				}
				$limits[ $key ][ $feature ] = (int) $value;
			}
		}
		return $limits;
	}

	/* -------------------------------------------------------------- membership */

	/** Raw membership row (may be expired). */
	public function membership( int $user_id ) : ?array {
		global $wpdb;
		$row = $wpdb->get_row( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'memberships' ) . ' WHERE user_id = %d', $user_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		return $row ? $row : null;
	}

	/** The plan that really applies to this user, family seats included. */
	public function plan_of( int $user_id ) : array {
		$row = $this->membership( $user_id );
		if ( $row && $this->is_current( $row ) ) {
			return array(
				'plan'     => (string) $row['plan'],
				'label'    => $this->label( (string) $row['plan'] ),
				'active'   => true,
				'expires'  => $row['expires_at'],
				'source'   => (string) $row['source'],
				'inherited' => false,
			);
		}

		$owner_id = $this->family_owner( $user_id );
		if ( $owner_id ) {
			$owner_row = $this->membership( $owner_id );
			if ( $owner_row && $this->is_current( $owner_row ) ) {
				return array(
					'plan'      => (string) $owner_row['plan'],
					'label'     => $this->label( (string) $owner_row['plan'] ),
					'active'    => true,
					'expires'   => $owner_row['expires_at'],
					'source'    => 'family',
					'inherited' => true,
					'owner'     => $owner_id,
				);
			}
		}

		return array(
			'plan'      => 'free',
			'label'     => $this->label( 'free' ),
			'active'    => false,
			'expires'   => null,
			'source'    => 'none',
			'inherited' => false,
		);
	}

	private function is_current( array $row ) : bool {
		if ( in_array( (string) $row['status'], array( 'canceled', 'expired' ), true ) ) {
			return false;
		}
		if ( empty( $row['expires_at'] ) || '0000-00-00 00:00:00' === $row['expires_at'] ) {
			return true; // lifetime / manual
		}
		return strtotime( (string) $row['expires_at'] ) >= time();
	}

	public function label( string $plan ) : string {
		$labels = self::labels();
		return isset( $labels[ $plan ] ) ? $labels[ $plan ] : $plan;
	}

	/** Grants (or extends) a plan. */
	public function assign( int $user_id, string $plan, string $source = 'manual', int $days = 30, string $ref = '' ) : void {
		global $wpdb;
		$limits = $this->limits();
		if ( ! isset( $limits[ $plan ] ) ) {
			$plan = 'plus';
		}
		$expires = $days > 0 ? gmdate( 'Y-m-d H:i:s', time() + ( $days * DAY_IN_SECONDS ) ) : null;
		$table   = Niva_DB::table( 'memberships' );

		$existing = $this->membership( $user_id );
		$data     = array(
			'user_id'    => $user_id,
			'plan'       => $plan,
			'status'     => 'active',
			'source'     => $source,
			'ref'        => $ref,
			'expires_at' => $expires,
			'updated_at' => current_time( 'mysql' ),
		);
		if ( $existing ) {
			$wpdb->update( $table, $data, array( 'user_id' => $user_id ) ); // phpcs:ignore WordPress.DB
		} else {
			$data['created_at'] = current_time( 'mysql' );
			$wpdb->insert( $table, $data ); // phpcs:ignore WordPress.DB
		}

		/*
		 * Denormalised mirrors of the membership row. The admin user list can
		 * then filter and sort by plan and expiry with a plain meta query,
		 * instead of joining the memberships table on every page load.
		 */
		update_user_meta( $user_id, 'niva_plan', $plan );
		update_user_meta( $user_id, 'niva_plan_status', 'active' );
		update_user_meta( $user_id, 'niva_plan_expires', $expires ? $expires : '' );

		do_action( 'dr_niva_plan_assigned', $user_id, $plan, $source, $expires );
		Niva_Notifications::notify(
			$user_id,
			'اشتراک ' . $this->label( $plan ) . ' فعال شد',
			$expires ? 'اشتراکت تا ' . $expires . ' فعال است.' : 'اشتراکت فعال است.',
			home_url( '/' )
		);
	}

	public function revoke( int $user_id, string $reason = 'refund' ) : void {
		global $wpdb;
		$wpdb->update( Niva_DB::table( 'memberships' ), array( 'status' => 'canceled', 'updated_at' => current_time( 'mysql' ) ), array( 'user_id' => $user_id ) ); // phpcs:ignore WordPress.DB
		update_user_meta( $user_id, 'niva_plan_status', 'canceled' );
		do_action( 'dr_niva_plan_revoked', $user_id, $reason );
	}

	/* ------------------------------------------------------------------ limits */

	public function limit( int $user_id, string $feature, int $amount = 1 ) : int {
		$plan   = $this->plan_of( $user_id );
		$limits = $this->limits();
		$value  = isset( $limits[ $plan['plan'] ][ $feature ] ) ? (int) $limits[ $plan['plan'] ][ $feature ] : 0;
		return $value;
	}

	/** Whether a registered module is included in the user's current plan. */
	public function feature_access( int $user_id, string $feature ) {
		$rules = self::feature_gate_rules( (string) dr_niva()->settings->get( 'feature_plan_gates', '' ) );

		if ( ! isset( $rules[ $feature ] ) ) {
			return apply_filters( 'dr_niva_feature_access', true, $user_id, $feature, $this->plan_of( $user_id ) );
		}

		$current = $this->plan_of( $user_id );
		if ( in_array( (string) $current['plan'], $rules[ $feature ], true ) ) {
			return apply_filters( 'dr_niva_feature_access', true, $user_id, $feature, $current );
		}
		$labels = array_map( array( $this, 'label' ), $rules[ $feature ] );
		return new WP_Error(
			'niva_feature_locked',
			$labels
				? 'این بخش در پلن فعلی فعال نیست. پلن‌های لازم: ' . implode( '، ', $labels ) . '.'
				: 'این بخش در حال حاضر برای پلنی فعال نشده است.',
			array(
				'status'  => 402,
				'feature' => $feature,
				'plans'   => $rules[ $feature ],
				'upgrade' => ( new Niva_Links() )->url( 'plans' ),
			)
		);
	}

	/**
	 * Atomically reserves one real plan-quota use before external work begins.
	 *
	 * @return array|WP_Error
	 */
	public function reserve_usage( int $user_id, string $feature, string $kind ) {
		global $wpdb;
		$lock_name = 'niva_plan_' . substr( hash( 'sha256', $user_id . ':' . $feature ), 0, 48 );
		$locked    = (int) $wpdb->get_var( $wpdb->prepare( 'SELECT GET_LOCK(%s, 5)', $lock_name ) ); // phpcs:ignore WordPress.DB
		if ( 1 !== $locked ) {
			return new WP_Error( 'niva_quota_busy', 'بررسی سهمیه هم‌زمان است؛ چند لحظه دیگر دوباره تلاش کن.', array( 'status' => 409 ) );
		}

		try {
			$limit = $this->limit( $user_id, $feature );
			$used  = $this->usage( $user_id, $feature );
			if ( $limit > 0 && $used >= $limit ) {
				return new WP_Error(
					'niva_limit',
					'سهمیهٔ این امکان تمام شده است. می‌توانی از اعتبار استفاده کنی یا اشتراکت را ارتقا بدهی.',
					array(
						'status'  => 402,
						'plan'    => $this->plan_of( $user_id )['plan'],
						'limit'   => $limit,
						'used'    => $used,
						'upgrade' => ( new Niva_Links() )->url( 'plans' ),
					)
				);
			}
			$usage_id = dr_niva()->wallet->log_usage(
				$user_id,
				$kind,
				0,
				'plan_reserved',
				'plan:' . wp_generate_uuid4()
			);
			if ( $usage_id < 1 ) {
				return new WP_Error( 'niva_quota_reservation_failed', 'رزرو سهمیه ثبت نشد؛ اعتبارت تغییری نکرده است. دوباره تلاش کن.', array( 'status' => 500 ) );
			}
			return array( 'usage_id' => $usage_id, 'limit' => $limit, 'used' => $used + 1 );
		} finally {
			$wpdb->get_var( $wpdb->prepare( 'SELECT RELEASE_LOCK(%s)', $lock_name ) ); // phpcs:ignore WordPress.DB
		}
	}

	/** A minimal, user-safe snapshot for the advisor usage card. */
	public function chat_quota_summary( int $user_id ) : array {
		$plan  = $this->plan_of( $user_id );
		$limit = $this->limit( $user_id, 'chat_per_day' );
		$used  = $this->usage( $user_id, 'chat_per_day' );
		return array(
			'label'     => (string) $plan['label'],
			'active'    => ! empty( $plan['active'] ),
			'expires'   => ! empty( $plan['expires'] ) ? Niva_Chrome::format_datetime_gmt( (string) $plan['expires'] ) : '',
			'limit'     => $limit,
			'used'      => $used,
			'remaining' => 0 === $limit ? -1 : max( 0, $limit - $used ),
			'unlimited' => 0 === $limit,
		);
	}

	/** Uses so far in the current window (day or month, depending on the feature). */
	public function usage( int $user_id, string $feature ) : int {
		global $wpdb;

		switch ( $feature ) {
			case 'chat_per_day':
				$table = Niva_DB::table( 'usage' );
				return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
					$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND kind = 'chat' AND charged_from <> 'refunded' AND created_at >= %s", $user_id, current_time( 'Y-m-d 00:00:00' ) ) // phpcs:ignore WordPress.DB
				);
			case 'lab_per_month':
			case 'image_per_month':
				$kind  = 'lab_per_month' === $feature ? 'lab' : 'image';
				$table = Niva_DB::table( 'usage' );
				return (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
					$wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND kind = %s AND charged_from <> 'refunded' AND created_at >= %s", $user_id, $kind, current_time( 'Y-m-01 00:00:00' ) ) // phpcs:ignore WordPress.DB
				);
			case 'growth_profiles':
				$table = Niva_DB::table( 'growth' );
				return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(DISTINCT COALESCE(NULLIF(profile_id, ''), 'default')) FROM {$table} WHERE user_id = %d", $user_id ) ); // phpcs:ignore WordPress.DB
			case 'reminders':
				$table = Niva_DB::table( 'reminders' );
				return (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND done = 0", $user_id ) ); // phpcs:ignore WordPress.DB
			case 'family_seats':
				return count( $this->family_members( $user_id ) );
		}
		return 0;
	}

	/**
	 * The single gate every feature asks.
	 *
	 * @return true|WP_Error True when allowed, otherwise a ready-to-show error.
	 */
	public function can( int $user_id, string $feature ) {
		$limit = $this->limit( $user_id, $feature );
		if ( in_array( $feature, array( 'pdf_export', 'doctor_review' ), true ) && $limit < 1 ) {
			return new WP_Error(
				'niva_feature_locked',
				'این امکان در پلن فعلی فعال نیست؛ برای استفاده، پلن مناسب را انتخاب کن.',
				array(
					'status'  => 402,
					'feature' => $feature,
					'upgrade' => ( new Niva_Links() )->url( 'plans' ),
				)
			);
		}
		if ( 'family_seats' === $feature && $limit < 1 ) {
			return new WP_Error(
				'niva_feature_locked',
				'اشتراک خانوادگی در پلن فعلی فعال نیست.',
				array(
					'status'  => 402,
					'feature' => $feature,
					'upgrade' => ( new Niva_Links() )->url( 'plans' ),
				)
			);
		}
		if ( 0 === $limit ) {
			return true; // unlimited
		}
		$used = $this->usage( $user_id, $feature );
		if ( $used < $limit ) {
			return true;
		}

		$plan = $this->plan_of( $user_id );
		$text = array(
			'chat_per_day'    => 'سهمیه‌ی گفت‌وگوی امروزت تمام شد.',
			'lab_per_month'   => 'سهمیه‌ی تحلیل آزمایش این ماهت تمام شد.',
			'image_per_month' => 'سهمیه‌ی تحلیل تصویر این ماهت تمام شد.',
			'growth_profiles' => 'تعداد پرونده‌های رشد مجاز پلنت پر شده است.',
			'reminders'       => 'تعداد یادآورهای پلنت پر شده است.',
		);
		$message = isset( $text[ $feature ] ) ? $text[ $feature ] : 'به سقف این امکان در پلنت رسیدی.';

		return new WP_Error(
			'niva_limit',
			$message . ' با ارتقای اشتراک ادامه بده.',
			array(
				'status' => 402,
				'plan'   => $plan['plan'],
				'limit'  => $limit,
				'used'   => $used,
				'upgrade' => ( new Niva_Links() )->url( 'plans' ),
			)
		);
	}

	/* ------------------------------------------------------------------ family */

	public function family_owner( int $member_id ) : int {
		global $wpdb;
		return (int) $wpdb->get_var( $wpdb->prepare( 'SELECT owner_id FROM ' . Niva_DB::table( 'family_members' ) . ' WHERE member_id = %d', $member_id ) ); // phpcs:ignore WordPress.DB
	}

	public function family_members( int $owner_id ) : array {
		global $wpdb;
		$rows = $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'family_members' ) . ' WHERE owner_id = %d ORDER BY id ASC', $owner_id ), ARRAY_A ); // phpcs:ignore WordPress.DB
		return $rows ? $rows : array();
	}

	public function family_seats_left( int $owner_id ) : int {
		$limit = $this->limit( $owner_id, 'family_seats' );
		if ( 0 === $limit ) {
			return 0;
		}
		return max( 0, $limit - count( $this->family_members( $owner_id ) ) );
	}

	public function invite_code( int $owner_id ) : string {
		$code = get_user_meta( $owner_id, 'niva_family_code', true );
		if ( ! $code ) {
			$code = strtoupper( substr( md5( $owner_id . microtime( true ) ), 0, 6 ) );
			update_user_meta( $owner_id, 'niva_family_code', $code );
		}
		return (string) $code;
	}

	public function accept_invite( int $user_id, string $code ) {
		global $wpdb;
		$code = strtoupper( trim( sanitize_text_field( $code ) ) );

		$owner_id = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = 'niva_family_code' AND meta_value = %s LIMIT 1", $code ) // phpcs:ignore WordPress.DB
		);
		if ( ! $owner_id ) {
			return new WP_Error( 'niva_family_code', 'این کد معتبر نیست.', array( 'status' => 404 ) );
		}
		if ( $owner_id === $user_id ) {
			return new WP_Error( 'niva_family_self', 'خودت صاحب این اشتراک هستی.', array( 'status' => 400 ) );
		}
		if ( $this->family_seats_left( $owner_id ) < 1 ) {
			return new WP_Error( 'niva_family_full', 'ظرفیت اشتراک خانوادگی این کد پر است.', array( 'status' => 409 ) );
		}
		if ( $this->membership( $user_id ) ) {
			return new WP_Error( 'niva_family_has_plan', 'اشتراک شخصی داری؛ اول آن را لغو کن.', array( 'status' => 409 ) );
		}

		$wpdb->insert( // phpcs:ignore WordPress.DB
			Niva_DB::table( 'family_members' ),
			array(
				'owner_id'   => $owner_id,
				'member_id'  => $user_id,
				'joined_at'  => current_time( 'mysql' ),
			)
		);
		do_action( 'dr_niva_family_joined', $owner_id, $user_id );
		Niva_Notifications::notify( $owner_id, 'یک عضو جدید به اشتراک خانوادگی اضافه شد', get_userdata( $user_id )->display_name . ' با کد تو عضو شد.', home_url( '/' ) );
		return array( 'ok' => true, 'owner' => $owner_id );
	}

	public function remove_member( int $owner_id, int $member_id ) : void {
		global $wpdb;
		$wpdb->delete( Niva_DB::table( 'family_members' ), array( 'owner_id' => $owner_id, 'member_id' => $member_id ) ); // phpcs:ignore WordPress.DB
	}

	/* ----------------------------------------------------------------- summary */

	/** Payload for /me and the "subscription status" card. */
	public function summary( int $user_id = 0 ) : array {
		/*
		 * The id is optional on purpose: any cached template or third-party call
		 * that forgets it used to throw a fatal ArgumentCountError instead of
		 * simply describing the current user.
		 */
		if ( ! $user_id ) {
			$user_id = (int) get_current_user_id();
		}
		if ( ! $user_id ) {
			return array( 'plan' => 'free', 'label' => 'رایگان', 'active' => false );
		}

		$plan = $this->plan_of( $user_id );
		$keys = array( 'chat_per_day', 'lab_per_month', 'image_per_month', 'growth_profiles', 'reminders', 'family_seats' );
		$out  = array();

		foreach ( $keys as $key ) {
			$limit = $this->limit( $user_id, $key );
			$used  = $this->usage( $user_id, $key );
			$out[ $key ] = array(
				'limit'     => $limit,
				'used'      => $used,
				'remaining' => 0 === $limit ? -1 : max( 0, $limit - $used ),
				'unlimited' => 0 === $limit,
			);
		}

		return array(
			'plan'        => $plan['plan'],
			'label'       => $plan['label'],
			'active'      => $plan['active'],
			'inherited'   => $plan['inherited'],
			'expires'     => $plan['expires'],
			'upgrade_url' => Niva_Modules::url( 'plans' ),
			'credits_url' => Niva_Modules::url( 'wallet' ),
			'limits'      => $out,
			'family'      => 'family' === $plan['plan'] || $plan['inherited'] ? array(
				'code'        => $this->invite_code( $plan['inherited'] && isset( $plan['owner'] ) ? (int) $plan['owner'] : $user_id ),
				'members'     => $this->family_members( $plan['inherited'] && isset( $plan['owner'] ) ? (int) $plan['owner'] : $user_id ),
				'seats_left'  => $this->family_seats_left( $plan['inherited'] && isset( $plan['owner'] ) ? (int) $plan['owner'] : $user_id ),
			) : null,
		);
	}

	/* --------------------------------------------------- back-office helpers */

	/** Is this user currently holding the given plan (or inheriting it)? */
	public function has_plan( int $user_id, string $plan ) : bool {
		$current = $this->plan_of( $user_id );
		return ! empty( $current['active'] ) && (string) $current['plan'] === $plan;
	}

	/**
	 * Everyone currently holding one plan — used by the partners screen to show
	 * who already has the partner plan switched on.
	 *
	 * @return array<int,array<string,mixed>>
	 */
	public function holders( string $plan, int $limit = 100 ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'memberships' );
		$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( "SELECT * FROM {$table} WHERE plan = %s ORDER BY updated_at DESC LIMIT %d", $plan, $limit ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);
		if ( ! $rows ) {
			return array();
		}

		$out = array();
		foreach ( $rows as $row ) {
			$user = get_userdata( (int) $row['user_id'] );
			$row['display_name'] = $user ? $user->display_name : '#' . (int) $row['user_id'];
			$row['email']        = $user ? $user->user_email : '';
			$row['active']       = $this->is_current( $row );
			$out[]               = $row;
		}
		return $out;
	}

	/** Turns a plan on for one user. Lifetime when $days is 0. */
	public function grant( int $user_id, string $plan, int $days = 0, string $source = 'manual', string $ref = '' ) : bool {
		if ( ! $user_id || ! get_userdata( $user_id ) ) {
			return false;
		}
		$this->assign( $user_id, $plan, $source, $days, $ref );
		return true;
	}

	/* ------------------------------------------------------- plan configuration */

	const OPTION = 'dr_niva_plan_config';

	/** Feature keys the owner can set per plan, with a friendly label. */
	public static function feature_fields() : array {
		return array(
			'chat_per_day'    => 'گفت‌وگو با مشاور در روز',
			'lab_per_month'   => 'تحلیل آزمایش در ماه',
			'image_per_month' => 'تحلیل تصویر در ماه',
			'advisor_topics'  => 'موضوع مشاوره',
			'growth_profiles' => 'پروندهٔ رشد کودک',
			'reminders'       => 'یادآور فعال',
			'family_seats'    => 'عضو خانواده',
		);
	}

	/** Switches per plan. */
	public static function switch_fields() : array {
		return array(
			'pdf_export'    => 'خروجی PDF',
			'doctor_review' => 'بازبینی پزشکی',
		);
	}

	/**
	 * Every plan, exactly as the owner configured it. Stored as one option that
	 * the plan editor owns, so a bad settings registry can never break it.
	 */
	public static function plan_config() : array {
		$stored = get_option( self::OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		$plans  = isset( $stored['plans'] ) && is_array( $stored['plans'] ) ? $stored['plans'] : array();

		$out = array();
		foreach ( self::default_limits() as $key => $defaults ) {
			$row = array( 'price' => 0, 'discount' => 0 );
			foreach ( self::feature_fields() as $feature => $label ) {
				$row[ $feature ] = isset( $defaults[ $feature ] ) ? (int) $defaults[ $feature ] : 0;
			}
			foreach ( self::switch_fields() as $feature => $label ) {
				$row[ $feature ] = isset( $defaults[ $feature ] ) ? (int) $defaults[ $feature ] : 0;
			}
			if ( 'plus' === $key ) {
				$row['price'] = 149000;
			} elseif ( 'family' === $key ) {
				$row['price'] = 249000;
			} elseif ( 'partner' === $key ) {
				$row['price'] = 20000000;
			}
			if ( isset( $plans[ $key ] ) && is_array( $plans[ $key ] ) ) {
				$row = array_merge( $row, array_intersect_key( $plans[ $key ], $row ) );
			}
			$out[ $key ] = $row;
		}
		return $out;
	}

	/** Save the editor's values (already sanitised by the caller). */
	public static function save_plan_config( array $plans ) : void {
		update_option( self::OPTION, array( 'plans' => $plans ), false );
	}

	/* ------------------------------------------------------ sellable catalog */

	/** 'plus=149000, family=249000' -> array( plus => 149000, ... ) */
	private static function pairs( string $raw ) : array {
		$out = array();
		foreach ( explode( ',', $raw ) as $piece ) {
			$bits = explode( '=', $piece, 2 );
			if ( 2 === count( $bits ) ) {
				$out[ sanitize_key( trim( $bits[0] ) ) ] = (float) trim( $bits[1] );
			}
		}
		return $out;
	}

	/**
	 * The plans as they are actually sold: a monthly price, an optional discount
	 * and the real limits. Everything is editable in the back office, so the
	 * owner can change a price or run a discount without touching code.
	 */
	public static function catalog() : array {
		$settings = dr_niva()->settings;
		$config    = self::plan_config();
		$prices    = array();
		$discounts = array();
		foreach ( $config as $config_key => $config_row ) {
			$prices[ $config_key ]    = (float) $config_row['price'];
			$discounts[ $config_key ] = (float) $config_row['discount'];
		}
		$limits    = ( function_exists( 'dr_niva' ) && dr_niva()->plans ) ? dr_niva()->plans->limits() : self::default_limits();
		$labels    = self::labels();

		$out = array();
		foreach ( array( 'free', 'plus', 'family', 'partner' ) as $key ) {
			$price    = isset( $prices[ $key ] ) ? (float) $prices[ $key ] : 0;
			$discount = isset( $discounts[ $key ] ) ? max( 0, min( 90, (float) $discounts[ $key ] ) ) : 0;
			$pay      = $price > 0 ? (int) round( $price * ( 100 - $discount ) / 100 ) : 0;

			/* The plan's real limits, in words. 0 means "no ceiling" in this plugin. */
			$labels_map = array(
				'chat_per_day'    => 'گفت‌وگو با مشاور در روز: %s',
				'lab_per_month'   => 'تحلیل آزمایش در ماه: %s',
				'image_per_month' => 'تحلیل تصویر در ماه: %s',
				'advisor_topics'  => 'موضوع مشاوره: %s',
				'growth_profiles' => 'پروندهٔ رشد کودک: %s',
				'reminders'       => 'یادآور فعال: %s',
				'family_seats'    => 'عضو خانواده: %s',
				'pdf_export'      => 'خروجی PDF',
				'doctor_review'   => 'بازبینی پزشکی',
			);
			$features = array();
			foreach ( ( $limits[ $key ] ?? array() ) as $limit_key => $value ) {
				if ( ! isset( $labels_map[ $limit_key ] ) ) {
					continue;
				}
				$amount = ( 0 === (int) $value ) ? 'نامحدود' : Niva_Chrome::digits( (int) $value );
				$line   = $labels_map[ $limit_key ];
				$features[] = ( '%s' === substr( $line, -2 ) ) ? sprintf( $line, $amount ) : $line;
			}
			$features = array_slice( $features, 0, 6 );

			$out[ $key ] = array(
				'key'       => $key,
				'label'     => $labels[ $key ] ?? $key,
				'price'     => $price,
				'discount'  => $discount,
				'payable'   => $pay,
				'features'  => $features,
				'monthly'   => $price > 0,
				'unlimited' => false,
			);
		}
		return $out;
	}
}
