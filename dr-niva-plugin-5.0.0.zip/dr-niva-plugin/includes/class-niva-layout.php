<?php
/**
 * Module layout: which front-end modules exist, in what order, switched on or off.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Layout {

	/** Every module of the product. The admin can reorder or disable each one. */
	public static function modules() : array {
		return array(
			'home_tasks'    => array( 'label' => 'کارت‌های «الان چه کاری داری؟»', 'group' => 'صفحه اصلی', 'default' => 1 ),
			'home_status'   => array( 'label' => 'وضعیت امروزت', 'group' => 'صفحه اصلی', 'default' => 1 ),
			'home_message'  => array( 'label' => 'پیام امروز مشاور', 'group' => 'صفحه اصلی', 'default' => 1 ),
			'faq'           => array( 'label' => 'پرسش‌های پرتکرار', 'group' => 'عمومی', 'default' => 1 ),
			'advisor'       => array( 'label' => 'مشاور هوشمند', 'group' => 'ابزارها', 'default' => 1 ),
			'lab'           => array( 'label' => 'تحلیل آزمایش و تصویر', 'group' => 'ابزارها', 'default' => 1 ),
			'cycle'         => array( 'label' => 'تقویم چرخه', 'group' => 'ابزارها', 'default' => 1 ),
			'pregnancy'     => array( 'label' => 'مسیر بارداری', 'group' => 'ابزارها', 'default' => 1 ),
			'baby'          => array( 'label' => 'رشد نوزاد', 'group' => 'ابزارها', 'default' => 1 ),
			'mind'          => array( 'label' => 'حال من', 'group' => 'ابزارها', 'default' => 1 ),
			'reminders'     => array( 'label' => 'یادآور و اعلان', 'group' => 'ابزارها', 'default' => 1 ),
			'tools'         => array( 'label' => 'فهرست ابزارها', 'group' => 'ناوبری', 'default' => 1 ),
			'plans'         => array( 'label' => 'پلن‌ها و شارژ اعتبار', 'group' => 'ناوبری', 'default' => 1 ),
			'about'         => array( 'label' => 'درباره ما و حریم خصوصی', 'group' => 'ناوبری', 'default' => 1 ),
			'wallet_bar'    => array( 'label' => 'نوار اعتبار کاربر', 'group' => 'اعتبار', 'default' => 1 ),
		);
	}

	public function seed_defaults() : void {
		if ( false === get_option( DR_NIVA_LAYOUT_OPTION, false ) ) {
			$rows = array();
			$i    = 0;
			foreach ( self::modules() as $id => $module ) {
				$rows[] = array( 'id' => $id, 'enabled' => (int) $module['default'], 'order' => $i );
				$i++;
			}
			add_option( DR_NIVA_LAYOUT_OPTION, $rows );
		}
	}

	/** Ordered rows with any new module appended automatically. */
	public function all() : array {
		$stored = get_option( DR_NIVA_LAYOUT_OPTION, array() );
		$stored = is_array( $stored ) ? $stored : array();
		$seen   = array();
		$rows   = array();

		foreach ( $stored as $row ) {
			$id = isset( $row['id'] ) ? (string) $row['id'] : '';
			if ( '' === $id || ! array_key_exists( $id, self::modules() ) || isset( $seen[ $id ] ) ) {
				continue;
			}
			$rows[]        = array(
				'id'      => $id,
				'enabled' => empty( $row['enabled'] ) ? 0 : 1,
				'order'   => isset( $row['order'] ) ? (int) $row['order'] : count( $rows ),
			);
			$seen[ $id ] = true;
		}

		foreach ( self::modules() as $id => $module ) {
			if ( isset( $seen[ $id ] ) ) {
				continue;
			}
			$rows[] = array( 'id' => $id, 'enabled' => (int) $module['default'], 'order' => count( $rows ) );
		}

		usort(
			$rows,
			function ( $a, $b ) {
				return $a['order'] <=> $b['order'];
			}
		);
		return $rows;
	}

	/** @return array<int,string> */
	public function enabled_ids() : array {
		$out = array();
		foreach ( $this->all() as $row ) {
			if ( ! empty( $row['enabled'] ) ) {
				$out[] = $row['id'];
			}
		}
		return $out;
	}

	public function is_enabled( string $id ) : bool {
		foreach ( $this->all() as $row ) {
			if ( $row['id'] === $id ) {
				return ! empty( $row['enabled'] );
			}
		}
		return false;
	}

	/** Payload handed to the browser as window.NIVA_CONFIG.layout */
	public function config() : array {
		$out = array();
		foreach ( $this->all() as $row ) {
			$out[] = array(
				'id'      => $row['id'],
				'enabled' => (bool) $row['enabled'],
				'order'   => (int) $row['order'],
				'label'   => self::modules()[ $row['id'] ]['label'] ?? $row['id'],
			);
		}
		return $out;
	}

	/** Saves rows posted from the layout builder (id, enabled, order). */
	public function update( array $rows ) : array {
		$clean = array();
		$order = 0;
		foreach ( $rows as $row ) {
			$id = isset( $row['id'] ) ? sanitize_key( $row['id'] ) : '';
			if ( '' === $id || ! array_key_exists( $id, self::modules() ) ) {
				continue;
			}
			$clean[] = array(
				'id'      => $id,
				'enabled' => empty( $row['enabled'] ) ? 0 : 1,
				'order'   => $order,
			);
			$order++;
		}
		update_option( DR_NIVA_LAYOUT_OPTION, $clean );
		return $clean;
	}
}
