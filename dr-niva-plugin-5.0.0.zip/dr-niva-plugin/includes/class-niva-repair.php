<?php
/**
 * App-page repair (2.0.1).
 *
 * Two jobs:
 *
 *  1. Re-importing the WXR file must update the pages that are already there
 *     instead of creating a second copy of every screen.
 *  2. A site that imported the 2.0.0 file has pages whose only widget was a
 *     bare module, so the screen rendered without the app shell — and if the
 *     file was imported twice, each screen exists twice. The tool rewrites the
 *     kept page to `[dr_niva_app view="…"]` and moves the extras to the trash.
 *     Nothing is ever deleted permanently.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

/**
 * Page repair helper and the small admin screen that runs it.
 */
class Niva_Repair {

	/** Page key => the view the app shell must render for it. */
	public static function views() : array {
		return array(
			'home'             => 'home',
			'profile'          => 'profile',
			'cycle'            => 'cycle',
			'pregnancy'        => 'pregnancy',
			'mind'             => 'mind',
			'reminders'        => 'alarms',
			'analyze'          => 'analyze',
			'plans'            => 'plans',
			'wallet'           => 'wallet',
			'family'           => 'family',
			'partners'         => 'partners',
			'notifications'    => 'notifications',
			'tools'            => 'tools',
			'advisor'          => 'advisor',
			'baby'             => 'baby',
			'onboarding'       => 'onboarding',
			'community'        => 'community',
			'community_thread' => 'community_thread',
			'community_new'    => 'community_new',
			'companion_create' => 'companion_create',
			'companion_view'   => 'companion_view',
			'visibility'       => 'profile',
			'about'            => 'about',
			'faq'              => 'tools',
		);
	}

	public function __construct() {
		add_filter( 'wp_import_existing_post', array( $this, 'existing_post' ), 10, 2 );
		add_action( 'admin_menu', array( $this, 'menu' ), 20 );
		add_action( 'admin_post_dr_niva_repair_pages', array( $this, 'handle' ) );
	}

	/**
	 * Keeps a re-import honest: an existing page with the same slug is updated
	 * instead of duplicated. WordPress Importer calls this filter before insert.
	 *
	 * @param int   $post_id Existing post id, or 0.
	 * @param array $post    Post data being imported.
	 * @return int
	 */
	public function existing_post( $post_id, $post ) {
		if ( $post_id || ! is_array( $post ) ) {
			return $post_id;
		}
		if ( 'page' !== ( isset( $post['post_type'] ) ? (string) $post['post_type'] : 'post' ) ) {
			return $post_id;
		}
		$slug = isset( $post['post_name'] ) ? (string) $post['post_name'] : '';
		if ( '' === $slug ) {
			return $post_id;
		}
		$found = get_page_by_path( $slug );
		if ( $found instanceof WP_Post ) {
			return (int) $found->ID;
		}
		return $post_id;
	}

	public function menu() : void {
		add_submenu_page(
			'dr-niva',
			'تعمیر برگه‌ها',
			'تعمیر برگه‌ها',
			'manage_options',
			'dr-niva-repair',
			array( $this, 'page' )
		);
	}

	/** The tiny admin screen: what is wrong and one button to fix it. */
	public function page() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			return;
		}
		$report = get_transient( 'dr_niva_repair_result_' . get_current_user_id() );
		if ( $report ) {
			delete_transient( 'dr_niva_repair_result_' . get_current_user_id() );
		}
		$state = self::state();
		?>
		<div class="wrap avadm" dir="rtl">
			<h1>تعمیر برگه‌های اپ</h1>
			<p>
				این ابزار برگه‌های ساخته‌شده را به حالت درست برمی‌گرداند: هر برگه فقط نمای خودش را نشان می‌دهد،
				نسخه‌های تکراری به «زباله‌دان» می‌روند (حذف دائمی نمی‌شوند) و درون‌ریزی دوبارهٔ فایل XML هم دیگر
				برگهٔ تکراری نمی‌سازد.
			</p>

			<?php if ( $report ) : ?>
				<div class="notice notice-success">
					<p>
						<?php
						printf(
							'اصلاح‌شده: %s برگه · به زباله‌دان: %s · صفحه درست: %s',
							esc_html( number_format_i18n( count( $report['fixed'] ) ) ),
							esc_html( number_format_i18n( count( $report['trashed'] ) ) ),
							esc_html( number_format_i18n( count( $report['kept'] ) ) )
						);
						?>
					</p>
				</div>
			<?php endif; ?>

			<table class="widefat striped" style="max-width:900px">
				<thead>
					<tr>
						<th>کلید برگه</th>
						<th>نمای لازم</th>
						<th>وضعیت</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $state as $row ) : ?>
						<tr>
							<td><code><?php echo esc_html( $row['key'] ); ?></code></td>
							<td><code><?php echo esc_html( $row['view'] ); ?></code></td>
							<td>
								<?php if ( $row['ok'] ) : ?>
									<span style="color:#1b7f4b">درست</span>
								<?php elseif ( $row['missing'] ) : ?>
									<span style="color:#8a6d3b">برگه‌اش ساخته نشده — فایل XML را درون‌ریزی کن</span>
								<?php else : ?>
									<span style="color:#b03030">
										نیازمند اصلاح
										<?php if ( $row['duplicates'] > 1 ) : ?>
											(<?php echo esc_html( number_format_i18n( $row['duplicates'] ) ); ?> نسخه)
										<?php endif; ?>
									</span>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" style="margin-top:16px">
				<input type="hidden" name="action" value="dr_niva_repair_pages" />
				<?php wp_nonce_field( 'dr_niva_repair_pages' ); ?>
				<button type="submit" class="button button-primary">اصلاح برگه‌ها</button>
			</form>
		</div>
		<?php
	}

	public function handle() : void {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_die( esc_html__( 'دسترسی لازم را نداری.', 'dr-niva' ) );
		}
		check_admin_referer( 'dr_niva_repair_pages' );
		set_transient( 'dr_niva_repair_result_' . get_current_user_id(), self::run(), 300 );
		wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-repair' ) );
		exit;
	}

	/**
	 * What each screen looks like right now.
	 *
	 * @return array<int,array{key:string,view:string,ok:bool,missing:bool,duplicates:int,id:int}>
	 */
	public static function state() : array {
		$out = array();
		foreach ( self::views() as $key => $view ) {
			$pages = self::pages_for( $key );
			$first = $pages ? $pages[0] : null;
			$out[] = array(
				'key'        => $key,
				'view'       => $view,
				'ok'         => $first ? self::is_correct( (int) $first->ID, $view ) : false,
				'missing'    => ! $first,
				'duplicates' => count( $pages ),
				'id'         => $first ? (int) $first->ID : 0,
			);
		}
		return $out;
	}

	/**
	 * Rewrites every app page to the shell and trashes the duplicates.
	 *
	 * @return array{fixed:array,trashed:array,kept:array}
	 */
	public static function run() : array {
		$fixed   = array();
		$trashed = array();
		$kept    = array();

		foreach ( self::views() as $key => $view ) {
			$pages = self::pages_for( $key );
			if ( ! $pages ) {
				continue;
			}
			// The oldest page wins: it is the one the menu and search engines know.
			$keep = (int) $pages[0]->ID;
			$kept[] = $key;

			foreach ( array_slice( $pages, 1 ) as $extra ) {
				wp_trash_post( (int) $extra->ID );
				$trashed[] = (int) $extra->ID;
			}

			if ( ! self::is_correct( $keep, $view ) ) {
				self::write_view( $keep, $key, $view );
				$fixed[] = $keep;
			}
		}

		Niva_Links::flush_page_map();
		delete_transient( 'dr_niva_app_shell_page' );

		if ( class_exists( '\Elementor\Plugin' ) && isset( \Elementor\Plugin::$instance->files_manager ) ) {
			\Elementor\Plugin::$instance->files_manager->clear_cache();
		}

		return array(
			'fixed'   => $fixed,
			'trashed' => $trashed,
			'kept'    => $kept,
		);
	}

	/**
	 * All pages carrying a page key, oldest first.
	 *
	 * @return WP_Post[]
	 */
	private static function pages_for( string $key ) : array {
		$pages = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => array( 'publish', 'draft', 'pending', 'private' ),
				'posts_per_page'   => 50,
				'orderby'          => 'ID',
				'order'            => 'ASC',
				'suppress_filters' => true,
				'meta_key'         => '_dr_niva_page_key', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => $key, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);
		if ( $pages ) {
			return $pages;
		}

		// No meta yet (an older import): fall back to the known slugs.
		$registry = Niva_Links::registry();
		$slugs    = isset( $registry[ $key ][1] ) && is_array( $registry[ $key ][1] ) ? $registry[ $key ][1] : array();
		foreach ( $slugs as $slug ) {
			$page = get_page_by_path( $slug );
			if ( $page instanceof WP_Post ) {
				update_post_meta( (int) $page->ID, '_dr_niva_page_key', $key );
				return array( $page );
			}
		}
		return array();
	}

	/** Whether the page already renders the shell for the expected view. */
	private static function is_correct( int $page_id, string $view ) : bool {
		$data  = (string) get_post_meta( $page_id, '_elementor_data', true );
		$content = (string) get_post_field( 'post_content', $page_id );
		$needle = 'dr_niva_app view="' . $view . '"';
		return false !== strpos( $data, $needle ) || false !== strpos( $content, $needle );
	}

	/** Writes the shell shortcode into the page, as an Elementor widget. */
	private static function write_view( int $page_id, string $key, string $view ) : void {
		$data = sprintf(
			'[{"id":"sec-%1$s","elType":"section","settings":[],"elements":[{"id":"col-%1$s","elType":"column","settings":{"_column_size":100},"elements":[{"id":"wid-%1$s","elType":"widget","settings":{"shortcode":"[dr_niva_app view=\\"%2$s\\"]"},"elements":[],"widgetType":"shortcode"}]}]}]',
			$key,
			$view
		);
		update_post_meta( $page_id, '_elementor_data', wp_slash( $data ) );
		update_post_meta( $page_id, '_elementor_edit_mode', 'builder' );
		update_post_meta( $page_id, '_elementor_template_type', 'wp-page' );
		update_post_meta( $page_id, '_elementor_version', defined( 'ELEMENTOR_VERSION' ) ? ELEMENTOR_VERSION : '3.0.0' );
		update_post_meta( $page_id, '_dr_niva_page_key', $key );
		update_post_meta( $page_id, '_wp_page_template', 'elementor_canvas' );
	}
}
