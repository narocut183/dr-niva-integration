<?php
/**
 * Onboarding wizard (2.0.0).
 *
 * Replaces the old single-sheet onboarding modal with a full-page, one-question
 * per step wizard that saves after every step. Everything here is server-side:
 * the step list, the visibility rules (a man never sees the cycle questions),
 * the validation, the snooze window and the one-time nudge notification.
 *
 * The wizard never invents an answer. A skipped question stays empty and the
 * screens downstream show an explicit "not set yet" state.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Onboarding {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
		add_action( 'init', array( $this, 'maybe_nudge' ), 30 );
	}

	/**
	 * The fourteen steps, in order.
	 *
	 * `audience` decides who may see a step: 'female' steps are hidden from a
	 * man (and from anyone who has not said they are a woman) instead of being
	 * shown greyed out.
	 *
	 * @return array<string,array>
	 */
	public static function steps() : array {
		return array(
			'name'          => array(
				'title'  => 'اسمت را بنویس',
				'hint'   => 'با همین اسم داخل اپ صدایت می‌زنیم.',
				'fields' => array( 'first_name', 'last_name', 'avatar_id' ),
				'audience' => 'all',
				'optional' => false,
			),
			'phone'         => array(
				'title'  => 'شمارهٔ موبایلت',
				'hint'   => 'برای تأیید و بازیابی حساب. می‌توانی فعلاً رد کنی.',
				'fields' => array( 'phone' ),
				'audience' => 'all',
				'optional' => true,
			),
			'sex'           => array(
				'title'  => 'جنسیت',
				'hint'   => 'تا محتوای درست را نشانت بدهیم.',
				'fields' => array( 'sex' ),
				'audience' => 'all',
				'optional' => false,
			),
			'birth'         => array(
				'title'  => 'سال تولدت را انتخاب کن',
				'hint'   => 'برای محاسبهٔ دقیق سن و یادآورها کمک می‌کند.',
				'fields' => array( 'birth_date' ),
				'audience' => 'all',
				'optional' => true,
			),
			'height'        => array(
				'title'  => 'قدت چقدر است؟',
				'hint'   => 'برای محاسبهٔ شاخص تودهٔ بدنی.',
				'fields' => array( 'height' ),
				'audience' => 'all',
				'optional' => true,
			),
			'weight'        => array(
				'title'  => 'وزنت چقدر است؟',
				'hint'   => 'می‌توانی حدودی وارد کنی.',
				'fields' => array( 'weight' ),
				'audience' => 'all',
				'optional' => true,
			),
			'lmp'           => array(
				'title'  => 'آخرین بار چه روزی پریود شدی؟',
				'hint'   => 'اگر یادت نیست رد کن؛ بعداً هم می‌شود اصلاح کرد.',
				'fields' => array( 'lmp' ),
				'audience' => 'female',
				'optional' => true,
			),
			'period_length' => array(
				'title'  => 'پریود شما معمولاً چند روز طول می‌کشد؟',
				'hint'   => 'می‌توانی حدودی وارد کنی. اگر نمی‌دانی رد کن.',
				'fields' => array( 'period_length' ),
				'audience' => 'female',
				'optional' => true,
			),
			'cycle_length'  => array(
				'title'  => 'سیکل شما معمولاً چند روز طول می‌کشد؟',
				'hint'   => 'از اولین روز پریود تا اولین روز پریود بعدی.',
				'fields' => array( 'cycle_length' ),
				'audience' => 'female',
				'optional' => true,
			),
			'pregnancy'     => array(
				'title'  => 'آیا باردار هستی؟',
				'hint'   => 'اگر بله، هفتهٔ بارداری را حساب می‌کنیم و تأیید می‌گیریم.',
				'fields' => array( 'pregnant', 'lmp', 'due_date' ),
				'audience' => 'female',
				'optional' => true,
			),
			'baby'          => array(
				'title'  => 'فرزندی داری؟',
				'hint'   => 'برای پیگیری رشد و یادآورهای کودک.',
				'fields' => array( 'baby_name', 'baby_birth' ),
				'audience' => 'all',
				'optional' => true,
			),
			'mood'          => array(
				'title'  => 'این روزها حالت چطور است؟',
				'hint'   => 'یک انتخاب ساده؛ می‌توانی رد کنی.',
				'fields' => array( 'mood_scores' ),
				'audience' => 'all',
				'optional' => true,
			),
			'notify'        => array(
				'title'  => 'اجازهٔ اطلاع‌رسانی',
				'hint'   => 'یادآور دارو و قرار را برایت بفرستیم. فقط با اجازهٔ خودت.',
				'fields' => array( 'channels' ),
				'audience' => 'all',
				'optional' => true,
			),
			'focus'         => array(
				'title'  => 'دوست داری دکتر نیوا کجا را اول نشانت بدهد؟',
				'hint'   => 'هر وقت خواستی عوضش کن.',
				'fields' => array( 'focus_area' ),
				'audience' => 'all',
				'optional' => true,
			),
		);
	}

	/** Focus areas the last step offers. */
	public static function focus_areas() : array {
		return array(
			'cycle' => array( 'label' => 'چرخه و باروری', 'icon' => 'droplet' ),
			'mind'  => array( 'label' => 'سلامت روان', 'icon' => 'heart' ),
			'baby'  => array( 'label' => 'مراقبت نوزاد', 'icon' => 'baby' ),
		);
	}

	private function profile() : Niva_Profile {
		return dr_niva()->profile instanceof Niva_Profile ? dr_niva()->profile : new Niva_Profile();
	}

	/* ------------------------------------------------------------------- state */

	public function state( int $user_id = 0 ) : array {
		$user_id = $user_id ? $user_id : (int) get_current_user_id();
		$profile = $user_id ? $this->profile()->get( $user_id ) : array();
		$raw     = isset( $profile['onboarding_state'] ) && is_array( $profile['onboarding_state'] ) ? $profile['onboarding_state'] : array();

		$snoozed_until = (string) ( $raw['snoozed_until'] ?? '' );
		$state         = array(
			'completed'     => ! empty( $raw['completed'] ) || ! empty( $profile['profile_completed'] ),
			'step'          => (string) ( $raw['step'] ?? '' ),
			'skipped'       => array_values( (array) ( $raw['skipped'] ?? array() ) ),
			'notified'      => ! empty( $raw['notified'] ),
			'snoozed_until' => $snoozed_until,
			'snoozed'       => '' !== $snoozed_until && strtotime( $snoozed_until ) > time(),
			'profile_percent' => (int) ( $profile['completion']['percent'] ?? 0 ),
		);
		$state['steps']    = $this->visible_steps( $user_id );
		$state['order']    = array_keys( $state['steps'] );
		$state['values']   = $this->values( $profile, $user_id );
		$state['progress'] = $this->progress( $state );
		return $state;
	}

	/** The subset of steps this user should be asked. */
	public function visible_steps( int $user_id ) : array {
		$steps = self::steps();
		$sex   = (string) ( $this->profile()->get( $user_id )['sex'] ?? '' );
		$out   = array();
		foreach ( $steps as $id => $step ) {
			if ( 'female' === $step['audience'] && 'female' !== $sex ) {
				continue;
			}
			$out[ $id ] = array(
				'title'    => $step['title'],
				'hint'     => $step['hint'],
				'fields'   => $step['fields'],
				'optional' => (bool) $step['optional'],
			);
		}
		return $out;
	}

	/** Values the wizard pre-fills from the profile (never a made-up default). */
	private function values( array $profile, int $user_id ) : array {
		return array(
			'first_name'    => (string) ( $profile['first_name'] ?? '' ),
			'last_name'     => (string) ( $profile['last_name'] ?? '' ),
			'avatar_id'     => (int) ( $profile['avatar_id'] ?? 0 ),
			'avatar_url'    => (string) ( $profile['avatar_url'] ?? '' ),
			'phone'         => (string) get_user_meta( $user_id, 'niva_phone', true ),
			'phone_verified' => (bool) get_user_meta( $user_id, 'niva_phone_verified', true ),
			'sex'           => (string) ( $profile['sex'] ?? '' ),
			'birth_date'    => (string) ( $profile['birth_date'] ?? '' ),
			'height'        => (string) ( $profile['height'] ?? '' ),
			'weight'        => (string) ( $profile['weight'] ?? '' ),
			'lmp'           => (string) ( $profile['lmp'] ?? '' ),
			'period_length' => (string) ( $profile['period_length'] ?? '' ),
			'cycle_length'  => (string) ( $profile['cycle_length'] ?? '' ),
			'pregnant'      => ! empty( $profile['pregnant'] ),
			'due_date'      => (string) ( $profile['due_date'] ?? '' ),
			'baby_name'     => (string) ( $profile['baby_name'] ?? '' ),
			'baby_birth'    => (string) ( $profile['baby_birth'] ?? '' ),
			'focus_area'    => (string) ( $profile['focus_area'] ?? '' ),
		);
	}

	/** How many of the visible steps already have an answer. */
	private function progress( array $state ) : array {
		$values = $state['values'];
		$done   = 0;
		$total  = max( 1, count( $state['steps'] ) );
		foreach ( $state['steps'] as $id => $step ) {
			if ( $this->step_answered( $id, $values ) ) {
				$done++;
			}
		}
		return array( 'done' => $done, 'total' => $total, 'percent' => (int) round( ( $done / $total ) * 100 ) );
	}

	private function step_answered( string $step_id, array $values ) : bool {
		switch ( $step_id ) {
			case 'name':
				return '' !== trim( $values['first_name'] . $values['last_name'] );
			case 'phone':
				return '' !== trim( (string) $values['phone'] );
			case 'sex':
				return '' !== $values['sex'];
			case 'birth':
				return '' !== $values['birth_date'];
			case 'height':
				return '' !== trim( (string) $values['height'] );
			case 'weight':
				return '' !== trim( (string) $values['weight'] );
			case 'lmp':
				return '' !== $values['lmp'];
			case 'period_length':
				return '' !== trim( (string) $values['period_length'] );
			case 'cycle_length':
				return '' !== trim( (string) $values['cycle_length'] );
			case 'pregnancy':
				return ! empty( $values['pregnant'] ) || '' !== $values['due_date'];
			case 'baby':
				return '' !== trim( $values['baby_name'] ) || '' !== $values['baby_birth'];
			case 'mood':
				return '' !== (string) ( $values['mood_scores'] ?? '' ) && '0' !== (string) ( $values['mood_scores'] ?? '' );
			case 'notify':
				return ! empty( $values['channels'] );
			case 'focus':
				return '' !== $values['focus_area'];
		}
		return false;
	}

	/** True when a user still needs the wizard and has not closed it for now. */
	public function needs_wizard( int $user_id = 0 ) : bool {
		$user_id = $user_id ? $user_id : (int) get_current_user_id();
		if ( ! $user_id ) {
			return false;
		}
		if ( ! dr_niva()->settings->is_on( 'onboarding_wizard_enabled' ) ) {
			return false;
		}
		$state = $this->state( $user_id );
		if ( $state['completed'] ) {
			return false;
		}
		return ! $state['snoozed'];
	}

	/** Closes the wizard for a while (default from settings, 7 days). */
	public function snooze( int $user_id, int $days = 0 ) : void {
		$days = $days > 0 ? $days : (int) dr_niva()->settings->get( 'onboarding_snooze_days', 7 );
		$this->save_state(
			$user_id,
			array( 'snoozed_until' => gmdate( 'Y-m-d H:i:s', time() + max( 1, $days ) * DAY_IN_SECONDS ) )
		);
	}

	/** Merges a patch into the stored onboarding state. */
	public function save_state( int $user_id, array $patch ) : array {
		$profile = $this->profile();
		$current = $profile->get( $user_id );
		$state   = isset( $current['onboarding_state'] ) && is_array( $current['onboarding_state'] ) ? $current['onboarding_state'] : array();

		$next = array(
			'completed'     => ! empty( $state['completed'] ),
			'step'          => (string) ( $state['step'] ?? '' ),
			'skipped'       => array_values( (array) ( $state['skipped'] ?? array() ) ),
			'notified'      => ! empty( $state['notified'] ),
			'snoozed_until' => (string) ( $state['snoozed_until'] ?? '' ),
		);

		if ( array_key_exists( 'completed', $patch ) ) {
			$next['completed'] = $patch['completed'] ? 1 : 0;
		}
		if ( isset( $patch['step'] ) ) {
			$next['step'] = sanitize_key( (string) $patch['step'] );
		}
		if ( isset( $patch['skipped'] ) ) {
			$next['skipped'] = array_slice( array_values( array_filter( array_map( 'sanitize_key', (array) $patch['skipped'] ) ) ), 0, 30 );
		}
		if ( isset( $patch['notified'] ) ) {
			$next['notified'] = $patch['notified'] ? 1 : 0;
		}
		if ( isset( $patch['snoozed_until'] ) ) {
			$value                   = (string) $patch['snoozed_until'];
			$next['snoozed_until']   = preg_match( '/^\d{4}-\d{2}-\d{2} \d{2}:\d{2}:\d{2}$/', $value ) ? $value : '';
		}

		// Niva_Profile::save() is the single writer of niva_profile, so the state
		// goes through it (partial mode keeps every other field intact).
		$profile->save(
			$user_id,
			array( '__partial' => 1, 'onboarding_state' => $next ) + $this->profile_input( $user_id )
		);
		return $this->state( $user_id );
	}

	/** Current profile values, so a partial save never blanks a field. */
	private function profile_input( int $user_id ) : array {
		$profile = $this->profile()->get( $user_id );
		unset( $profile['completion'], $profile['avatar_url'], $profile['full_name'], $profile['age'] );
		return $profile;
	}

	/* ------------------------------------------------------------------ nudges */

	/**
	 * One internal notification per user, ever, for an unfinished profile.
	 *
	 * Runs at most once every few minutes per request and only for people who
	 * actually still need the wizard, so it cannot turn into a spam loop.
	 */
	public function maybe_nudge() : void {
		if ( ! is_user_logged_in() || ! dr_niva()->settings->is_on( 'onboarding_notice_enabled' ) ) {
			return;
		}
		$user_id = (int) get_current_user_id();
		if ( get_transient( 'niva_ob_nudge_check_' . $user_id ) ) {
			return;
		}
		set_transient( 'niva_ob_nudge_check_' . $user_id, 1, 6 * HOUR_IN_SECONDS );

		$state = $this->state( $user_id );
		if ( $state['completed'] || $state['notified'] ) {
			return;
		}
		if ( class_exists( 'Niva_Notifications' ) ) {
			Niva_Notifications::notify(
				$user_id,
				'پروفایلت کامل نیست — ۲ دقیقه وقت می‌برد',
				'با کامل‌کردن پروفایل، محتوای اپ دقیق‌تر و شخصی‌تر می‌شود.',
				Niva_Modules::url( 'onboarding_wizard', array(), home_url( '/?dr_niva_wizard=1' ) )
			);
		}
		$this->save_state( $user_id, array( 'notified' => 1 ) );
	}

	/* -------------------------------------------------------------------- REST */

	public function routes() : void {
		$auth = array( 'permission_callback' => array( $this, 'can_use' ) );

		register_rest_route(
			Niva_Rest::NS,
			'/onboarding/state',
			array( 'methods' => 'GET', 'callback' => array( $this, 'rest_state' ) ) + $auth
		);
		register_rest_route(
			Niva_Rest::NS,
			'/onboarding/step',
			array( 'methods' => 'POST', 'callback' => array( $this, 'rest_step' ) ) + $auth
		);
		register_rest_route(
			Niva_Rest::NS,
			'/onboarding/complete',
			array( 'methods' => 'POST', 'callback' => array( $this, 'rest_complete' ) ) + $auth
		);
		register_rest_route(
			Niva_Rest::NS,
			'/onboarding/snooze',
			array( 'methods' => 'POST', 'callback' => array( $this, 'rest_snooze' ) ) + $auth
		);
		register_rest_route(
			Niva_Rest::NS,
			'/onboarding/avatar',
			array( 'methods' => 'POST', 'callback' => array( $this, 'rest_avatar' ) ) + $auth
		);
		/*
		 * 2.0.1 — the browser downsizes the picture and posts it as data, so a
		 * phone photo can no longer exhaust memory and turn into an HTML error
		 * page (the «Unexpected token '<'» the user saw).
		 */
		register_rest_route(
			Niva_Rest::NS,
			'/onboarding/avatar-json',
			array( 'methods' => 'POST', 'callback' => array( $this, 'rest_avatar_data' ) ) + $auth
		);
		register_rest_route(
			Niva_Rest::NS,
			'/onboarding/otp',
			array( 'methods' => 'POST', 'callback' => array( $this, 'rest_otp' ) ) + $auth
		);
	}

	public function can_use() : bool {
		return is_user_logged_in();
	}

	private function no_cache( WP_REST_Response $response ) : WP_REST_Response {
		$response->header( 'Cache-Control', 'no-store, no-cache, must-revalidate' );
		return $response;
	}

	public function rest_state( WP_REST_Request $request ) {
		return $this->no_cache( new WP_REST_Response( $this->state(), 200 ) );
	}

	/**
	 * Saves one step.
	 *
	 * The step id decides which fields are accepted, so a crafted request can
	 * never write a field the wizard does not own.
	 */
	public function rest_step( WP_REST_Request $request ) {
		$user_id  = (int) get_current_user_id();
		$step_id  = sanitize_key( (string) $request->get_param( 'step' ) );
		$steps    = self::steps();
		$visible  = $this->visible_steps( $user_id );

		if ( isset( $steps[ $step_id ] ) && ! isset( $visible[ $step_id ] ) ) {
			return new WP_Error( 'niva_step_hidden', 'این مرحله برای پروفایل تو فعال نیست.', array( 'status' => 403 ) );
		}
		if ( ! isset( $steps[ $step_id ] ) ) {
			return new WP_Error( 'niva_step_unknown', 'این مرحله شناخته نشد.', array( 'status' => 400 ) );
		}

		$data   = (array) $request->get_param( 'data' );
		$input  = array( '__partial' => 1 ) + $this->profile_input( $user_id );
		$fields = $steps[ $step_id ]['fields'];
		$skip   = (bool) $request->get_param( 'skip' );

		if ( 'phone' === $step_id ) {
			$phone = isset( $data['phone'] ) ? preg_replace( '/[^0-9+]/', '', (string) $data['phone'] ) : '';
			update_user_meta( $user_id, 'niva_phone', $phone );
			$input = array( '__partial' => 1 ) + $this->profile_input( $user_id );
		} else {
			foreach ( $fields as $field ) {
				if ( array_key_exists( $field, $data ) ) {
					$input[ $field ] = $data[ $field ];
				}
			}
		}

		$before = $this->state( $user_id );
		try {
			$this->profile()->save( $input );
		} catch ( \Throwable $error ) {
			// 3.3.0 — a write problem must never answer with an HTML crash page;
			// the step advances and the final save carries the whole bag.
			if ( function_exists( 'error_log' ) ) {
				error_log( '[dr-niva] onboarding step save failed: ' . $error->getMessage() ); // phpcs:ignore
			}
		}

		/*
		 * The next step is computed after the save, because answering «جنسیت»
		 * changes which steps exist at all (a man loses the cycle questions).
		 */
		$order    = array_keys( $this->visible_steps( $user_id ) );
		$index    = array_search( $step_id, $order, true );
		$next_id  = ( false !== $index && isset( $order[ $index + 1 ] ) ) ? (string) $order[ $index + 1 ] : '';
		$skipped  = $before['skipped'];
		if ( $skip ) {
			$skipped[] = $step_id;
			$skipped   = array_values( array_unique( $skipped ) );
		} else {
			$skipped = array_values( array_diff( $skipped, array( $step_id ) ) );
		}

		$state = $this->save_state( $user_id, array( 'step' => $next_id, 'skipped' => $skipped ) );

		return $this->no_cache( new WP_REST_Response( array( 'ok' => true, 'state' => $state ), 200 ) );
	}

	public function rest_complete( WP_REST_Request $request ) {
		$user_id = (int) get_current_user_id();

		/*
		 * 3.3.0 — this endpoint only flipped the «completed» flag, so any step
		 * whose own request failed took its answer with it. The last screen now
		 * sends the whole questionnaire back and it is written here as well, so
		 * nothing the user typed can be lost.
		 */
		$bag = $request->get_param( 'data' );
		if ( is_array( $bag ) && $bag ) {
			$known = array();
			foreach ( self::steps() as $definition ) {
				foreach ( (array) ( $definition['fields'] ?? array() ) as $field ) {
					$known[ (string) $field ] = true;
				}
			}
			$input = array( '__partial' => 1 ) + $this->profile_input( $user_id );
			foreach ( $bag as $field => $value ) {
				if ( isset( $known[ (string) $field ] ) ) {
					$input[ (string) $field ] = $value;
				}
			}
			if ( isset( $bag['channels'] ) && is_array( $bag['channels'] ) ) {
				$input['channels'] = $bag['channels'];
			}
			try {
				$this->profile()->save( $input );
			} catch ( \Throwable $error ) {
				return new WP_Error( 'niva_complete_failed', 'ذخیرهٔ نهایی انجام نشد؛ یک بار دیگر تلاش کن.', array( 'status' => 500 ) );
			}
		}

		$state = $this->save_state( $user_id, array( 'completed' => 1, 'step' => '' ) );
		return $this->no_cache( new WP_REST_Response( array( 'ok' => true, 'state' => $state ), 200 ) );
	}

	public function rest_snooze( WP_REST_Request $request ) {
		$user_id = (int) get_current_user_id();
		$this->snooze( $user_id, (int) $request->get_param( 'days' ) );
		return $this->no_cache( new WP_REST_Response( array( 'ok' => true, 'state' => $this->state( $user_id ) ), 200 ) );
	}

	/**
	 * Avatar upload.
	 *
	 * Validated against the site's own allowed types and the configured size
	 * limit, then handed to WordPress so the media library does the work.
	 */
	public function rest_avatar( WP_REST_Request $request ) {
		return $this->handle_avatar( $request, false );
	}

	/** Avatar sent as a resized data URL (JSON) — no multipart, no fatals. */
	public function rest_avatar_data( WP_REST_Request $request ) {
		return $this->handle_avatar( $request, true );
	}

	/**
	 * One upload path for both transports.
	 *
	 * Everything that can throw is caught and answered as JSON. A fatal inside
	 * the upload used to be delivered as WordPress' HTML crash page, which the
	 * browser reported as «…” is not valid JSON».
	 */
	private function handle_avatar( WP_REST_Request $request, bool $as_data ) {
		$user_id = (int) get_current_user_id();
		if ( ! dr_niva()->settings->is_on( 'avatar_allow_user_upload' ) ) {
			return new WP_Error( 'niva_avatar_disabled', 'آپلود عکس پروفایل خاموش است.', array( 'status' => 403 ) );
		}

		$max_mb  = max( 1, (int) dr_niva()->settings->get( 'avatar_max_mb', 2 ) );
		$allowed = array_filter( array_map( 'trim', explode( ',', (string) dr_niva()->settings->get( 'avatar_allowed_types', 'jpg,jpeg,png,webp' ) ) ) );

		try {
			$attachment_id = $as_data
				? $this->avatar_from_data( (string) $request->get_param( 'data' ), $max_mb, $allowed, $user_id )
				: $this->avatar_from_upload( $request, $max_mb, $allowed, $user_id );
		} catch ( \Throwable $error ) {
			return new WP_Error( 'niva_avatar_failed', 'عکس ذخیره نشد: ' . $error->getMessage(), array( 'status' => 500 ) );
		}

		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		$this->profile()->save(
			$user_id,
			array( '__partial' => 1, 'avatar_id' => (int) $attachment_id ) + $this->profile_input( $user_id )
		);

		return $this->no_cache(
			new WP_REST_Response(
				array(
					'ok'    => true,
					'id'    => (int) $attachment_id,
					'url'   => $this->avatar_url( (int) $attachment_id ),
					'state' => $this->state( $user_id ),
				),
				200
			)
		);
	}

	/** The best available URL for a chosen avatar. */
	private function avatar_url( int $attachment_id ) : string {
		$url = (string) wp_get_attachment_image_url( $attachment_id, 'thumbnail' );
		if ( '' === $url ) {
			$url = (string) wp_get_attachment_url( $attachment_id );
		}
		return $url;
	}

	/** Classic multipart upload from the file input. */
	private function avatar_from_upload( WP_REST_Request $request, int $max_mb, array $allowed, int $user_id ) {
		$files = $request->get_file_params();
		$file  = isset( $files['file'] ) && is_array( $files['file'] ) ? $files['file'] : array();
		if ( ! $file ) {
			return new WP_Error( 'niva_avatar_missing', 'فایلی انتخاب نشده است.', array( 'status' => 400 ) );
		}
		if ( ! empty( $file['error'] ) ) {
			return new WP_Error( 'niva_avatar_upload', $this->upload_error_message( (int) $file['error'] ), array( 'status' => 400 ) );
		}
		if ( (int) $file['size'] > $max_mb * MB_IN_BYTES ) {
			return new WP_Error( 'niva_avatar_size', 'حجم عکس باید حداکثر ' . $max_mb . ' مگابایت باشد.', array( 'status' => 400 ) );
		}
		$check = wp_check_filetype_and_ext( (string) $file['tmp_name'], sanitize_file_name( (string) $file['name'] ) );
		$ext   = strtolower( (string) ( $check['ext'] ?? '' ) );
		if ( '' === $ext || ! in_array( $ext, $allowed, true ) ) {
			return new WP_Error( 'niva_avatar_type', 'فقط این فرمت‌ها مجاز است: ' . implode( ', ', $allowed ), array( 'status' => 400 ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		return media_handle_upload(
			'file',
			0,
			array( 'post_title' => 'عکس پروفایل ' . $user_id ),
			array( 'test_form' => false )
		);
	}

	/** Data-URL upload: validated, decoded and stored through the media library. */
	private function avatar_from_data( string $data, int $max_mb, array $allowed, int $user_id ) {
		$data = trim( $data );
		if ( '' === $data ) {
			return new WP_Error( 'niva_avatar_missing', 'عکسی انتخاب نشده است.', array( 'status' => 400 ) );
		}
		if ( ! preg_match( '#^data:image/([a-z0-9+.-]+);base64,(.+)$#i', $data, $match ) ) {
			return new WP_Error( 'niva_avatar_type', 'فقط تصویر قابل قبول است.', array( 'status' => 400 ) );
		}
		$ext = strtolower( 'jpeg' === strtolower( $match[1] ) ? 'jpg' : strtolower( $match[1] ) );
		if ( ! in_array( $ext, $allowed, true ) ) {
			return new WP_Error( 'niva_avatar_type', 'فقط این فرمت‌ها مجاز است: ' . implode( ', ', $allowed ), array( 'status' => 400 ) );
		}
		$bytes = base64_decode( preg_replace( '/\s+/', '', (string) $match[2] ), true ); // phpcs:ignore WordPress.PHP.DiscouragedPHPFunctions
		if ( false === $bytes || '' === $bytes ) {
			return new WP_Error( 'niva_avatar_broken', 'فایل تصویری ارسالی سالم نبود.', array( 'status' => 400 ) );
		}
		if ( strlen( $bytes ) > $max_mb * MB_IN_BYTES ) {
			return new WP_Error( 'niva_avatar_size', 'حجم عکس باید حداکثر ' . $max_mb . ' مگابایت باشد.', array( 'status' => 400 ) );
		}

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';

		$upload = wp_upload_bits( 'niva-avatar-' . $user_id . '-' . wp_generate_password( 6, false, false ) . '.' . $ext, null, $bytes );
		if ( ! empty( $upload['error'] ) ) {
			return new WP_Error( 'niva_avatar_write', (string) $upload['error'], array( 'status' => 500 ) );
		}

		$filetype      = wp_check_filetype( (string) $upload['file'] );
		$attachment_id = wp_insert_attachment(
			array(
				'post_mime_type' => $filetype['type'] ? $filetype['type'] : 'image/' . $ext,
				'post_title'     => 'عکس پروفایل ' . $user_id,
				'post_status'    => 'inherit',
			),
			(string) $upload['file'],
			0,
			true
		);
		if ( is_wp_error( $attachment_id ) ) {
			return $attachment_id;
		}

		// A failed metadata pass must not lose the avatar itself.
		try {
			wp_update_attachment_metadata(
				(int) $attachment_id,
				wp_generate_attachment_metadata( (int) $attachment_id, (string) $upload['file'] )
			);
		} catch ( \Throwable $error ) {
			unset( $error ); // the file is stored; only the extra sizes are missing
		}
		return (int) $attachment_id;
	}

	/** Turns PHP's upload error code into a sentence a user can act on. */
	private function upload_error_message( int $code ) : string {
		switch ( $code ) {
			case UPLOAD_ERR_INI_SIZE:
			case UPLOAD_ERR_FORM_SIZE:
				return 'حجم عکس بیشتر از حد مجاز سرور است.';
			case UPLOAD_ERR_PARTIAL:
				return 'آپلود کامل نشد؛ دوباره تلاش کن.';
			case UPLOAD_ERR_NO_FILE:
				return 'فایلی انتخاب نشده است.';
			case UPLOAD_ERR_NO_TMP_DIR:
			case UPLOAD_ERR_CANT_WRITE:
				return 'پوشهٔ موقت سرور آمادهٔ نوشتن نیست؛ با مدیر سرور تماس بگیر.';
			default:
				return 'ارسال عکس ناموفق بود؛ دوباره تلاش کن.';
		}
	}

	/**
	 * Mobile verification.
	 *
	 * A code is generated and stored hashed; an SMS provider must be wired to
	 * the `dr_niva_send_otp` filter. Until a provider answers, the endpoint says
	 * so plainly and the wizard lets the user continue without verification —
	 * it never reports a success that did not happen.
	 */
	public function rest_otp( WP_REST_Request $request ) {
		$user_id = (int) get_current_user_id();
		$mode    = sanitize_key( (string) $request->get_param( 'mode' ) );
		$phone   = preg_replace( '/[^0-9+]/', '', (string) $request->get_param( 'phone' ) );

		if ( '' === $phone ) {
			return new WP_Error( 'niva_otp_phone', 'شمارهٔ موبایل را وارد کن.', array( 'status' => 400 ) );
		}

		if ( 'send' === $mode ) {
			$code = (string) wp_rand( 100000, 999999 );
			update_user_meta( $user_id, 'niva_phone', $phone );
			update_user_meta( $user_id, 'niva_otp_hash', wp_hash_password( $code ) );
			update_user_meta( $user_id, 'niva_otp_expires', time() + 300 );
			update_user_meta( $user_id, 'niva_otp_tries', 0 );

			/**
			 * Sends the one-time code. Return true when it was handed to a
			 * provider; return a WP_Error to explain why it could not be sent.
			 */
			$sent = apply_filters( 'dr_niva_send_otp', new WP_Error( 'niva_otp_unavailable', 'سرویس پیامک روی این سایت تنظیم نشده است.' ), $phone, $code, $user_id );
			if ( is_wp_error( $sent ) ) {
				return $sent;
			}
			return new WP_REST_Response( array( 'ok' => true, 'sent' => true ), 200 );
		}

		if ( 'verify' === $mode ) {
			$tries = (int) get_user_meta( $user_id, 'niva_otp_tries', true );
			if ( $tries >= 5 ) {
				return new WP_Error( 'niva_otp_locked', 'تعداد تلاش‌ها زیاد شد؛ یک کد تازه بگیر.', array( 'status' => 429 ) );
			}
			update_user_meta( $user_id, 'niva_otp_tries', $tries + 1 );

			$hash    = (string) get_user_meta( $user_id, 'niva_otp_hash', true );
			$expires = (int) get_user_meta( $user_id, 'niva_otp_expires', true );
			$code    = preg_replace( '/\D/', '', (string) $request->get_param( 'code' ) );

			if ( '' === $hash || $expires < time() ) {
				return new WP_Error( 'niva_otp_expired', 'کد منقضی شده است؛ دوباره درخواست کن.', array( 'status' => 400 ) );
			}
			if ( ! wp_check_password( $code, $hash ) ) {
				return new WP_Error( 'niva_otp_wrong', 'کد درست نیست.', array( 'status' => 400 ) );
			}

			update_user_meta( $user_id, 'niva_phone_verified', 1 );
			delete_user_meta( $user_id, 'niva_otp_hash' );
			update_user_meta( $user_id, 'niva_otp_expires', 0 );
			return $this->no_cache( new WP_REST_Response( array( 'ok' => true, 'verified' => true, 'state' => $this->state( $user_id ) ), 200 ) );
		}

		return new WP_Error( 'niva_otp_mode', 'درخواست نامعتبر است.', array( 'status' => 400 ) );
	}
}
