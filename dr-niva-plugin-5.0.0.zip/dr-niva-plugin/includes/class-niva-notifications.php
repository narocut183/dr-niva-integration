<?php
/**
 * Notifications: in-app inbox, Web Push subscriptions, e-mail fallback, cron.
 *
 * Web Push payload encryption needs a crypto library. The plugin ships the whole
 * pipeline (service worker, subscription storage, VAPID keys, sending, retries)
 * and delegates only the encryption step:
 *   - add_filter( 'dr_niva_webpush_sender', fn() => new Minishlink\WebPush\WebPush( $auth, $defaults ) )
 * When no sender is available every notification still lands in the in-app inbox
 * and, if enabled, in the user's mailbox — nothing is silently dropped.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Notifications {

	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
		add_action( 'dr_niva_every_minute', array( $this, 'run_due_reminders' ) );
		add_action( 'dr_niva_daily', array( $this, 'daily_digest' ) );
		add_action( 'wp_enqueue_scripts', array( $this, 'localize' ), 20 );
	}

	/* ------------------------------------------------------------------ REST */

	public function routes() : void {
		register_rest_route(
			Niva_Rest::NS,
			'/push/key',
			array(
				'methods'             => 'GET',
				'permission_callback' => '__return_true',
				'callback'            => function () {
					return array(
						'publicKey' => (string) dr_niva()->settings->get( 'vapid_public' ),
						'enabled'   => (bool) dr_niva()->settings->get( 'push_enabled' ),
					);
				},
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/push/subscribe',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( $this, 'subscribe' ),
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/push/unsubscribe',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( $this, 'unsubscribe' ),
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/notifications',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => array( $this, 'inbox' ),
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => array( $this, 'mark_read' ),
				),
			)
		);
	}

	public function subscribe( WP_REST_Request $request ) {
		global $wpdb;
		$endpoint = esc_url_raw( (string) $request->get_param( 'endpoint' ) );
		$keys     = (array) $request->get_param( 'keys' );
		if ( ! $endpoint || empty( $keys['p256dh'] ) || empty( $keys['auth'] ) ) {
			return new WP_Error( 'niva_push_invalid', 'اطلاعات اشتراک اعلان کامل نیست.', array( 'status' => 400 ) );
		}

		$table = Niva_DB::table( 'push_subs' );
		$row   = array(
			'user_id'    => get_current_user_id(),
			'endpoint'   => $endpoint,
			'p256dh'     => sanitize_text_field( (string) $keys['p256dh'] ),
			'auth'       => sanitize_text_field( (string) $keys['auth'] ),
			'device'     => sanitize_text_field( (string) $request->get_param( 'device' ) ),
			'created_at' => current_time( 'mysql' ),
			'last_seen'  => current_time( 'mysql' ),
		);

		$existing = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE endpoint = %s", $endpoint ) ); // phpcs:ignore WordPress.DB
		if ( $existing ) {
			$wpdb->update( $table, $row, array( 'id' => (int) $existing ) ); // phpcs:ignore WordPress.DB
		} else {
			$wpdb->insert( $table, $row ); // phpcs:ignore WordPress.DB
		}

		return array( 'ok' => true );
	}

	public function unsubscribe( WP_REST_Request $request ) {
		global $wpdb;
		$endpoint = esc_url_raw( (string) $request->get_param( 'endpoint' ) );
		if ( $endpoint ) {
			$wpdb->delete( Niva_DB::table( 'push_subs' ), array( 'endpoint' => $endpoint ) ); // phpcs:ignore WordPress.DB
		}
		return array( 'ok' => true );
	}

	public function inbox() : array {
		global $wpdb;
		$table = Niva_DB::table( 'notifications' );
		$rows  = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT id, title, body, url, is_read, created_at FROM {$table} WHERE user_id = %d ORDER BY id DESC LIMIT 50", // phpcs:ignore WordPress.DB
				get_current_user_id()
			),
			ARRAY_A
		);
		foreach ( (array) $rows as &$row ) {
			$row['created_at_label'] = Niva_Chrome::format_datetime( (string) $row['created_at'] );
		}
		unset( $row );
		$unread = (int) $wpdb->get_var( $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_read = 0", get_current_user_id() ) ); // phpcs:ignore WordPress.DB
		return array( 'items' => $rows ? $rows : array(), 'unread' => $unread );
	}

	public static function unread_count() : int {
		global $wpdb;
		$table = Niva_DB::table( 'notifications' );
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND is_read = 0",
				get_current_user_id()
			)
		); // phpcs:ignore WordPress.DB
	}

	public function mark_read( WP_REST_Request $request ) {
		global $wpdb;
		$id = absint( $request->get_param( 'id' ) );
		$wpdb->query( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				'UPDATE ' . Niva_DB::table( 'notifications' ) . ' SET is_read = 1 WHERE user_id = %d AND ( id = %d OR %d = 0 )', // phpcs:ignore WordPress.DB
				get_current_user_id(),
				$id,
				$id
			)
		);
		return array( 'ok' => true );
	}

	/* ------------------------------------------------------------- delivery */

	/**
	 * The single entry point every feature uses.
	 *
	 * @param int    $user_id Recipient.
	 * @param string $title   Short title.
	 * @param string $body    One or two lines of plain text.
	 * @param string $url     Where the tap should land.
	 * @param array  $args    ['channels' => array, 'ref' => string]
	 */
	public static function notify( int $user_id, string $title, string $body, string $url = '', array $args = array() ) : bool {
		if ( ! $user_id ) {
			return false;
		}
		global $wpdb;
		$channels = isset( $args['channels'] ) ? (array) $args['channels'] : self::channels();

		$stored = false;
		if ( in_array( 'inapp', $channels, true ) ) {
			$stored = (bool) $wpdb->insert( // phpcs:ignore WordPress.DB
				Niva_DB::table( 'notifications' ),
				array(
					'user_id'    => $user_id,
					'title'      => wp_strip_all_tags( $title ),
					'body'       => wp_strip_all_tags( $body ),
					'url'        => esc_url_raw( $url ),
					'ref'        => isset( $args['ref'] ) ? sanitize_text_field( (string) $args['ref'] ) : '',
					'is_read'    => 0,
					'created_at' => current_time( 'mysql' ),
				)
			);
		}

		if ( in_array( 'push', $channels, true ) && dr_niva()->settings->get( 'push_enabled' ) ) {
			self::send_push( $user_id, $title, $body, $url );
		}

		// mobile app devices (Android / iOS) go through the app push transport
		if ( in_array( 'push', $channels, true ) && dr_niva()->settings->is_on( 'app_push_enabled' ) && dr_niva()->push ) {
			Niva_Push::send( $user_id, $title, $body, $url );
		}

		if ( in_array( 'email', $channels, true ) ) {
			$user = get_userdata( $user_id );
			if ( $user && is_email( $user->user_email ) ) {
				$subject = '[' . get_bloginfo( 'name' ) . '] ' . wp_strip_all_tags( $title );
				$message = wp_strip_all_tags( $body ) . ( $url ? "\n\n" . $url : '' );
				wp_mail( $user->user_email, $subject, $message );
			}
		}

		return $stored;
	}

	public static function channels() : array {
		$configured = (array) dr_niva()->settings->get( 'notify_channels' );
		$channels   = array();
		foreach ( $configured as $key => $value ) {
			if ( $value ) {
				$channels[] = $key;
			}
		}
		return $channels ? $channels : array( 'inapp' );
	}

	/**
	 * Sends a Web Push message to every device of a user.
	 * Encryption is delegated to the sender returned by the filter.
	 */
	public static function send_push( int $user_id, string $title, string $body, string $url = '' ) : int {
		global $wpdb;
		$sender = apply_filters( 'dr_niva_webpush_sender', null );
		if ( ! $sender ) {
			/**
			 * No crypto sender available: the notification is already in the inbox,
			 * and the admin screen reports exactly what to install to enable push.
			 */
			do_action( 'dr_niva_push_skipped', $user_id, $title );
			return 0;
		}

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare( 'SELECT endpoint, p256dh, auth FROM ' . Niva_DB::table( 'push_subs' ) . ' WHERE user_id = %d', $user_id ), // phpcs:ignore WordPress.DB
			ARRAY_A
		);

		$payload = wp_json_encode(
			array(
				'title' => wp_strip_all_tags( $title ),
				'body'  => wp_strip_all_tags( $body ),
				'url'   => $url ? $url : home_url( '/' ),
				'badge' => 1,
				'icon'  => (string) dr_niva()->settings->get( 'brand_logo_url' ),
			)
		);

		$sent = 0;
		foreach ( (array) $rows as $row ) {
			$subscription = array(
				'endpoint' => $row['endpoint'],
				'keys'     => array( 'p256dh' => $row['p256dh'], 'auth' => $row['auth'] ),
			);
			try {
				$report = $sender->sendOneNotification( $subscription, (string) $payload, array( 'TTL' => 3600 ) );
				if ( $report && ! $report->isSuccess() ) {
					$reason = $report->getReason();
					if ( false !== stripos( (string) $reason, 'expired' ) || false !== stripos( (string) $reason, 'gone' ) ) {
						$wpdb->delete( Niva_DB::table( 'push_subs' ), array( 'endpoint' => $row['endpoint'] ) ); // phpcs:ignore WordPress.DB
					}
				} else {
					$sent++;
				}
			} catch ( \Exception $e ) {
				do_action( 'dr_niva_push_error', $user_id, $e->getMessage() );
			}
		}
		return $sent;
	}

	/** Broadcast helper for the admin screen. */
	public static function broadcast( string $title, string $body, string $url = '', string $audience = 'all', int $limit = 500 ) : int {
		$args  = array( 'fields' => array( 'ID' ), 'number' => $limit );
		if ( 'subscribers' === $audience ) {
			global $wpdb;
			$ids = $wpdb->get_col( 'SELECT DISTINCT user_id FROM ' . Niva_DB::table( 'push_subs' ) ); // phpcs:ignore WordPress.DB
			$args['include'] = array_map( 'absint', (array) $ids );
			if ( ! $args['include'] ) {
				return 0;
			}
		}
		$users = get_users( $args );
		$count = 0;
		foreach ( $users as $user ) {
			if ( self::notify( (int) $user->ID, $title, $body, $url ) ) {
				$count++;
			}
		}
		return $count;
	}

	/* ---------------------------------------------------------------- cron */

	/** Sends reminders whose time has come (runs every minute). */
	public function run_due_reminders() : void {
		global $wpdb;
		$table = Niva_DB::table( 'reminders' );
		$now   = current_time( 'H:i' );
		$today = current_time( 'Y-m-d' );

		$rows = $wpdb->get_results( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE done = 0 AND time_at <= %s AND ( fired_on IS NULL OR fired_on < %s ) AND ( repeat_rule <> 'weekly' OR DAYOFWEEK(created_at) = DAYOFWEEK(%s) ) LIMIT 50", // phpcs:ignore WordPress.DB
				$now,
				$today,
				$today
			),
			ARRAY_A
		);

		foreach ( (array) $rows as $row ) {
			$channels = array_values( array_unique( array_merge( array( 'inapp' ), self::channels() ) ) );
			$stored   = self::notify(
				(int) $row['user_id'],
				(string) $row['title'],
				'وقتش رسیده. اگر انجامش دادی، تیک بزن.',
				( new Niva_Links() )->url( 'reminders' ),
				array(
					'ref'      => 'reminder:' . (int) $row['id'],
					'channels' => $channels,
				)
			);
			if ( ! $stored ) {
				continue;
			}
			$once = isset( $row['repeat_rule'] ) && 'once' === $row['repeat_rule'];
			$wpdb->update( // phpcs:ignore WordPress.DB
				$table,
				$once ? array( 'fired_on' => $today, 'done' => 1 ) : array( 'fired_on' => $today ),
				array( 'id' => (int) $row['id'] )
			);
		}
	}

	/** A short Sunday-…-style digest (only when the admin turns it on). */
	public function daily_digest() : void {
		$this->pregnancy_daily();
		if ( ! dr_niva()->settings->get( 'daily_digest' ) ) {
			return;
		}
		$users = get_users( array( 'fields' => array( 'ID' ), 'number' => 200 ) );
		foreach ( $users as $user ) {
			$summary = dr_niva()->wallet->summary( (int) $user->ID );
			self::notify(
				(int) $user->ID,
				'خلاصه‌ی امروز',
				'اعتبار باقی‌مانده: ' . number_format_i18n( $summary['balance'] ) . ' — یادآورها و برنامه‌های امروزت را ببین.',
				( new Niva_Links() )->url( 'reminders' ),
				array( 'channels' => array( 'inapp' ) )
			);
		}
	}

	/** A once-daily, pregnancy-only prompt to open the week-specific care plan. */
	private function pregnancy_daily() : void {
		if ( ! dr_niva()->profile ) {
			return;
		}
		$page = 1;
		$today = current_time( 'Y-m-d' );
		do {
			$users = get_users(
				array(
					'fields' => array( 'ID' ),
					'number' => 200,
					'paged'  => $page,
					'orderby' => 'ID',
					'order'  => 'ASC',
				)
			);
			foreach ( $users as $user ) {
				$user_id = (int) $user->ID;
				if ( ! dr_niva()->profile->is_pregnant( $user_id ) || $today === get_user_meta( $user_id, 'niva_pregnancy_notice_date', true ) ) {
					continue;
				}
				$week = dr_niva()->profile->pregnancy_week( $user_id );
				$sent = self::notify(
					$user_id,
					'برنامهٔ امروز بارداری',
					sprintf( 'امروز در هفتهٔ %s بارداری هستی. نکته‌های روز، کارهای پیشنهادی و یادآورها را در مسیر بارداری ببین.', number_format_i18n( $week ) ),
					( new Niva_Links() )->url( 'pregnancy' ),
					array(
						'ref'      => 'pregnancy-daily:' . $today,
						'channels' => array_values( array_unique( array_merge( array( 'inapp' ), self::channels() ) ) ),
					)
				);
				if ( $sent ) {
					update_user_meta( $user_id, 'niva_pregnancy_notice_date', $today );
				}
			}
			++$page;
		} while ( count( $users ) === 200 );
	}

	/* ------------------------------------------------------------ front-end */

	/** Hands the service-worker URL and the public key to the browser. */
	public function localize() : void {
		$handle = 'dr-niva-bridge';
		if ( ! wp_script_is( $handle, 'registered' ) ) {
			return;
		}
		wp_localize_script(
			$handle,
			'NIVA_PUSH',
			array(
				'endpoint'  => rest_url( Niva_Rest::NS . '/push/subscribe' ),
				'keyUrl'    => rest_url( Niva_Rest::NS . '/push/key' ),
				'nonce'     => wp_create_nonce( 'wp_rest' ),
				'sw'        => home_url( '/dr-niva-sw.js' ),
				'publicKey' => (string) dr_niva()->settings->get( 'vapid_public' ),
				'enabled'   => (bool) dr_niva()->settings->get( 'push_enabled' ),
				'senderReady' => false !== has_filter( 'dr_niva_webpush_sender' ),
			)
		);
	}

	/* -------------------------------------------------------------- VAPID */

	/** Creates the VAPID key pair once, when the plugin is activated. */
	public static function ensure_vapid_keys() : void {
		$settings = dr_niva()->settings;
		if ( $settings->get( 'vapid_public' ) && $settings->get( 'vapid_private' ) ) {
			return;
		}
		if ( ! function_exists( 'openssl_pkey_new' ) ) {
			return;
		}

		$resource = openssl_pkey_new(
			array(
				'private_key_type' => OPENSSL_KEYTYPE_EC,
				'curve_name'       => 'prime256v1',
			)
		);
		if ( ! $resource ) {
			return;
		}

		$details = openssl_pkey_get_details( $resource );
		openssl_pkey_export( $resource, $private );
		if ( empty( $details['ec']['x'] ) || empty( $details['ec']['y'] ) ) {
			return;
		}

		$public = "\x04" . $details['ec']['x'] . $details['ec']['y'];
		$settings->update(
			array(
				'vapid_public'  => self::b64url( $public ),
				'vapid_private' => $private,
			)
		);
	}

	private static function b64url( string $bin ) : string {
		return rtrim( strtr( base64_encode( $bin ), '+/', '-_' ), '=' );
	}
}
