<?php
/**
 * Daily message engine.
 *
 * Decides which researched message a user sees today:
 *   pregnancy → one per day of pregnancy, rotating through the week's messages
 *   baby      → one per month of the baby
 *   cycle     → one per day of the current cycle phase
 *   general   → one per day of the year
 * Because the pick is derived from the day counter, the message changes every
 * 24 hours and the previous days can always be reconstructed.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Messages {

	public function __construct() {
		add_action( 'admin_post_dr_niva_messages', array( $this, 'handle_admin_action' ) );
	}

	public static function audiences() : array {
		return array(
			'pregnancy' => 'بارداری (بر پایه‌ی هفته)',
			'baby'      => 'نوزاد (بر پایه‌ی ماه)',
			'cycle'     => 'چرخه‌ی بانوان (بر پایه‌ی فاز)',
			'mind'      => 'حال روان',
			'general'   => 'عمومی',
		);
	}

	/* ------------------------------------------------------------------ data */

	public function count() : int {
		global $wpdb;
		return (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . Niva_DB::table( 'messages' ) ); // phpcs:ignore WordPress.DB
	}

	/**
	 * Completes the bundled library import idempotently.
	 *
	 * @param bool $force Kept for compatibility with existing integrations; imports remain idempotent.
	 */
	public function seed( bool $force = false ) : int {
		global $wpdb;

		if ( ! Niva_DB::table_exists( 'messages' ) ) {
			Niva_DB::install();
		}
		if ( ! Niva_DB::table_exists( 'messages' ) ) {
			update_option( 'dr_niva_missing_tables', array( 'messages' ), false );
			throw new RuntimeException( 'جدول پیام‌های روزانه در دسترس نیست.' );
		}

		$table = Niva_DB::table( 'messages' );
		$previous_suppress_errors = $wpdb->suppress_errors( true );
		$imported = 0;
		try {
			$files = glob( DR_NIVA_PATH . 'data/messages-*.json' );
			if ( ! $files ) {
				throw new RuntimeException( 'فایل‌های کتابخانهٔ پیام‌های روزانه پیدا نشدند.' );
			}
			foreach ( $files as $file ) {
				$rows = json_decode( (string) file_get_contents( $file ), true ); // phpcs:ignore WordPress.WP.AlternativeFunctions
				if ( ! is_array( $rows ) ) {
					throw new RuntimeException( 'فایل کتابخانهٔ پیام معتبر نیست: ' . basename( $file ) );
				}
				foreach ( $rows as $row ) {
					$audience = sanitize_key( $row['audience'] ?? 'general' );
					$title    = sanitize_text_field( $row['title'] ?? '' );
					if ( '' === $title || '' === trim( wp_strip_all_tags( (string) ( $row['body'] ?? '' ) ) ) ) {
						throw new RuntimeException( 'یکی از پیام‌های کتابخانه عنوان یا متن ندارد: ' . basename( $file ) );
					}
					$exists = (int) $wpdb->get_var( // phpcs:ignore WordPress.DB
						$wpdb->prepare(
							"SELECT COUNT(*) FROM {$table} WHERE audience = %s AND title = %s", // phpcs:ignore WordPress.DB
							$audience,
							$title
						)
					);
					if ( $exists ) {
						continue;
					}
					$inserted = $wpdb->insert( // phpcs:ignore WordPress.DB
						$table,
						array(
							'audience'    => $audience,
							'week'        => isset( $row['week'] ) && null !== $row['week'] ? (int) $row['week'] : null,
							'month'       => isset( $row['month'] ) && null !== $row['month'] ? (int) $row['month'] : null,
							'phase'       => isset( $row['phase'] ) && null !== $row['phase'] ? sanitize_key( $row['phase'] ) : null,
							'day_index'   => (int) ( $row['day_index'] ?? 0 ),
							'title'       => $title,
							'body'        => wp_kses_post( $row['body'] ?? '' ),
							'action'      => sanitize_text_field( $row['action'] ?? '' ),
							'source_name' => sanitize_text_field( $row['source_name'] ?? '' ),
							'source_url'  => esc_url_raw( $row['source_url'] ?? '' ),
							'active'      => 1,
							'created_at'  => current_time( 'mysql' ),
						)
					);
					if ( false === $inserted ) {
						throw new RuntimeException( 'ذخیرهٔ پیام کتابخانه در پایگاه داده ناموفق بود: ' . $wpdb->last_error );
					}
					$imported++;
				}
			}
		} finally {
			$wpdb->suppress_errors( $previous_suppress_errors );
		}
		return $imported;
	}

	/** Rows of one group, ordered. */
	public function group( string $audience, $key = null, bool $active_only = true ) : array {
		global $wpdb;
		$table = Niva_DB::table( 'messages' );
		$where = array( 'audience = %s' );
		$args  = array( $audience );

		if ( null !== $key ) {
			$column  = 'baby' === $audience ? 'month' : ( 'cycle' === $audience ? 'phase' : 'week' );
			$where[] = $column . ' = %s';
			$args[]  = $key;
		}
		if ( $active_only ) {
			$where[] = 'active = 1';
		}

		$sql = 'SELECT * FROM ' . $table . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY day_index ASC, id ASC';
		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $args ), ARRAY_A ); // phpcs:ignore WordPress.DB
		return $rows ? $rows : array();
	}

	public function all_rows( array $args = array() ) : array {
		global $wpdb;
		$table    = Niva_DB::table( 'messages' );
		$audience = isset( $args['audience'] ) ? sanitize_key( $args['audience'] ) : '';
		$search   = isset( $args['search'] ) ? (string) $args['search'] : '';
		$per_page = isset( $args['per_page'] ) ? max( 1, (int) $args['per_page'] ) : 50;
		$page     = isset( $args['page'] ) ? max( 1, (int) $args['page'] ) : 1;
		$offset   = ( $page - 1 ) * $per_page;

		$where = array( '1=1' );
		$params = array();
		if ( $audience ) {
			$where[]  = 'audience = %s';
			$params[] = $audience;
		}
		if ( '' !== $search ) {
			$where[]  = '(title LIKE %s OR body LIKE %s)';
			$like     = '%' . $wpdb->esc_like( $search ) . '%';
			$params[] = $like;
			$params[] = $like;
		}

		$sql      = 'SELECT * FROM ' . $table . ' WHERE ' . implode( ' AND ', $where ) . ' ORDER BY audience ASC, week ASC, month ASC, day_index ASC, id ASC LIMIT %d OFFSET %d';
		$params[] = $per_page;
		$params[] = $offset;

		$rows = $wpdb->get_results( $wpdb->prepare( $sql, $params ), ARRAY_A ); // phpcs:ignore WordPress.DB

		$count_where = array( '1=1' );
		$count_params = array();
		if ( $audience ) {
			$count_where[]  = 'audience = %s';
			$count_params[] = $audience;
		}
		if ( '' !== $search ) {
			$count_where[]  = '(title LIKE %s OR body LIKE %s)';
			$count_params[] = '%' . $wpdb->esc_like( $search ) . '%';
			$count_params[] = '%' . $wpdb->esc_like( $search ) . '%';
		}
		$total = $count_params
			? (int) $wpdb->get_var( $wpdb->prepare( 'SELECT COUNT(*) FROM ' . $table . ' WHERE ' . implode( ' AND ', $count_where ), $count_params ) ) // phpcs:ignore WordPress.DB
			: (int) $wpdb->get_var( 'SELECT COUNT(*) FROM ' . $table ); // phpcs:ignore WordPress.DB

		return array( 'rows' => $rows ? $rows : array(), 'total' => $total, 'pages' => (int) ceil( $total / $per_page ) );
	}

	public function save( array $data, int $id = 0 ) : int {
		global $wpdb;
		$audiences = self::audiences();
		$audience = sanitize_key( $data['audience'] ?? 'general' );
		if ( ! isset( $audiences[ $audience ] ) || '' === trim( (string) ( $data['title'] ?? '' ) ) || '' === trim( wp_strip_all_tags( (string) ( $data['body'] ?? '' ) ) ) ) {
			return 0;
		}
		$row = array(
			'audience'    => $audience,
			'week'        => '' === ( $data['week'] ?? '' ) ? null : (int) $data['week'],
			'month'       => '' === ( $data['month'] ?? '' ) ? null : (int) $data['month'],
			'phase'       => '' === ( $data['phase'] ?? '' ) ? null : sanitize_key( $data['phase'] ),
			'day_index'   => (int) ( $data['day_index'] ?? 0 ),
			'title'       => sanitize_text_field( $data['title'] ?? '' ),
			'body'        => wp_kses_post( $data['body'] ?? '' ),
			'action'      => sanitize_text_field( $data['action'] ?? '' ),
			'source_name' => sanitize_text_field( $data['source_name'] ?? '' ),
			'source_url'  => esc_url_raw( $data['source_url'] ?? '' ),
			'active'      => empty( $data['active'] ) ? 0 : 1,
		);
		if ( $id ) {
			$wpdb->update( Niva_DB::table( 'messages' ), $row, array( 'id' => $id ) ); // phpcs:ignore WordPress.DB
			return $id;
		}
		$row['created_at'] = current_time( 'mysql' );
		$wpdb->insert( Niva_DB::table( 'messages' ), $row ); // phpcs:ignore WordPress.DB
		return (int) $wpdb->insert_id;
	}

	public function delete( int $id ) : void {
		global $wpdb;
		$wpdb->delete( Niva_DB::table( 'messages' ), array( 'id' => $id ) ); // phpcs:ignore WordPress.DB
	}

	/* -------------------------------------------------------------- for user */

	/** Which group applies to this user right now. */
	public function target( int $user_id = 0 ) : array {
		$user_id = $user_id ? $user_id : get_current_user_id();

		if ( $user_id && dr_niva()->profile ) {
			if ( dr_niva()->profile->is_pregnant( $user_id ) ) {
				$week = dr_niva()->profile->pregnancy_week( $user_id );
				if ( $week ) {
					return array( 'audience' => 'pregnancy', 'key' => max( 4, min( 41, $week ) ), 'day' => dr_niva()->profile->pregnancy_days( $user_id ) );
				}
			}
			$months = dr_niva()->profile->baby_age_months( $user_id );
			if ( $months >= 0 && $months <= 12 ) {
				return array( 'audience' => 'baby', 'key' => $months, 'day' => (int) gmdate( 'z' ) );
			}
			$cycle = $this->cycle_target( $user_id );
			if ( $cycle ) {
				return $cycle;
			}
		}

		return array( 'audience' => 'general', 'key' => null, 'day' => (int) gmdate( 'z' ) );
	}

	/** Phase of the cycle, using the last period date the user logged. */
	private function cycle_target( int $user_id ) : ?array {
		$last = (string) get_user_meta( $user_id, 'niva_last_period', true );
		if ( ! $last ) {
			return null;
		}
		$length = (int) get_user_meta( $user_id, 'niva_cycle_length', true );
		$length = $length >= 21 && $length <= 40 ? $length : 28;
		$day    = (int) floor( ( strtotime( gmdate( 'Y-m-d' ) ) - strtotime( $last ) ) / DAY_IN_SECONDS );

		if ( $day < 0 || $day > 90 ) {
			return null;
		}

		if ( $day <= 5 ) {
			$phase = 'period';
		} elseif ( $day >= 11 && $day <= 16 ) {
			$phase = 'fertile';
		} elseif ( $day > 16 && $day <= $length ) {
			$phase = 'luteal';
		} else {
			$phase = 'irregular';
		}

		return array( 'audience' => 'cycle', 'key' => $phase, 'day' => $day );
	}

	/** Today's message for a user. */
	public function today( int $user_id = 0 ) : ?array {
		$target = $this->target( $user_id );
		$items  = $this->group( $target['audience'], $target['key'] );
		if ( ! $items ) {
			$items = $this->group( 'general', null );
		}
		if ( ! $items ) {
			return null;
		}
		$message                 = $items[ $target['day'] % count( $items ) ];
		$message['_audience']    = $target['audience'];
		$message['_key']         = $target['key'];
		$message['_day']         = $target['day'];
		return $message;
	}

	/** The messages of the previous days, newest first. */
	public function previous( int $user_id = 0, int $days = 7 ) : array {
		$target = $this->target( $user_id );
		$items  = $this->group( $target['audience'], $target['key'] );
		if ( ! $items ) {
			return array();
		}
		$count = count( $items );
		$out   = array();
		for ( $back = 1; $back <= $days; $back++ ) {
			$day     = $target['day'] - $back;
			if ( $day < 0 ) {
				break;
			}
			$message          = $items[ $day % $count ];
			$message['_ago']  = $back;
			$out[]            = $message;
		}
		return $out;
	}

	/** Every message of the group the user is in (the archive). */
	public function archive( int $user_id = 0 ) : array {
		$target = $this->target( $user_id );
		$items  = $this->group( $target['audience'], $target['key'] );
		if ( ! $items ) {
			$items = $this->group( 'general', null );
		}
		return $items;
	}

	/* ----------------------------------------------------------------- admin */

	public function handle_admin_action() : void {
		if ( ! current_user_can( 'manage_options' ) || ! check_admin_referer( 'dr_niva_messages' ) ) {
			wp_die( 'دسترسی مجاز نیست.' );
		}
		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';

		if ( 'seed' === $do ) {
			try {
				$count = $this->seed();
				wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-messages&seeded=' . $count ) );
			} catch ( Throwable $error ) {
				error_log( 'Dr. Niva message library sync failed: ' . $error->getMessage() );
				wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-messages&seed_error=1' ) );
			}
			exit;
		}
		if ( 'save' === $do ) {
			$posted = wp_unslash( $_POST ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput.InputNotSanitized
			$id = $this->save(
				array(
					'audience'    => $posted['audience'] ?? 'general',
					'week'        => $posted['week'] ?? '',
					'month'       => $posted['month'] ?? '',
					'phase'       => $posted['phase'] ?? '',
					'day_index'   => $posted['day_index'] ?? 0,
					'title'       => $posted['title'] ?? '',
					'body'        => $posted['body'] ?? '',
					'action'      => $posted['action_text'] ?? '',
					'source_name' => $posted['source_name'] ?? '',
					'source_url'  => $posted['source_url'] ?? '',
					'active'      => $posted['active'] ?? 0,
				),
				absint( $posted['id'] ?? 0 )
			);
			if ( ! $id ) {
				wp_die( 'عنوان، متن و گروه معتبر برای پیام وارد کن.' );
			}
			wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-messages&saved=' . $id ) );
			exit;
		}
		if ( 'delete' === $do ) {
			$this->delete( absint( $_POST['id'] ?? 0 ) );
			wp_safe_redirect( admin_url( 'admin.php?page=dr-niva-messages&deleted=1' ) );
			exit;
		}
	}
}
