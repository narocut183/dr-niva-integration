<?php
/**
 * The user's own profile: identity, pregnancy dates, notification and appearance
 * preferences, plus data export and deletion. Everything is stored as user meta
 * and reused by the message engine, the advisor context and the reminders.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Profile {


	public function __construct() {
		add_action( 'rest_api_init', array( $this, 'routes' ) );
	}

	/** Fields the completion meter counts, in the order the wizard asks them. */
	public static function completion_fields() : array {
		return array( 'first_name', 'last_name', 'sex', 'birth_date', 'height', 'weight' );
	}

	public function defaults() : array {
		return array(
			'display_name'  => '',
			'first_name'    => '',
			'last_name'     => '',
			'sex'           => '',
			'birth_year'    => '',
			'birth_date'    => '',
			'avatar_id'     => 0,
			'focus_area'    => '',
			'profile_completed' => 0,
			'companion_allowed' => 1,
			'onboarding_state'  => array( 'completed' => 0, 'step' => '', 'skipped' => array() ),
			'height'        => '',
			'weight'        => '',
			'pregnant'      => 0,
			'lmp'           => '',
			// Deliberately empty: the user's own numbers, never a system default.
			'cycle_length'  => '',
			'period_length' => '',
			'due_date'      => '',
			'baby_name'     => '',
			'baby_birth'    => '',
			'channels'      => array( 'inapp' => 1, 'push' => 1, 'email' => 0 ),
			'quiet_from'    => '23:00',
			'quiet_to'      => '07:00',
			'theme'         => 'auto',
			'font_scale'    => 'normal',
			'mood_scores'   => '',
			'newsletter'    => 0,
		);
	}

	public function get( int $user_id = 0 ) : array {
		$user_id = $user_id ? $user_id : get_current_user_id();
		if ( ! $user_id ) {
			return $this->defaults();
		}
		$stored = get_user_meta( $user_id, 'niva_profile', true );
		$data   = is_array( $stored ) ? $stored : array();
		$data   = wp_parse_args( $data, $this->defaults() );

		/*
		 * Backfill the split name from the WordPress account once, then keep the
		 * two in step. Existing installs stored a single display_name, so the
		 * first name is the best available guess and never overwrites anything
		 * the user typed in the profile itself.
		 */
		$user = get_userdata( $user_id );
		if ( $user ) {
			if ( '' === $data['first_name'] ) {
				$data['first_name'] = (string) $user->first_name;
			}
			if ( '' === $data['last_name'] ) {
				$data['last_name'] = (string) $user->last_name;
			}
		}
		if ( '' === $data['display_name'] ) {
			$data['display_name'] = trim( $data['first_name'] . ' ' . $data['last_name'] );
			if ( '' === $data['display_name'] && $user ) {
				$data['display_name'] = $user->display_name;
			}
		}
		$data['full_name'] = trim( $data['first_name'] . ' ' . $data['last_name'] );
		if ( '' === $data['full_name'] ) {
			$data['full_name'] = $data['display_name'];
		}

		/*
		 * Age is derived from the full birth date when we have it. Legacy
		 * installs only stored a Jalali year; we approximate it to 1 Farvardin
		 * of that year so nothing regresses, and the value is never written
		 * back — the real migration happens once, in migrate_legacy_batch().
		 */
		$data['age'] = '';
		$born        = (string) $data['birth_date'];
		if ( '' === $born && '' !== (string) $data['birth_year'] ) {
			$born = self::approx_birth_date_from_year( (int) $data['birth_year'] );
		}
		if ( '' !== $born ) {
			$data['age'] = self::age_from_date( $born );
		}

		$data['avatar_url'] = $this->avatar_url( $user_id );
		$data['completion'] = $this->completion( $data );

		return $data;
	}

	/** Whole years between a YYYY-MM-DD date and today (0 when unknown). */
	public static function age_from_date( string $date ) : int {
		if ( ! preg_match( '/^(\d{4})-(\d{2})-(\d{2})$/', $date, $m ) ) {
			return 0;
		}
		$y = (int) $m[1];
		$mo = (int) $m[2];
		$d  = (int) $m[3];
		if ( $y < 1900 || $y > (int) gmdate( 'Y' ) ) {
			return 0;
		}
		$age = (int) gmdate( 'Y' ) - $y;
		$md  = ( (int) gmdate( 'n' ) ) * 100 + (int) gmdate( 'j' );
		if ( $md < $mo * 100 + $d ) {
			$age--;
		}
		return max( 0, $age );
	}

	/** 1 Farvardin of a Jalali year, as a Gregorian YYYY-MM-DD string. */
	public static function approx_birth_date_from_year( int $jalali_year ) : string {
		if ( $jalali_year < 1200 || $jalali_year > 1500 ) {
			return '';
		}
		list( $gy, $gm, $gd ) = Niva_Chrome::jalali_to_gregorian( $jalali_year, 1, 1 );
		return sprintf( '%04d-%02d-%02d', $gy, $gm, $gd );
	}

	/** Jalali year of a Gregorian YYYY-MM-DD date (0 when unknown). */
	public static function jalali_year_of( string $date ) : int {
		if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $date ) ) {
			return 0;
		}
		$ts = strtotime( $date . ' 12:00:00' );
		if ( ! $ts ) {
			return 0;
		}
		$jalali = Niva_Chrome::jalali( $ts );
		return (int) ( $jalali[0] ?? 0 );
	}

	/** 0–100 completion figure plus the list of still-missing fields. */
	public function completion( array $data = array() ) : array {
		$data = $data ? $data : $this->get();
		$fields = self::completion_fields();
		$missing = array();
		foreach ( $fields as $key ) {
			$value = $data[ $key ] ?? '';
			if ( is_array( $value ) ) {
				$value = implode( '', $value );
			}
			if ( '' === trim( (string) $value ) || '0' === (string) $value ) {
				$missing[] = $key;
			}
		}
		$done    = count( $fields ) - count( $missing );
		$percent = (int) round( ( $done / max( 1, count( $fields ) ) ) * 100 );
		return array(
			'percent'    => $percent,
			'missing'    => $missing,
			'complete'   => 100 === $percent,
		);
	}

	/** Real avatar image URL, or '' when the user has no picture yet. */
	public function avatar_url( int $user_id = 0, string $size = 'thumbnail' ) : string {
		$user_id = $user_id ? $user_id : (int) get_current_user_id();
		if ( ! $user_id ) {
			return '';
		}
		$profile = get_user_meta( $user_id, 'niva_profile', true );
		$id      = is_array( $profile ) ? (int) ( $profile['avatar_id'] ?? 0 ) : 0;
		if ( $id <= 0 ) {
			return '';
		}
		$url = wp_get_attachment_image_url( $id, $size );
		return $url ? (string) $url : '';
	}

	public function save( $user_id = 0, array $input = array() ) : array {
		if ( is_array( $user_id ) ) {
			$input   = $user_id;
			$user_id = (int) get_current_user_id();
		}
		$user_id = (int) $user_id;
		if ( ! $user_id ) {
			$user_id = (int) get_current_user_id();
		}
		if ( ! $user_id ) {
			return $this->defaults();
		}

		/*
		 * A partial write (the questionnaire posts only its score) must not reset
		 * every other field to its default, so the stored profile is merged in
		 * first whenever the caller marks the request as partial.
		 */
		$input = self::normalize_digits( $input );

		/*
		 * 3.7.0 — every key must exist before it is read. A missing key used to
		 * raise a PHP warning, and on a site with display_errors on that warning
		 * was printed before the JSON, so the wizard could not read the answer
		 * back (symptom: «تاریخ تولد قابل ثبت نیست» while the data was fine).
		 */
		$input = array_merge( $this->defaults(), (array) $input );

		if ( isset( $input['__partial'] ) ) {
			$input = array_merge( (array) $this->get( $user_id ), $input );
		}

		$clean = $this->defaults();

		$clean['display_name'] = sanitize_text_field( (string) ( $input['display_name'] ?? '' ) );
		$clean['sex']          = in_array( ( $input['sex'] ?? '' ), array( 'female', 'male', 'other' ), true ) ? $input['sex'] : '';
		foreach ( array( 'birth_year', 'height', 'weight' ) as $number_field ) {
			$clean[ $number_field ] = '' === ( $input[ $number_field ] ?? '' ) ? '' : (float) $input[ $number_field ];
		}
		// 3.4.0 — accept 1/0, yes/no and true/false from any client.
		$clean['pregnant']   = in_array( (string) ( $input['pregnant'] ?? '' ), array( '1', 'yes', 'true', 'on' ), true ) ? 1 : 0;
		$clean['lmp']        = $this->clean_date( (string) ( $input['lmp'] ?? '' ) );
		// An empty field keeps what is already stored — it must never silently
		// overwrite the user's cycle length with a clamped default.
		$niva_stored             = $this->get( $user_id );
		$mood = array();
		foreach ( explode( ',', (string) ( $input['mood_scores'] ?? '' ) ) as $piece ) {
			$piece = trim( $piece );
			if ( '' !== $piece && is_numeric( $piece ) ) {
				$mood[] = max( 0, min( 27, (int) $piece ) );
			}
		}
		$mood                  = array_slice( $mood, -24 );
		$clean['mood_scores']  = implode( ',', $mood );

		/*
		 * The cycle length and period length are the user's own numbers. Nothing
		 * is imposed: when neither this request nor the stored profile carries a
		 * value, an empty string is kept (the screens show a "not set yet" state
		 * instead of silently pretending the user chose 28 / 5).
		 */
		$clean['cycle_length']  = $this->clean_range( $input['cycle_length'] ?? '', $niva_stored['cycle_length'] ?? '', 20, 45 );
		$clean['period_length'] = $this->clean_range( $input['period_length'] ?? '', $niva_stored['period_length'] ?? '', 2, 10 );
		$clean['due_date']   = $this->clean_date( (string) ( $input['due_date'] ?? '' ) );
		$clean['baby_name']  = sanitize_text_field( (string) ( $input['baby_name'] ?? '' ) );
		$clean['baby_birth'] = $this->clean_date( (string) ( $input['baby_birth'] ?? '' ) );

		$channels = isset( $input['channels'] ) && is_array( $input['channels'] ) ? $input['channels'] : array();
		$clean['channels'] = array(
			'inapp' => empty( $channels['inapp'] ) ? 0 : 1,
			'push'  => empty( $channels['push'] ) ? 0 : 1,
			'email' => empty( $channels['email'] ) ? 0 : 1,
		);

		$clean['quiet_from'] = $this->clean_time( (string) ( $input['quiet_from'] ?? '' ) );
		$clean['quiet_to']   = $this->clean_time( (string) ( $input['quiet_to'] ?? '' ) );
		$clean['theme']      = in_array( ( $input['theme'] ?? 'auto' ), array( 'auto', 'light', 'dark' ), true ) ? $input['theme'] : 'auto';
		$clean['font_scale'] = in_array( ( $input['font_scale'] ?? 'normal' ), array( 'normal', 'large', 'xlarge' ), true ) ? $input['font_scale'] : 'normal';
		$clean['newsletter'] = empty( $input['newsletter'] ) ? 0 : 1;

		/* ---- 2.0.0 identity fields ------------------------------------------------- */

		$clean['first_name'] = sanitize_text_field( (string) ( $input['first_name'] ?? '' ) );
		$clean['last_name']  = sanitize_text_field( (string) ( $input['last_name'] ?? '' ) );

		// The birth date is the source of truth; the Jalali year is derived from
		// it so nothing that still reads birth_year breaks.
		$clean['birth_date'] = $this->clean_date( (string) ( $input['birth_date'] ?? '' ) );
		if ( '' !== $clean['birth_date'] ) {
			$clean['birth_year'] = self::jalali_year_of( $clean['birth_date'] );
		} else {
			$clean['birth_year'] = '' === ( $input['birth_year'] ?? '' ) ? '' : (int) $input['birth_year'];
		}

		$clean['avatar_id'] = isset( $input['avatar_id'] ) ? absint( $input['avatar_id'] ) : (int) ( $niva_stored['avatar_id'] ?? 0 );

		$focus = sanitize_key( (string) ( $input['focus_area'] ?? '' ) );
		$clean['focus_area'] = in_array( $focus, array( 'cycle', 'mind', 'baby' ), true ) ? $focus : '';

		// A companion may only ever be granted or revoked explicitly.
		if ( array_key_exists( 'companion_allowed', $input ) ) {
			$clean['companion_allowed'] = empty( $input['companion_allowed'] ) ? 0 : 1;
		} else {
			$clean['companion_allowed'] = (int) ( $niva_stored['companion_allowed'] ?? 1 );
		}

		// Onboarding is written incrementally by the wizard, so it merges.
		$clean['onboarding_state'] = $this->clean_onboarding_state(
			$input['onboarding_state'] ?? ( $niva_stored['onboarding_state'] ?? array() )
		);

		// The display name always follows the split name when one is present.
		$clean['display_name'] = trim( $clean['first_name'] . ' ' . $clean['last_name'] );
		if ( '' === $clean['display_name'] ) {
			$clean['display_name'] = sanitize_text_field( (string) ( $input['display_name'] ?? ( $niva_stored['display_name'] ?? '' ) ) );
		}

		$completion                 = $this->completion( $clean );
		$clean['profile_completed'] = $completion['complete'] ? 1 : (int) ( $niva_stored['profile_completed'] ?? 0 );

		update_user_meta( $user_id, 'niva_profile', $clean );

		// Derived flags live in their own meta rows, so the admin user list can
		// filter and sort without unserialising every profile on every request.
		update_user_meta( $user_id, 'niva_profile_completed', $completion['complete'] ? 1 : 0 );
		update_user_meta( $user_id, 'niva_pregnant', empty( $clean['pregnant'] ) ? 0 : 1 );
		$has_baby = ( '' !== trim( (string) $clean['baby_name'] ) || '' !== trim( (string) $clean['baby_birth'] ) ) ? 1 : 0;
		update_user_meta( $user_id, 'niva_has_baby', $has_baby );

		// Flat mirrors of the cycle numbers, kept because the daily-message
		// engine reads them directly from user meta.
		update_user_meta( $user_id, 'niva_cycle_length', (string) $clean['cycle_length'] );
		update_user_meta( $user_id, 'niva_period_length', (string) $clean['period_length'] );
		update_user_meta( $user_id, 'niva_birth_date', (string) $clean['birth_date'] );

		// Keep the WordPress account name aligned with the profile name.
		$account = get_userdata( $user_id );
		if ( $account && ( $account->first_name !== $clean['first_name'] || $account->last_name !== $clean['last_name'] ) ) {
			wp_update_user(
				array(
					'ID'         => $user_id,
					'first_name' => $clean['first_name'],
					'last_name'  => $clean['last_name'],
				)
			);
		}

		if ( $clean['pregnant'] && $clean['lmp'] ) {
			update_user_meta( $user_id, 'niva_pregnancy_week', $this->pregnancy_week( $user_id ) );
		}

		return $this->get( $user_id );
	}

	/**
	 * Persian and Arabic digits are what a Persian keyboard produces (۱۴۰۵، ۱۷۰).
	 * Without this, every numeric answer and every date was rejected and stored
	 * as an empty string — the reason the questionnaire «never saved».
	 */
	public static function normalize_digits( $value ) {
		if ( is_array( $value ) ) {
			$out = array();
			foreach ( $value as $key => $item ) {
				$out[ $key ] = self::normalize_digits( $item );
			}
			return $out;
		}
		if ( ! is_string( $value ) ) {
			return $value;
		}
		return str_replace(
			array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩', '٫' ),
			array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '.' ),
			$value
		);
	}

	/**
	 * A date is accepted as `YYYY-MM-DD` or `YYYY/MM/DD`, in Persian or Latin
	 * digits, and either Jalali (what the questionnaire asks for) or Gregorian.
	 * Jalali input is converted, because the profile stores Gregorian dates.
	 */
	private function clean_date( string $value ) : string {
		$value = trim( self::normalize_digits( $value ) );
		$value = str_replace( array( '/', '.', '\\' ), '-', $value );
		if ( ! preg_match( '/^(\d{3,4})-(\d{1,2})-(\d{1,2})$/', $value, $parts ) ) {
			return '';
		}
		$year  = (int) $parts[1];
		$month = (int) $parts[2];
		$day   = (int) $parts[3];

		if ( $year >= 1200 && $year <= 1500 && method_exists( 'Niva_Chrome', 'jalali_to_gregorian' ) ) {
			$converted = Niva_Chrome::jalali_to_gregorian( $year, $month, $day );
			if ( is_array( $converted ) && 3 === count( $converted ) ) {
				$gy = (int) $converted[0];
				$gm = (int) $converted[1];
				$gd = (int) $converted[2];
				if ( checkdate( $gm, $gd, $gy ) ) {
					return sprintf( '%04d-%02d-%02d', $gy, $gm, $gd );
				}
			}
		}
		if ( checkdate( $month, $day, $year ) ) {
			return sprintf( '%04d-%02d-%02d', $year, $month, $day );
		}
		return '';
	}

	private function clean_time( string $value ) : string {
		return preg_match( '/^\d{2}:\d{2}$/', trim( $value ) ) ? trim( $value ) : '';
	}

	/**
	 * A bounded integer that may legitimately be unknown.
	 *
	 * Returns '' when neither the incoming value nor the stored one exists, so a
	 * skipped wizard question never turns into a made-up number.
	 */
	private function clean_range( $incoming, $stored, int $min, int $max ) : string {
		$value = trim( (string) $incoming );
		if ( '' === $value ) {
			$value = trim( (string) $stored );
		}
		if ( '' === $value || ! is_numeric( $value ) ) {
			return '';
		}
		return (string) max( $min, min( $max, (int) $value ) );
	}

	/** Normalises the wizard's incremental save state. */
	private function clean_onboarding_state( $value ) : array {
		$value = is_array( $value ) ? $value : array();
		$skipped = isset( $value['skipped'] ) && is_array( $value['skipped'] ) ? $value['skipped'] : array();
		$skipped = array_values( array_filter( array_map( 'sanitize_key', $skipped ) ) );
		return array(
			'completed' => empty( $value['completed'] ) ? 0 : 1,
			'step'      => sanitize_key( (string) ( $value['step'] ?? '' ) ),
			'skipped'   => array_slice( $skipped, 0, 30 ),
		);
	}

	/* ------------------------------------------------- 2.0.0 legacy migration */

	/**
	 * One-off, batched migration for accounts created before 2.0.0.
	 *
	 * The old profile only stored a Jalali birth year, so it is expanded to the
	 * first of Farvardin of that year — approximate, never destructive: the
	 * original birth_year is left untouched, and every other field is preserved.
	 * Runs a few hundred users per request and finishes on its own.
	 */
	public static function maybe_migrate_legacy( $batch = 200, $max_batches = 3 ) : void {
		// Deliberately untyped: WordPress hands hook callbacks an empty string,
		// and any caller may pass one too. Casting here keeps every path safe.
		$batch       = max( 1, (int) $batch );
		$max_batches = max( 1, (int) $max_batches );

		if ( 'done' === get_option( 'dr_niva_profile_migration', '' ) ) {
			return;
		}
		// Throttle: at most one migration run per 10 minutes, so a busy admin
		// session never pays for it on every page load.
		if ( get_transient( 'dr_niva_profile_migration_lock' ) ) {
			return;
		}
		set_transient( 'dr_niva_profile_migration_lock', 1, 10 * MINUTE_IN_SECONDS );

		for ( $i = 0; $i < max( 1, $max_batches ); $i++ ) {
			$scanned = self::migrate_legacy_batch( $batch );
			if ( $scanned < $batch ) {
				// The last page of profiles was reached; nothing left to do.
				update_option( 'dr_niva_profile_migration', 'done', false );
				return;
			}
		}
		// More profiles remain; the next request continues from the stored ID.
	}

	/**
	 * Migrates one page of legacy profiles, page-by-page by user ID so the run
	 * always terminates (the same first page is never re-scanned forever).
	 *
	 * @return int number of profiles scanned (not only the ones changed), so the
	 *             caller can tell "end of list" from "page full".
	 */
	public static function migrate_legacy_batch( int $limit = 200 ) : int {
		global $wpdb;

		$last = (int) get_option( 'dr_niva_profile_migration_last', 0 );
		$ids  = $wpdb->get_col( // phpcs:ignore WordPress.DB
			$wpdb->prepare(
				"SELECT user_id FROM {$wpdb->usermeta} WHERE meta_key = %s AND user_id > %d ORDER BY user_id ASC LIMIT %d",
				'niva_profile',
				$last,
				max( 1, $limit )
			)
		);
		$users = array_map( 'intval', (array) $ids );
		if ( $users ) {
			update_option( 'dr_niva_profile_migration_last', max( $users ), false );
		}

		foreach ( $users as $id ) {
			$stored = get_user_meta( $id, 'niva_profile', true );
			if ( ! is_array( $stored ) ) {
				continue;
			}
			$changed = false;

			// Legacy birth year -> approximate full date (original year kept).
			if ( empty( $stored['birth_date'] ) && ! empty( $stored['birth_year'] ) ) {
				$approx = self::approx_birth_date_from_year( (int) $stored['birth_year'] );
				if ( '' !== $approx ) {
					$stored['birth_date'] = $approx;
					$changed              = true;
				}
			}

			$account = get_userdata( $id );
			if ( $account ) {
				if ( empty( $stored['first_name'] ) && '' !== (string) $account->first_name ) {
					$stored['first_name'] = (string) $account->first_name;
					$changed              = true;
				}
				if ( empty( $stored['last_name'] ) && '' !== (string) $account->last_name ) {
					$stored['last_name'] = (string) $account->last_name;
					$changed              = true;
				}
			}

			foreach ( array( 'avatar_id' => 0, 'companion_allowed' => 1 ) as $key => $default ) {
				if ( ! isset( $stored[ $key ] ) ) {
					$stored[ $key ] = $default;
					$changed        = true;
				}
			}

			if ( ! isset( $stored['onboarding_state'] ) ) {
				// An account that already recorded a sex has clearly been through
				// the old sheet, so the new wizard does not nag it.
				$stored['onboarding_state'] = array(
					'completed' => empty( $stored['sex'] ) ? 0 : 1,
					'step'      => '',
					'skipped'   => array(),
				);
				$changed                    = true;
			}

			if ( ! $changed ) {
				continue;
			}

			$profile     = new self();
			$merged      = wp_parse_args( $stored, $profile->defaults() );
			$completion  = $profile->completion( $merged );
			$stored['profile_completed'] = $completion['complete'] ? 1 : (int) ( $stored['profile_completed'] ?? 0 );
			update_user_meta( $id, 'niva_profile', $stored );

			// Mirror the derived flags used by the admin user list.
			update_user_meta( $id, 'niva_profile_completed', $completion['complete'] ? 1 : 0 );
			update_user_meta( $id, 'niva_pregnant', empty( $stored['pregnant'] ) ? 0 : 1 );
			$has_baby = ( '' !== trim( (string) ( $stored['baby_name'] ?? '' ) ) || '' !== trim( (string) ( $stored['baby_birth'] ?? '' ) ) ) ? 1 : 0;
			update_user_meta( $id, 'niva_has_baby', $has_baby );
		}

		return count( $users );
	}

	/* ------------------------------------------------------------- pregnancy */

	/** Days since conception date (LMP + 14) is the medical convention; we use LMP. */
	public function pregnancy_days( int $user_id = 0 ) : int {
		$data = $this->get( $user_id );
		$start = $data['lmp'];
		if ( ! $start && $data['due_date'] ) {
			$start = gmdate( 'Y-m-d', strtotime( $data['due_date'] . ' -280 days' ) );
		}
		if ( ! $start ) {
			return 0;
		}
		$days = (int) floor( ( strtotime( gmdate( 'Y-m-d' ) ) - strtotime( $start ) ) / DAY_IN_SECONDS );
		return max( 0, min( 300, $days ) );
	}

	public function pregnancy_week( int $user_id = 0 ) : int {
		$days = $this->pregnancy_days( $user_id );
		return $days ? max( 1, min( 42, (int) floor( $days / 7 ) + 1 ) ) : 0;
	}

	public function is_pregnant( int $user_id = 0 ) : bool {
		$data = $this->get( $user_id );
		return ! empty( $data['pregnant'] ) && ( $data['lmp'] || $data['due_date'] );
	}

	/** Days of pregnancy left, for the progress bar. */
	public function days_left( int $user_id = 0 ) : int {
		$days = $this->pregnancy_days( $user_id );
		return $days ? max( 0, 280 - $days ) : 0;
	}

	/** Baby age in months, used by the message engine and the growth screen. */
	public function baby_age_months( int $user_id = 0 ) : int {
		$data = $this->get( $user_id );
		if ( ! $data['baby_birth'] ) {
			return -1;
		}
		$diff = (int) floor( ( strtotime( gmdate( 'Y-m-d' ) ) - strtotime( $data['baby_birth'] ) ) / DAY_IN_SECONDS );
		return max( 0, (int) floor( $diff / 30.4 ) );
	}

	/** Quiet hours respected by every notification channel. */
	public function in_quiet_hours( int $user_id = 0 ) : bool {
		$data = $this->get( $user_id );
		if ( ! $data['quiet_from'] || ! $data['quiet_to'] ) {
			return false;
		}
		$now  = current_time( 'H:i' );
		$from = $data['quiet_from'];
		$to   = $data['quiet_to'];
		if ( $from <= $to ) {
			return $now >= $from && $now < $to;
		}
		return $now >= $from || $now < $to; // window crosses midnight
	}

	/** Monthly questionnaire results, newest first. */
	public function mood_assessments( int $user_id = 0 ) : array {
		$user_id = $user_id ? $user_id : (int) get_current_user_id();
		$rows    = $user_id ? get_user_meta( $user_id, 'dr_niva_mood_assessments', true ) : array();
		if ( ! is_array( $rows ) ) {
			return array();
		}
		return array_values(
			array_filter(
				$rows,
				static function ( $row ) {
					return is_array( $row )
						&& preg_match( '/^\d{4}-(0[1-9]|1[0-2])$/', (string) ( $row['month'] ?? '' ) )
						&& isset( $row['score'], $row['answers'] )
						&& is_array( $row['answers'] )
						&& count( $row['answers'] ) === 9
						&& (int) $row['score'] >= 0
						&& (int) $row['score'] <= 27;
				}
			)
		);
	}

	/** Saves one questionnaire per current Jalali month. */
	public function save_mood_assessment( int $user_id, array $answers ) {
		if ( 9 !== count( $answers ) ) {
			return new WP_Error( 'niva_assessment_incomplete', 'به همهٔ ۹ پرسش پاسخ بده.', array( 'status' => 400 ) );
		}
		$clean_answers = array();
		foreach ( $answers as $answer ) {
			if ( ! is_numeric( $answer ) || (int) $answer < 0 || (int) $answer > 3 ) {
				return new WP_Error( 'niva_assessment_invalid', 'یکی از پاسخ‌ها معتبر نیست.', array( 'status' => 400 ) );
			}
			$clean_answers[] = (int) $answer;
		}

		$jalali = Niva_Chrome::jalali( current_time( 'timestamp', true ) );
		if ( empty( $jalali[0] ) || empty( $jalali[1] ) ) {
			return new WP_Error( 'niva_assessment_date', 'تاریخ محلی سایت قابل محاسبه نیست.', array( 'status' => 500 ) );
		}
		$month = sprintf( '%04d-%02d', $jalali[0], $jalali[1] );
		$rows  = $this->mood_assessments( $user_id );
		foreach ( $rows as $row ) {
			if ( $month === $row['month'] ) {
				return new WP_Error( 'niva_assessment_already_done', 'پرسشنامهٔ این ماه قبلاً ثبت شده است.', array( 'status' => 409, 'assessment' => $row ) );
			}
		}

		$score = array_sum( $clean_answers );
		array_unshift(
			$rows,
			array(
				'month'   => $month,
				'date'    => current_time( 'Y-m-d' ),
				'score'   => $score,
				'answers' => $clean_answers,
			)
		);
		$rows = array_slice( $rows, 0, 24 );
		update_user_meta( $user_id, 'dr_niva_mood_assessments', $rows );

		$profile = $this->get( $user_id );
		$legacy  = array_filter( array_map( 'trim', explode( ',', (string) ( $profile['mood_scores'] ?? '' ) ) ), 'strlen' );
		$legacy[] = (string) $score;
		$profile['mood_scores'] = implode( ',', array_slice( $legacy, -24 ) );
		update_user_meta( $user_id, 'niva_profile', $profile );

		return $rows[0];
	}

	/* ------------------------------------------------------------------ REST */

	public function routes() : void {
		register_rest_route(
			Niva_Rest::NS,
			'/profile',
			array(
				array(
					'methods'             => 'GET',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => function () {
						return array( 'profile' => $this->get() );
					},
				),
				array(
					'methods'             => 'POST',
					'permission_callback' => function () {
						return is_user_logged_in();
					},
					'callback'            => function ( WP_REST_Request $request ) {
						return array( 'profile' => $this->save( get_current_user_id(), (array) $request->get_params() ) );
					},
				),
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/profile/assessment',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => function ( WP_REST_Request $request ) {
					$access = dr_niva()->plans->feature_access( get_current_user_id(), 'mind_assessment' );
					if ( is_wp_error( $access ) ) {
						return $access;
					}
					$result = $this->save_mood_assessment( get_current_user_id(), (array) $request->get_param( 'answers' ) );
					return is_wp_error( $result ) ? $result : array( 'assessment' => $result );
				},
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/profile/export',
			array(
				'methods'             => 'GET',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( $this, 'export' ),
			)
		);

		register_rest_route(
			Niva_Rest::NS,
			'/profile/delete',
			array(
				'methods'             => 'POST',
				'permission_callback' => function () {
					return is_user_logged_in();
				},
				'callback'            => array( $this, 'delete_data' ),
			)
		);
	}

	/** A full copy of what we store about the signed-in user. */
	public function export() : array {
		global $wpdb;
		$user_id = get_current_user_id();
		$data    = array(
			'profile'       => $this->get( $user_id ),
			'mood_assessments' => $this->mood_assessments( $user_id ),
			'wallet'        => dr_niva()->wallet->summary( $user_id ),
			'plan'          => dr_niva()->plans ? dr_niva()->plans->summary( $user_id ) : null,
			'chats'         => $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'chats' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'messages'      => $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'chat_messages' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'growth'        => $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'growth' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'daily_logs'    => $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'daily_logs' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'reminders'     => $wpdb->get_results( $wpdb->prepare( 'SELECT * FROM ' . Niva_DB::table( 'reminders' ) . ' WHERE user_id = %d', $user_id ), ARRAY_A ), // phpcs:ignore WordPress.DB
			'exported_at'   => current_time( 'mysql' ),
		);
		return $data;
	}

	/** Removes the user's health data but keeps the account itself. */
	public function delete_data() : array {
		global $wpdb;
		$user_id = get_current_user_id();
		delete_user_meta( $user_id, 'dr_niva_mood_assessments' );
		foreach ( array( 'chats', 'chat_messages', 'growth', 'daily_logs', 'reminders', 'documents', 'notifications', 'push_subs', 'push_devices', 'family_members' ) as $table ) {
			if ( 'family_members' === $table ) {
				$wpdb->delete( Niva_DB::table( $table ), array( 'member_id' => $user_id ) ); // phpcs:ignore WordPress.DB
				continue;
			}
			$wpdb->delete( Niva_DB::table( $table ), array( 'user_id' => $user_id ) ); // phpcs:ignore WordPress.DB
		}
		delete_user_meta( $user_id, 'niva_profile' );
		Niva_Notifications::notify( $user_id, 'داده‌های تو پاک شد', 'همه‌ی سوابق سلامت حذف شدند. حساب کاربری‌ات باقی مانده است.', home_url( '/' ), array( 'channels' => array( 'email', 'inapp' ) ) );
		return array( 'ok' => true );
	}
}
