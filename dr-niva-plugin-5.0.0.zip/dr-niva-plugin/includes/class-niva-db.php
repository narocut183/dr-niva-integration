<?php
/**
 * Database schema.
 *
 * Money and usage live in dedicated tables (not post meta) so every credit
 * movement is auditable with a single query.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_DB {

	public const VERSION = '3';

	/** Full table name for one of our tables. */
	public static function table( string $name ) : string {
		global $wpdb;
		return $wpdb->prefix . 'niva_' . $name;
	}

	/** Creates or upgrades the schema. Safe to run repeatedly. */
	/** Every table the plugin owns, in one place. */
	public static function tables() : array {
		return array(
			'wallets', 'ledger', 'usage', 'documents', 'reviews', 'reminders',
			'notifications', 'push_subs', 'chats', 'chat_messages', 'growth', 'daily_logs',
			'memberships', 'family_members', 'partners', 'partner_referrals', 'payouts',
			'push_devices', 'messages',
			// Added in 2.0.0 — community, companion access, store receipts, audit log.
			'community_categories', 'community_threads', 'community_comments',
			'community_reactions', 'community_reports',
			'companion_codes', 'companion_views',
			'store_purchases', 'audit_log',
		);
	}

	/** Tables that are expected but do not exist yet. */
	public static function missing_tables() : array {
		global $wpdb;
		$missing = array();
		foreach ( self::tables() as $name ) {
			$table = self::table( $name );
			$found = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ); // phpcs:ignore WordPress.DB
			if ( $found !== $table ) {
				$missing[] = $name;
			}
		}
		return $missing;
	}

	public static function table_exists( string $name ) : bool {
		global $wpdb;
		$table = self::table( $name );
		return $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table; // phpcs:ignore WordPress.DB
	}

	/**
	 * Self-healing: if a table is missing (an interrupted activation, a database
	 * without CREATE rights at the time, a plugin updated by hand …) it is
	 * created on the next request. Throttled so it costs nothing when all is well.
	 */
	public static function ensure_tables() : void {
		if ( get_transient( 'dr_niva_tables_ok' ) ) {
			return;
		}
		$missing = self::missing_tables();
		if ( ! $missing ) {
			set_transient( 'dr_niva_tables_ok', 1, HOUR_IN_SECONDS );
			delete_option( 'dr_niva_missing_tables' );
			return;
		}

		update_option( 'dr_niva_missing_tables', $missing, false );
		self::install();

		$still = self::missing_tables();
		if ( ! $still ) {
			set_transient( 'dr_niva_tables_ok', 1, HOUR_IN_SECONDS );
			delete_option( 'dr_niva_missing_tables' );
		} else {
			update_option( 'dr_niva_missing_tables', $still, false );
		}
	}

	public static function install() : void {
		global $wpdb;
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$charset = $wpdb->get_charset_collate();

		$wallets = self::table( 'wallets' );
		$ledger  = self::table( 'ledger' );
		$usage   = self::table( 'usage' );
		$docs    = self::table( 'documents' );
		$reviews = self::table( 'reviews' );
		$remind  = self::table( 'reminders' );
		$devices = self::table( 'push_devices' );
		$partners = self::table( 'partners' );
		$refs     = self::table( 'partner_referrals' );
		$payouts  = self::table( 'payouts' );
		$daily   = self::table( 'messages' );
		$members = self::table( 'memberships' );
		$family  = self::table( 'family_members' );
		$chats   = self::table( 'chats' );
		$msgs    = self::table( 'chat_messages' );
		$growth  = self::table( 'growth' );
		$logs    = self::table( 'daily_logs' );
		$notify  = self::table( 'notifications' );
		$pushes  = self::table( 'push_subs' );

		$queries = array();

		$queries[] = "CREATE TABLE {$wallets} (
			user_id BIGINT UNSIGNED NOT NULL,
			balance BIGINT NOT NULL DEFAULT 0,
			spent_total BIGINT NOT NULL DEFAULT 0,
			quota_date DATE NULL,
			quota_used INT NOT NULL DEFAULT 0,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (user_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$ledger} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			delta BIGINT NOT NULL,
			reason VARCHAR(40) NOT NULL,
			ref VARCHAR(191) NULL,
			balance_after BIGINT NOT NULL DEFAULT 0,
			meta LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY reason (reason)
		) {$charset};";

		$queries[] = "CREATE TABLE {$usage} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			kind VARCHAR(40) NOT NULL,
			provider VARCHAR(40) NULL,
			model VARCHAR(80) NULL,
			cost INT NOT NULL DEFAULT 0,
			charged_from VARCHAR(10) NULL,
			tokens_in INT NOT NULL DEFAULT 0,
			tokens_out INT NOT NULL DEFAULT 0,
			ref VARCHAR(191) NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY kind (kind)
		) {$charset};";

		$queries[] = "CREATE TABLE {$docs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			title VARCHAR(191) NOT NULL,
			kind VARCHAR(40) NOT NULL DEFAULT 'lab',
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			lab_name VARCHAR(191) NULL,
			tested_on VARCHAR(20) NULL,
			result_json LONGTEXT NULL,
			attachment_id BIGINT UNSIGNED NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$reviews} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			ref VARCHAR(191) NULL,
			reason VARCHAR(80) NOT NULL,
			payload LONGTEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'open',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status (status)
		) {$charset};";

		$queries[] = "CREATE TABLE {$remind} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			title VARCHAR(191) NOT NULL,
			time_at VARCHAR(5) NOT NULL,
			repeat_rule VARCHAR(10) NOT NULL DEFAULT 'daily',
			done TINYINT(1) NOT NULL DEFAULT 0,
			fired_on DATE NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$notify} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			title VARCHAR(191) NOT NULL DEFAULT '',
			body TEXT NULL,
			url VARCHAR(255) NOT NULL DEFAULT '',
			ref VARCHAR(120) NOT NULL DEFAULT '',
			is_read TINYINT(1) NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_unread (user_id, is_read),
			KEY created_at (created_at)
		) {$charset};";

		$queries[] = "CREATE TABLE {$pushes} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			endpoint VARCHAR(255) NOT NULL,
			p256dh VARCHAR(255) NOT NULL,
			auth VARCHAR(120) NOT NULL,
			device VARCHAR(120) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			last_seen DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY endpoint (endpoint(120)),
			KEY user_id (user_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$chats} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			topic VARCHAR(60) NOT NULL DEFAULT '',
			title VARCHAR(191) NOT NULL DEFAULT '',
			provider VARCHAR(40) NOT NULL DEFAULT '',
			model VARCHAR(80) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'open',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY updated_at (updated_at)
		) {$charset};";

		$queries[] = "CREATE TABLE {$msgs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			chat_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			role VARCHAR(12) NOT NULL DEFAULT 'user',
			content LONGTEXT NULL,
			flags VARCHAR(191) NOT NULL DEFAULT '',
			cost INT NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY chat_id (chat_id),
			KEY user_id (user_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$growth} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			profile_id VARCHAR(40) NOT NULL DEFAULT 'default',
			name VARCHAR(80) NOT NULL DEFAULT '',
			sex VARCHAR(8) NOT NULL DEFAULT '',
			birth_year SMALLINT NULL,
			birth_month TINYINT NULL,
			birth_day TINYINT NULL,
			measured_on DATE NULL,
			age_months INT NULL,
			weight DECIMAL(6,2) NULL,
			height DECIMAL(6,2) NULL,
			head DECIMAL(6,2) NULL,
			analysis VARCHAR(30) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_id (user_id),
			KEY measured_on (measured_on)
		) {$charset};";

		$queries[] = "CREATE TABLE {$logs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			log_date DATE NOT NULL,
			kind VARCHAR(24) NOT NULL DEFAULT 'mood',
			value VARCHAR(40) NOT NULL DEFAULT '',
			note TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY user_kind_date (user_id, kind, log_date)
		) {$charset};";

		$queries[] = "CREATE TABLE {$members} (
			user_id BIGINT UNSIGNED NOT NULL,
			plan VARCHAR(24) NOT NULL DEFAULT 'free',
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			source VARCHAR(24) NOT NULL DEFAULT 'manual',
			ref VARCHAR(120) NOT NULL DEFAULT '',
			expires_at DATETIME NULL,
			period_months INT NOT NULL DEFAULT 1,
			quota_window_start DATETIME NULL,
			quota_chat_used INT NOT NULL DEFAULT 0,
			quota_lab_used INT NOT NULL DEFAULT 0,
			quota_image_used INT NOT NULL DEFAULT 0,
			quota_carried_chat INT NOT NULL DEFAULT 0,
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			PRIMARY KEY  (user_id),
			KEY plan_status (plan, status)
		) {$charset};";

		$queries[] = "CREATE TABLE {$family} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			owner_id BIGINT UNSIGNED NOT NULL,
			member_id BIGINT UNSIGNED NOT NULL,
			joined_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY member (member_id),
			KEY owner_id (owner_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$partners} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			name VARCHAR(191) NOT NULL DEFAULT '',
			type VARCHAR(30) NOT NULL DEFAULT 'clinic',
			phone VARCHAR(40) NOT NULL DEFAULT '',
			email VARCHAR(120) NOT NULL DEFAULT '',
			city VARCHAR(80) NOT NULL DEFAULT '',
			note TEXT NULL,
			code VARCHAR(20) NOT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			commission DECIMAL(5,2) NOT NULL DEFAULT 0,
			clicks INT NOT NULL DEFAULT 0,
			approved_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code),
			KEY status (status),
			KEY user_id (user_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$refs} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			partner_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			commission DECIMAL(12,2) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'signup',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY partner_id (partner_id),
			KEY order_id (order_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$payouts} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			partner_id BIGINT UNSIGNED NOT NULL,
			amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'paid',
			note VARCHAR(191) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY partner_id (partner_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$devices} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL,
			token VARCHAR(255) NOT NULL,
			platform VARCHAR(12) NOT NULL DEFAULT 'android',
			app_version VARCHAR(20) NOT NULL DEFAULT '',
			enabled TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			last_seen DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY token (token(160)),
			KEY user_id (user_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$daily} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			audience VARCHAR(20) NOT NULL DEFAULT 'general',
			week SMALLINT NULL,
			month TINYINT NULL,
			phase VARCHAR(20) NULL,
			day_index TINYINT NOT NULL DEFAULT 0,
			title VARCHAR(191) NOT NULL DEFAULT '',
			body TEXT NULL,
			action VARCHAR(191) NOT NULL DEFAULT '',
			source_name VARCHAR(120) NOT NULL DEFAULT '',
			source_url VARCHAR(255) NOT NULL DEFAULT '',
			active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY group_key (audience, week, month, phase),
			KEY active (active)
		) {$charset};";

		/* ---------------------------------------------------------- 2.0.0 tables */

		$ccat   = self::table( 'community_categories' );
		$cthr   = self::table( 'community_threads' );
		$ccom   = self::table( 'community_comments' );
		$creact = self::table( 'community_reactions' );
		$crep   = self::table( 'community_reports' );
		$ccodes = self::table( 'companion_codes' );
		$cviews = self::table( 'companion_views' );
		$storep = self::table( 'store_purchases' );
		$audit  = self::table( 'audit_log' );

		$queries[] = "CREATE TABLE {$ccat} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			slug VARCHAR(60) NOT NULL,
			title VARCHAR(191) NOT NULL DEFAULT '',
			description TEXT NULL,
			icon VARCHAR(40) NOT NULL DEFAULT '',
			color VARCHAR(20) NOT NULL DEFAULT '',
			sort_order INT NOT NULL DEFAULT 0,
			is_active TINYINT(1) NOT NULL DEFAULT 1,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY slug (slug),
			KEY is_active (is_active)
		) {$charset};";

		$queries[] = "CREATE TABLE {$cthr} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			category_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL,
			title VARCHAR(191) NOT NULL DEFAULT '',
			body LONGTEXT NULL,
			image_id BIGINT UNSIGNED NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'pending',
			is_pinned TINYINT(1) NOT NULL DEFAULT 0,
			is_featured TINYINT(1) NOT NULL DEFAULT 0,
			likes INT NOT NULL DEFAULT 0,
			comment_count INT NOT NULL DEFAULT 0,
			views INT NOT NULL DEFAULT 0,
			anchor VARCHAR(20) NOT NULL DEFAULT 'general',
			created_at DATETIME NOT NULL,
			updated_at DATETIME NULL,
			last_activity_at DATETIME NULL,
			PRIMARY KEY  (id),
			KEY category_id (category_id),
			KEY user_id (user_id),
			KEY status_created (status, created_at),
			KEY last_activity_at (last_activity_at),
			KEY anchor (anchor)
		) {$charset};";

		$queries[] = "CREATE TABLE {$ccom} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			thread_id BIGINT UNSIGNED NOT NULL,
			user_id BIGINT UNSIGNED NOT NULL,
			parent_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			body LONGTEXT NULL,
			likes INT NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'publish',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY thread_id (thread_id),
			KEY user_id (user_id),
			KEY status_created (status, created_at)
		) {$charset};";

		$queries[] = "CREATE TABLE {$creact} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			object_type VARCHAR(20) NOT NULL DEFAULT 'thread',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			type VARCHAR(20) NOT NULL DEFAULT 'like',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY once_per_user (object_type(20), object_id, user_id, type(20)),
			KEY object_id (object_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$crep} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			object_type VARCHAR(20) NOT NULL DEFAULT 'thread',
			object_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			reason VARCHAR(191) NOT NULL DEFAULT '',
			status VARCHAR(20) NOT NULL DEFAULT 'open',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY status_created (status, created_at),
			KEY object_id (object_id)
		) {$charset};";

		$queries[] = "CREATE TABLE {$ccodes} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			owner_id BIGINT UNSIGNED NOT NULL,
			code VARCHAR(24) NOT NULL,
			companion_name VARCHAR(191) NOT NULL DEFAULT '',
			companion_phone VARCHAR(40) NOT NULL DEFAULT '',
			phone_verified TINYINT(1) NOT NULL DEFAULT 0,
			scopes TEXT NULL,
			status VARCHAR(20) NOT NULL DEFAULT 'active',
			token_secret VARCHAR(64) NOT NULL DEFAULT '',
			otp_hash VARCHAR(191) NULL,
			otp_expires DATETIME NULL,
			views INT NOT NULL DEFAULT 0,
			last_view DATETIME NULL,
			created_at DATETIME NOT NULL,
			expires_at DATETIME NULL,
			revoked_at DATETIME NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY code (code),
			KEY owner_id (owner_id),
			KEY status (status)
		) {$charset};";

		$queries[] = "CREATE TABLE {$cviews} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			code_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			owner_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			scope VARCHAR(40) NOT NULL DEFAULT '',
			ip_hash VARCHAR(64) NOT NULL DEFAULT '',
			user_agent VARCHAR(191) NOT NULL DEFAULT '',
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY code_id (code_id),
			KEY owner_id (owner_id),
			KEY created_at (created_at)
		) {$charset};";

		$queries[] = "CREATE TABLE {$storep} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			store VARCHAR(20) NOT NULL DEFAULT '',
			sku VARCHAR(120) NOT NULL DEFAULT '',
			purchase_token VARCHAR(191) NOT NULL DEFAULT '',
			grant_type VARCHAR(20) NOT NULL DEFAULT 'credit',
			grant_value VARCHAR(60) NOT NULL DEFAULT '',
			amount DECIMAL(12,2) NOT NULL DEFAULT 0,
			status VARCHAR(20) NOT NULL DEFAULT 'granted',
			granted_at DATETIME NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			UNIQUE KEY store_token (store(20), purchase_token(120)),
			KEY user_id (user_id),
			KEY status (status)
		) {$charset};";

		$queries[] = "CREATE TABLE {$audit} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			admin_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			target_user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
			action VARCHAR(60) NOT NULL DEFAULT '',
			ref VARCHAR(191) NOT NULL DEFAULT '',
			meta LONGTEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY  (id),
			KEY admin_id (admin_id),
			KEY target_user_id (target_user_id),
			KEY action_created (action, created_at)
		) {$charset};";

		foreach ( $queries as $query ) {
			dbDelta( $query );
		}

		update_option( 'dr_niva_db_version', self::VERSION );
		// A schema change invalidates the self-heal cache so the new tables are
		// verified (and created) on the very next request, not an hour later.
		delete_transient( 'dr_niva_tables_ok' );
	}

	/**
	 * Runs the schema installer once per stored version bump.
	 *
	 * Called from the plugin bootstrap; cheap when nothing changed because it
	 * only compares one option.
	 */
	public static function maybe_upgrade() : void {
		if ( get_option( 'dr_niva_db_version' ) === self::VERSION ) {
			return;
		}
		self::install();
		self::ensure_tables();
	}

	/** Drops everything — only called from uninstall.php when the admin opted in. */
	public static function drop_all() : void {
		global $wpdb;
		foreach ( self::tables() as $name ) {
			$table = self::table( $name );
			$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore
		}
		delete_option( 'dr_niva_db_version' );
	}
}
