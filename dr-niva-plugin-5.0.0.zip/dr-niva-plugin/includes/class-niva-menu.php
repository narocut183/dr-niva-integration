<?php
/**
 * Header menu builder (2.0.0).
 *
 * Why this exists: WordPress's WXR importer refuses to import nav menu items
 * unless the menu already exists as a `nav_menu` term, and on some installs it
 * reports "invalid menu slug" and silently skips every item. Rather than depend
 * on that, the plugin builds the menu itself — deterministically, on activation
 * and from an admin button — and stays idempotent so running it twice is safe.
 *
 * It never deletes or reorders anything the site owner added by hand.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_Menu {

	public const SLUG = 'niva-main';
	public const NAME = 'منوی اصلی دکتر نیوا';

	/**
	 * Five top-level destinations plus their children, matching the product spec.
	 *
	 * `page_key` is the idempotent key written on each page by the importer
	 * (`_dr_niva_page_key`); `slug` is the fallback when that meta is missing.
	 *
	 * @return array<int,array<string,string>>
	 */
	public static function structure() : array {
		return array(
			array( 'key' => 'home', 'slug' => 'home', 'title' => 'خانه', 'parent' => '', 'icon' => 'home' ),
			array( 'key' => 'cycle', 'slug' => 'cycle', 'title' => 'سیکل', 'parent' => '', 'icon' => 'droplet' ),
			array( 'key' => 'tools', 'slug' => 'tools', 'title' => 'کلینیک', 'parent' => '', 'icon' => 'stethoscope' ),
			array( 'key' => 'community', 'slug' => 'community', 'title' => 'گفتگو', 'parent' => '', 'icon' => 'message-circle' ),
			array( 'key' => 'profile', 'slug' => 'profile', 'title' => 'پروفایل من', 'parent' => '', 'icon' => 'user' ),
			// children
			array( 'key' => 'pregnancy', 'slug' => 'pregnancy', 'title' => 'بارداری', 'parent' => 'cycle', 'icon' => 'baby' ),
			array( 'key' => 'baby', 'slug' => 'baby', 'title' => 'کودک', 'parent' => 'cycle', 'icon' => 'smile' ),
			array( 'key' => 'analyze', 'slug' => 'analyze', 'title' => 'تحلیل آزمایش', 'parent' => 'tools', 'icon' => 'chart-line' ),
			array( 'key' => 'reminders', 'slug' => 'reminders', 'title' => 'یادآورها', 'parent' => 'tools', 'icon' => 'clock' ),
			array( 'key' => 'advisor', 'slug' => 'advisor', 'title' => 'مشاور هوشمند', 'parent' => 'tools', 'icon' => 'sparkles' ),
			array( 'key' => 'mind', 'slug' => 'mind', 'title' => 'حال روان', 'parent' => 'tools', 'icon' => 'heart' ),
			array( 'key' => 'community_new', 'slug' => 'community-new', 'title' => 'پرسش تازه', 'parent' => 'community', 'icon' => 'message-plus' ),
			array( 'key' => 'onboarding', 'slug' => 'profile-completion', 'title' => 'تکمیل پروفایل', 'parent' => 'profile', 'icon' => 'check-circle' ),
			array( 'key' => 'wallet', 'slug' => 'wallet', 'title' => 'کیف پول', 'parent' => 'profile', 'icon' => 'wallet' ),
			array( 'key' => 'plans', 'slug' => 'plans', 'title' => 'اشتراک‌ها', 'parent' => 'profile', 'icon' => 'crown' ),
			array( 'key' => 'companion_create', 'slug' => 'companion', 'title' => 'کد همراهی', 'parent' => 'profile', 'icon' => 'heart-handshake' ),
			array( 'key' => 'notifications', 'slug' => 'notifications', 'title' => 'اعلان‌ها', 'parent' => 'profile', 'icon' => 'bell' ),
			array( 'key' => 'visibility', 'slug' => 'why-not-visible', 'title' => 'چرا نمی‌بینم؟', 'parent' => 'profile', 'icon' => 'eye-off' ),
			array( 'key' => 'about', 'slug' => 'about', 'title' => 'درباره', 'parent' => 'profile', 'icon' => 'info' ),
		);
	}

	/** Finds the page for one entry, by idempotent key first, then by slug. */
	private static function find_page( array $entry ) : int {
		$posts = get_posts(
			array(
				'post_type'        => 'page',
				'post_status'      => 'publish',
				'numberposts'      => 1,
				'fields'           => 'ids',
				'meta_key'         => '_dr_niva_page_key', // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => $entry['key'],      // phpcs:ignore WordPress.DB.SlowDBQuery
				'suppress_filters' => false,
			)
		);
		if ( $posts ) {
			return (int) $posts[0];
		}
		$page = get_page_by_path( $entry['slug'] );
		return $page ? (int) $page->ID : 0;
	}

	private static function find_menu() : int {
		$menu = wp_get_nav_menu_object( self::SLUG );
		if ( $menu ) {
			return (int) $menu->term_id;
		}
		$menu = wp_get_nav_menu_object( self::NAME );
		return $menu ? (int) $menu->term_id : 0;
	}

	/**
	 * Creates the menu, adds any missing items and returns a short report.
	 *
	 * @return array{menu_id:int,created:int,reused:int,skipped:string[]}
	 */
	public static function ensure() : array {
		$report = array( 'menu_id' => 0, 'created' => 0, 'reused' => 0, 'skipped' => array() );

		$menu_id = self::find_menu();
		if ( ! $menu_id ) {
			$menu_id = (int) wp_create_nav_menu( self::NAME );
			if ( $menu_id && self::SLUG !== '' ) {
				// Keep the slug predictable so repeated runs find the same menu.
				wp_update_term( $menu_id, 'nav_menu', array( 'slug' => self::SLUG ) );
			}
		}
		if ( ! $menu_id ) {
			$report['skipped'][] = 'ساخت فهرست ناموفق بود';
			return $report;
		}
		$report['menu_id'] = $menu_id;

		$existing = wp_get_nav_menu_items( $menu_id, array( 'post_status' => 'any' ) );
		$by_object = array();
		foreach ( (array) $existing as $item ) {
			$by_object[ (int) $item->object_id ] = (int) $item->ID;
		}

		$parent_ids = array();
		foreach ( self::structure() as $entry ) {
			$page_id = self::find_page( $entry );
			if ( ! $page_id ) {
				$report['skipped'][] = $entry['title'] . ' (برگه پیدا نشد: ' . $entry['slug'] . ')';
				continue;
			}

			if ( isset( $by_object[ $page_id ] ) ) {
				$item_id                = $by_object[ $page_id ];
				$report['reused']++;
			} else {
				$item_id = wp_update_nav_menu_item(
					$menu_id,
					0,
					array(
						'menu-item-title'     => $entry['title'],
						'menu-item-object'    => 'page',
						'menu-item-object-id' => $page_id,
						'menu-item-type'      => 'post_type',
						'menu-item-status'    => 'publish',
						'menu-item-parent-id' => '' !== $entry['parent'] && isset( $parent_ids[ $entry['parent'] ] ) ? $parent_ids[ $entry['parent'] ] : 0,
					)
				);
				if ( is_wp_error( $item_id ) || ! $item_id ) {
					$report['skipped'][] = $entry['title'] . ' (افزودن ناموفق)';
					continue;
				}
				$report['created']++;
			}

			// Icon meta is what the theme/app reads to draw the menu.
			update_post_meta( (int) $item_id, '_dr_niva_menu_icon', $entry['icon'] );

			if ( '' === $entry['parent'] ) {
				$parent_ids[ $entry['key'] ] = (int) $item_id;
			} else {
				$parent_ids[ $entry['key'] ] = (int) $item_id;
				// Children added later in the loop already point at their parent;
				// a child that appears before its parent is re-pointed here.
				$parent_key = $entry['parent'];
				if ( isset( $parent_ids[ $parent_key ] ) ) {
					wp_update_post(
						array(
							'ID'          => (int) $item_id,
							'post_parent' => (int) $parent_ids[ $parent_key ],
						)
					);
				}
			}
		}

		/*
		 * The "already built" flag is only set when nothing was missing. That way
		 * the automatic run retries after the pages are imported, instead of
		 * giving up on its first (too early) attempt.
		 */
		if ( empty( $report['skipped'] ) ) {
			update_option( 'dr_niva_menu_built', current_time( 'mysql' ), false );
		}
		return $report;
	}

	/** Human summary used by the admin button's notice. */
	public static function summary( array $report ) : string {
		$parts = array();
		if ( $report['created'] > 0 ) {
			$parts[] = $report['created'] . ' آیتم تازه اضافه شد';
		}
		if ( $report['reused'] > 0 ) {
			$parts[] = $report['reused'] . ' آیتم از قبل بود';
		}
		if ( ! empty( $report['skipped'] ) ) {
			$parts[] = 'رد شد: ' . implode( '، ', array_slice( $report['skipped'], 0, 5 ) );
		}
		if ( ! $parts ) {
			$parts[] = 'چیزی برای افزودن نبود';
		}
		return implode( ' · ', $parts );
	}
}
