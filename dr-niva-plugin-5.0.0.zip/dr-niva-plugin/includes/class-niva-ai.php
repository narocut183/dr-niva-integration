<?php
/**
 * AI provider layer.
 *
 * All providers are called server side; keys never reach the browser.
 * GapGPT's API uses the OpenAI-compatible chat-completions request format.
 *
 * @package DrAva
 */

defined( 'ABSPATH' ) || exit;

class Niva_AI {

	/** Provider catalogue. */
	public function providers() : array {
		$settings = dr_niva()->settings;
		return array(
			'gapgpt' => array(
				'label'     => 'GapGPT',
				'style'     => 'openai',
				'base'      => 'https://api.gapgpt.app/v1',
				'key'       => (string) $settings->get( 'ai_key_gapgpt' ),
				'model'     => $this->configured_model( 'ai_model_chat' ),
				'vision'    => true,
			),
		);
	}

	/** The server-side GapGPT connection exposed to the app when configured. */
	public function available() : array {
		$provider = $this->providers()['gapgpt'];
		if ( '' === trim( (string) $provider['key'] ) ) {
			return array();
		}
		return array(
			'gapgpt' => array(
				'id'    => 'gapgpt',
				'label' => 'GapGPT',
			),
		);
	}

	/** Providers configured for server-side features (vision, summaries). */
	public function configured_vision() : ?string {
		$providers = $this->providers();
		return ! empty( $providers['gapgpt']['key'] ) ? 'gapgpt' : null;
	}

	/**
	 * Sends a chat completion.
	 *
	 * @param array $messages [ ['role' => 'user|assistant|system', 'content' => '...'] ]
	 * @param array $opts     provider, model, temperature, max_tokens, system
	 * @return array|WP_Error { text, provider, model, tokens_in, tokens_out }
	 */
	public function chat( array $messages, array $opts = array() ) {
		$providers = $this->providers();
		$provider  = $providers['gapgpt'];
		if ( '' === trim( (string) $provider['key'] ) ) {
			return new WP_Error( 'niva_ai_missing_key', 'کلید API گپ‌جی‌پی‌تی را در تنظیمات وارد و ذخیره کن.' );
		}

		$provider_opts            = $opts;
		$provider_opts['provider'] = 'gapgpt';
		$provider_opts['model']    = isset( $opts['model'] ) && '' !== trim( (string) $opts['model'] )
			? sanitize_text_field( (string) $opts['model'] )
			: $provider['model'];
		$result = $this->call_openai_compatible( $provider, $messages, $provider_opts );
		if ( is_wp_error( $result ) ) {
			$this->log( 'GapGPT request failed', array( 'code' => $result->get_error_code() ) );
		}
		return $result;
	}

	/** Routes one call to the right protocol. */
	private function dispatch( string $id, array $provider, array $messages, array $opts ) {
		switch ( $provider['style'] ) {
			case 'gemini':
				return $this->call_gemini( $provider, $messages, $opts );
			case 'claude':
				return $this->call_claude( $provider, $messages, $opts );
			case 'local':
				return $this->call_local( $messages, $opts );
			default:
				return $this->call_openai_compatible( $provider, $messages, $opts );
		}
	}

	private function call_openai_compatible( array $provider, array $messages, array $opts ) {
		$base = untrailingslashit( (string) $provider['base'] );
		if ( '' === $base ) {
			return new WP_Error( 'niva_ai_no_base', 'آدرس پایه‌ی این موتور تنظیم نشده است.' );
		}
		$body = array(
			'model'       => $opts['model'] ?? $provider['model'],
			'messages'    => $messages,
			'temperature' => (float) ( $opts['temperature'] ?? dr_niva()->settings->get( 'ai_temperature' ) ),
			'max_tokens'  => (int) ( $opts['max_tokens'] ?? dr_niva()->settings->get( 'ai_max_tokens' ) ),
		);

		$response = wp_remote_post(
			$base . '/chat/completions',
			array(
				'timeout' => (int) dr_niva()->settings->get( 'timeout_seconds' ),
				'headers' => array(
					'Authorization' => 'Bearer ' . $provider['key'],
					'Content-Type'  => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);
		return $this->parse_openai_like( $response, $provider, $body['model'], $opts );
	}

	private function call_gemini( array $provider, array $messages, array $opts ) {
		$system   = '';
		$contents = array();
		foreach ( $messages as $message ) {
			if ( 'system' === $message['role'] ) {
				$system .= $message['content'] . "\n";
				continue;
			}
			$contents[] = array(
				'role'  => 'assistant' === $message['role'] ? 'model' : 'user',
				'parts' => array( array( 'text' => (string) $message['content'] ) ),
			);
		}
		$model = $opts['model'] ?? $provider['model'];
		$body  = array(
			'contents'          => $contents,
			'generationConfig'  => array(
				'temperature'     => (float) ( $opts['temperature'] ?? dr_niva()->settings->get( 'ai_temperature' ) ),
				'maxOutputTokens' => (int) ( $opts['max_tokens'] ?? dr_niva()->settings->get( 'ai_max_tokens' ) ),
			),
		);
		if ( '' !== trim( $system ) ) {
			$body['systemInstruction'] = array( 'parts' => array( array( 'text' => $system ) ) );
		}

		$response = wp_remote_post(
			untrailingslashit( $provider['base'] ) . '/models/' . rawurlencode( $model ) . ':generateContent?key=' . rawurlencode( $provider['key'] ),
			array(
				'timeout' => (int) dr_niva()->settings->get( 'timeout_seconds' ),
				'headers' => array( 'Content-Type' => 'application/json' ),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code > 299 ) {
			return new WP_Error( 'niva_ai_http', 'پاسخ ناموفق از Gemini (کد ' . $code . ')' );
		}
		$text = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';
		if ( '' === trim( (string) $text ) ) {
			return new WP_Error( 'niva_ai_empty', 'پاسخ خالی از Gemini' );
		}
		return array(
			'text'        => (string) $text,
			'provider'    => 'gemini',
			'model'       => $model,
			'tokens_in'   => (int) ( $json['usageMetadata']['promptTokenCount'] ?? 0 ),
			'tokens_out'  => (int) ( $json['usageMetadata']['candidatesTokenCount'] ?? 0 ),
		);
	}

	private function call_claude( array $provider, array $messages, array $opts ) {
		$system   = '';
		$payload  = array();
		foreach ( $messages as $message ) {
			if ( 'system' === $message['role'] ) {
				$system .= $message['content'] . "\n";
				continue;
			}
			$payload[] = array(
				'role'    => 'assistant' === $message['role'] ? 'assistant' : 'user',
				'content' => is_array( $message['content'] ) ? $message['content'] : (string) $message['content'],
			);
		}
		$model = $opts['model'] ?? $provider['model'];
		$body  = array(
			'model'       => $model,
			'max_tokens'  => (int) ( $opts['max_tokens'] ?? dr_niva()->settings->get( 'ai_max_tokens' ) ),
			'messages'    => $payload,
			'temperature' => (float) ( $opts['temperature'] ?? dr_niva()->settings->get( 'ai_temperature' ) ),
		);
		if ( '' !== trim( $system ) ) {
			$body['system'] = $system;
		}
		$response = wp_remote_post(
			untrailingslashit( $provider['base'] ) . '/messages',
			array(
				'timeout' => (int) dr_niva()->settings->get( 'timeout_seconds' ),
				'headers' => array(
					'x-api-key'         => $provider['key'],
					'anthropic-version' => '2023-06-01',
					'Content-Type'      => 'application/json',
				),
				'body'    => wp_json_encode( $body ),
			)
		);
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code > 299 ) {
			return new WP_Error( 'niva_ai_http', 'پاسخ ناموفق از Claude (کد ' . $code . ')' );
		}
		$text = $json['content'][0]['text'] ?? '';
		if ( '' === trim( (string) $text ) ) {
			return new WP_Error( 'niva_ai_empty', 'پاسخ خالی از Claude' );
		}
		return array(
			'text'       => (string) $text,
			'provider'   => 'claude',
			'model'      => $model,
			'tokens_in'  => (int) ( $json['usage']['input_tokens'] ?? 0 ),
			'tokens_out' => (int) ( $json['usage']['output_tokens'] ?? 0 ),
		);
	}

	/** The offline engine: works with no key, no network, no cost. */
	private function call_local( array $messages, array $opts ) {
		$question = '';
		foreach ( array_reverse( $messages ) as $message ) {
			if ( 'user' === $message['role'] ) {
				$question = (string) $message['content'];
				break;
			}
		}
		$topic = isset( $opts['topic'] ) ? (string) $opts['topic'] : 'general';
		$text  = $this->local_reply( $topic, $question, $opts );
		return array(
			'text'       => $text,
			'provider'   => 'local',
			'model'      => 'niva-local',
			'tokens_in'  => 0,
			'tokens_out' => 0,
		);
	}

	/** Topic aware canned answers — keeps the product usable offline. */
	public function local_reply( string $topic, string $question, array $opts = array() ) : string {
		$map = array(
			'depression' => array(
				array( array( 'خواب', 'بی‌خوابی' ), 'برای خواب سه کار ساده کمک می‌کند: ساعت خواب و بیداری ثابت، کم‌کردن نور صفحه در ساعت آخر، و نوشتن فکرها روی کاغذ پیش از خواب. اگر بی‌خوابی بیشتر از دو هفته ماند، با پزشک درباره‌اش حرف بزن.' ),
				array( array( 'روان‌شناس', 'مراجعه', 'پزشک' ), 'اگر بیشتر روزهای دو هفته‌ی گذشته حالت پایین بود، از کارهای روزمره لذت نمی‌بری یا فکر آسیب به خودت داشتی، وقت مراجعه است. این نشانه‌ی ضعف نیست؛ یک قدم عملی است.' ),
				array( array( 'تمرین', 'قدم' ), 'یک قدم کوچک برای امروز: ده دقیقه پیاده‌روی، نوشتن سه جمله‌ی سپاسگزاری، یا تماس با یک نفر که راحت با او حرف می‌زنی.' ),
			),
			'family' => array(
				array( array( 'دعوا', 'حرف', 'گفت‌وگو' ), 'با «من» شروع کن نه «تو»: «وقتی این‌طور می‌شود، خسته می‌شوم» خیلی کمتر از «تو هیچ‌وقت توجه نمی‌کنی» جبهه می‌سازد. گفت‌وگو را در زمان آرام بگذار، نه در میانه‌ی دعوا.' ),
				array( array( 'مرز', 'نه گفتن' ), 'مرز یعنی تصمیم بگیری کدام کارها وظیفه‌ی توست. یک جمله‌ی آماده بساز: «این را نمی‌توانم قبول کنم، ولی می‌توانم این کار را بکنم.»' ),
				array( array( 'خسته', 'تنهایی' ), 'اول فهرست کن چه کارهایی را می‌توانی واگذار کنی، بعد یک کار مشخص را به یک نفر مشخص بسپار — درخواست کلی معمولاً بی‌پاسخ می‌ماند.' ),
			),
			'marriage' => array(
				array( array( 'نیاز', 'حرف' ), 'به جای «تو نمی‌فهمی»، خواسته‌ی روشن بگو: «اگر شب‌ها ده دقیقه بدون موبایل با هم حرف بزنیم، حالم بهتر می‌شود.»' ),
				array( array( 'دعوا', 'بحث' ), 'قاعده‌ی توقف: وقتی ضربان بالا رفت، بیست دقیقه گفت‌وگو را کنار بگذارید و بعد ادامه بدهید.' ),
				array( array( 'صمیمیت', 'فاصله' ), 'صمیمیت از کارهای کوچک روزانه برمی‌گردد، نه از یک گفت‌وگوی بزرگ. اگر فاصله طولانی شده، مشاور زوج‌درمانگر راه را کوتاه می‌کند.' ),
			),
			'pregnancy' => array(
				array( array( 'خونریزی', 'خطر', 'علائم' ), 'خونریزی از واژن، ترشح آبکی پیوسته، کاهش واضح حرکت جنین، سردرد شدید یا ورم ناگهانی صورت و دست‌ها را نباید صبر کرد؛ همین حالا با پزشک یا مامای خودت تماس بگیر.' ),
				array( array( 'خواب', 'پهلو' ), 'خواب به پهلوی چپ با بالش بین زانوها و یک بالش کوچک زیر شکم، کمردرد و سوزش را کم می‌کند.' ),
				array( array( 'آزمایش', 'تغذیه' ), 'کارهای هفته‌به‌هفته و آزمایش‌های مانده در صفحه‌ی «مسیر بارداری» همین سامانه فهرست شده است. برای مکمل‌ها و رژیم، الگوی خودت را با ماما یا پزشک چک کن.' ),
			),
			'nutrition' => array(
				array( array( 'وزن', 'لاغر', 'رژیم' ), 'به جای حذف یک گروه غذایی، سه چیز را ثابت کن: پروتئین در هر وعده، کربوهیدرات سبوس‌دار، و سبزیجات. برنامه‌ای که نتوانی ماه‌ها ادامه بدهی، نتیجه‌ی پایدار نمی‌دهد.' ),
				array( array( 'میان‌وعده', 'میوه', 'غذا' ), 'پیشنهاد ساده: ماست و گردو، سیب و کره‌ی بادام‌زمینی، یا نان سبوس‌دار و پنیر با خیار؛ برای میان‌وعده‌ی سبک، میوه‌های فصل و مغزها انتخاب های خوبی هستند.' ),
			),
			'anxiety' => array(
				array( array( 'تپش', 'نفس', 'تمرین' ), 'تنفس ۴-۷-۸: چهار ثانیه دم، هفت ثانیه نگه‌داشتن، هشت ثانیه بازدم؛ سه بار. همین تمرین با تایمر در صفحه‌ی «حال من» آماده است.' ),
				array( array( 'نگرانی', 'فکر' ), 'برای نگرانی یک زمان مشخص بگذار (مثلاً ۱۵ دقیقه عصر). در طول روز فکر را یادداشت کن و به خودت بگو «عصر بررسی می‌کنم».' ),
			),
			'sleep' => array(
				array( array( 'روتین', 'شب' ), 'یک ساعت پیش از خواب: نور کم، کار ذهنی سنگین نه، و یک کار آرام تکراری. بدن با تکرار همین الگو شرط می‌گیرد.' ),
				array( array( 'بیدار', 'نیمه' ), 'اگر بیست دقیقه در تخت بیدار ماندی، بیرون بیا و در نور کم کاری آرام بکن تا خواب‌آلود شوی؛ در تخت نمان که با اضطراب شرط بگیرد.' ),
			),
			'parenting' => array(
				array( array( 'لجبازی', 'گوش' ), 'اول احساس کودک را نام‌گذاری کن («می‌دانم ناراحتی») و بعد مرز را کوتاه بگو. قاعده‌ی دو گزینه‌ای هم خوب کار می‌کند: «الان بخوابی یا بعد از یک قصه؟»' ),
				array( array( 'تنبیه', 'تشویق' ), 'پیامد منطقی روشن و تشویق فوری مشخص، بیشتر از تنبیه شدید رفتار را شکل می‌دهد.' ),
			),
			'general' => array(),
		);

		$replies = $map[ $topic ] ?? array();
		foreach ( $replies as $rule ) {
			foreach ( $rule[0] as $needle ) {
				if ( false !== mb_strpos( $question, $needle ) ) {
					return $rule[1];
				}
			}
		}

		$fallbacks = array(
			'بگو بیشتر چه چیزی برایت سنگین است و کدام قسمت را می‌خواهی همین حالا با هم باز کنیم؟',
			'می‌توانی کمی بیشتر توضیح بدهی؟ هر چه دقیق‌تر بگویی، قدم عملی‌تری می‌توانم پیشنهاد بدم.',
			'متوجه شدم. اگر بخواهی، از یک کار کوچک برای امروز شروع کنیم.',
		);
		return $fallbacks[ array_rand( $fallbacks ) ];
	}

	/** Shared parser for OpenAI-style responses. */
	private function parse_openai_like( $response, array $provider, string $model, array $opts ) {
		if ( is_wp_error( $response ) ) {
			return $response;
		}
		$code = (int) wp_remote_retrieve_response_code( $response );
		$json = json_decode( wp_remote_retrieve_body( $response ), true );
		if ( $code < 200 || $code > 299 ) {
			$message = (string) ( $json['error']['message'] ?? ( 'کد ' . $code ) );
			if ( '' !== (string) ( $provider['key'] ?? '' ) ) {
				$message = str_replace( (string) $provider['key'], '[کلید پنهان شد]', $message );
			}
			return new WP_Error( 'niva_ai_http', 'پاسخ ناموفق از ' . $provider['label'] . ': ' . $message );
		}
		$text = $json['choices'][0]['message']['content'] ?? '';
		if ( is_array( $text ) ) {
			$text = wp_json_encode( $text );
		}
		if ( '' === trim( (string) $text ) ) {
			return new WP_Error( 'niva_ai_empty', 'پاسخ خالی از ' . $provider['label'] );
		}
		return array(
			'text'       => (string) $text,
			'provider'   => $opts['provider'] ?? $provider['label'],
			'model'      => $model,
			'tokens_in'  => (int) ( $json['usage']['prompt_tokens'] ?? 0 ),
			'tokens_out' => (int) ( $json['usage']['completion_tokens'] ?? 0 ),
		);
	}

	/**
	 * Reads a document image (lab report, ultrasound…) and returns structured JSON.
	 *
	 * @param string $image_url Public URL or data URI of the file.
	 * @param string $prompt    Extraction instruction.
	 * @return array|WP_Error
	 */
	public function read_document( string $image_url, string $prompt ) {
		$provider_id = $this->configured_vision();
		if ( ! $provider_id ) {
			return new WP_Error( 'niva_vision_unavailable', 'برای خواندن تصویر، کلید API گپ‌جی‌پی‌تی را در تنظیمات وارد کن.' );
		}
		$provider = $this->providers()[ $provider_id ];
		$model    = $this->configured_model( 'ai_model_vision' );
		$inline   = array();
		if ( preg_match( '#^data:(image/(?:jpeg|png|webp));base64,([A-Za-z0-9+/=]+)$#', $image_url, $match ) ) {
			$inline = array( 'mime' => $match[1], 'data' => $match[2] );
		}

		if ( 'gemini' === $provider['style'] ) {
			$image_part = $inline
				? array( 'inline_data' => array( 'mime_type' => $inline['mime'], 'data' => $inline['data'] ) )
				: array( 'file_data' => array( 'file_uri' => $image_url ) );
			$body = array(
				'contents' => array(
					array(
						'role'  => 'user',
						'parts' => array(
							array( 'text' => $prompt ),
							$image_part,
						),
					),
				),
				'generationConfig' => array( 'temperature' => 0.1, 'maxOutputTokens' => 3000 ),
			);
			$response = wp_remote_post(
				untrailingslashit( $provider['base'] ) . '/models/' . rawurlencode( $provider['model'] ) . ':generateContent?key=' . rawurlencode( $provider['key'] ),
				array( 'timeout' => 90, 'headers' => array( 'Content-Type' => 'application/json' ), 'body' => wp_json_encode( $body ) )
			);
			if ( is_wp_error( $response ) ) {
				return $response;
			}
			$code = (int) wp_remote_retrieve_response_code( $response );
			$json = json_decode( wp_remote_retrieve_body( $response ), true );
			if ( $code < 200 || $code > 299 ) {
				return new WP_Error( 'niva_ai_http', 'پاسخ ناموفق از Gemini (کد ' . $code . ')' );
			}
			$text = $json['candidates'][0]['content']['parts'][0]['text'] ?? '';
		} elseif ( 'claude' === $provider['style'] ) {
			if ( ! $inline ) {
				return new WP_Error( 'niva_vision_format', 'برای خواندن تصویر با Claude باید تصویر به‌صورت امن بارگذاری شود.' );
			}
			$messages = array(
				array(
					'role'    => 'user',
					'content' => array(
						array( 'type' => 'text', 'text' => $prompt ),
						array(
							'type'   => 'image',
							'source' => array(
								'type'       => 'base64',
								'media_type' => $inline['mime'],
								'data'       => $inline['data'],
							),
						),
					),
				),
			);
			$result = $this->chat( $messages, array( 'provider' => $provider_id, 'model' => $model, 'max_tokens' => 1500, 'temperature' => 0.1 ) );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$text = $result['text'];
		} else {
			$messages = array(
				array(
					'role'    => 'user',
					'content' => array(
						array( 'type' => 'text', 'text' => $prompt ),
						array( 'type' => 'image_url', 'image_url' => array( 'url' => $image_url ) ),
					),
				),
			);
			$result = $this->chat( $messages, array( 'provider' => $provider_id, 'model' => $model, 'max_tokens' => 1500, 'temperature' => 0.1 ) );
			if ( is_wp_error( $result ) ) {
				return $result;
			}
			$text = $result['text'];
		}

		$json_start = strpos( (string) $text, '{' );
		$json_end   = strrpos( (string) $text, '}' );
		if ( false === $json_start || false === $json_end ) {
			return new WP_Error( 'niva_vision_parse', 'خروجی خواندن تصویر ساختار JSON نداشت.' );
		}
		$decoded = json_decode( substr( (string) $text, $json_start, $json_end - $json_start + 1 ), true );
		if ( ! is_array( $decoded ) ) {
			return new WP_Error( 'niva_vision_parse', 'JSON خروجی خواندن تصویر معتبر نبود.' );
		}
		return array( 'data' => $decoded, 'provider' => $provider_id, 'model' => $model );
	}

	private function configured_model( string $setting ) : string {
		$model = trim( (string) dr_niva()->settings->get( $setting, '' ) );
		return '' !== $model ? $model : 'gpt-6-luna';
	}

	private function log( string $message, array $context = array() ) : void {
		if ( defined( 'WP_DEBUG' ) && WP_DEBUG ) {
			error_log( '[dr-niva] ' . $message . ' ' . wp_json_encode( $context ) ); // phpcs:ignore
		}
	}
}
